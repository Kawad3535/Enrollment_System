ASCB REGISTRAR — FLEXIBLE ADMIN STAFF ASSIGNMENTS
================================================

WHAT'S INCLUDED
- staff_assignments.php: assignment management UI for authorized UNIT HEADs.
- api/staff_assignments.php: authenticated, CSRF-protected assignment API.
- database/migrate_master.php: the single idempotent migration (includes the staff assignment tables).
- Staff Accounts table now has an Assign button for ADMIN STAFF accounts.

INSTALL (XAMPP)
1. Back up the ASCB database before changing schema.
2. Extract the package into your existing ASCB project folder (merge/replace files after reviewing your own custom changes).
3. Open Command Prompt in the project root, e.g. C:\xampp\htdocs\ascb.registrar.
4. Run:
   C:\xampp\php\php.exe database\migrate_master.php
5. Log in as UNIT HEAD, open Staff Accounts, then click Assign beside an ADMIN STAFF account.
6. Assign one or more departments. For each department, choose at least one program OR explicitly check “Allow all current and future programs”. Save.

MIGRATION SAFETY
- The migration uses CREATE TABLE IF NOT EXISTS and INSERT IGNORE.
- Existing ADMIN STAFF department_id assignments are preserved as explicit all-program assignments, matching the previous department-wide scope.
- It does not delete users, student records, enrollments, grades, or departments.
- Back up the database first, as with any production migration.

IMPORTANT SCOPE NOTE
GRADE MANAGEMENT INTEGRATION
- Grade Management (api/grades.php) now limits ADMIN STAFF student rows to active department/program assignments. The paginated total and student list use the same scope, so assigned programs appear and unrelated programs are excluded.
- Subject Gradebook (api/professor_gradebook.php) uses the same assignment scope when listing subjects, students, and course options.
- ADMIN STAFF grade submission checks the assigned program scope and uses the enrollment department for its approval submission, so staff no longer need a single legacy users.department_id value to work across multiple assigned departments.
- Grade Evaluation remains the existing cross-department read-only report; it is not changed by this Grade Management filter.

SCOPE / DEPLOYMENT NOTE
The changes cover Grade Management and Subject Gradebook only. Other Registrar modules and exports may still use legacy department_id-based access checks and must be reviewed separately before claiming course-level restrictions across the entire application. Test in a staging copy before production use.

DEAN ASSIGNMENTS (Grade Management + Grade Evaluation)
- The Assign button in Staff Accounts now also appears for DEAN accounts (UNIT HEAD only).
- A Dean with one or more active assignments sees ONLY those departments/programs in Grade Evaluation and Grade Management (server-side filter in api/grades.php, includes/departments.php).
- A Dean with NO assignment yet keeps the old behavior: only the single Department set in Edit Account.
- Hide/Unhide Grades (Grade Evaluation) follows the same assignment scope for DEAN and ADMIN STAFF.
- Other modules (Enrollment list, Student 360, Honors, Dashboard stats, exports) still use the Dean's single Department from Edit Account.
- Re-run database/migrate_master.php to seed existing Deans' department as an assignment (idempotent).
