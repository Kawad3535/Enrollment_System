<?php /* V6 Enterprise hardening applied: pagination-ready, bounded responses, secure errors. */ ?>
<?php
/* =========================================================
   API: APPROVED SO
   ---------------------------------------------------------
   Bawat entry = pangalan + isang PDF file. Pwedeng i-add,
   i-update (palitan ang pangalan at/o ang PDF), at i-delete.

   GET  -> ibinabalik ang listahan ng mga Approved SO entries
           (pinaka-bago muna).

           Params: q (search text, optional)
                   Walang limit — palaging ibabalik lahat ng
                   tugma sa database.

   POST -> multipart/form-data (HINDI JSON, dahil may
           kasamang file upload). Ang "action" field ang
           nagsasabi kung create / update / delete:

           action=create : fields name, file (1 PDF, required)
           action=update : fields id, name, file (optional —
                            kung may bagong file, papalitan
                            ang luma)
           action=delete : field id
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../config/db.php';

/* (2024 audit fix) Dati, WALANG role check dito — kahit sinong naka-login
   (kasama ang DEAN) ay may access. Ang mga table na ito (Documents log,
   Approved SO, Course Files) ay general registrar-office records na
   walang Department-level na paghihiwalay sa schema, kaya sa halip na
   subukang mag-scope ng hindi maaasahang paraan, ang DEAN na lang (na
   read-only/scoped-to-own-department sa ibang modules) ang in-eexclude
   dito. Tingnan ang includes/permissions.php ('manage_office_records')
   kung kailangang baguhin ito. */
if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'manage_office_records')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'You do not have access to this module.'));
    exit;
}

$UPLOAD_DIR = __DIR__ . '/../uploads/approved_so/';
if (!is_dir($UPLOAD_DIR)) {
    @mkdir($UPLOAD_DIR, 0755, true);
}
if (!is_dir($UPLOAD_DIR) || !is_writable($UPLOAD_DIR)) {
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'The upload folder on the server is not writable. Please check the deployment folder permissions.'));
    exit;
}

$maxSizeBytes = ASCB_MAX_UPLOAD_MB * 1024 * 1024; // configurable; default 25 MB

$method = $_SERVER['REQUEST_METHOD'];


/* =========================================================
   Tulong na function: i-validate + i-save ang isang na-upload
   na PDF file. Ibinabalik ang array(original, stored, size)
   kung tagumpay, o direktang nagpapadala ng JSON error at
   nag-e-exit kung mayroong problema.
   ========================================================= */
function ascbSoHandleUpload($fieldName, $UPLOAD_DIR, $maxSizeBytes) {

    if (empty($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] === UPLOAD_ERR_NO_FILE) {
        return null; // walang na-upload na file
    }

    if ($_FILES[$fieldName]['error'] !== UPLOAD_ERR_OK) {
        $uploadErrCode = $_FILES[$fieldName]['error'];
        $uploadErrMsgs = array(
            UPLOAD_ERR_INI_SIZE   => 'Lumagpas sa upload_max_filesize ng server (php.ini). Kailangang taasan ito ng system admin.',
            UPLOAD_ERR_FORM_SIZE  => 'Lumagpas sa max file size na tinakda sa form.',
            UPLOAD_ERR_PARTIAL    => 'Hindi natapos ang pag-upload ng file (na-interrupt sa gitna, baka slow connection o na-timeout).',
            UPLOAD_ERR_NO_TMP_DIR => 'Walang temporary folder sa server para sa upload.',
            UPLOAD_ERR_CANT_WRITE => 'Hindi ma-isulat ang file sa disk ng server (baka permission issue).',
            UPLOAD_ERR_EXTENSION  => 'Hinarang ang upload ng isang PHP extension sa server.',
        );
        $uploadErrText = isset($uploadErrMsgs[$uploadErrCode])
            ? $uploadErrMsgs[$uploadErrCode]
            : 'Hindi kilalang error (code ' . $uploadErrCode . ').';

        http_response_code(400);
        echo json_encode(array(
            'ok'    => false,
            'error' => 'There was an error uploading the file (' . $_FILES[$fieldName]['name'] . '): ' . $uploadErrText,
        ));
        exit;
    }

    $tmpPath      = $_FILES[$fieldName]['tmp_name'];
    $originalName = $_FILES[$fieldName]['name'];
    $size         = $_FILES[$fieldName]['size'];

    if ($size > $maxSizeBytes) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => $originalName . ' is too large (max ' . ASCB_MAX_UPLOAD_MB . 'MB).'));
        exit;
    }

    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

    $mime = '';
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $mime = finfo_file($finfo, $tmpPath);
            finfo_close($finfo);
        }
    }

    if ($ext !== 'pdf' || ($mime !== '' && $mime !== 'application/pdf')) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => $originalName . ' ay hindi PDF file.'));
        exit;
    }

    $storedName  = 'so_' . ascb_random_token(16) . '.pdf';
    $destination = $UPLOAD_DIR . $storedName;

    if (!move_uploaded_file($tmpPath, $destination)) {
        http_response_code(500);
        echo json_encode(array('ok' => false, 'error' => 'Unable to save ' . $originalName . '.'));
        exit;
    }

    return array('original' => $originalName, 'stored' => $storedName, 'size' => (int) $size);
}



/* =========================================================
   PDF TEXT EXTRACTION
   ---------------------------------------------------------
   Prefer pdftotext when available (common on development
   machines). A pure-PHP fallback is included for Windows/XAMPP
   deployments so the feature does not require Composer or an
   external PHP package. Scanned/image-only PDFs: susubukan ang OCR
   (kung naka-install); kung wala pa ring pangalan, ise-save pa rin ang PDF
   gamit ang filename bilang pangalan.
   ========================================================= */
function ascbSoPdfDecodeLiteral($value) {
    $out = '';
    $len = strlen($value);
    for ($i = 0; $i < $len; $i++) {
        $c = $value[$i];
        if ($c !== '\\') { $out .= $c; continue; }
        $i++;
        if ($i >= $len) break;
        $e = $value[$i];
        $map = array('n'=>"\n", 'r'=>"\r", 't'=>"\t", 'b'=>"\x08", 'f'=>"\x0c", '\\'=>'\\', '('=>'(', ')'=>')');
        if (isset($map[$e])) { $out .= $map[$e]; continue; }
        if ($e >= '0' && $e <= '7') {
            $oct = $e;
            for ($j=0; $j<2 && ($i+1)<$len && $value[$i+1]>='0' && $value[$i+1]<='7'; $j++) { $i++; $oct .= $value[$i]; }
            $out .= chr(octdec($oct));
            continue;
        }
        $out .= $e;
    }
    return $out;
}

function ascbSoPdfDecodeHex($hex) {
    $hex = preg_replace('/\s+/', '', $hex);
    if ($hex === '') return '';
    if (strlen($hex) % 2) $hex .= '0';
    $bin = @hex2bin($hex);
    if ($bin === false) return '';
    /* UTF-16BE with BOM is common in PDF text. */
    if (substr($bin, 0, 2) === "\xFE\xFF" && function_exists('mb_convert_encoding')) {
        return mb_convert_encoding(substr($bin, 2), 'UTF-8', 'UTF-16BE');
    }
    return $bin;
}

function ascbSoPdfStreamText($stream) {
    $text = '';
    /* Parenthesized strings followed by Tj/TJ. */
    if (preg_match_all('/\((?:\\.|[^\\)])*\)\s*T[Jj]/s', $stream, $matches)) {
        foreach ($matches[0] as $m) {
            $pos = strrpos($m, ')');
            if ($pos !== false) {
                $raw = substr($m, 1, $pos - 1);
                $text .= ' ' . ascbSoPdfDecodeLiteral($raw);
            }
        }
    }
    /* Hex strings followed by Tj/TJ. */
    if (preg_match_all('/<([0-9A-Fa-f\s]+)>\s*T[Jj]/s', $stream, $matches)) {
        foreach ($matches[1] as $hex) $text .= ' ' . ascbSoPdfDecodeHex($hex);
    }
    /* Array TJ: collect all literal/hex strings inside arrays. */
    if (preg_match_all('/\[(.*?)\]\s*TJ/s', $stream, $arrays)) {
        foreach ($arrays[1] as $arr) {
            if (preg_match_all('/\((?:\\.|[^\\)])*\)|<([0-9A-Fa-f\s]+)>/', $arr, $parts)) {
                foreach ($parts[0] as $part) {
                    if ($part[0] === '(') $text .= ' ' . ascbSoPdfDecodeLiteral(substr($part, 1, -1));
                    else $text .= ' ' . ascbSoPdfDecodeHex(trim(substr($part, 1, -1)));
                }
            }
        }
    }
    return $text;
}

function ascbSoExtractPdfText($path) {
    /* Best available extractor if installed. */
    if (function_exists('shell_exec')) {
        $which = @shell_exec((stripos(PHP_OS, 'WIN') === 0 ? 'where pdftotext 2>NUL' : 'command -v pdftotext 2>/dev/null'));
        if (trim((string)$which) !== '') {
            $cmd = 'pdftotext -layout -enc UTF-8 ' . escapeshellarg($path) . ' - 2>/dev/null';
            $out = @shell_exec($cmd);
            if (is_string($out) && trim($out) !== '') return $out;
        }
    }

    /* Ang pure-PHP fallback ay para sa text-based PDF lang. Ang scanned
       PDF ay puro imahe (malaki ang file), at ang regex sa buong binary
       ay mabagal/nauubusan ng memory — kaya nilalaktawan ito kapag
       masyadong malaki. Sa ganitong kaso, OCR o filename ang gagamitin. */
    $pdfSize = @filesize($path);
    if ($pdfSize !== false && $pdfSize > 12 * 1024 * 1024) return '';
    $pdf = @file_get_contents($path);
    if ($pdf === false || $pdf === '') return '';
    $text = '';
    /* Decode FlateDecode streams. This covers most generated text PDFs. */
    if (preg_match_all('/<<(.*?)>>\s*stream\r?\n(.*?)\r?\nendstream/s', $pdf, $streams, PREG_SET_ORDER)) {
        foreach ($streams as $m) {
            $dict = $m[1];
            $data = $m[2];
            if (stripos($dict, '/FlateDecode') !== false) {
                $decoded = @gzuncompress($data);
                if ($decoded === false) $decoded = @gzinflate($data);
                if ($decoded !== false) $data = $decoded;
                else continue;
            }
            $text .= ' ' . ascbSoPdfStreamText($data);
        }
    }
    /* Also inspect uncompressed content/operators. */
    $text .= ' ' . ascbSoPdfStreamText($pdf);
    return $text;
}

/* =========================================================
   OPTIONAL OCR (para sa scanned / image-only PDF)
   ---------------------------------------------------------
   Gumagana lang kung naka-install sa server ang `pdftoppm`
   (poppler) at `tesseract`. Kung wala, tahimik itong nagbabalik
   ng '' at ang system ay gagamit na lang ng filename bilang
   pansamantalang pangalan — HINDI na nito hinaharangan ang
   pag-save ng PDF.

   Para sa Windows/XAMPP na wala sa PATH ang mga tool, i-set ang
   environment variable ASCB_TESSERACT_PATH at ASCB_PDFTOPPM_PATH
   (buong path ng .exe).
   ========================================================= */
function ascbSoFindBinary($name, $envKey) {
    $custom = function_exists('ascb_env') ? ascb_env($envKey, '') : '';
    if ($custom !== '' && @is_file($custom)) return $custom;
    if (!function_exists('shell_exec')) return '';
    $isWin = stripos(PHP_OS, 'WIN') === 0;
    $out = @shell_exec($isWin ? 'where ' . $name . ' 2>NUL' : 'command -v ' . $name . ' 2>/dev/null');
    $out = trim((string)$out);
    if ($out === '') return '';
    $lines = preg_split('/\r?\n/', $out);
    return trim($lines[0]);
}

function ascbSoOcrPdfText($path) {
    if (!function_exists('shell_exec')) return '';
    $pdftoppm  = ascbSoFindBinary('pdftoppm', 'ASCB_PDFTOPPM_PATH');
    $tesseract = ascbSoFindBinary('tesseract', 'ASCB_TESSERACT_PATH');
    if ($pdftoppm === '' || $tesseract === '') return '';

    @set_time_limit(60);
    $base = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'so_ocr_' . ascb_random_token(8);
    /* Unang 2 pages lang ang kailangan — nasa itaas ng SO ang pangalan. */
    @shell_exec(escapeshellarg($pdftoppm) . ' -r 200 -f 1 -l 2 -png ' . escapeshellarg($path) . ' ' . escapeshellarg($base) . ' 2>&1');
    $images = glob($base . '*.png');
    if (!$images) return '';
    sort($images);

    $text = '';
    foreach ($images as $img) {
        $out = @shell_exec(escapeshellarg($tesseract) . ' ' . escapeshellarg($img) . ' stdout --psm 6 2>&1');
        if (is_string($out)) $text .= "\n" . $out;
        @unlink($img);
    }
    return $text;
}

/* Pansamantalang pangalan mula sa filename kapag walang nakitang
   student name (hal. "juan_dela_cruz_SO.pdf" -> "juan dela cruz SO"). */
function ascbSoNameFromFilename($filename) {
    $base = pathinfo((string)$filename, PATHINFO_FILENAME);
    $base = trim(preg_replace('/[\s_]+/', ' ', str_replace(array('-', '.'), ' ', $base)));
    if ($base === '') $base = 'Unnamed Approved SO';
    if (function_exists('mb_substr')) $base = mb_substr($base, 0, 255, 'UTF-8');
    else $base = substr($base, 0, 255);
    return $base;
}

function ascbSoNormalizeExtractedText($text) {
    $text = str_replace(array("\xC2\xA0", "\r", "\t"), array(' ', "\n", ' '), (string)$text);
    $text = preg_replace('/[ ]{2,}/', ' ', $text);
    $lines = preg_split('/\n+/', $text);
    $clean = array();
    foreach ($lines as $line) {
        $line = trim(preg_replace('/\s+/', ' ', $line));
        if ($line !== '') $clean[] = $line;
    }
    return $clean;
}

function ascbSoExtractNameFromText($text) {
    $lines = ascbSoNormalizeExtractedText($text);
    $labels = '(?:student\s+name|name\s+of\s+(?:the\s+)?student|full\s+name|student|name)';
    foreach ($lines as $i => $line) {
        if (preg_match('/^' . $labels . '\s*[:\-]\s*(.+)$/i', $line, $m)) {
            $name = trim($m[1]);
            if (strlen($name) >= 3 && strlen($name) <= 255) return $name;
        }
        if (preg_match('/^' . $labels . '\s*$/i', $line) && isset($lines[$i+1])) {
            $name = trim($lines[$i+1]);
            if (strlen($name) >= 3 && strlen($name) <= 255) return $name;
        }
    }
    /* Inline forms such as "Name : Juan Dela Cruz". */
    if (preg_match('/\b(?:student\s+name|name\s+of\s+(?:the\s+)?student|full\s+name|name)\s*[:\-]\s*([A-Za-z][A-Za-z.,\'\- ]{2,100})/i', $text, $m)) {
        $name = trim(preg_replace('/\s+/', ' ', $m[1]));
        if ($name !== '') return $name;
    }
    return '';
}

function ascbSoValidateUploadedPdf($file, $maxSizeBytes) {
    $originalName = isset($file['name']) ? $file['name'] : 'file.pdf';
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        $code = isset($file['error']) ? (int)$file['error'] : -1;
        $msgs = array(
            UPLOAD_ERR_INI_SIZE=>'Lumagpas sa upload_max_filesize ng server.',
            UPLOAD_ERR_FORM_SIZE=>'Lumagpas sa max file size ng form.',
            UPLOAD_ERR_PARTIAL=>'Hindi kumpleto ang upload.',
            UPLOAD_ERR_NO_TMP_DIR=>'Walang temporary folder sa server.',
            UPLOAD_ERR_CANT_WRITE=>'Hindi maisulat ang file sa disk.',
            UPLOAD_ERR_EXTENSION=>'Hinarang ng PHP extension ang upload.'
        );
        return array('ok'=>false, 'error'=>isset($msgs[$code]) ? $msgs[$code] : 'Upload error.');
    }
    $size = isset($file['size']) ? (int)$file['size'] : 0;
    if ($size <= 0 || $size > $maxSizeBytes) return array('ok'=>false, 'error'=>$originalName . ' exceeds the allowed file size.');
    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $mime = '';
    if (function_exists('finfo_open')) {
        $f = finfo_open(FILEINFO_MIME_TYPE);
        if ($f) { $mime = finfo_file($f, $file['tmp_name']); finfo_close($f); }
    }
    if ($ext !== 'pdf' || ($mime !== '' && $mime !== 'application/pdf')) return array('ok'=>false, 'error'=>$originalName . ' ay hindi valid na PDF.');
    return array('ok'=>true);
}

/* =========================================================
   DUPLICATE FILENAME GUARD
   ---------------------------------------------------------
   Hindi ia-upload ang PDF kapag may Approved SO na na may
   parehong filename (original_filename). Hindi case-sensitive
   (utf8mb4_unicode_ci), kaya "SO-001.pdf" = "so-001.PDF".
   $excludeId ay para sa Edit/Replace file (huwag ihambing sa
   sarili nitong record).
   ========================================================= */
if (!defined('ASCB_SO_DUPLICATE_MSG')) {
    define('ASCB_SO_DUPLICATE_MSG', 'Failed upload - duplicate file name.');
}

function ascbSoFilenameExists($pdo, $filename, $excludeId = 0) {
    $filename = trim((string)$filename);
    if ($filename === '') return false;
    if ((int)$excludeId > 0) {
        $stmt = $pdo->prepare("SELECT id FROM approved_so WHERE original_filename = ? AND id <> ? LIMIT 1");
        $stmt->execute(array($filename, (int)$excludeId));
    } else {
        $stmt = $pdo->prepare("SELECT id FROM approved_so WHERE original_filename = ? LIMIT 1");
        $stmt->execute(array($filename));
    }
    return $stmt->fetchColumn() !== false;
}

/* ========================================== GET — LIST */

if ($method === 'GET') {

    $q = trim(ascb_get($_GET, 'q', ''));
    $page = max(1, (int)ascb_get($_GET, 'page', 1));
    $limit = (int)ascb_get($_GET, 'limit', 25);
    if ($limit <= 0 || $limit > 100) $limit = 25;
    $offset = ($page - 1) * $limit;

    $where = array();
    $params = array();
    if ($q !== '') {
        $qNorm = str_replace(array("\xC2\xA0", "\t", "\r", "\n"), ' ', $q);
        $qNorm = trim(preg_replace('/\s+/', ' ', $qNorm));
        $qEscaped = str_replace(array('\\', '%', '_'), array('\\\\', '\%', '\_'), $qNorm);
        $like = '%' . $qEscaped . '%';
        $where[] = "(TRIM(s.name) LIKE ? ESCAPE '\\\\' OR TRIM(s.original_filename) LIKE ? ESCAPE '\\\\')";
        $params[] = $like; $params[] = $like;
    }
    $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

    try {
        $count = $pdo->prepare("SELECT COUNT(*) FROM approved_so s" . $whereSql);
        $count->execute($params);
        $total = (int)$count->fetchColumn();

        $sql = "SELECT s.*, u.display_name AS uploaded_by_name
                FROM approved_so s
                LEFT JOIN users u ON u.id = s.uploaded_by_user_id" . $whereSql .
               " ORDER BY s.created_at DESC, s.id DESC LIMIT " . $limit . " OFFSET " . $offset;
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(array('ok'=>false,'error'=>'There was an error retrieving Approved SO records.'), JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode(array(
        'ok'=>true, 'rows'=>$rows, 'count'=>count($rows), 'total'=>$total,
        'page'=>$page, 'limit'=>$limit, 'totalPages'=>(int)max(1, ceil($total/$limit))
    ), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($method === 'POST') {

    $action = ascb_get($_POST, 'action', 'create');

    /* ----------------------------------------- BATCH CREATE
       Multi-PDF upload:
       - Walang application-level file-count limit.
       - The browser sends files in small chunks to avoid PHP
         max_file_uploads/post_max_size limits.
       - The database name is ALWAYS the uploaded PDF filename.
       - No OCR/PDF text extraction is needed for Approved SO.
       - One bad file does not cancel the other valid files.
    */
    if ($action === 'batch_create') {
        $files = isset($_FILES['files']) ? $_FILES['files'] : array();
        if (empty($files) || !isset($files['name']) || !is_array($files['name'])) {
            http_response_code(400);
            echo json_encode(array('ok'=>false,'error'=>'No PDF files were received.'));
            exit;
        }

        $indexes = isset($_POST['file_indexes']) && is_array($_POST['file_indexes'])
            ? $_POST['file_indexes'] : array();

        $results = array();
        $count = count($files['name']);

        for ($i = 0; $i < $count; $i++) {
            $displayIndex = isset($indexes[$i]) ? (int)$indexes[$i] : $i;

            $file = array(
                'name'     => isset($files['name'][$i]) ? $files['name'][$i] : 'file.pdf',
                'type'     => isset($files['type'][$i]) ? $files['type'][$i] : '',
                'tmp_name' => isset($files['tmp_name'][$i]) ? $files['tmp_name'][$i] : '',
                'error'    => isset($files['error'][$i]) ? (int)$files['error'][$i] : UPLOAD_ERR_NO_FILE,
                'size'     => isset($files['size'][$i]) ? (int)$files['size'][$i] : 0,
            );

            $original = basename((string)$file['name']);
            if ($original === '') $original = 'file.pdf';

            $valid = ascbSoValidateUploadedPdf($file, $maxSizeBytes);
            if (!$valid['ok']) {
                $results[] = array(
                    'index' => $displayIndex,
                    'filename' => $original,
                    'saved' => false,
                    'error' => $valid['error']
                );
                continue;
            }

            /* Duplicate filename -> do NOT upload, report as failed. */
            if (ascbSoFilenameExists($pdo, $original)) {
                $results[] = array(
                    'index' => $displayIndex,
                    'filename' => $original,
                    'saved' => false,
                    'duplicate' => true,
                    'error' => ASCB_SO_DUPLICATE_MSG
                );
                continue;
            }

            /*
             * IMPORTANT:
             * The Approved SO "name" is the PDF filename itself.
             * Do not read the PDF contents, do not use OCR, and do not
             * require a manual name field.
             */
            $name = function_exists('mb_substr')
                ? mb_substr($original, 0, 255, 'UTF-8')
                : substr($original, 0, 255);

            $storedName = 'so_' . ascb_random_token(16) . '.pdf';
            $destination = $UPLOAD_DIR . $storedName;

            if (!move_uploaded_file($file['tmp_name'], $destination)) {
                $results[] = array(
                    'index' => $displayIndex,
                    'filename' => $original,
                    'saved' => false,
                    'error' => 'Unable to save the PDF to uploads/approved_so/.'
                );
                continue;
            }

            try {
                $stmt = $pdo->prepare(
                    "INSERT INTO approved_so
                        (name, stored_filename, original_filename, filesize_bytes, uploaded_by_user_id)
                     VALUES (?,?,?,?,?)"
                );
                $stmt->execute(array(
                    $name,
                    $storedName,
                    $original,
                    $file['size'],
                    ascb_get($ascbUser, 'id', null)
                ));

                $results[] = array(
                    'index' => $displayIndex,
                    'filename' => $original,
                    'name' => $name,
                    'saved' => true,
                    'id' => (int)$pdo->lastInsertId()
                );
            } catch (Exception $e) {
                @unlink($destination);
                $results[] = array(
                    'index' => $displayIndex,
                    'filename' => $original,
                    'saved' => false,
                    'error' => 'Database error while saving the record.'
                );
            }
        }

        $saved = 0;
        foreach ($results as $r) {
            if (!empty($r['saved'])) $saved++;
        }

        $failed = count($results) - $saved;

        echo json_encode(array(
            'ok' => true,
            'received' => count($results),
            'saved' => $saved,
            'failed' => $failed,
            'total' => count($results),
            'results' => $results
        ), JSON_UNESCAPED_UNICODE);
        exit;
    }

    /* ----------------------------------------- CREATE */
    if ($action === 'create') {

        $name = trim(ascb_get($_POST, 'name', ''));
        if ($name === '') {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Name is required.'));
            exit;
        }

        if (!empty($_FILES['file']['name']) && ascbSoFilenameExists($pdo, basename((string)$_FILES['file']['name']))) {
            http_response_code(409);
            echo json_encode(array('ok' => false, 'duplicate' => true, 'error' => ASCB_SO_DUPLICATE_MSG));
            exit;
        }

        $uploaded = ascbSoHandleUpload('file', $UPLOAD_DIR, $maxSizeBytes);
        if (!$uploaded) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'A PDF file is required.'));
            exit;
        }

        $stmt = $pdo->prepare(
            "INSERT INTO approved_so
                (name, stored_filename, original_filename, filesize_bytes, uploaded_by_user_id)
             VALUES (?,?,?,?,?)"
        );
        $stmt->execute(array(
            $name,
            $uploaded['stored'],
            $uploaded['original'],
            $uploaded['size'],
            ascb_get($ascbUser, 'id', null),
        ));

        echo json_encode(array('ok' => true, 'id' => $pdo->lastInsertId()));
        exit;
    }

    /* ----------------------------------------- UPDATE */
    if ($action === 'update') {

        $id = (int) ascb_get($_POST, 'id', 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM approved_so WHERE id = ?");
        $stmt->execute(array($id));
        $existing = $stmt->fetch();

        if (!$existing) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Entry not found.'));
            exit;
        }

        $name = trim(ascb_get($_POST, 'name', ''));

        /* Ang bagong file ay optional — kung wala, panatilihin ang
           existing PDF/name. Kapag may bagong PDF, automatic na ang
           filename nito ang gagawing Approved SO name. */
        if (!empty($_FILES['file']['name']) && ascbSoFilenameExists($pdo, basename((string)$_FILES['file']['name']), $id)) {
            http_response_code(409);
            echo json_encode(array('ok' => false, 'duplicate' => true, 'error' => ASCB_SO_DUPLICATE_MSG));
            exit;
        }

        $uploaded = ascbSoHandleUpload('file', $UPLOAD_DIR, $maxSizeBytes);

        if ($uploaded) {
            $autoName = basename((string)$uploaded['original']);
            $name = function_exists('mb_substr')
                ? mb_substr($autoName, 0, 255, 'UTF-8')
                : substr($autoName, 0, 255);

            $stmt = $pdo->prepare(
                "UPDATE approved_so
                    SET name = ?, stored_filename = ?, original_filename = ?, filesize_bytes = ?
                  WHERE id = ?"
            );
            $stmt->execute(array($name, $uploaded['stored'], $uploaded['original'], $uploaded['size'], $id));

            // matagumpay na na-update ang DB — ngayon safe nang tanggalin ang lumang file
            $oldPath = $UPLOAD_DIR . $existing['stored_filename'];
            if (is_file($oldPath)) {
                @unlink($oldPath);
            }
        } else {
            if ($name === '') {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Name is required.'));
                exit;
            }
            $stmt = $pdo->prepare("UPDATE approved_so SET name = ? WHERE id = ?");
            $stmt->execute(array($name, $id));
        }

        echo json_encode(array('ok' => true));
        exit;
    }

    /* ----------------------------------------- DELETE */
    if ($action === 'delete') {

        $id = (int) ascb_get($_POST, 'id', 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM approved_so WHERE id = ?");
        $stmt->execute(array($id));
        $existing = $stmt->fetch();

        if (!$existing) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Entry not found.'));
            exit;
        }

        $stmt = $pdo->prepare("DELETE FROM approved_so WHERE id = ?");
        $stmt->execute(array($id));

        $path = $UPLOAD_DIR . $existing['stored_filename'];
        if (is_file($path)) {
            @unlink($path);
        }

        echo json_encode(array('ok' => true));
        exit;
    }

    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
    exit;
}


/* ========================================== OTHER METHODS */

http_response_code(405);
echo json_encode(array('ok' => false, 'error' => 'Method not allowed.'));