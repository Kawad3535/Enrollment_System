<?php
/* =========================================================
   API: BACKUP CRON ENDPOINT (walang login — token ang proteksyon)
   ---------------------------------------------------------
   Tawagin ito ng external pinger (hal. cron-job.org, UptimeRobot)
   bawat 5–10 minuto:
       https://YOUR-SITE/api/backup_cron.php?token=XXXXXXXX
   Gagawa lang ito ng backup kung due na ang naka-set na oras.
   ========================================================= */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('X-Robots-Tag: noindex');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/backup_engine.php';

if (!$pdo) { http_response_code(503); echo json_encode(array('ok' => false, 'error' => 'Database unavailable.')); exit; }
try {
    ascb_backup_ensure_schema($pdo);
    $token = isset($_GET['token']) ? (string) $_GET['token'] : '';
    $real = (string) $pdo->query("SELECT cron_token FROM backup_schedule WHERE id=1")->fetchColumn();
    if ($token === '' || $real === '' || !hash_equals($real, $token)) {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'Invalid token.'));
        exit;
    }
    $r = ascb_backup_run_if_due($pdo);
    echo json_encode(array('ok' => true, 'ran' => !empty($r['ran']), 'reason' => isset($r['reason']) ? $r['reason'] : null, 'status' => isset($r['status']) ? $r['status'] : null, 'message' => isset($r['message']) ? $r['message'] : null));
} catch (Exception $e) {
    error_log('ASCB backup_cron: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'Backup error.'));
}
