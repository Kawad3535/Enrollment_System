<?php
/* Download ng isang automatic backup file (login + CSRF + full_backup permission). */
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/backup_engine.php';

$role = ascb_get($ascbUser, 'role', '');
if (!ascb_can($role, 'full_backup')) { http_response_code(403); exit('Forbidden'); }
if (!ascb_verify_csrf(ascb_get($_GET, 'csrf', ''))) { http_response_code(403); exit('Expired o invalid ang request token. I-refresh ang page at subukan muli.'); }

$id = (int) ascb_get($_GET, 'id', 0);
$st = $pdo->prepare("SELECT filename FROM backup_history WHERE id=? AND backup_type IN (" . ascb_backup_auto_types_sql() . ")");
$st->execute(array($id));
$name = $st->fetchColumn();
if (!$name) { http_response_code(404); exit('Backup not found'); }
$name = basename($name);
$dir = realpath(ascb_backup_dir());
$path = $dir ? realpath($dir . '/' . $name) : false;
if (!$path || strpos($path, $dir) !== 0 || !is_file($path)) { http_response_code(404); exit('Backup file no longer exists on the server (retention).'); }

$ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
if ($ext === 'xlsx') {
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
} elseif ($ext === 'sql') {
    header('Content-Type: application/sql; charset=UTF-8');
} else {
    header('Content-Type: text/csv; charset=UTF-8'); // lumang CSV backup
}
header('Content-Disposition: attachment; filename="' . $name . '"');
header('Content-Length: ' . filesize($path));
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
$fh = fopen($path, 'rb');
while ($fh && !feof($fh)) { echo fread($fh, 1048576); if (function_exists('ob_flush')) @ob_flush(); flush(); }
if ($fh) fclose($fh);
ascb_log_activity($pdo, $ascbUser, 'AUTO_BACKUP_DOWNLOAD', 'database', 'ascb_registrar', $name);
