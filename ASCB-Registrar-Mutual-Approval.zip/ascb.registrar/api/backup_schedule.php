<?php
/* =========================================================
   API: AUTOMATIC BACKUP SCHEDULE
   Actions: list (get) | save | run_now | tick | regen_token
   Lahat ng action ay tumatanggap ng opsyonal na "page" at "perPage" para sa
   pagination ng listahan ng backup files (default: page 1, 10 bawat page).
   UNIT HEAD / SCHOOL REGISTRAR lang (permission 'full_backup').
   ========================================================= */
require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/backup_engine.php';

$role = ascb_get($ascbUser, 'role', '');
if (!ascb_can($role, 'full_backup')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'Only UNIT HEAD or SCHOOL REGISTRAR can manage automatic backups.'));
    exit;
}
if (!$pdo) {
    http_response_code(503);
    echo json_encode(array('ok' => false, 'error' => 'Database unavailable.'));
    exit;
}

$input = ascb_read_json_body();
$action = ascb_get($input, 'action', 'get');
$pgPage = (int) ascb_get($input, 'page', 1);
$pgPer = (int) ascb_get($input, 'perPage', 10);

/* Pinapayagang laki ng page sa listahan ng backup files. */
function ascb_backup_clamp_per_page($n) {
    $n = (int) $n;
    return in_array($n, array(5, 10, 20, 50), true) ? $n : 10;
}

function ascb_backup_api_state($pdo, $page = 1, $perPage = 10) {
    $s = ascb_backup_get_settings($pdo);
    $dir = ascb_backup_dir();
    $files = array();
    $perPage = ascb_backup_clamp_per_page($perPage);
    $typesSql = ascb_backup_auto_types_sql();
    $total = (int) $pdo->query("SELECT COUNT(*) FROM backup_history WHERE backup_type IN ($typesSql)")->fetchColumn();
    $totalPages = max(1, (int) ceil($total / $perPage));
    $page = (int) $page;
    if ($page < 1) $page = 1;
    if ($page > $totalPages) $page = $totalPages;
    $offset = ($page - 1) * $perPage;
    // Server-side pagination: LIMIT/OFFSET (int na lahat kaya ligtas i-interpolate).
    $q = $pdo->query("SELECT h.id,h.backup_type,h.filename,h.created_at,h.school_year,h.term_label,d.code AS department_code
                      FROM backup_history h LEFT JOIN departments d ON d.id=h.department_id
                      WHERE h.backup_type IN ($typesSql)
                      ORDER BY h.id DESC LIMIT $perPage OFFSET $offset");
    while ($r = $q->fetch(PDO::FETCH_ASSOC)) {
        $p = $dir . '/' . basename($r['filename']);
        $exists = is_file($p);
        if ($r['backup_type'] === 'AUTO_FULL_SQL') $type = 'Full SQL';
        elseif ($r['backup_type'] === 'AUTO_DEPT_XLSX') $type = 'Department ' . ($r['department_code'] ? $r['department_code'] : '') . ' (Excel)';
        else $type = 'Department ' . ($r['department_code'] ? $r['department_code'] : '') . ' (CSV, luma)';
        $files[] = array(
            'id' => (int) $r['id'],
            'type' => $type,
            'filename' => $r['filename'],
            'schoolYear' => $r['school_year'],
            'term' => $r['term_label'],
            'createdAt' => $r['created_at'],
            'size' => $exists ? (int) filesize($p) : null,
            'available' => $exists,
        );
    }
    return array(
        'ok' => true,
        'serverTime' => date('Y-m-d H:i:s'),
        'settings' => array(
            'enabled' => (int) $s['is_enabled'],
            'frequency' => $s['frequency'],
            'time' => $s['run_time'],
            'weekday' => (int) $s['run_weekday'],
            'includeSql' => (int) $s['include_sql'],
            'includeDepartments' => (int) $s['include_departments'],
            'keep' => (int) $s['keep_count'],
            'nextRunAt' => $s['next_run_at'],
            'lastRunAt' => $s['last_run_at'],
            'lastStatus' => $s['last_status'],
            'lastMessage' => $s['last_message'],
            'running' => (!empty($s['running_until']) && $s['running_until'] > date('Y-m-d H:i:s')) ? 1 : 0,
            'cronToken' => $s['cron_token'],
        ),
        'files' => $files,
        'pagination' => array('page' => $page, 'perPage' => $perPage, 'total' => $total, 'totalPages' => $totalPages),
    );
}

try {
    ascb_backup_ensure_schema($pdo);

    if ($action === 'get' || $action === 'list') {
        echo json_encode(ascb_backup_api_state($pdo, $pgPage, $pgPer));
        exit;
    }

    if ($action === 'save') {
        $enabled = ascb_get($input, 'enabled', 0) ? 1 : 0;
        $freq = ascb_get($input, 'frequency', 'daily') === 'weekly' ? 'weekly' : 'daily';
        $time = trim((string) ascb_get($input, 'time', '02:00'));
        $weekday = (int) ascb_get($input, 'weekday', 1);
        $incSql = ascb_get($input, 'includeSql', 0) ? 1 : 0;
        $incDept = ascb_get($input, 'includeDepartments', 0) ? 1 : 0;
        $keep = (int) ascb_get($input, 'keep', 7);
        if (!preg_match('/^([01]\d|2[0-3]):([0-5]\d)$/', $time)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid time. Use HH:MM (24-hour).'));
            exit;
        }
        if ($weekday < 0 || $weekday > 6) $weekday = 1;
        if ($keep < 1) $keep = 1;
        if ($keep > 60) $keep = 60;
        if ($enabled && !$incSql && !$incDept) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Pumili ng kahit isa: Full SQL o Department data.'));
            exit;
        }
        $next = $enabled ? ascb_backup_compute_next($freq, $time, $weekday) : null;
        $st = $pdo->prepare("UPDATE backup_schedule SET is_enabled=?, frequency=?, run_time=?, run_weekday=?, include_sql=?, include_departments=?, keep_count=?, next_run_at=?, updated_by_user_id=?, updated_at=? WHERE id=1");
        $st->execute(array($enabled, $freq, $time, $weekday, $incSql, $incDept, $keep, $next, (int) ascb_get($ascbUser, 'id', 0), date('Y-m-d H:i:s')));
        ascb_log_activity($pdo, $ascbUser, 'AUTO_BACKUP_SCHEDULE', 'database', 'ascb_registrar', ($enabled ? 'ON ' . $freq . ' ' . $time : 'OFF'));
        echo json_encode(ascb_backup_api_state($pdo, $pgPage, $pgPer));
        exit;
    }

    if ($action === 'run_now') {
        $r = ascb_backup_run($pdo, $ascbUser, 'manual');
        $state = ascb_backup_api_state($pdo, $pgPage, $pgPer);
        $state['run'] = $r;
        if (empty($r['ok'])) $state['ok'] = false;
        if (empty($r['ok'])) $state['error'] = $r['message'];
        echo json_encode($state);
        exit;
    }

    if ($action === 'tick') {
        $r = ascb_backup_run_if_due($pdo);
        $state = ascb_backup_api_state($pdo, $pgPage, $pgPer);
        $state['ran'] = !empty($r['ran']);
        echo json_encode($state);
        exit;
    }

    if ($action === 'regen_token') {
        $up = $pdo->prepare("UPDATE backup_schedule SET cron_token=? WHERE id=1");
        $up->execute(array(ascb_backup_new_token()));
        ascb_log_activity($pdo, $ascbUser, 'AUTO_BACKUP_TOKEN_REGEN', 'database', 'ascb_registrar', null);
        echo json_encode(ascb_backup_api_state($pdo, $pgPage, $pgPer));
        exit;
    }

    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
} catch (Exception $e) {
    error_log('ASCB backup_schedule: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'Backup schedule operation failed. Please check the server audit log.'));
}
