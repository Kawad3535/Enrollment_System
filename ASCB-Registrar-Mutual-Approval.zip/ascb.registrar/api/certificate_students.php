<?php
/* Search and load approved enrollment records for certificate generation. */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/certificate_student_source.php';

if (strtoupper(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET') !== 'GET') {
    http_response_code(405);
    header('Allow: GET');
    echo json_encode(array('ok' => false, 'error' => 'Only GET requests are supported.'));
    exit;
}

try {
    $enrollmentId = (int) ascb_get($_GET, 'enrollment_id', 0);
    if ($enrollmentId > 0) {
        $student = ascb_certificate_load_enrollment($pdo, $enrollmentId, $ascbUser);
        if (!$student) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'No approved enrollment record was found.'));
            exit;
        }
        echo json_encode(array('ok' => true, 'student' => $student), JSON_UNESCAPED_UNICODE);
        exit;
    }

    $query = trim((string) ascb_get($_GET, 'q', ''));
    $queryLength = function_exists('mb_strlen') ? mb_strlen($query, 'UTF-8') : strlen($query);
    if ($queryLength < 2) {
        echo json_encode(array('ok' => true, 'students' => array()), JSON_UNESCAPED_UNICODE);
        exit;
    }

    $students = ascb_certificate_search_enrollments($pdo, $query, $ascbUser);
    echo json_encode(array('ok' => true, 'students' => $students), JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    error_log('ASCB certificate student lookup failed: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'Student lookup failed. Please try again.'));
}