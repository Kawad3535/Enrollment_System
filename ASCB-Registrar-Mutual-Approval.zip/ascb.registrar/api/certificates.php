<?php
/* =========================================================
   API: CERTIFICATES
   Nag-lo-log ng bawat na-generate na certificate sa DB.
   Tinatawag ito ng script.js (generateCertificate) sa
   sandaling matagumpay na nabuo ang preview — hindi ito
   humaharang sa pag-print, log lang ito sa background.

   POST body (JSON), default (action omitted o "create"): {
     certificateType, enrollmentId, studentName, studentId, program,
     yearLevel, trimester, academicYear, enrollmentDate,
     status, orNumber, totalUnits, gwa, preparedBy,
     subjects: [{code, description, grade, units}, ...]
   }
   Sa bagong record, enrollmentId ang ginagamit para muling kunin
   sa database ang opisyal na student, term, subject, unit, at grade data.

   POST body (JSON), manual=true — MANUAL na paggawa ng certificate:
   walang enrollmentId, kaya ang ipinasang student, term at subjects
   ang ginagamit. Buong validation ang isinasagawa dito bago i-insert.

   Ang response ng create/update ay may kasamang "verify" object
   (token, code, url, qrText) para sa QR ng ENROLLMENT at
   REGISTRATION certificate. Tingnan ang
   includes/certificate_verify_helper.php at verify.php.

   POST body (JSON), action="update" — itinatama ang isang
   record na nasa Records (History) na dati nang na-log,
   sa halip na gumawa ng bagong hiwalay na row:
     { action: "update", id, ...parehong fields sa itaas }
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/certificate_student_source.php';
require_once __DIR__ . '/../includes/certificate_verify_helper.php';

$data = ascb_read_json_body();
$action = trim((string) ascb_get($data, 'action', 'create'));

if (empty($data['studentName']) || empty($data['studentId'])) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Missing student name or student ID.'));
    exit;
}

if ($action === 'update') {
    // Parehong permission na gumagamit sa Certificates/Records module —
    // ang pag-tama ng isang naka-log nang record ay hindi dapat mas
    // mababa pa sa access na kailangan para makagawa ng bago.
    $role = ascb_get($ascbUser, 'role', '');
    if (!ascb_can($role, 'manage_office_records')) {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'You do not have access to update the Records log.'));
        exit;
    }
    $id = (int) ascb_get($data, 'id', 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Invalid record id.'));
        exit;
    }
    $exists = $pdo->prepare("SELECT student_name, student_id FROM certificates WHERE id = ?");
    $exists->execute(array($id));
    $old = $exists->fetch();
    if (!$old) {
        http_response_code(404);
        echo json_encode(array('ok' => false, 'error' => 'This record was not found.'));
        exit;
    }

    $stmt = $pdo->prepare(
        "UPDATE certificates SET
            certificate_type = ?, student_name = ?, student_id = ?, program = ?, year_level = ?,
            trimester = ?, academic_year = ?, enrollment_date = ?, status = ?, or_number = ?,
            total_units = ?, gwa = ?, subjects_json = ?, prepared_by = ?
         WHERE id = ?"
    );
    $stmt->execute(array(
        ascb_get($data, 'certificateType', ''),
        ascb_get($data, 'studentName', ''),
        ascb_get($data, 'studentId', ''),
        ascb_get($data, 'program', ''),
        ascb_get($data, 'yearLevel', ''),
        ascb_get($data, 'trimester', ''),
        ascb_get($data, 'academicYear', ''),
        !empty($data['enrollmentDate']) ? $data['enrollmentDate'] : null,
        ascb_get($data, 'status', ''),
        ascb_get($data, 'orNumber', ''),
        (isset($data['totalUnits']) && $data['totalUnits'] !== '') ? $data['totalUnits'] : null,
        (isset($data['gwa']) && $data['gwa'] !== '') ? $data['gwa'] : null,
        json_encode(ascb_get($data, 'subjects', array()), JSON_UNESCAPED_UNICODE),
        ascb_get($data, 'preparedBy', ascb_get($ascbUser, 'preparedBy', '')),
        $id,
    ));

    ascb_log_activity($pdo, $ascbUser, 'RECORD_UPDATE', 'certificate',
        ascb_get($data, 'studentName', '') . ' (' . ascb_get($data, 'studentId', '') . ')',
        'Corrected certificate record #' . $id . ' sa Records/History.');

    echo json_encode(array('ok' => true, 'id' => $id, 'updated' => true, 'verify' => ascb_cert_verify_info($pdo, $id)), JSON_UNESCAPED_UNICODE);
    exit;
}

$certificateType = trim((string) ascb_get($data, 'certificateType', ''));
if (!in_array($certificateType, array('ENROLLMENT', 'REGISTRATION', 'GRADE_EVALUATION'), true)) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Select a valid certificate type.'));
    exit;
}

/* =========================================================
   MANUAL CERTIFICATE
   Walang enrollment record na pinagbabatayan — hayagang
   ita-type ng tauhan ang lahat ng detalye (walk-in, legacy,
   o special na kaso). Dito ginagawa ang buong validation at
   sanitation ng ipinasang data dahil wala nang official
   source sa database na pwedeng ikumpara.
   ========================================================= */
if (!empty($data['manual'])) {

    $limit = function ($value, $max) {
        $value = trim((string) $value);
        $value = preg_replace('/[\x00-\x1F\x7F]/u', '', $value);
        return function_exists('mb_substr') ? mb_substr($value, 0, $max, 'UTF-8') : substr($value, 0, $max);
    };

    $studentName  = $limit(ascb_get($data, 'studentName', ''), 150);
    $studentIdVal = $limit(ascb_get($data, 'studentId', ''), 50);
    $programCode  = $limit(ascb_get($data, 'program', ''), 50);
    $yearLevel    = $limit(ascb_get($data, 'yearLevel', ''), 30);
    $trimester    = $limit(ascb_get($data, 'trimester', ''), 30);
    $academicYear = $limit(ascb_get($data, 'academicYear', ''), 20);
    $statusValue  = $limit(ascb_get($data, 'status', ''), 30);
    $orNumber     = $limit(ascb_get($data, 'orNumber', ''), 50);

    if ($studentName === '' || $studentIdVal === '' || $programCode === ''
        || $yearLevel === '' || $trimester === '' || $academicYear === '') {
        http_response_code(422);
        echo json_encode(array('ok' => false, 'error' => 'Student name, Student ID, program, year level, term, and academic year are all required for a manual certificate.'));
        exit;
    }

    /* Ang program ay kailangang isa sa tunay na programs ng ASCB —
       hindi pwedeng basta-bastang text na pinasok sa request. */
    require_once __DIR__ . '/../includes/programs_helper.php';
    $validPrograms = ascb_program_dropdown_options($pdo);
    if (!isset($validPrograms[$programCode])) {
        http_response_code(422);
        echo json_encode(array('ok' => false, 'error' => 'Select a valid Course / Program.'));
        exit;
    }

    if (!in_array($statusValue, array('OFFICIALLY ENROLLED', 'FOR VALIDATION'), true)) {
        $statusValue = 'OFFICIALLY ENROLLED';
    }

    $enrollmentDate = trim((string) ascb_get($data, 'enrollmentDate', ''));
    if ($enrollmentDate !== '') {
        $parsed = DateTime::createFromFormat('Y-m-d', $enrollmentDate);
        if (!$parsed || $parsed->format('Y-m-d') !== $enrollmentDate) {
            http_response_code(422);
            echo json_encode(array('ok' => false, 'error' => 'Enter a valid Date of Enrollment (YYYY-MM-DD).'));
            exit;
        }
    } else {
        $enrollmentDate = null;
    }

    $rawSubjects = ascb_get($data, 'subjects', array());
    if (!is_array($rawSubjects)) $rawSubjects = array();

    $manualSubjects = array();
    $seenCodes = array();
    $totalUnits = 0;
    $weightedGradeTotal = 0;
    $gradedUnits = 0;
    $hasRecordedGrade = false;

    foreach ($rawSubjects as $subject) {
        if (!is_array($subject)) continue;
        $code = $limit(ascb_get($subject, 'code', ''), 50);
        $description = $limit(ascb_get($subject, 'description', ''), 255);
        if ($code === '' && $description === '') continue;

        $units = (float) ascb_get($subject, 'units', 0);
        if ($units < 0) $units = 0;
        if ($units > 99) $units = 99;

        $grade = $limit(ascb_get($subject, 'grade', ''), 10);
        if ($grade !== '' && is_numeric($grade)) {
            $gradeNumber = (float) $grade;
            if ($gradeNumber < 0 || $gradeNumber > 100) {
                http_response_code(422);
                echo json_encode(array('ok' => false, 'error' => 'A grade you entered is out of range. Check the Grade column.'));
                exit;
            }
        }

        $codeKey = strtoupper($code);
        if ($code !== '' && isset($seenCodes[$codeKey])) {
            http_response_code(422);
            echo json_encode(array('ok' => false, 'error' => 'The subject "' . $code . '" appears more than once. Remove the duplicate row.'));
            exit;
        }
        if ($code !== '') $seenCodes[$codeKey] = true;

        $totalUnits += $units;
        if ($grade !== '') $hasRecordedGrade = true;
        if ($grade !== '' && is_numeric($grade) && $units > 0) {
            $weightedGradeTotal += ((float) $grade) * $units;
            $gradedUnits += $units;
        }

        $manualSubjects[] = array(
            'code' => $code,
            'description' => $description,
            'grade' => $grade,
            'units' => $units,
        );

        if (count($manualSubjects) >= 60) break;
    }

    if (!count($manualSubjects)) {
        http_response_code(422);
        echo json_encode(array('ok' => false, 'error' => 'Add at least one subject before generating a certificate.'));
        exit;
    }

    if ($certificateType === 'GRADE_EVALUATION' && !$hasRecordedGrade) {
        http_response_code(422);
        echo json_encode(array('ok' => false, 'error' => 'Grade Evaluation needs at least one recorded grade.'));
        exit;
    }

    $gwa = $gradedUnits > 0 ? round($weightedGradeTotal / $gradedUnits, 2) : null;

    $stmt = $pdo->prepare(
        "INSERT INTO certificates
            (certificate_type, student_name, student_id, program, year_level, trimester,
             academic_year, enrollment_date, status, or_number, total_units, gwa,
             subjects_json, prepared_by, issued_by_user_id)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    );
    $stmt->execute(array(
        $certificateType,
        $studentName,
        $studentIdVal,
        $programCode,
        $yearLevel,
        $trimester,
        $academicYear,
        $enrollmentDate,
        $statusValue,
        $orNumber,
        $totalUnits,
        $gwa,
        json_encode($manualSubjects, JSON_UNESCAPED_UNICODE),
        ascb_get($ascbUser, 'preparedBy', ''),
        ascb_get($ascbUser, 'id', null),
    ));

    $newId = $pdo->lastInsertId();

    ascb_log_activity($pdo, $ascbUser, 'RECORD_CREATE', 'certificate',
        $studentName . ' (' . $studentIdVal . ')',
        'Manually encoded ' . $certificateType . ' certificate #' . $newId . ' (no enrollment record).');

    echo json_encode(array('ok' => true, 'id' => $newId, 'manual' => true, 'verify' => ascb_cert_verify_info($pdo, $newId)), JSON_UNESCAPED_UNICODE);
    exit;
}

$enrollmentId = (int) ascb_get($data, 'enrollmentId', 0);
if ($enrollmentId <= 0) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Select an approved student enrollment before generating a certificate.'));
    exit;
}

$source = ascb_certificate_load_enrollment($pdo, $enrollmentId, $ascbUser);
if (!$source) {
    http_response_code(404);
    echo json_encode(array('ok' => false, 'error' => 'The selected enrollment is no longer available. Search and select the student again.'));
    exit;
}

if (trim((string) ascb_get($data, 'studentId', '')) !== $source['studentId']) {
    http_response_code(409);
    echo json_encode(array('ok' => false, 'error' => 'The selected student record changed. Search and select the student again.'));
    exit;
}

if ($source['programCode'] === '' || $source['yearLevel'] === '' || $source['trimester'] === '' || $source['academicYear'] === '') {
    http_response_code(422);
    echo json_encode(array('ok' => false, 'error' => 'The selected enrollment is missing required program or term details.'));
    exit;
}

$officialSubjects = $source['subjects'];
$totalUnits = 0;
$weightedGradeTotal = 0;
$gradedUnits = 0;
$hasRecordedGrade = false;
foreach ($officialSubjects as $subject) {
    $units = (float) $subject['units'];
    $totalUnits += $units;
    if (trim((string) $subject['grade']) !== '') {
        $hasRecordedGrade = true;
    }
    if (is_numeric($subject['grade']) && $units > 0) {
        $weightedGradeTotal += ((float) $subject['grade']) * $units;
        $gradedUnits += $units;
    }
}

if ($certificateType === 'GRADE_EVALUATION' && !$hasRecordedGrade) {
    http_response_code(422);
    echo json_encode(array('ok' => false, 'error' => 'No grades are recorded for the selected enrollment.'));
    exit;
}

$gwa = $gradedUnits > 0 ? round($weightedGradeTotal / $gradedUnits, 2) : null;
$enrollmentDate = $source['enrollmentDate'] !== '' ? $source['enrollmentDate'] : null;
$orNumber = trim((string) ascb_get($data, 'orNumber', ''));
$preparedBy = ascb_get($ascbUser, 'preparedBy', '');

$stmt = $pdo->prepare(
    "INSERT INTO certificates
        (certificate_type, student_name, student_id, program, year_level, trimester,
         academic_year, enrollment_date, status, or_number, total_units, gwa,
         subjects_json, prepared_by, issued_by_user_id)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
);

$stmt->execute(array(
    $certificateType,
    $source['studentName'],
    $source['studentId'],
    $source['programCode'],
    $source['yearLevel'],
    $source['trimester'],
    $source['academicYear'],
    $enrollmentDate,
    $source['status'],
    $orNumber,
    $totalUnits,
    $gwa,
    json_encode($officialSubjects, JSON_UNESCAPED_UNICODE),
    $preparedBy,
    ascb_get($ascbUser, 'id', null),
));

$newCertId = $pdo->lastInsertId();
echo json_encode(array('ok' => true, 'id' => $newCertId, 'verify' => ascb_cert_verify_info($pdo, $newCertId)), JSON_UNESCAPED_UNICODE);
