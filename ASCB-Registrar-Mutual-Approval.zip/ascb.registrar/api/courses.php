<?php
/* =========================================================
   API: COURSES
   POST body (JSON): { "action": "add", "name": "..." }
                   or { "action": "delete", "name": "..." }
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../config/db.php';

$input = ascb_read_json_body();
$action = ascb_get($input, 'action', '');

// Only UNIT HEAD and ADMIN STAFF may manage Schools & Courses.
// Keep the read-only "list" action available for existing system dropdowns.
if (in_array($action, array('add', 'delete'), true) && !ascb_can(ascb_get($ascbUser, 'role', ''), 'manage_lookups')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'Only UNIT HEAD and ADMIN STAFF can manage Schools & Courses.'));
    exit;
}

if ($action === 'add') {
    $name = trim(ascb_get($input, 'name', ''));

    if ($name === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Enter the course name.'));
        exit;
    }

    $check = $pdo->prepare("SELECT id FROM courses WHERE LOWER(name) = LOWER(?)");
    $check->execute(array($name));
    if ($check->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'This course is already saved.'));
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO courses (name) VALUES (?)");
    try {
        $stmt->execute(array($name));
    } catch (PDOException $e) {
        // DATABASE TRANSACTION HANDLING — kung dalawang request ang halos
        // sabay-sabay na nag-add ng parehong course name (nakalusot sa
        // pre-check SELECT sa itaas), ang UNIQUE constraint (uniq_course_name)
        // ang huling proteksyon. SQLSTATE 23000 = duplicate/constraint.
        if ($e->getCode() === '23000') {
            echo json_encode(array('ok' => false, 'error' => 'This course is already saved.'));
            exit;
        }
        throw $e;
    }

    ascb_log_activity($pdo, $ascbUser, 'COURSE_ADD', 'course', $name);

    echo json_encode(array('ok' => true, 'course' => array('id' => $pdo->lastInsertId(), 'name' => $name)));
    exit;
}

if ($action === 'delete') {

    if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'manage_lookups')) {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'You do not have access to delete a course.'));
        exit;
    }

    $name = trim(ascb_get($input, 'name', ''));

    if ($name === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Missing course name.'));
        exit;
    }

    $stmt = $pdo->prepare("DELETE FROM courses WHERE name = ?");
    $stmt->execute(array($name));

    ascb_log_activity($pdo, $ascbUser, 'COURSE_DELETE', 'course', $name);

    echo json_encode(array('ok' => true));
    exit;
}

if ($action === 'list') {
    $rows = $pdo->query("SELECT id, name FROM courses ORDER BY name")->fetchAll();
    echo json_encode(array('ok' => true, 'courses' => $rows));
    exit;
}

http_response_code(400);
echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
