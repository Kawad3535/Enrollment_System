<?php
/* =========================================================
   API: DASHBOARD STATS
   ---------------------------------------------------------
   GET params:
     trimester   (opsyonal) — hal. "1st Trimester". Kung
                  blangko/wala, lahat ng trimester ang isasama.
     school_year (opsyonal) — hal. "2025-2026". Kung
                  blangko/wala, lahat ng school year ang isasama.

   GET -> ibinabalik ang:
            - totalEnrolled : bilang ng mga ESTUDYANTE (hindi
                               records) na approved — hindi
                               na-archive at hindi pending/rejected.
                               Kung may ilang term/record na ang
                               isang estudyante, ISANG BESES lang
                               siya binibilang (batay sa student_id,
                               gamit ang PINAKA-BAGONG record niya).
            - male / female : bilang ng estudyanteng lalaki / babae
                               (batay rin sa parehong "isang
                               estudyante = isang beses lang" na
                               paraan sa itaas).
            - byCourse      : listahan kada Course/Program —
                               {course, male, female, total} —
                               pinagsunod-sunod mula sa pinaka-
                               maraming estudyante. Ang "course"
                               dito ay ang MAIKLING CODE (hal. BSA,
                               BSCS, BSBA-FM) mula sa program_code
                               column — pantay-pantay ang format
                               para sa LAHAT ng kurso, hindi na
                               yung mahabang pangalan. Kung walang
                               program_code (lumang datos), ang
                               `course` (mahabang pangalan) na lang
                               ang gagamitin bilang fallback.

   Ang buong counting logic ay nasa includes/dashboard_stats_helper.php
   (ascb_dashboard_stats) — parehong ginagamit ng Excel export sa
   api/dashboard_stats_export.php para laging magkatugma ang
   nakikita sa Dashboard at ang na-e-export.

   Bukas ito sa kahit sinong naka-login (parehong pattern gaya ng
   ibang GET API dito) — walang binabagong data, basa lang.
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/dashboard_stats_helper.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../includes/cache.php';
require_once __DIR__ . '/../config/db.php';

$trimester = trim((string) ascb_get($_GET, 'trimester', ''));
$schoolYear = trim((string) ascb_get($_GET, 'school_year', ''));
$departmentId = ascb_get($ascbUser,'role','') === 'DEAN' ? ascb_require_dean_department($pdo,$ascbUser) : null;

/* DASHBOARD CACHING — ang ascb_dashboard_stats() ay isang mabigat na
   GROUP BY/aggregation sa buong `enrollees` table (posibleng 500k+
   row). Ang Dashboard card na ito ay tinitignan nang paulit-ulit sa
   loob ng maikling panahon (page load, pag-switch ng tab, ilang user
   na magkasabay) kaya sa halip na paulit-ulit itong i-compute nang
   eksaktong parehong resulta, i-cache ito nang 60 segundo bawat
   natatanging (trimester, school year, department) na kombinasyon.
   Ang API ng Excel export (dashboard_stats_export.php) ay SADYANG
   HINDI dumadaan dito — laging live/uncached ang opisyal na export. */
$ascbDashCacheKey = 'dashboard_stats_v2_' . md5($trimester . '|' . $schoolYear . '|' . ($departmentId !== null ? $departmentId : 0));
$stats = ascb_cache_get($ascbDashCacheKey);
if ($stats === null) {
    $stats = ascb_dashboard_stats($pdo, $trimester, $departmentId, $schoolYear);
    ascb_cache_set($ascbDashCacheKey, $stats, 60);
}

echo json_encode(array(
    'ok'            => true,
    'totalEnrolled' => $stats['totalEnrolled'], // legacy key: unique students
    'totalUniqueStudents' => $stats['totalUniqueStudents'] ?? $stats['totalEnrolled'],
    'totalEnrollments' => $stats['totalEnrollments'] ?? null,
    'male'          => $stats['male'],
    'female'        => $stats['female'],
    'byCourse'      => $stats['byCourse'],
));
