<?php
/* =========================================================
   API: EXPORT DASHBOARD STATS AS EXCEL
   ---------------------------------------------------------
   "Report" button sa Dashboard > Enrollment Overview.
   Kinukuha ang PAREHONG datos na nakikita sa Dashboard
   (gamit ang parehong helper, includes/dashboard_stats_helper.php)
   at ini-export bilang totoong Excel file — hindi CSV, hindi
   HTML na pinapanggap na Excel. Gumagamit ng SpreadsheetML
   ("Excel XML") na format, kaya walang kailangang extension
   (hal. ZipArchive) — plain text lang ang output, bukas agad
   sa Excel.

   GET params: trimester   (opsyonal) — hal. "1st Trimester".
                            Blangko = lahat ng trimester (parehong
                            filter gaya ng nasa Dashboard).
               school_year (opsyonal) — hal. "2025-2026".
                            Blangko = lahat ng school year
                            (parehong filter gaya ng nasa Dashboard).
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/dashboard_stats_helper.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../config/db.php';

/* ADMIN STAFF: walang access sa pag-generate ng report. */
if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'generate_reports')) {
    http_response_code(403);
    exit('Forbidden');
}

// GET is used for a download link, so explicitly validate the session CSRF token.
$csrfToken = ascb_get($_GET, 'csrf', '');
if (!ascb_verify_csrf($csrfToken)) {
    http_response_code(403);
    exit('Expired o invalid ang request token. I-refresh ang page at subukan muli.');
}
$trimester = trim((string) ascb_get($_GET, 'trimester', ''));
$schoolYear = trim((string) ascb_get($_GET, 'school_year', ''));
/* DEAN: sariling Department lang ang laman ng export (hindi buong school). */
$exportDeptId = null; $exportDeptName = '';
if (ascb_get($ascbUser, 'role', '') === 'DEAN') {
    $exportDeptId = ascb_require_dean_department($pdo, $ascbUser);
    $dq = $pdo->prepare('SELECT name FROM departments WHERE id = ?');
    $dq->execute(array((int) $exportDeptId));
    $exportDeptName = (string) $dq->fetchColumn();
}
$stats = ascb_dashboard_stats($pdo, $trimester, $exportDeptId, $schoolYear);

$trimesterLabel  = ($trimester !== '') ? $trimester : 'All Trimesters';
$schoolYearLabel = ($schoolYear !== '') ? $schoolYear : 'All School Years';
$generatedAt     = date('F j, Y g:i A');

function ascb_xls_text($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function ascb_xls_string_cell($value, $styleId = '') {
    $style = $styleId ? ' ss:StyleID="' . $styleId . '"' : '';
    return '<Cell' . $style . '><Data ss:Type="String">' . ascb_xls_text($value) . '</Data></Cell>';
}

function ascb_xls_number_cell($value, $styleId = '') {
    $style = $styleId ? ' ss:StyleID="' . $styleId . '"' : '';
    return '<Cell' . $style . '><Data ss:Type="Number">' . (int) $value . '</Data></Cell>';
}

$rowsXml = '';

/* Title + meta */
$rowsXml .= '<Row><Cell ss:MergeAcross="3" ss:StyleID="Title"><Data ss:Type="String">ASCB REGISTRAR - ENROLLMENT OVERVIEW</Data></Cell></Row>';
$rowsXml .= '<Row>' . ascb_xls_string_cell('School Year:', 'Label') . ascb_xls_string_cell($schoolYearLabel) . '</Row>';
$rowsXml .= '<Row>' . ascb_xls_string_cell('Trimester:', 'Label') . ascb_xls_string_cell($trimesterLabel) . '</Row>';
if ($exportDeptName !== '') { $rowsXml .= '<Row>' . ascb_xls_string_cell('Department:', 'Label') . ascb_xls_string_cell($exportDeptName) . '</Row>'; }
$rowsXml .= '<Row>' . ascb_xls_string_cell('Generated:', 'Label') . ascb_xls_string_cell($generatedAt) . '</Row>';
$rowsXml .= '<Row></Row>';

/* Overall summary — parehong 3 cards sa Dashboard */
$rowsXml .= '<Row>' . ascb_xls_string_cell('Total Enrolled', 'Header') . ascb_xls_number_cell($stats['totalEnrolled']) . '</Row>';
$rowsXml .= '<Row>' . ascb_xls_string_cell('Male', 'Header') . ascb_xls_number_cell($stats['male']) . '</Row>';
$rowsXml .= '<Row>' . ascb_xls_string_cell('Female', 'Header') . ascb_xls_number_cell($stats['female']) . '</Row>';
$rowsXml .= '<Row></Row>';

/* Per-course breakdown — parehong laman ng dashboard cards kada course */
$rowsXml .= '<Row>'
    . ascb_xls_string_cell('Course / Program', 'Header')
    . ascb_xls_string_cell('Male', 'Header')
    . ascb_xls_string_cell('Female', 'Header')
    . ascb_xls_string_cell('Total', 'Header')
    . '</Row>';

foreach ($stats['byCourse'] as $row) {
    $rowsXml .= '<Row>'
        . ascb_xls_string_cell($row['course'])
        . ascb_xls_number_cell($row['male'])
        . ascb_xls_number_cell($row['female'])
        . ascb_xls_number_cell($row['total'])
        . '</Row>';
}

$xml = '<?xml version="1.0"?>' . "\n"
    . '<?mso-application progid="Excel.Sheet"?>' . "\n"
    . '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" '
    . 'xmlns:o="urn:schemas-microsoft-com:office:office" '
    . 'xmlns:x="urn:schemas-microsoft-com:office:excel" '
    . 'xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">'
    . '<Styles>'
    . '<Style ss:ID="Title"><Font ss:Bold="1" ss:Size="14"/></Style>'
    . '<Style ss:ID="Label"><Font ss:Bold="1"/></Style>'
    . '<Style ss:ID="Header"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#123E67" ss:Pattern="Solid"/></Style>'
    . '</Styles>'
    . '<Worksheet ss:Name="Enrollment Overview">'
    . '<Table>'
    . $rowsXml
    . '</Table>'
    . '</Worksheet>'
    . '</Workbook>';

$safeSchoolYear = ($schoolYear !== '') ? preg_replace('/[^A-Za-z0-9]+/', '_', $schoolYear) : 'AllYears';
$safeTrimester  = ($trimester !== '') ? preg_replace('/[^A-Za-z0-9]+/', '_', $trimester) : 'All';
$filename = 'Enrollment_Overview_' . $safeSchoolYear . '_' . $safeTrimester . '_' . date('Ymd') . '.xls';

/* api_guard.php nagset na ng Content-Type: application/json —
   i-override natin dito dahil Excel file ang ipapadala (parehong
   the same file-stream pattern). */
header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('X-Content-Type-Options: nosniff');
echo $xml;
exit;
