<?php
/* =========================================================
   DASHBOARD REPORT: SUMMARY OF ENROLLMENT (PDF)
   ---------------------------------------------------------
   Uses the Dashboard's enrollment records but renders the
   official-style Summary of Enrollment layout supplied by
   the Registrar: A4 portrait, ASCB letterhead, AY + 1st/2nd/3rd
   trimester columns, Male/Female/Total, program/year rows,
   subtotals, and Prepared by / Noted blocks.
   ========================================================= */
require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../includes/programs_helper.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/simple_pdf.php';

/* ADMIN STAFF: walang access sa pag-generate ng report. */
if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'generate_reports')) {
    http_response_code(403);
    exit('Forbidden');
}

$csrfToken = ascb_get($_GET, 'csrf', '');
if (!ascb_verify_csrf($csrfToken)) {
    http_response_code(403);
    exit('Expired o invalid ang request token. I-refresh ang page at subukan muli.');
}

$schoolYear = trim((string)ascb_get($_GET, 'school_year', ''));

/* Optional scoping: pwedeng i-limit ng user ang report sa isang
   Department lang, at (kung may Department na) sa isang partikular
   na Course/Program lang sa loob niyon — parehong dropdown gaya ng
   ginagamit sa Department Export. Isang DEAN account ay laging
   naka-lock sa sarili niyang Department, anuman ang ipinasa dito. */
$role = ascb_get($ascbUser, 'role', '');
$departmentId = (int) ascb_get($_GET, 'department_id', 0);
$programId = (int) ascb_get($_GET, 'program_id', 0);
if ($role === 'DEAN') $departmentId = ascb_require_dean_department($pdo, $ascbUser);

$filterDeptName = '';
$filterProgramLabel = '';
if ($programId) {
    $pc = $pdo->prepare('SELECT id, code, course_name, major, department_id FROM programs WHERE id = ?');
    $pc->execute(array($programId));
    $progRow = $pc->fetch();
    if (!$progRow) { http_response_code(400); exit('Invalid Course.'); }
    if ($departmentId && (int)$progRow['department_id'] !== $departmentId) {
        http_response_code(400); exit('Invalid Course for the selected Department.');
    }
    if (!$departmentId) $departmentId = (int)$progRow['department_id'];
    $filterProgramLabel = trim((string)$progRow['course_name']);
    if ($progRow['major']) $filterProgramLabel .= ' — ' . $progRow['major'];
    if ($filterProgramLabel === '') $filterProgramLabel = (string)$progRow['code'];
}
if ($departmentId) {
    $dc = $pdo->prepare('SELECT name FROM departments WHERE id = ?');
    $dc->execute(array($departmentId));
    $filterDeptName = (string)$dc->fetchColumn();
    if ($filterDeptName === '') { http_response_code(404); exit('Department not found.'); }
}

/* A Summary of Enrollment is inherently school-year based. If the
   Dashboard filter is blank, use the latest school year present in
   the enrollment data instead of silently combining multiple years. */
if ($schoolYear === '') {
    $st = $pdo->query("SELECT school_year FROM enrollees WHERE school_year IS NOT NULL AND TRIM(school_year) <> '' ORDER BY school_year DESC LIMIT 1");
    $schoolYear = (string)$st->fetchColumn();
}
if ($schoolYear === '') $schoolYear = date('Y') . '-' . (date('Y') + 1);

/* (fix MAEd) Semester-based Program (hal. MAEd) ay naka-"1st/2nd Semester",
   kaya dati nawawala sila sa report. Kinukuha na lahat ng term; ang columns
   ay inaayos sa ibaba base sa aktuwal na datos. */
$trimTerms = array('1st Trimester','2nd Trimester','3rd Trimester');
$semTerms  = array('1st Semester','2nd Semester');
$terms = array_merge($trimTerms, $semTerms, array('Summer'));
$semSeen = false; $trimSeen = false;
$placeholders = implode(',', array_fill(0, count($terms), '?'));
$extraWhere = '';
$params = array_merge(array($schoolYear), $terms);
/* (fix BSIS) Ang Department/Course filter ay dating puro SQL join sa
   p.code = e.program_code, kaya ang enrollment na blangko o hindi-tugma
   ang program_code (hal. BSIS na galing sa Excel import na may bahagyang
   ibang spelling ng course) ay AUTOMATIKONG nawawala. Ngayon isinasama
   rin ang mga row na walang tugmang Program (p.id IS NULL) at ang
   tamang pag-filter ay ginagawa sa PHP pagkatapos i-resolve ang Program. */
$scopeSql = '';
$scopeParams = array();
if ($departmentId) {
    $scopeSql .= " AND COALESCE(e.department_id, p.department_id) = ?";
    $scopeParams[] = $departmentId;
}
if ($programId) {
    $scopeSql .= " AND p.id = ?";
    $scopeParams[] = $programId;
}
if ($scopeSql !== '') {
    $extraWhere = " AND ((1=1" . $scopeSql . ") OR p.id IS NULL)";
    $params = array_merge($params, $scopeParams);
}
$deptNames = array();
foreach ($pdo->query('SELECT id, name FROM departments')->fetchAll() as $dn) $deptNames[(int)$dn['id']] = (string)$dn['name'];
$sql = "
    SELECT e.id, e.student_id, e.program_code, e.course, e.major, e.year_level,
           e.sex, e.trimester, e.school_year,
           p.id AS program_row_id, COALESCE(e.department_id, p.department_id) AS eff_dept_id,
           p.course_name AS mapped_course_name, p.major AS mapped_major,
           d.name AS department_name
    FROM enrollees e
    LEFT JOIN programs p ON UPPER(TRIM(p.code)) = UPPER(TRIM(e.program_code))
    LEFT JOIN departments d ON d.id = COALESCE(e.department_id, p.department_id)
    WHERE e.archived_at IS NULL
      AND e.status <> 'rejected'
      AND e.school_year = ?
      AND e.trimester IN ({$placeholders})
      {$extraWhere}
    ORDER BY COALESCE(d.name,''), COALESCE(p.course_name,e.course,''), e.program_code, e.year_level, e.id
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$raw = $stmt->fetchAll();

/* Deduplicate a student within the same school-year/trimester/program/year.
   Normal enrollment data has a unique student/term constraint, but this
   keeps the report safe for legacy rows too. */
$data = array();
$seen = array();
$yearOrder = array('First Year'=>1,'1st Year'=>1,'Second Year'=>2,'2nd Year'=>2,'Third Year'=>3,'3rd Year'=>3,'Fourth Year'=>4,'4th Year'=>4,'Fifth Year'=>5,'5th Year'=>5);
$normalizeYear = function($v) use ($yearOrder) {
    $v = trim((string)$v);
    $map = array('1st'=>'First Year','2nd'=>'Second Year','3rd'=>'Third Year','4th'=>'Fourth Year','5th'=>'Fifth Year');
    foreach ($map as $prefix=>$full) if (stripos($v,$prefix) === 0) return $full;
    return $v !== '' ? $v : 'Unspecified';
};
foreach ($raw as $r) {
    $term = trim((string)$r['trimester']);
    if (in_array($term, $semTerms, true)) $semSeen = true;
    elseif ($term !== 'Summer') $trimSeen = true;
    $programCode = trim((string)$r['program_code']);
    $mappedName = trim((string)$r['mapped_course_name']);
    $mappedMajor = trim((string)$r['mapped_major']);
    $rowProgId = (int)$r['program_row_id'];
    $rowDeptId = (int)$r['eff_dept_id'];
    $rowDeptName = trim((string)$r['department_name']);
    /* (fix BSIS) Walang tugmang Program sa DB? Hanapin mula sa code/course/major
       text (hal. "Bachelor of Science in Information System" -> BSIS). */
    if ($rowProgId === 0 || $mappedName === '') {
        $hit = ascb_resolve_program($pdo, $r['program_code'], $r['course'], $r['major']);
        if ($hit) {
            $rowProgId = (int)$hit['id'];
            $programCode = trim((string)$hit['code']);
            $mappedName = trim((string)$hit['course_name']);
            $mappedMajor = trim((string)$hit['major']);
            if ($rowDeptId === 0 && !empty($hit['department_id'])) {
                $rowDeptId = (int)$hit['department_id'];
                if ($rowDeptName === '' && isset($deptNames[$rowDeptId])) $rowDeptName = $deptNames[$rowDeptId];
            }
        }
    }
    if ($departmentId && $rowDeptId !== $departmentId) continue;
    if ($programId && $rowProgId !== $programId) continue;
    $programName = $mappedName;
    if ($programName === '') $programName = trim((string)$r['course']);
    if ($programName === '') $programName = $programCode !== '' ? $programCode : 'Unspecified Program';
    $dept = $rowDeptName;
    if ($dept === '') $dept = 'TERTIARY';
    $year = $normalizeYear($r['year_level']);
    $sex = trim((string)$r['sex']);
    if ($sex !== 'Male' && $sex !== 'Female') $sex = 'Unknown';
    $programMajor = $mappedMajor;
    if ($programMajor === '') $programMajor = trim((string)$r['major']);
    $programKey = ($dept . '|' . $programCode . '|' . $programName . '|' . $programMajor);
    $key = $programKey . '|' . $year . '|' . $term;
    $studentKey = trim((string)$r['student_id']);
    if ($studentKey === '') $studentKey = 'ROW:' . (int)$r['id'];
    $dedupe = $key . '|' . $studentKey;
    if (isset($seen[$dedupe])) continue;
    $seen[$dedupe] = true;
    if (!isset($data[$programKey])) {
        $data[$programKey] = array('dept'=>$dept,'code'=>$programCode,'name'=>$programName,'major'=>$programMajor,'years'=>array());
    }
    if (!isset($data[$programKey]['years'][$year])) {
        $data[$programKey]['years'][$year] = array();
    }
    if (!isset($data[$programKey]['years'][$year][$term])) $data[$programKey]['years'][$year][$term] = array('Male'=>0,'Female'=>0,'Unknown'=>0);
    $data[$programKey]['years'][$year][$term][$sex]++;
}

/* (fix MAEd) Columns:
   Semester  -> 1st Semester, 2nd Semester, Summer
   Trimester -> 1st Trimester, 2nd Trimester, 3rd Trimester (walang Summer)
   Magkahalo -> 1st Sem, 2nd Sem, Summer, 1st Tri, 2nd Tri, 3rd Tri */
if ($semSeen && $trimSeen)  $terms = array('1st Semester','2nd Semester','Summer','1st Trimester','2nd Trimester','3rd Trimester');
elseif ($semSeen)           $terms = array('1st Semester','2nd Semester','Summer');
else                        $terms = array('1st Trimester','2nd Trimester','3rd Trimester');
$termLabels = $terms;

/* Sort departments, programs, and year levels. */
usort($data, function($a,$b){
    $c = strcasecmp($a['dept'],$b['dept']);
    if ($c !== 0) return $c;
    return strcasecmp($a['name'],$b['name']);
});
foreach ($data as &$p) {
    uksort($p['years'], function($a,$b) use ($yearOrder) {
        $aa = isset($yearOrder[$a]) ? $yearOrder[$a] : 99;
        $bb = isset($yearOrder[$b]) ? $yearOrder[$b] : 99;
        return $aa === $bb ? strcasecmp($a,$b) : ($aa < $bb ? -1 : 1);
    });
}
unset($p);

/* Aggregate subtotals for each program and all-program totals. */
$allTotals = array();
foreach ($data as $pk=>$p) {
    $programSubtotal = array();
    foreach ($terms as $term) $programSubtotal[$term] = array('Male'=>0,'Female'=>0,'Total'=>0);
    foreach ($p['years'] as $year=>$termsData) {
        foreach ($terms as $term) {
            $m = isset($termsData[$term]['Male']) ? $termsData[$term]['Male'] : 0;
            $f = isset($termsData[$term]['Female']) ? $termsData[$term]['Female'] : 0;
            $programSubtotal[$term]['Male'] += $m;
            $programSubtotal[$term]['Female'] += $f;
            $programSubtotal[$term]['Total'] += $m+$f;
            if (!isset($allTotals[$term])) $allTotals[$term] = array('Male'=>0,'Female'=>0,'Total'=>0);
            $allTotals[$term]['Male'] += $m;
            $allTotals[$term]['Female'] += $f;
            $allTotals[$term]['Total'] += $m+$f;
        }
    }
    $data[$pk]['subtotal'] = $programSubtotal;
}


/* ---- Course label: "Course — Major"; add the program code only when two
   courses in the same Department would otherwise look identical. ---- */
$labelCount = array();
foreach ($data as $pk=>$p) {
    $lbl = $p['name'] . ($p['major'] !== '' ? ' — ' . $p['major'] : '');
    $data[$pk]['label'] = $lbl;
    $lk = strtolower($p['dept'] . '|' . $lbl);
    $labelCount[$lk] = isset($labelCount[$lk]) ? $labelCount[$lk] + 1 : 1;
}
foreach ($data as $pk=>$p) {
    $lk = strtolower($p['dept'] . '|' . $p['label']);
    if ($labelCount[$lk] > 1 && $p['code'] !== '') $data[$pk]['label'] .= ' (' . $p['code'] . ')';
}

/* ---- Group Course rows under their Department, and total each one. ---- */
$emptyTerms = function() use ($terms) {
    $t = array(); foreach ($terms as $term) $t[$term] = array('Male'=>0,'Female'=>0,'Total'=>0); return $t;
};
$byDept = array();
foreach ($data as $p) {
    if (!isset($byDept[$p['dept']])) $byDept[$p['dept']] = array('programs'=>array(), 'total'=>$emptyTerms());
    $byDept[$p['dept']]['programs'][] = $p;
    foreach ($terms as $term) foreach (array('Male','Female','Total') as $c) $byDept[$p['dept']]['total'][$term][$c] += $p['subtotal'][$term][$c];
}
/* Records with no Sex recorded can't go in the Male/Female columns; they
   are counted in Total only (and footnoted) so the report never
   under-counts compared with the Dashboard. */
$unknownSex = 0;
foreach ($data as $p) foreach ($p['years'] as $td) foreach ($td as $c) $unknownSex += $c['Unknown'];

$headerJpg = __DIR__ . '/../Header_ASCB_Report.jpg';
$watermarkJpg = __DIR__ . '/../ASCB_LOGO_watermark.jpg';
$pdf = new ASCB_SimplePDF();
$PW = $pdf->pageWidth(); $PH = $pdf->pageHeight();   // Short bond / Letter, same paper as the Certificates

$filterLine = '';
if ($filterDeptName !== '') {
    $filterLine = $filterDeptName;
    if ($filterProgramLabel !== '') $filterLine .= ' — ' . $filterProgramLabel;
}

/* Table geometry: 572pt wide (20pt side margins, same as the letterhead). */
$X0 = 20; $W0 = count($terms) > 4 ? 152 : 188;
$GROUP = min(128, (572 - $W0) / count($terms)); $COL = $GROUP / 3;
$SMALL = ($GROUP < 90);             // 6 columns: mas maliit na font
$FS = $SMALL ? 8 : 10; $HFS = $SMALL ? 7.5 : 9.5; $TABLE_W = $W0 + count($terms) * $GROUP;
$ROW_H = 21; $TABLE_TOP = 222; $PAGE_LIMIT = $PH - 30;

$drawHeader = function($pdf) use ($schoolYear, $watermarkJpg, $headerJpg, $filterLine, $PW, $PH) {
    $pdf->setFillGray(0.0);
    $pdf->setStrokeGray(0.35);
    /* Watermark FIRST so it sits behind everything else on the page. Same
       logo, size (5.4in) and 10% opacity as the Certificate of Enrollment,
       centered on the paper. */
    if (file_exists($watermarkJpg)) {
        $wm = 5.4 * 72;
        $pdf->imageJpeg($watermarkJpg, ($PW - $wm) / 2, ($PH - $wm) / 2, $wm, $wm, 0.10);
    }
    if (file_exists($headerJpg)) $pdf->imageJpeg($headerJpg, 20, 18, 572, 126);   // letterhead
    $pdf->text($PW / 2, 172, 'SUMMARY OF ENROLLMENT', 18, true, 'center');
    $pdf->text($PW / 2, 194, $schoolYear, 14, true, 'center');
    if ($filterLine !== '') {
        $f = $pdf->fitText($filterLine, 560, 10.5, false, 8);
        $pdf->text($PW / 2, 210, $f[0], $f[1], false, 'center');
    }
};

$drawTableHeader = function($pdf, $schoolYear, &$y) use ($X0, $W0, $GROUP, $COL, $terms, $termLabels, $SMALL, $HFS) {
    $h1 = 27; $h2 = 23; $h3 = 23;
    $pdf->fillRect($X0, $y, $W0 + count($terms) * $GROUP, $h1 + $h2 + $h3, 0.78, 0.85, 0.93, 0.55);
    $pdf->rect($X0, $y, $W0, $h1 + $h2 + $h3, false);
    foreach ($terms as $g => $term) {
        $pdf->rect($X0 + $W0 + $g * $GROUP, $y, $GROUP, $h1, false);
        $pdf->rect($X0 + $W0 + $g * $GROUP, $y + $h1, $GROUP, $h2, false);
        for ($c = 0; $c < 3; $c++) $pdf->rect($X0 + $W0 + $g * $GROUP + $c * $COL, $y + $h1 + $h2, $COL, $h3, false);
    }
    $pdf->text($X0 + $W0 / 2, $y + 38, 'TERTIARY', 11, true, 'center');
    $names = $termLabels;
    foreach ($names as $g => $term) {
        $gx = $X0 + $W0 + $g * $GROUP + $GROUP / 2;
        $pdf->text($gx, $y + 18, 'AY ' . $schoolYear, $HFS, true, 'center');
        $pdf->text($gx, $y + $h1 + 15, $names[$g], $HFS, true, 'center');
        foreach (($SMALL ? array('M', 'F', 'Total') : array('Male', 'Female', 'Total')) as $c => $label)
            $pdf->text($X0 + $W0 + $g * $GROUP + $c * $COL + $COL / 2, $y + $h1 + $h2 + 15, $label, $HFS, true, 'center');
    }
    $y += $h1 + $h2 + $h3;
};

$y = 0;
$currentDept = null;
$newPage = function() use ($pdf, $drawHeader, $drawTableHeader, $schoolYear, &$y, &$currentDept, $TABLE_TOP) {
    $pdf->finishPage(); $pdf->addPage(); $drawHeader($pdf);
    $y = $TABLE_TOP; $drawTableHeader($pdf, $schoolYear, $y);
    $currentDept = null;   // repeat the Department row on the continuation page
};
/* Make sure $need points fit on this page, otherwise start a new one. */
$ensure = function($need) use (&$y, $PAGE_LIMIT, $newPage) { if ($y + $need > $PAGE_LIMIT) $newPage(); };

/* A row of the table. $style: 'year' (centered label), 'sub' (Sub-Total),
   'total' (Department / Grand total). */
$drawRow = function($label, $counts, $style) use ($pdf, &$y, $terms, $X0, $W0, $GROUP, $COL, $ROW_H, $TABLE_W, $FS) {
    if ($style !== 'year') $pdf->fillRect($X0, $y, $TABLE_W, $ROW_H, 0.85, 0.88, 0.93, $style === 'total' ? 0.6 : 0.35);
    $pdf->rect($X0, $y, $W0, $ROW_H, false);
    foreach ($terms as $g => $term) $pdf->rect($X0 + $W0 + $g * $GROUP, $y, $GROUP, $ROW_H, false);
    foreach ($terms as $g => $term) for ($c = 0; $c < 3; $c++)
        if ($c > 0) $pdf->line($X0 + $W0 + $g * $GROUP + $c * $COL, $y, $X0 + $W0 + $g * $GROUP + $c * $COL, $y + $ROW_H, 0.5);
    $lb = ($style === 'total');
    $f = $pdf->fitText($label, $W0 - 12, 10, $lb, 8);
    if ($style === 'year') $pdf->text($X0 + $W0 / 2, $y + 14, $f[0], $f[1], false, 'center');
    else                   $pdf->text($X0 + 6, $y + 14, $f[0], $f[1], $lb, 'left');
    foreach ($terms as $g => $term) {
        $has = isset($counts[$term]);
        $m = $has && isset($counts[$term]['Male']) ? $counts[$term]['Male'] : 0;
        $fe = $has && isset($counts[$term]['Female']) ? $counts[$term]['Female'] : 0;
        $t = $has && isset($counts[$term]['Total']) ? $counts[$term]['Total'] : ($m + $fe + ($has && isset($counts[$term]['Unknown']) ? $counts[$term]['Unknown'] : 0));
        $bold = ($style !== 'year');
        /* Like the official sheet: a trimester with no records yet shows
           blank Male/Female and a 0 Total on year rows. */
        $cells = ($style === 'year' && !$has) ? array('', '', '0') : array((string)$m, (string)$fe, (string)$t);
        foreach ($cells as $c => $v)
            if ($v !== '') $pdf->text($X0 + $W0 + $g * $GROUP + $c * $COL + $COL / 2, $y + 14, $v, $FS, $bold, 'center');
    }
    $y += $ROW_H;
};
/* A full-width label row (Department / Course heading). */
$drawBand = function($label, $bold, $shade) use ($pdf, &$y, $X0, $TABLE_W, $ROW_H) {
    if ($shade) $pdf->fillRect($X0, $y, $TABLE_W, $ROW_H, 0.85, 0.88, 0.93, 0.6);
    $pdf->rect($X0, $y, $TABLE_W, $ROW_H, false);
    $f = $pdf->fitText($label, $TABLE_W - 14, 10.5, $bold, 8);
    $pdf->text($X0 + 7, $y + 14, $f[0], $f[1], $bold, 'left');
    $y += $ROW_H;
};

$pdf->addPage(); $drawHeader($pdf);
$y = $TABLE_TOP; $drawTableHeader($pdf, $schoolYear, $y);

if (empty($data)) {
    $drawRow('No enrollment records found', array(), 'year');
}

foreach ($byDept as $deptName => $dept) {
    foreach ($dept['programs'] as $p) {
        /* Keep a Course block together: heading + year rows + Sub-Total. */
        $block = ($currentDept !== $deptName ? $ROW_H : 0) + $ROW_H + count($p['years']) * $ROW_H + $ROW_H;
        if ($block <= ($PAGE_LIMIT - $TABLE_TOP - 73)) $ensure($block); else $ensure($ROW_H * 3);
        if ($currentDept !== $deptName) { $currentDept = $deptName; $drawBand($deptName, true, true); }
        $drawBand($p['label'], true, false);
        foreach ($p['years'] as $year => $termsData) { $ensure($ROW_H * 2); $drawRow($year, $termsData, 'year'); }
        $ensure($ROW_H);
        $drawRow('Sub-Total', $p['subtotal'], 'sub');
    }
    if (count($dept['programs']) > 1) { $ensure($ROW_H); $drawRow('Department Total', $dept['total'], 'total'); }
}
if (count($byDept) > 1) { $ensure($ROW_H); $drawRow('GRAND TOTAL', $allTotals, 'total'); }

if ($unknownSex > 0) {
    $ensure(16);
    $pdf->text($X0, $y + 12, 'Note: ' . $unknownSex . ' record(s) with no Sex recorded are counted in Total only.', 8, false, 'left');
    $y += 16;
}

/* Prepared by / Noted — same placement as the official sheet. */
$sigH = 116;
$y += 50;
if ($y + $sigH > $PAGE_LIMIT) { $pdf->finishPage(); $pdf->addPage(); $drawHeader($pdf); $y = $TABLE_TOP; }
$pdf->text(60, $y, 'Prepared by:', 9, false, 'left');
$pdf->text(150, $y + 34, 'REBECCA P. CAPONONG, MAEd', 10, true, 'center');
$pdf->text(150, $y + 48, 'School Registrar', 9, false, 'center');
$pdf->text(360, $y + 72, 'Noted:', 9, false, 'left');
$pdf->text(475, $y + 100, 'ANREY G. ANTIQUINA, PhD', 10, true, 'center');
$pdf->text(475, $y + 114, 'Acting School President', 9, false, 'center');

$pdf->finishPage();
$safe = preg_replace('/[^A-Za-z0-9_-]+/','_', $schoolYear);
$fileParts = array('SUMMARY_OF_ENROLLMENT', $safe);
if ($filterDeptName !== '') $fileParts[] = preg_replace('/[^A-Za-z0-9_-]+/','_', $filterDeptName);
if ($filterProgramLabel !== '') $fileParts[] = preg_replace('/[^A-Za-z0-9_-]+/','_', $filterProgramLabel);
$pdf->output(implode('_', $fileParts) . '.pdf');
