<?php
/* ASCB Registrar — browser SQL backup, memory-bounded and streamed. */
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../config/db.php';

$role = ascb_get($ascbUser, 'role', '');
if (!in_array($role, array('UNIT HEAD', 'SCHOOL REGISTRAR'), true)) { http_response_code(403); exit('Forbidden'); }
$csrfToken = ascb_get($_GET, 'csrf', '');
if (!ascb_verify_csrf($csrfToken)) { http_response_code(403); exit('Expired o invalid ang request token. I-refresh ang page at subukan muli.'); }

// Separate unbuffered connection: PDO MySQL otherwise buffers SELECT * results in client memory.
$dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
$backupPdo = new PDO($dsn, DB_USER, DB_PASS, array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => false,
));
$backupPdo->exec("SET time_zone = '+08:00'");

$filename = 'ASCB_FULL_BACKUP_' . date('Y-m-d_His') . '.sql';
header('Content-Type: application/sql; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');

$out = fopen('php://output', 'wb');
if (!$out) { http_response_code(500); exit('Unable to open backup stream'); }
$write = function($s) use ($out) { fwrite($out, $s); };
$write("-- ASCB Registrar Full Database Backup\n-- Generated: " . date('c') . "\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n");

// BASE TABLES only. Views are not treated as tables because DROP TABLE + CREATE VIEW is unsafe.
$tablesStmt = $backupPdo->query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'");
$tables = array();
while ($r = $tablesStmt->fetch(PDO::FETCH_NUM)) $tables[] = $r[0];
$tablesStmt->closeCursor();

foreach ($tables as $table) {
    $safe = str_replace('`', '``', $table);
    $create = $backupPdo->query("SHOW CREATE TABLE `$safe`")->fetch(PDO::FETCH_NUM);
    $write("DROP TABLE IF EXISTS `$safe`;\n" . $create[1] . ";\n\n");

    $stmt = $backupPdo->query("SELECT * FROM `$safe`");
    $columns = null;
    $valueBatch = array();
    $batchSize = 250;
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if ($columns === null) {
            $columns = array_map(function($c){ return '`' . str_replace('`','``',$c) . '`'; }, array_keys($row));
        }
        $vals = array();
        foreach ($row as $v) $vals[] = ($v === null ? 'NULL' : $backupPdo->quote((string)$v));
        $valueBatch[] = '(' . implode(',', $vals) . ')';
        if (count($valueBatch) >= $batchSize) {
            $write('INSERT INTO `' . $safe . '` (' . implode(',', $columns) . ') VALUES ' . implode(',', $valueBatch) . ";\n");
            $valueBatch = array();
            if (function_exists('ob_flush')) @ob_flush(); flush();
        }
    }
    if ($valueBatch && $columns !== null) {
        $write('INSERT INTO `' . $safe . '` (' . implode(',', $columns) . ') VALUES ' . implode(',', $valueBatch) . ";\n");
    }
    $stmt->closeCursor();
    $write("\n");
}
$write("SET FOREIGN_KEY_CHECKS=1;\n");
fclose($out);

try {
    $b = $pdo->prepare("INSERT INTO backup_history(backup_type,filename,created_by_user_id) VALUES('FULL_SQL',?,?)");
    $b->execute(array($filename, (int)ascb_get($ascbUser,'id',0)));
    ascb_log_activity($pdo, $ascbUser, 'FULL_DATABASE_BACKUP', 'database', 'ascb_registrar', $filename);
} catch (Exception $e) { error_log('ASCB browser backup log failed: ' . $e->getMessage()); }
