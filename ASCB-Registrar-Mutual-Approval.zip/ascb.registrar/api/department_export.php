<?php
/*
 * ASCB Registrar — Large-data Department Export
 *
 * Exports CSV (UTF-8 BOM, Excel-compatible) in bounded batches.
 * This intentionally does NOT generate legacy HTML .xls because BIFF .xls
 * has a 65,536-row limit. CSV can safely exceed 100k rows.
 */
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../config/db.php';

$role = ascb_get($ascbUser, 'role', '');
if (!ascb_can($role, 'export_department')) {
    http_response_code(403); exit('Forbidden');
}

$csrfToken = ascb_get($_GET, 'csrf', '');
if (!ascb_verify_csrf($csrfToken)) {
    http_response_code(403);
    exit('Expired o invalid ang request token. I-refresh ang page at subukan muli.');
}

$departmentId = (int) ascb_get($_GET, 'department_id', 0);
$programId = (int) ascb_get($_GET, 'program_id', 0);
$sy = trim((string) ascb_get($_GET, 'school_year', ''));
$term = trim((string) ascb_get($_GET, 'term', ''));
if ($role === 'DEAN') $departmentId = ascb_require_dean_department($pdo, $ascbUser);
if (!$departmentId) { http_response_code(400); exit('Department required'); }

// If a Course/Program is specified, make sure it actually belongs to this Department.
if ($programId) {
    $pc = $pdo->prepare('SELECT id FROM programs WHERE id=? AND department_id=?');
    $pc->execute(array($programId, $departmentId));
    if (!$pc->fetch()) { http_response_code(400); exit('Invalid Course for the selected Department'); }
}

$d = $pdo->prepare('SELECT code,name FROM departments WHERE id=?');
$d->execute(array($departmentId));
$dep = $d->fetch();
if (!$dep) { http_response_code(404); exit('Department not found'); }

$prog = null;
if ($programId) {
    $pn = $pdo->prepare('SELECT code,course_name,term_type FROM programs WHERE id=?');
    $pn->execute(array($programId));
    $prog = $pn->fetch();
}

/* (fix Semester) Kapag Semester-based ang napiling Course (hal. MAED) at
   "Nth Trimester" ang napili sa Term filter, gawing katumbas na "Nth
   Semester" — at isama rin ang lumang record na nai-save bilang "Nth
   Trimester" para hindi mawala sa export. */
$termFilterValues = array();
if ($prog && $term !== '' && isset($prog['term_type']) && $prog['term_type'] === 'Semester'
    && preg_match('/^(\d+)\s*(?:st|nd|rd|th)?\s*(?:trimester|semester)?$/i', $term, $tm) && (int) $tm[1] >= 1 && (int) $tm[1] <= 2) {
    $n = (int) $tm[1];
    $sfx = ($n === 1) ? 'st' : 'nd';
    $term = $n . $sfx . ' Semester';
    $termFilterValues = array($n . $sfx . ' Semester', $n . $sfx . ' Trimester');
}

$filename = 'ASCB_' . preg_replace('/[^A-Za-z0-9_-]+/', '_', $dep['code']) .
    ($prog ? '_' . preg_replace('/[^A-Za-z0-9_-]+/', '_', $prog['code']) : '') . '_' .
    ($sy ?: 'ALL_SY') . '_' . ($term ? preg_replace('/\s+/', '_', $term) : 'ALL_TERMS') . '_' . date('Y-m-d') . '.csv';

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');

$out = fopen('php://output', 'wb');
if (!$out) { http_response_code(500); exit('Unable to open export stream'); }

// UTF-8 BOM makes the CSV open cleanly in modern Microsoft Excel.
fwrite($out, "\xEF\xBB\xBF");
fputcsv($out, array('ASCB Department Student Data Export'));
fputcsv($out, array('Department', $dep['name'] . ' (' . $dep['code'] . ')'));
fputcsv($out, array('School Year', $sy !== '' ? $sy : 'All', 'Term', $term !== '' ? $term : 'All'));
fputcsv($out, array());
fputcsv($out, array('Student ID','Surname','Given Name','Middle Name','Birthdate','Student Type','Program Code','Program','Major','Year Level','Term','School Year','Subject Code','Subject Description','Grade','Units'));

$where = array(
    'e.archived_at IS NULL',
    "e.status <> 'rejected'",
    '(e.department_id=? OR (e.department_id IS NULL AND p.department_id=?))'
);
$paramsBase = array($departmentId, $departmentId);
if ($programId) { $where[] = 'p.id=?'; $paramsBase[] = $programId; }
if ($sy !== '') { $where[] = 'e.school_year=?'; $paramsBase[] = $sy; }
if ($term !== '') {
    if (count($termFilterValues) > 1) {
        $where[] = 'e.trimester IN (' . implode(',', array_fill(0, count($termFilterValues), '?')) . ')';
        foreach ($termFilterValues as $tv) $paramsBase[] = $tv;
    } else {
        $where[] = 'e.trimester=?'; $paramsBase[] = $term;
    }
}
$whereSql = implode(' AND ', $where);

$batchSize = 500;
$lastId = 0;
$totalRows = 0;
$firstBatch = true;

// "Month Day, Year" gamit ang buong pangalan ng buwan (hindi numero) —
// hal. "January 5, 2000" — para sa Birthdate column ng export.
/* Student ID is exported exactly as stored in the ASCB enrollment record.
   Do NOT rebuild/reformat it from the Excel source or from numeric values.
   The database value is the system's source of truth (e.g. 2026-00005). */
function ascb_export_student_id($rawStudentId) {
    return trim((string) $rawStudentId);
}

function ascb_export_format_birthdate($rawDate) {
    if (!$rawDate) return '';
    $d = DateTime::createFromFormat('Y-m-d', $rawDate);
    if (!$d || $d->format('Y-m-d') !== $rawDate) return $rawDate;
    return $d->format('F j, Y');
}

while (true) {
    $sql = "SELECT e.id AS enrollment_id,e.student_id,
                   e.surname,e.first_name,e.middle_name" . ascb_suffix_sql_cols($pdo) . ",e.birth_date,
                   e.student_type,e.program_code,e.course,e.major,e.year_level,e.trimester,e.school_year,e.status,e.subjects_json,
                   p.code AS program_db_code,p.course_name AS program_db_name,p.major AS program_db_major,p.term_type AS program_term_type
            FROM enrollees e
            LEFT JOIN programs p ON UPPER(TRIM(p.code))=UPPER(TRIM(e.program_code))
            WHERE e.id>? AND $whereSql
            ORDER BY e.id ASC
            LIMIT $batchSize";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array_merge(array($lastId), $paramsBase));
    $enrollees = array_map('ascb_row_print_split', $stmt->fetchAll(PDO::FETCH_ASSOC)); /* PSA placement ng suffix */
    $stmt->closeCursor();
    if (!$enrollees) break;

    $lastId = (int) $enrollees[count($enrollees)-1]['enrollment_id'];
    $ids = array_column($enrollees, 'enrollment_id');
    $byEnrollment = array();

    // Only load subjects for the current 500-enrollment batch.
    if ($ids) {
        $in = implode(',', array_fill(0, count($ids), '?'));
        $es = $pdo->prepare("SELECT es.enrollment_id,es.course_code,es.description,es.units,g.grade
                             FROM enrollment_subjects es
                             LEFT JOIN grades g ON g.enrollment_subject_id=es.id
                             WHERE es.enrollment_id IN ($in)
                             ORDER BY es.enrollment_id,es.id");
        $es->execute($ids);
        while ($r = $es->fetch(PDO::FETCH_ASSOC)) {
            $byEnrollment[$r['enrollment_id']][] = $r;
        }
        $es->closeCursor();
    }

    foreach ($enrollees as $e) {
        $programCode = $e['program_code'] ?: $e['program_db_code'];
        $courseName = $e['course'] ?: $e['program_db_name'];
        $major = $e['major'] ?: $e['program_db_major'];
        /* (fix Semester) Semester-based ang Program -> "Semester" ang isusulat sa
           Term column (hindi "Trimester"), para Semester din ang mabasa ng import. */
        $termOut = (string) $e['trimester'];
        if (isset($e['program_term_type']) && $e['program_term_type'] === 'Semester') {
            $termOut = preg_replace('/\bTrimester\b/i', 'Semester', $termOut);
        }
        $base = array(
            ascb_export_student_id($e['student_id']), $e['surname'], $e['first_name'], $e['middle_name'], ascb_export_format_birthdate($e['birth_date']), $e['student_type'], $programCode,
            $courseName, $major, $e['year_level'], $termOut, $e['school_year']
        );
        $subjects = isset($byEnrollment[$e['enrollment_id']]) ? $byEnrollment[$e['enrollment_id']] : array();

        if ($subjects) {
            $first = true;
            foreach ($subjects as $sub) {
                fputcsv($out, array_merge($first ? $base : array('', '', '', '', '', '', '', '', '', '', '', ''), array(
                    $sub['course_code'], $sub['description'], ascb_clean_numeric_string($sub['grade']), ascb_clean_numeric_string($sub['units'])
                )));
                $first = false;
                $totalRows++;
            }
        } elseif (!empty($e['subjects_json'])) {
            $legacy = json_decode($e['subjects_json'], true);
            if (is_array($legacy) && count($legacy)) {
                $first = true;
                foreach ($legacy as $lsub) {
                    fputcsv($out, array_merge($first ? $base : array('', '', '', '', '', '', '', '', '', '', '', ''), array(
                        ascb_get($lsub, 'code', ''), ascb_get($lsub, 'description', ''),
                        ascb_clean_numeric_string(ascb_get($lsub, 'grade', '')), ascb_clean_numeric_string(ascb_get($lsub, 'units', ''))
                    )));
                    $first = false;
                    $totalRows++;
                }
            } else {
                fputcsv($out, array_merge($base, array('', '', '', ''))); $totalRows++;
            }
        } else {
            fputcsv($out, array_merge($base, array('', '', '', ''))); $totalRows++;
        }
    }

    // Release the current batch before the next query.
    unset($enrollees, $ids, $byEnrollment);
    if (function_exists('gc_collect_cycles')) gc_collect_cycles();
    if (function_exists('ob_flush')) @ob_flush();
    flush();
}

if ($totalRows === 0) {
    $pc = $pdo->prepare('SELECT COUNT(*) FROM programs WHERE department_id=?');
    $pc->execute(array($departmentId));
    $programCount = (int) $pc->fetchColumn();
    fputcsv($out, array('No student records found.', $programCount ?
        'The Department has assigned Programs, but no matching active enrollment records were found for the selected filters.' :
        'No Programs are assigned to this Department yet.'));
}

fclose($out);
try {
    $b = $pdo->prepare("INSERT INTO backup_history(backup_type,department_id,school_year,term_label,filename,created_by_user_id) VALUES('DEPARTMENT_EXCEL',?,?,?,?,?)");
    $b->execute(array($departmentId, $sy ?: null, $term ?: null, $filename, (int) ascb_get($ascbUser, 'id', 0)));
    ascb_log_activity($pdo, $ascbUser, 'DEPARTMENT_EXCEL_EXPORT', 'department', $dep['name'], $filename);
} catch (Exception $e) {
    error_log('ASCB department export log failed: ' . $e->getMessage());
}
