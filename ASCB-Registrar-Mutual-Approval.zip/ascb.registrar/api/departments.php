<?php
require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../config/db.php';
$input=ascb_read_json_body();
$action=ascb_get($input,'action','list'); $role=ascb_get($ascbUser,'role','');
if(!ascb_has_column($pdo,'programs','department_id')){
  // Retry the automatic schema upgrade once, live, in case the earlier
  // attempt (on connect) hit a transient error.
  if (function_exists('ascb_ensure_department_schema')) { ascb_ensure_department_schema($pdo); }
  if(!ascb_has_column($pdo,'programs','department_id')){
    http_response_code(503);
    $detail = !empty($GLOBALS['ascb_department_schema_error']) ? $GLOBALS['ascb_department_schema_error'] : 'Hindi alam ang dahilan; i-check ang PHP error log ng server.';
    echo json_encode(array('ok'=>false,'error'=>'The Departments/Backup tables have not been set up. Detail: '.$detail.' — If this is due to missing ALTER/CREATE privileges, check the database MySQL user, or run database/migrate_master.php.'));
    exit;
  }
}
if($action==='list'){
  if($role==='DEAN'){
    $deanDept=ascb_require_dean_department($pdo,$ascbUser);
    $ls=$pdo->prepare("SELECT d.id,d.code,d.name,d.is_active,d.created_at,(SELECT COUNT(*) FROM programs p WHERE p.department_id=d.id) program_count,(SELECT COUNT(*) FROM users u WHERE u.department_id=d.id AND u.role='DEAN' AND u.is_active=1) dean_count FROM departments d WHERE d.id=? ORDER BY d.name");
    $ls->execute(array($deanDept));
    echo json_encode(array('ok'=>true,'departments'=>$ls->fetchAll()));exit;
  }
  $rows=$pdo->query("SELECT d.id,d.code,d.name,d.is_active,d.created_at,(SELECT COUNT(*) FROM programs p WHERE p.department_id=d.id) program_count,(SELECT COUNT(*) FROM users u WHERE u.department_id=d.id AND u.role='DEAN' AND u.is_active=1) dean_count FROM departments d ORDER BY d.name")->fetchAll();
  echo json_encode(array('ok'=>true,'departments'=>$rows));exit;
}
if(!ascb_can($role,'manage_departments')){http_response_code(403);echo json_encode(array('ok'=>false,'error'=>'Only UNIT HEAD or SCHOOL REGISTRAR can manage Departments.'));exit;}
if($action==='add'||$action==='update'){
  $id=(int)ascb_get($input,'id',0);$code=strtoupper(trim(ascb_get($input,'code','')));$name=trim(ascb_get($input,'name',''));$active=ascb_get($input,'isActive',1)?1:0;
  if($code===''||$name===''){http_response_code(400);echo json_encode(array('ok'=>false,'error'=>'Department Code and Name are required.'));exit;}
  try{
   if($action==='add'){$s=$pdo->prepare("INSERT INTO departments(code,name,is_active) VALUES(?,?,1)");$s->execute(array($code,$name));$id=$pdo->lastInsertId();ascb_log_activity($pdo,$ascbUser,'DEPARTMENT_ADD','department',$code.' — '.$name);}
   else{$s=$pdo->prepare("UPDATE departments SET code=?,name=?,is_active=? WHERE id=?");$s->execute(array($code,$name,$active,$id));ascb_log_activity($pdo,$ascbUser,'DEPARTMENT_UPDATE','department',$code.' — '.$name);}
   echo json_encode(array('ok'=>true,'id'=>$id));
  }catch(PDOException $e){http_response_code(400);echo json_encode(array('ok'=>false,'error'=>'Duplicate Department Code/Name o invalid data.'));}exit;
}
if($action==='delete'){
 $id=(int)ascb_get($input,'id',0);
 try {
   $pdo->beginTransaction();
   // DATABASE TRANSACTION HANDLING — ang COUNT check at ang DELETE ay
   // pinagsama sa isang transaction para hindi maisingit ang ibang
   // request (hal. isang bagong Program na nire-relate dito) sa
   // pagitan ng pagkuha ng bilang at ng aktwal na pagbura.
   $c=$pdo->prepare("SELECT COUNT(*) FROM programs WHERE department_id=? FOR UPDATE");
   $c->execute(array($id));
   if((int)$c->fetchColumn()>0){
     $pdo->rollBack();
     http_response_code(400);echo json_encode(array('ok'=>false,'error'=>'This Department still has Programs assigned to it. Please move those Programs first.'));exit;
   }
   $s=$pdo->prepare("DELETE FROM departments WHERE id=?");$s->execute(array($id));
   ascb_log_activity($pdo,$ascbUser,'DEPARTMENT_DELETE','department','#'.$id);
   $pdo->commit();
   echo json_encode(array('ok'=>true));exit;
 } catch (PDOException $e) {
   if ($pdo->inTransaction()) $pdo->rollBack();
   throw $e;
 }
}
http_response_code(400);echo json_encode(array('ok'=>false,'error'=>'Unknown action.'));
