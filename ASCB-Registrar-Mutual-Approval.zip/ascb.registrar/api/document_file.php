<?php
/* =========================================================
   API: SERVE A DOCUMENT FILE
   ---------------------------------------------------------
   Streams ang totoong PDF file ng isang naka-log na document
   transaction. Naka-login lang (via api_guard.php) ang
   pwedeng makakuha nito — hindi direkta ma-access ang mga PDF
   sa uploads/documents/ dahil naka-deny ito sa .htaccess.

   GET param: id = ID ng row sa document_transaction_files
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/file_stream.php';
require_once __DIR__ . '/../config/db.php';

/* (2024 audit fix) Dati, WALANG role check dito — kahit sinong naka-login
   (kasama ang DEAN) ay may access. Ang mga table na ito (Documents log,
   Approved SO, Course Files) ay general registrar-office records na
   walang Department-level na paghihiwalay sa schema, kaya sa halip na
   subukang mag-scope ng hindi maaasahang paraan, ang DEAN na lang (na
   read-only/scoped-to-own-department sa ibang modules) ang in-eexclude
   dito. Tingnan ang includes/permissions.php ('manage_office_records')
   kung kailangang baguhin ito. */
if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'manage_office_records')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'You do not have access to this module.'));
    exit;
}

$fileId = (int) ascb_get($_GET, 'id', 0);

if ($fileId <= 0) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Invalid file id.'));
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM document_transaction_files WHERE id = ?");
$stmt->execute(array($fileId));
$file = $stmt->fetch();

if (!$file) {
    http_response_code(404);
    echo json_encode(array('ok' => false, 'error' => 'File not found.'));
    exit;
}

$path = __DIR__ . '/../uploads/documents/' . $file['stored_filename'];

if (!is_file($path)) {
    http_response_code(404);
    echo json_encode(array('ok' => false, 'error' => 'File missing on server.'));
    exit;
}

// Nagdadagdag ng ETag/Last-Modified caching (304 sa paulit-ulit na
// pagtingin ng parehong file) at HTTP Range support (206, para sa
// mabilisang PDF scrubbing) — tingnan ang includes/file_stream.php.
ascb_stream_file($path, 'application/pdf', $file['original_filename'], true);
exit;
