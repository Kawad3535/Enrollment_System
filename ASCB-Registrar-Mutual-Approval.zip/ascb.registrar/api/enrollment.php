<?php /* V6 Enterprise hardening applied: pagination-ready, bounded responses, secure errors. */ ?>
<?php
/* =========================================================
   API: ENROLLMENT
   ---------------------------------------------------------
   Bawat entry = basic info ng estudyante: Surname, Given Name,
   Middle Name, Sex, Student Type (Regular/Transferee/Irregular),
   Birth Date, Address, Mobile Number, Previous
   School (Junior High) at Previous School (Senior High),
   Course/Program (+ Major kung meron), Year Level, Trimester,
   at ang mga Subjects na na-load mula sa prospectus (script.js).

   Bawat estudyante ay may "student_id" (auto-generated, hal.
   "2026-00001"): taon ng UNANG enrollment niya + 5-digit
   running number. Pareho ito sa lahat ng term/record niya
   (ginagamit ng "New Term" ang student_id ng lumang record
   sa halip na gumawa ng bago), at hindi na nagbabago sa
   "Update"/edit.

   APPROVAL WORKFLOW ("status"):
     - Kapag ADMIN STAFF ang nag-create/update ng record, awtomatikong
       "pending" ito — kailangan pang aprubahan ng UNIT HEAD o ng
       SCHOOL REGISTRAR (kahit sino sa dalawa, sapat na).
     - Kapag UNIT HEAD o SCHOOL REGISTRAR ang nag-create/update,
       awtomatikong "approved" agad.
     - UNIT HEAD o SCHOOL REGISTRAR lang (permission 'approve_enrollment')
       ang pwedeng gumamit ng action=approve / action=reject.

   GET  -> ibinabalik ang listahan ng mga enrollee (pinaka-bago
           muna). Params: q (search text, optional — humahanap
           sa surname/first name/middle name/course/major/mga
           previous school/student ID/mobile number), status
           (optional — "pending"/"approved", o "rejected" kapag
           scope=archived), scope (optional — "active" [default],
           "rejected", o "archived"; tingnan ang REJECTED /
           ARCHIVE sa ibaba).

   POST -> JSON body. Ang "action" field ang nagsasabi kung
           create / update / delete / restore / approve / reject:

           action=create : surname, firstName (required);
                            middleName, sex, studentType, birthDate, address,
                            mobileNumber, prevSchoolJuniorHs,
                            prevSchoolSeniorHs, programCode, course,
                            major, yearLevel, trimester, schoolYear,
                            subjects (array ng {code, description,
                            units, grade}) (optional);
                            studentId (optional — ipasa lang ito
                            kapag "New Term" ng ISANG estudyanteng
                            meron nang student_id, para hindi
                            gumawa ng bago)
           action=update : id (required) + enrollment fields gaya
                            ng create (student_id ay HINDI nababago dito) —
                            UNIT HEAD at ADMIN STAFF. Grades are NOT updated here.
                            (permission 'update_enrollment'). Kapag
                            ADMIN STAFF ang nag-update, babalik sa
                            "pending" ang record (tingnan sa ibaba).
           action=delete : id (required), reason (optional).
                            Kung HINDI pa naka-archive ang record,
                            ini-ARCHIVE lang ito (hindi tuluyang
                            binubura). Kung NAKA-ARCHIVE NA ito,
                            saka lang ito TULUYANG binubura sa
                            database (permanent delete).
           action=restore: id (required) — ibinabalik mula sa
                            Archive papunta sa normal na listahan.
           action=approve: id (required) — UNIT HEAD o SCHOOL REGISTRAR
           action=reject : id (required), remarks (optional) —
                            UNIT HEAD o SCHOOL REGISTRAR

   REJECTED / ARCHIVE:
     - Kapag "rejected" na ang isang record, HINDI na ito lumalabas
       sa Grade Evaluation o sa normal na Enrollment / New Term
       list (scope=active) — makikita na lang ito sa "Rejected
       Students" menu (scope=rejected), hanggang aksyunan pa
       (Update, o Delete/Archive).
     - Kapag "na-delete" ang isang enrollee kahit saan (Enrollment,
       New Term, o Rejected Students), hindi ito tuluyang nabubura
       sa database — inililipat lang ito sa "Archive" menu
       (scope=archived), para sa mga estudyanteng nag-drop o
       tinanggal sa listahan.
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../includes/cache.php';
require_once __DIR__ . '/../includes/master_record_helper.php';
require_once __DIR__ . '/../includes/student_account_helper.php';
require_once __DIR__ . '/../includes/student_search.php';
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'];

/* DASHBOARD CACHE INVALIDATION — anumang POST dito (create/update/
   approve/reject/archive/delete/restore) ay pwedeng magbago ng mga
   binibilang ng Dashboard (totalEnrolled/male/female/byCourse), kaya
   sa halip na maghintay maubos ang 60-segundong TTL ng cache, buburahin
   ito pagkatapos ng request na ito. Isang shutdown function na lang
   dito sa itaas ng file — isang lugar lang, kahit alin pa sa maraming
   action-branch (create/update/approve/reject/archive/delete/restore)
   ang tumakbo pababa. Bahagyang "maramot" ito (buburahin din kahit
   validation-error/no-op ang naging resulta) pero mura lamang ito —
   kasing-gastos lang ng isang extra dashboard query sa susunod na
   pag-load, at ginagarantiya nitong hindi kailanman makikita ang
   lipas na bilang matapos ang totoong pagbabago. */
register_shutdown_function(function () {
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        ascb_cache_clear_prefix('dashboard_stats_');
    }
});



/* Bumubuo ng bagong Student ID: taon (ngayon) + 5-digit running
   number, hal. "2026-00001".

   (2024 audit fix) Dati, SELECT MAX(...) sa PHP tapos +1 lang —
   kung dalawang request ang sumabay sa parehong segundo, pwedeng
   parehong makakuha ng IISANG parehong numero (race condition),
   dahil walang UNIQUE constraint na sasabat (at SINADYANG hindi
   dapat gawing UNIQUE ang student_id column, dahil paulit-ulit
   itong ginagamit kapag "New Term" ng parehong estudyante).

   Ngayon, gumagamit ng dedicated counter table
   (`student_id_sequences`) na ina-atomically i-increment gamit ang
   MySQL na `INSERT ... ON DUPLICATE KEY UPDATE ... LAST_INSERT_ID()`
   idiom — ito ay ligtas sa concurrent requests dahil ang row-level
   lock ng InnoDB sa PRIMARY KEY (year_key) ang siyang bumabantay,
   hindi ang application code. Ang lumang paraan (pagtingin sa
   pinakamalaking student_id na ginamit na) ay ginagamit pa rin,
   pero para lang "i-seed"/i-verify ang counter (hal. kapag bagong
   taon pa lang, o may lumang datos bago pa ito i-deploy) — hindi
   na ito ang huling desisyon kung ano ang isusunod na numero. */
function ascb_enrollment_generate_student_id($pdo) {
    $year = date('Y');
    $prefix = $year . '-';

    /* Fast path: once the yearly counter exists, allocation is O(1) and
       does not scan the enrollment table. LAST_INSERT_ID(next_number)
       returns the number allocated by this atomic UPDATE. */
    $fast = $pdo->prepare(
        "UPDATE student_id_sequences
            SET next_number = LAST_INSERT_ID(next_number + 1)
          WHERE year_key = ?"
    );
    $fast->execute(array($year));
    if ($fast->rowCount() > 0) {
        $assigned = (int) $pdo->lastInsertId();
        return $prefix . str_pad($assigned, 5, '0', STR_PAD_LEFT);
    }

    /* First use of a year (or a freshly imported database): seed the
       counter from existing IDs. This scan happens only once per year,
       not once per new student. */
    $stmt = $pdo->prepare(
        "SELECT student_id FROM enrollees
          WHERE student_id LIKE ?
          ORDER BY CAST(SUBSTRING(student_id, 6) AS UNSIGNED) DESC
          LIMIT 1"
    );
    $stmt->execute(array($prefix . '%'));
    $last = $stmt->fetchColumn();

    $seedNext = 1;
    if ($last && preg_match('/^' . preg_quote($prefix, '/') . '(\d+)$/', $last, $m)) {
        $seedNext = ((int) $m[1]) + 1;
    }

    /* If another request seeded the row concurrently, the duplicate-key
       branch increments that existing counter and still returns a unique
       number. Otherwise this request creates the first counter row. */
    $ins = $pdo->prepare(
        "INSERT INTO student_id_sequences (year_key, next_number)
             VALUES (?, LAST_INSERT_ID(?))
         ON DUPLICATE KEY UPDATE
             next_number = LAST_INSERT_ID(GREATEST(next_number, ?) + 1)"
    );
    $ins->execute(array($year, $seedNext, $seedNext - 1));
    $assigned = (int) $pdo->lastInsertId();
    if ($assigned < 1) $assigned = $seedNext;

    return $prefix . str_pad($assigned, 5, '0', STR_PAD_LEFT);
}

/* Kung "New Term" ito (may ipinasang studentId), i-verify muna na
   totoong existing student ID ito bago gamitin — para hindi basta
   makakapasok ng kahit anong string bilang student_id. Kung wala
   o hindi valid, gagawa na lang ng bago (parang bagong estudyante). */
function ascb_enrollment_resolve_student_id($pdo, $providedStudentId) {
    $providedStudentId = trim((string) $providedStudentId);

    if ($providedStudentId !== '') {
        $check = $pdo->prepare("SELECT COUNT(*) FROM enrollees WHERE student_id = ?");
        $check->execute(array($providedStudentId));
        if ((int) $check->fetchColumn() > 0) {
            return $providedStudentId;
        }
    }

    return ascb_enrollment_generate_student_id($pdo);
}

/* Kung ADMIN STAFF ang nag-input, dapat "pending" muna ito
   (naghihintay ng approval ng UNIT HEAD). Ang UNIT HEAD at
   SCHOOL REGISTRAR ay awtomatikong "approved" agad ang input. */
function ascb_enrollment_default_status($role) {
    return ($role === 'ADMIN STAFF') ? 'pending' : 'approved';
}

/* Keep the normalized subject table synchronized with Enrollment.
   Existing subject IDs are reused (kaya hindi nagbabago ang
   enrollment_subject_id, at nananatili ang grade) kung parehong code+
   description pa rin ang isang subject. PERO kung inalis/pinalitan
   na ng user ang isang subject sa form (wala na ito sa bagong listahan),
   TATANGGALIN na ito rito (kasama na ang kaugnay na grade nito, dahil
   ON DELETE CASCADE ang FK ng grades -> enrollment_subjects) — para
   hindi na maiwan ang lumang/binagong datos kapag "Update". Hindi ito
   nakakaapekto sa ibang term (ibang enrollment_id) — laging bago at
   walang subjects pa ang New Term, kaya hindi ito nagagalaw dito. */
function ascb_sync_enrollment_subjects($pdo, $enrollmentId, $subjects) {
    $find = $pdo->prepare("SELECT id FROM enrollment_subjects WHERE enrollment_id = ? AND ((course_code IS NOT NULL AND course_code = ?) OR (course_code IS NULL AND ? = '')) AND description = ? LIMIT 1");
    $insert = $pdo->prepare("INSERT INTO enrollment_subjects (enrollment_id, course_code, description, units) VALUES (?, ?, ?, ?)");
    $update = $pdo->prepare("UPDATE enrollment_subjects SET units = ?, description = ? WHERE id = ?");
    $keepIds = array();

    foreach ((array)$subjects as $subject) {
        $code = trim((string)($subject['code'] ?? ''));
        $description = trim((string)($subject['description'] ?? ''));
        if ($code === '' && $description === '') continue;
        if ($description === '') $description = '(No description)';
        /* (audit fix) Consistency gap: api/grades.php, api/grade_import.php,
           at api/record_corrections.php ay pare-parehong nagre-reject ng
           units na wala sa 0-99 range, pero dito, kahit anong numero (kasama
           ang negative o napakalaking value) ay direktang naisasave kapag
           direktang tinawag ang API (lampas sa normal na prospectus dropdown
           ng UI). I-clamp na lang sa 0-99 range, kagaya ng ginagawa sa ibang
           modules, sa halip na basta tanggapin ang kahit anong numero. */
        $units = is_numeric($subject['units'] ?? null) ? (float)$subject['units'] : 0;
        if ($units < 0) $units = 0;
        if ($units > 99) $units = 99;

        $find->execute([(int)$enrollmentId, $code, $code, $description]);
        $id = $find->fetchColumn();

        if ($id) {
            $update->execute([$units, $description, (int)$id]);
            $keepIds[] = (int)$id;
        } else {
            $insert->execute([(int)$enrollmentId, $code !== '' ? $code : null, $description, $units]);
            $keepIds[] = (int)$pdo->lastInsertId();
        }
    }

    /*
     * IMPORTANT: never delete an enrollment_subject that already has a grade.
     * grades.enrollment_subject_id uses ON DELETE CASCADE, so deleting the
     * subject would silently destroy an academic grade. A graded subject must
     * instead be handled through the record-correction workflow.
     */
    $params = [(int)$enrollmentId];
    if ($keepIds) {
        $placeholders = implode(',', array_fill(0, count($keepIds), '?'));
        $sql = "SELECT es.id, es.course_code, es.description
                FROM enrollment_subjects es
                WHERE es.enrollment_id = ? AND es.id NOT IN ($placeholders)
                  AND EXISTS (SELECT 1 FROM grades g WHERE g.enrollment_subject_id = es.id)
                LIMIT 1";
        $params = array_merge($params, $keepIds);
    } else {
        $sql = "SELECT es.id, es.course_code, es.description
                FROM enrollment_subjects es
                WHERE es.enrollment_id = ?
                  AND EXISTS (SELECT 1 FROM grades g WHERE g.enrollment_subject_id = es.id)
                LIMIT 1";
    }

    $guard = $pdo->prepare($sql);
    $guard->execute($params);
    $gradedRemoved = $guard->fetch();

    if ($gradedRemoved) {
        throw new RuntimeException(
            'Hindi maaaring alisin ang subject na may existing grade. Gamitin ang Record Correction workflow para sa pagbabago ng graded subject.'
        );
    }

    if ($keepIds) {
        $placeholders = implode(',', array_fill(0, count($keepIds), '?'));
        $delete = $pdo->prepare("DELETE FROM enrollment_subjects WHERE enrollment_id = ? AND id NOT IN ($placeholders)");
        $delete->execute(array_merge([(int)$enrollmentId], $keepIds));
    } else {
        $delete = $pdo->prepare("DELETE FROM enrollment_subjects WHERE enrollment_id = ?");
        $delete->execute([(int)$enrollmentId]);
    }
}

/* Resolve and snapshot the Department attached to the selected Program.
   The enrollment keeps this value so historical Department exports remain
   stable even if a Program is later moved to another Department. */
function ascb_enrollment_department_id($pdo, $programCode) {
    $programCode = trim((string)$programCode);
    if ($programCode === '' || !ascb_has_column($pdo, 'enrollees', 'department_id')) return null;
    $st = $pdo->prepare("SELECT department_id FROM programs WHERE UPPER(TRIM(code))=UPPER(TRIM(?)) LIMIT 1");
    $st->execute(array($programCode));
    $v = $st->fetchColumn();
    return ($v !== false && $v !== null) ? (int)$v : null;
}

/* ========================================== GET — LIST */

if ($method === 'GET') {

    $q = trim(ascb_get($_GET, 'q', ''));
    $statusFilter = trim(ascb_get($_GET, 'status', ''));

    // "scope" ang nagtatakda kung ANONG grupo ng enrollees ang
    // ibabalik ng listahan na ito:
    //   'active'   (default) — hindi pa na-archive AT hindi "rejected".
    //                Ito ang ginagamit ng Enrollment / New Term list
    //                at ng Grade Evaluation — kaya AWTOMATIKONG hindi
    //                lumalabas dito (at sa Grade Evaluation) ang mga
    //                "rejected" na record.
    //   'rejected' — hindi pa na-archive AT "rejected" ang status.
    //                Ginagamit ng bagong "Rejected Students" menu.
    //   'archived' — na-archive na (dating "delete" na ginawang
    //                archive na lang sa halip na tunay na tanggalin
    //                sa database). Ginagamit ng bagong "Archive" menu
    //                (mga estudyanteng nag-drop o tinanggal sa listahan).
    $scope = trim(ascb_get($_GET, 'scope', 'active'));
    if (!in_array($scope, array('active', 'rejected', 'archived'), true)) {
        $scope = 'active';
    }
    /* ADMIN STAFF: walang access sa Archive list. */
    if ($scope === 'archived' && !ascb_can(ascb_get($ascbUser, 'role', ''), 'view_archive')) {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'You do not have access to the Archive.'));
        exit;
    }

    $sql = "SELECT e.*, u.display_name AS enrolled_by_name,
                   a.display_name AS approved_by_name,
                   ar.display_name AS archived_by_name
            FROM enrollees e
            LEFT JOIN users u ON u.id = e.enrolled_by_user_id
            LEFT JOIN users a ON a.id = e.approved_by_user_id
            LEFT JOIN users ar ON ar.id = e.archived_by_user_id";
    $params = array();
    $where = array();

    // DEAN: read-only at sariling Department lamang.
    if (ascb_get($ascbUser, 'role', '') === 'DEAN') {
        $deptId = ascb_require_dean_department($pdo, $ascbUser);
        $where[] = "e.department_id = ?";
        $params[] = $deptId;
    }

    if ($q !== '') {
        /* Full name (kahit anong ayos: "Juan Dela Cruz" / "Dela Cruz, Juan")
           o Student ID. Tingnan ang includes/student_search.php */
        $sc = ascb_student_search_clause($q, 'e', ascb_master_available($pdo),
            array('mobile_number', 'prev_school_junior_hs', 'prev_school_senior_hs', 'course', 'major'));
        if ($sc['sql'] !== '') {
            $where[] = $sc['sql'];
            $params = array_merge($params, $sc['params']);
        }
    }
    if ($scope === 'archived') {
        $where[] = "e.archived_at IS NOT NULL";
        if (in_array($statusFilter, array('pending', 'approved', 'rejected'), true)) {
            $where[] = "e.status = ?";
            $params[] = $statusFilter;
        }
    } elseif ($scope === 'rejected') {
        $where[] = "e.archived_at IS NULL";
        $where[] = "e.status = 'rejected'";
    } else { // 'active'
        $where[] = "e.archived_at IS NULL";
        $where[] = "e.status != 'rejected'";
        if (in_array($statusFilter, array('pending', 'approved'), true)) {
            $where[] = "e.status = ?";
            $params[] = $statusFilter;
        }
    }

    $whereSql = !empty($where) ? (" WHERE " . implode(' AND ', $where)) : '';

    /* ---------------------------------------------------------
       PAGE / LIMIT — server-side pagination. Dati, kinukuha ng
       query na ito ANG LAHAT ng tumutugmang rows at ang browser
       pa lang ang nagpapaginate (12 sa isang pahina). Sa 100k+
       students, delikado 'yon — malaking response, mabagal na
       page load, posibleng mag-timeout. Ngayon, ang MySQL mismo
       ang nagbibigay lang ng isang pahina bawat request.
       --------------------------------------------------------- */
    $page  = max(1, (int) ascb_get($_GET, 'page', 1));
    $limit = (int) ascb_get($_GET, 'limit', 12);
    if ($limit <= 0 || $limit > 200) {
        $limit = 12;
    }
    $offset = ($page - 1) * $limit;

    try {
        if ($scope === 'active') {
            /* Isang estudyante = maaaring maraming "term" (row) sa
               `enrollees` (dahil sa "New Term"). Sa LISTAHAN, isang
               beses lang dapat lumabas ang estudyante — ang PINAKA-
               BAGONG term niya. Dati, kinukuha ng PHP (ascbEnrollLatestPerStudent
               sa script.js) ang "latest per student" MATAPOS ma-download
               ang lahat ng rows. Ngayon, ginagawa na ito sa SQL — parehong
               pattern gaya ng includes/dashboard_stats_helper.php — bago
               pa mag-LIMIT/OFFSET, para tama ang pagination kahit maraming
               term ang bawat estudyante.
               */
            /*
             * 500k+ optimization:
             * Group only by the real student_id column. The old query grouped
             * by COALESCE/TRIM(student_id), which forced a computed grouping key.
             * Legacy rows without a student_id are unique by id and are appended
             * separately. This preserves the existing behavior while allowing
             * the new student_id/id indexes to help the database.
             */
            // IMPORTANT: $whereSql was built using alias `e`. When the same
            // filter is reused inside the e1/e2/e3 branches, rewrite the alias
            // for each branch. Without this, the inner query references the
            // outer/non-existent `e` alias and the active/New Term list fails.
            $whereSqlE1 = str_replace('e.', 'e1.', $whereSql);
            $whereSqlE2 = str_replace('e.', 'e2.', $whereSql);
            $whereSqlE3 = str_replace('e.', 'e3.', $whereSql);

            /* (FIX — Imported records) Dati, "pinaka-bago" = pinakamalaking
               id. Kapag nag-import ka ng Excel na mas LUMANG term ang
               naisulat nang mas HULI (hal. na-import mo ang 1st Trimester
               pagkatapos ng 2nd Trimester), mas mataas ang id ng lumang
               term kaya iyon ang lumalabas na "latest" sa Enrollment /
               New Term list — mali ang term/subjects na nababasa.
               Ngayon, ang latest ay ang pinakamataas na School Year, tapos
               ang pinakamataas na Term (1st/2nd/3rd), at id na lang ang
               tie-breaker. Walang window function (compatible sa lumang
               MySQL/MariaDB). */
            $termRankE1 = "IF(LEFT(TRIM(COALESCE(e1.trimester,'')),1) BETWEEN '1' AND '9', CAST(LEFT(TRIM(e1.trimester),1) AS UNSIGNED), 0)";
            $termRankE2 = "IF(LEFT(TRIM(COALESCE(e2.trimester,'')),1) BETWEEN '1' AND '9', CAST(LEFT(TRIM(e2.trimester),1) AS UNSIGNED), 0)";

            $latestSql = "SELECT e1.id AS max_id
                FROM enrollees e1" . $whereSqlE1 . "
                  AND e1.student_id IS NOT NULL AND TRIM(e1.student_id) <> ''
                  AND NOT EXISTS (
                      SELECT 1
                      FROM enrollees e2" . $whereSqlE2 . "
                        AND e2.student_id = e1.student_id
                        AND (
                              COALESCE(e2.school_year,'') > COALESCE(e1.school_year,'')
                           OR (COALESCE(e2.school_year,'') = COALESCE(e1.school_year,'')
                               AND " . $termRankE2 . " > " . $termRankE1 . ")
                           OR (COALESCE(e2.school_year,'') = COALESCE(e1.school_year,'')
                               AND " . $termRankE2 . " = " . $termRankE1 . "
                               AND e2.id > e1.id)
                        )
                  )
                UNION ALL
                SELECT e3.id AS max_id
                FROM enrollees e3" . $whereSqlE3 . "
                  AND (e3.student_id IS NULL OR TRIM(e3.student_id) = '')";

            $latestParams = array_merge($params, $params, $params);
            $countSql = "SELECT COUNT(*) FROM (" . $latestSql . ") t";
            $countStmt = $pdo->prepare($countSql);
            $countStmt->execute($latestParams);
            $total = (int) $countStmt->fetchColumn();

            $sql = "SELECT e.*, u.display_name AS enrolled_by_name,
                           a.display_name AS approved_by_name,
                           ar.display_name AS archived_by_name
                    FROM enrollees e
                    INNER JOIN (" . $latestSql . ") latest ON latest.max_id = e.id
                    LEFT JOIN users u ON u.id = e.enrolled_by_user_id
                    LEFT JOIN users a ON a.id = e.approved_by_user_id
                    LEFT JOIN users ar ON ar.id = e.archived_by_user_id
                    ORDER BY e.created_at DESC, e.id DESC
                    LIMIT $limit OFFSET $offset";

            $stmt = $pdo->prepare($sql);
            $stmt->execute($latestParams);
            $rows = $stmt->fetchAll();
        } else {
            /* "rejected" at "archived" — ipinapakita ang BAWAT row
               (hindi lang ang latest per student), gaya ng dati. */
            $countSql = "SELECT COUNT(*) FROM enrollees e" . $whereSql;
            $countStmt = $pdo->prepare($countSql);
            $countStmt->execute($params);
            $total = (int) $countStmt->fetchColumn();

            $sql = $sql . $whereSql . " ORDER BY e.created_at DESC, e.id DESC LIMIT $limit OFFSET $offset";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll();
        }

        /* (FIX — Imported records) Ang Excel import (api/grade_import.php)
           ay sumusulat lang sa `enrollment_subjects` + `grades`, HINDI sa
           `subjects_json`. Kaya dati, walang lumalabas na subjects sa
           View/Edit/New Term para sa mga na-import na estudyante. Ngayon,
           binabasa muna ang normalized `enrollment_subjects` (kasama ang
           grade); `subjects_json` na lang ang fallback para sa mga record
           na walang normalized rows. */
        $normalizedSubjects = array();
        $rowIds = array();
        foreach ($rows as $r0) { $rowIds[] = (int) $r0['id']; }
        if ($rowIds) {
            try {
                $inIds = implode(',', array_fill(0, count($rowIds), '?'));
                $ss = $pdo->prepare(
                    "SELECT es.enrollment_id, es.course_code, es.description, es.units, g.grade
                       FROM enrollment_subjects es
                       LEFT JOIN grades g ON g.enrollment_subject_id = es.id
                      WHERE es.enrollment_id IN ($inIds)
                      ORDER BY es.enrollment_id, es.id"
                );
                $ss->execute($rowIds);
                foreach ($ss->fetchAll(PDO::FETCH_ASSOC) as $sr) {
                    $normalizedSubjects[(int) $sr['enrollment_id']][] = array(
                        'code'        => $sr['course_code'] !== null ? $sr['course_code'] : '',
                        'description' => $sr['description'],
                        'units'       => $sr['units'] !== null ? (float) $sr['units'] : 0,
                        'grade'       => $sr['grade'] !== null ? $sr['grade'] : '',
                    );
                }
            } catch (Throwable $subjErr) {
                error_log('ASCB enrollment subjects hydrate failed: ' . $subjErr->getMessage());
                $normalizedSubjects = array();
            }
        }

        foreach ($rows as &$row) {
            $rid = (int) $row['id'];
            if (!empty($normalizedSubjects[$rid])) {
                $row['subjects'] = $normalizedSubjects[$rid];
            } else {
                $decodedSubjects = json_decode(ascb_get($row, 'subjects_json', ''), true);
                $row['subjects'] = is_array($decodedSubjects) ? $decodedSubjects : array();
            }
            unset($row['subjects_json']);
        }
        unset($row);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(array(
            'ok'    => false,
            'error' => 'There was an error retrieving the list from the database.'
        ), JSON_UNESCAPED_UNICODE);
        exit;
    }

    $totalPages = (int) max(1, ceil($total / $limit));

    echo json_encode(array(
        'ok'         => true,
        'rows'       => $rows,
        'count'      => count($rows),
        'page'       => $page,
        'limit'      => $limit,
        'total'      => $total,
        'totalPages' => $totalPages,
    ), JSON_UNESCAPED_UNICODE);
    exit;
}


/* ========================================== POST — CREATE / UPDATE / DELETE */

if ($method === 'POST') {

    if (ascb_get($ascbUser, 'role', '') === 'DEAN') { http_response_code(403); echo json_encode(array('ok'=>false,'error'=>'The Dean account is read-only. It cannot modify official enrollment records.')); exit; }

    $input = ascb_read_json_body();
    $action = ascb_get($input, 'action', 'create');

    /* ----------------------------------------- CREATE / UPDATE */
    if ($action === 'create' || $action === 'update') {

        // Update ng enrollment record (student/term/subject assignment only).
        // Ang grades ay hiwalay nang minamanage sa api/grades.php.
        // Bukas ito sa UNIT HEAD at ADMIN STAFF (2026 fix) — pero
        // kapag ADMIN STAFF ang nag-update, babalik itong "pending"
        // (tingnan sa ascb_enrollment_default_status), kailangan
        // pang aprubahan ng UNIT HEAD o SCHOOL REGISTRAR. Ang
        // pag-enroll ng BAGONG estudyante (create) at New Term
        // (create rin, may studentId lang) ay bukas na rin.
        if ($action === 'update' && !ascb_can(ascb_get($ascbUser, 'role', ''), 'update_enrollment')) {
            http_response_code(403);
            echo json_encode(array('ok' => false, 'error' => 'You do not have access to update an enrollment record.'));
            exit;
        }

        $studentId          = trim(ascb_get($input, 'studentId', ''));
        $surname            = trim(ascb_get($input, 'surname', ''));
        $firstName          = trim(ascb_get($input, 'firstName', ''));
        $middleName         = trim(ascb_get($input, 'middleName', ''));
        /* SUFFIX + PSA PLACEMENT: hiwalay ang suffix (Jr., III...). Ang
           suffixPosition ang nagsasabi kung saan ito ilalabas ayon sa PSA
           Birth Certificate: 'separate' (default) | 'first_name' | 'surname'. */
        $suffix             = ascb_validate_suffix(ascb_get($input, 'suffix', ''));
        $suffixPosition     = ascb_normalize_suffix_position(ascb_get($input, 'suffixPosition', 'separate'));
        if ($suffix === null) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Suffix may only contain letters, numbers and periods (e.g. Jr., III), max 20 characters.'));
            exit;
        }
        if ($suffix === '') $suffixPosition = 'separate';
        $hasSuffixCols = ascb_column_exists($pdo, 'enrollees', 'suffix') && ascb_column_exists($pdo, 'enrollees', 'suffix_position');
        if ($suffix !== '' && !$hasSuffixCols) {
            http_response_code(500);
            echo json_encode(array('ok' => false, 'error' => 'Suffix columns are not installed yet. Run database/migrate_master.php first.'));
            exit;
        }
        $sex                = trim(ascb_get($input, 'sex', ''));
        $civilStatus        = trim(ascb_get($input, 'civilStatus', ''));
        $email              = trim(ascb_get($input, 'email', ''));
        $studentType        = trim(ascb_get($input, 'studentType', ''));
        $birthDate          = trim(ascb_get($input, 'birthDate', ''));
        $birthPlace         = trim(ascb_get($input, 'birthPlace', ascb_get($input, 'birthplace', '')));
        $address            = trim(ascb_get($input, 'address', ''));
        $mobileNumber       = trim(ascb_get($input, 'mobileNumber', ''));
        $guardianName       = trim(ascb_get($input, 'guardianName', ''));
        $prevSchoolJuniorHs = trim(ascb_get($input, 'prevSchoolJuniorHs', ascb_get($input, 'juniorHighSchool', ascb_get($input, 'previousJuniorHighSchool', ''))));
        $prevSchoolSeniorHs = trim(ascb_get($input, 'prevSchoolSeniorHs', ascb_get($input, 'seniorHighSchool', ascb_get($input, 'previousSeniorHighSchool', ''))));
        $programCode        = trim(ascb_get($input, 'programCode', ''));
        $course             = trim(ascb_get($input, 'course', ''));
        $major              = trim(ascb_get($input, 'major', ''));
        $yearLevel          = trim(ascb_get($input, 'yearLevel', ''));
        $trimester          = trim(ascb_get($input, 'trimester', ''));
        $schoolYear         = trim(ascb_get($input, 'schoolYear', ''));
        $newTermSourceId     = (int) ascb_get($input, 'sourceEnrollmentId', 0);
        $isNewTerm           = ($action === 'create' && $newTermSourceId > 0);

        $subjectsInput = ascb_get($input, 'subjects', array());
        $subjects = array();
        if (is_array($subjectsInput)) {
            foreach ($subjectsInput as $s) {
                $code = trim(ascb_get($s, 'code', ''));
                $description = trim(ascb_get($s, 'description', ''));
                if ($code === '' && $description === '') {
                    continue;
                }
                $subjects[] = array(
                    'code'        => $code,
                    'description' => $description,
                    'units'       => (isset($s['units']) && $s['units'] !== '') ? $s['units'] : 0,
                );
            }
        }
        $subjectsJson = json_encode($subjects, JSON_UNESCAPED_UNICODE);

        /* Reject duplicate subject codes within the same submission —
           without this, two rows with the same subject code would
           silently collapse into one during ascb_sync_enrollment_subjects
           (the second row overwrites the first's units, with no warning).
           Subjects without a code (custom/blank code) are compared by
           description instead, since code alone can't identify them. */
        $seenSubjectKeys = array();
        foreach ($subjects as $s) {
            $key = $s['code'] !== '' ? 'code:' . $s['code'] : 'desc:' . $s['description'];
            if (isset($seenSubjectKeys[$key])) {
                http_response_code(400);
                echo json_encode(array(
                    'ok' => false,
                    'error' => 'Duplicate subject: "' . ($s['code'] !== '' ? $s['code'] . ' — ' : '') . $s['description'] . '" was added more than once. Please remove the duplicate row.'
                ));
                exit;
            }
            $seenSubjectKeys[$key] = true;
        }

        if ($surname === '' || $firstName === '') {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Surname and Given Name are required.'));
            exit;
        }

        if ($mobileNumber !== '' && ascb_text_too_long($mobileNumber, 20)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Mobile Number is too long (max 20 characters).'));
            exit;
        }

        if ($guardianName !== '' && ascb_text_too_long($guardianName, 150)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Guardian Name is too long (max 150 characters).'));
            exit;
        }

        if ($birthPlace !== '' && ascb_text_too_long($birthPlace, 255)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Birth Place is too long (max 255 characters).'));
            exit;
        }

        $validateGraduationYear = static function ($value, $label) {
            if ($value === '') return null;
            if (!preg_match('/^\d{4}-\d{4}$/', $value)) {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => $label . ' must use YYYY-YYYY (hal. 2020-2021).'));
                exit;
            }
            $parts = explode('-', $value);
            if ((int)$parts[1] !== ((int)$parts[0] + 1)) {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => $label . ' is invalid. The second year must be the first year + 1.'));
                exit;
            }
            return $value;
        };
        $juniorHsGraduated = $validateGraduationYear(trim(ascb_get($input, 'juniorHsGraduated', '')), 'Junior High School Graduated');
        $seniorHsGraduated = $validateGraduationYear(trim(ascb_get($input, 'seniorHsGraduated', '')), 'Senior High School Graduated');

        if ($sex !== '' && !in_array($sex, array('Male', 'Female'), true)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid Sex.'));
            exit;
        }

        if ($civilStatus !== '' && !in_array($civilStatus, array('Single', 'Married', 'Widowed', 'Separated'), true)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid Civil Status.'));
            exit;
        }

        // Email is now OPTIONAL sa enrollment — kung binigyan lang ng
        // value ang field, saka lang ito i-validate na tamang format.
        if ($email !== '' && (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 254)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid Email Address.'));
            exit;
        }
        $emailValue = $email !== '' ? $email : null;

        /* Client-side validation is not enough; enforce School Year at the
           API boundary too so direct requests cannot store malformed values. */
        if ($schoolYear !== '' && !preg_match('/^\d{4}-\d{4}$/', $schoolYear)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid School Year. Use YYYY-YYYY (hal. 2026-2027).'));
            exit;
        }
        if ($schoolYear !== '') {
            $syParts = explode('-', $schoolYear);
            if ((int)$syParts[1] !== ((int)$syParts[0] + 1)) {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Invalid School Year. The second year must be the first year + 1.'));
                exit;
            }
        }

        if ($studentType !== '' && !in_array($studentType, array('Regular', 'Transferee', 'Irregular'), true)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid Student Type.'));
            exit;
        }

        /* NEW TERM: server-side validation. The UI is not trusted because
           this endpoint can also be called directly. A New Term must have
           a real source enrollment, a valid student ID, complete term data,
           and at least one subject. */
        if ($isNewTerm) {
            if ($newTermSourceId <= 0) {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Invalid source enrollment for New Term.'));
                exit;
            }

            $src = $pdo->prepare(
                "SELECT id, student_id, surname, first_name, status, archived_at
                   FROM enrollees
                  WHERE id = ?
                  LIMIT 1"
            );
            $src->execute(array($newTermSourceId));
            $source = $src->fetch(PDO::FETCH_ASSOC);

            if (!$source) {
                http_response_code(404);
                echo json_encode(array('ok' => false, 'error' => 'The selected source enrollment no longer exists. Please reopen New Term from the current enrollment record.'));
                exit;
            }
            if ($source['archived_at'] !== null || $source['status'] !== 'approved') {
                http_response_code(409);
                echo json_encode(array('ok' => false, 'error' => 'New Term can only be created from an active approved enrollment.'));
                exit;
            }
            if ($studentId !== '' && $studentId !== (string)$source['student_id']) {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Student ID does not match the selected source enrollment.'));
                exit;
            }
            $studentId = (string)$source['student_id'];

            if ($programCode === '') {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Please select a Course / Program.'));
                exit;
            }
            if ($yearLevel === '') {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Please select a Year Level.'));
                exit;
            }
            if (!in_array($yearLevel, array('1st Year','2nd Year','3rd Year','4th Year'), true)) {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Invalid Year Level. Please select 1st, 2nd, 3rd, or 4th Year.'));
                exit;
            }
            if ($trimester === '') {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Please select a Trimester / Semester.'));
                exit;
            }
            if ($schoolYear === '') {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Please enter the School Year (e.g. 2026-2027).'));
                exit;
            }
            if (!$subjects) {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Please add at least one subject before saving the New Term.'));
                exit;
            }

            /* (2026-09-22 fix) Normalized comparison. An exact string match let
               through near-duplicates that differ only by letter case or extra
               spaces (e.g. "1st trimester" vs "1ST  TRIMESTER", "2026-2027 ").
               The indexed student_id keeps this probe cheap. */
            $dup = $pdo->prepare(
                "SELECT id, status, archived_at
                   FROM enrollees
                  WHERE student_id = ?
                    AND UPPER(REPLACE(TRIM(COALESCE(school_year,'')),' ','')) = UPPER(REPLACE(TRIM(?),' ',''))
                    AND UPPER(TRIM(COALESCE(trimester,''))) = UPPER(TRIM(?))
                  ORDER BY id DESC
                  LIMIT 1"
            );
            $dup->execute(array($studentId, $schoolYear, $trimester));
            $duplicate = $dup->fetch(PDO::FETCH_ASSOC);
            if ($duplicate) {
                http_response_code(409);
                $state = $duplicate['archived_at'] !== null ? 'archived' : $duplicate['status'];
                echo json_encode(array(
                    'ok' => false,
                    'error' => 'Duplicate New Term: ' . $studentId . ' is already enrolled for ' . $trimester . ', AY ' . $schoolYear . ' (' . $state . '). Choose a different term.'
                ));
                exit;
            }
        }

        // birth_date: itago lang kung valid na petsa, blangko/NULL kung wala o hindi valid
        $birthDateValue = null;
        if ($birthDate !== '') {
            $d = DateTime::createFromFormat('Y-m-d', $birthDate);
            if ($d && $d->format('Y-m-d') === $birthDate) {
                $birthDateValue = $birthDate;
            }
        }

        if ($action === 'create') {

            $pdo->beginTransaction();
            try {
                $studentId = $isNewTerm
                    ? (string)$studentId
                    : ascb_enrollment_resolve_student_id($pdo, ascb_get($input, 'studentId', ''));

            /* MASTER RECORD: a New Term row must carry the student's CURRENT
               name/civil status. The New Term form is pre-filled from an old
               enrollment row, so when the submitted values are still exactly
               what that old row had (registrar did not type a different
               name), use the Master Record's values instead. Anything the
               registrar typed themselves is left alone, and old rows are
               never modified. No-op until the Master Record migration ran. */
            $ntSuffixTyped = false;
            if ($isNewTerm) {
                $masterNow = ascb_master_current($pdo, $studentId);
                if ($masterNow) {
                    $srcStmt = $pdo->prepare("SELECT * FROM enrollees WHERE id = ?");
                    $srcStmt->execute(array($newTermSourceId));
                    $src = $srcStmt->fetch();
                    if ($src
                        && strcasecmp(trim((string) $src['surname']), $surname) === 0
                        && strcasecmp(trim((string) $src['first_name']), $firstName) === 0
                        && strcasecmp(trim((string) $src['middle_name']), $middleName) === 0) {
                        $surname    = $masterNow['surname'];
                        $firstName  = $masterNow['first_name'];
                        $middleName = trim((string) $masterNow['middle_name']);
                        if ((string) $src['civil_status'] === $civilStatus && !empty($masterNow['civil_status'])) {
                            $civilStatus = $masterNow['civil_status'];
                        }
                    }
                    /* (fix) Suffix + PSA placement: hiwalay na ang check sa pangalan.
                       Kung hindi ginalaw ang suffix / placement sa form (kapareho pa
                       ng lumang row), sundin ang CURRENT sa Master Record - kahit
                       may binago sa pangalan. Kung talagang binago ng registrar,
                       iyon ang gagamitin at ipapasa sa Master Record at sa lahat
                       ng term ng estudyante (tingnan sa ibaba). */
                    $ntSuffixTyped = false;
                    if ($src && $hasSuffixCols) {
                        $srcSfx = trim((string) (isset($src['suffix']) ? $src['suffix'] : ''));
                        $srcPos = $srcSfx !== '' ? ascb_normalize_suffix_position(isset($src['suffix_position']) ? $src['suffix_position'] : '') : 'separate';
                        $formPos = $suffix !== '' ? $suffixPosition : 'separate';
                        if (strcasecmp($srcSfx, $suffix) === 0 && $srcPos === $formPos) {
                            $suffix = trim((string) (isset($masterNow['suffix']) ? $masterNow['suffix'] : ''));
                            $suffixPosition = $suffix !== ''
                                ? ascb_normalize_suffix_position(isset($masterNow['suffix_position']) ? $masterNow['suffix_position'] : '')
                                : 'separate';
                        } else {
                            $ntSuffixTyped = true;
                        }
                    }
                }
            }

            /* (fix) NEW TERM = MASTER RECORD: ang New Term form ay pre-filled mula
               sa LUMANG enrollment row. Kung ang isang detalye (Birthplace,
               Address, Mobile, Email, Guardian, Sex, Birth Date, Civil Status)
               ay hindi ginalaw ng registrar, ang Master Record ang masusunod
               (para hindi maibalik sa luma ang na-update na master). Kung
               may tinype siyang bago, iyon ang mapupunta sa BAGONG term AT sa
               Master Record - kaya laging pareho ang dalawa. */
            $ntTyped = array();
            if ($isNewTerm) {
                $ntSrcStmt = $pdo->prepare("SELECT * FROM enrollees WHERE id = ?");
                $ntSrcStmt->execute(array($newTermSourceId));
                $ntSrc = $ntSrcStmt->fetch();
                $ntMaster = ascb_master_current($pdo, $studentId);
                if ($ntSrc) {
                    $ntFields = array(
                        // key => array(src column, master column, submitted value)
                        'sex'           => array('sex',           'sex',           $sex),
                        'civil_status'  => array('civil_status',  'civil_status',  $civilStatus),
                        'birth_date'    => array('birth_date',    'birth_date',    $birthDateValue !== null ? $birthDateValue : ''),
                        'birth_place'   => array('birth_place',   'birthplace',    $birthPlace),
                        'address'       => array('address',       'address',       $address),
                        'mobile_number' => array('mobile_number', 'mobile_number', $mobileNumber),
                        'email'         => array('email',         'email',         $emailValue !== null ? $emailValue : ''),
                        'guardian_name' => array('guardian_name', 'guardian_name', $guardianName),
                    );
                    $ntResolved = array();
                    foreach ($ntFields as $key => $def) {
                        $srcVal = trim((string) (isset($ntSrc[$def[0]]) ? $ntSrc[$def[0]] : ''));
                        $subVal = trim((string) $def[2]);
                        if ($key === 'birth_date') $srcVal = substr($srcVal, 0, 10);
                        if (strcasecmp($srcVal, $subVal) === 0) {
                            $mVal = ($ntMaster && isset($ntMaster[$def[1]])) ? trim((string) $ntMaster[$def[1]]) : '';
                            if ($key === 'birth_date') $mVal = substr($mVal, 0, 10);
                            $ntResolved[$key] = ($mVal !== '') ? $mVal : $subVal;
                        } else {
                            $ntResolved[$key] = $subVal;
                            $ntTyped[$key] = $subVal;
                        }
                    }
                    $sex           = $ntResolved['sex'];
                    $civilStatus   = $ntResolved['civil_status'];
                    $birthDateValue = $ntResolved['birth_date'] !== '' ? $ntResolved['birth_date'] : null;
                    $birthPlace    = $ntResolved['birth_place'];
                    $address       = $ntResolved['address'];
                    $mobileNumber  = $ntResolved['mobile_number'];
                    $emailValue    = $ntResolved['email'] !== '' ? $ntResolved['email'] : null;
                    $guardianName  = $ntResolved['guardian_name'];
                }
            }

            $status = ascb_enrollment_default_status(ascb_get($ascbUser, 'role', ''));
            $approvedByUserId = ($status === 'approved') ? ascb_get($ascbUser, 'id', null) : null;
            $approvedAt = ($status === 'approved') ? date('Y-m-d H:i:s') : null;

            $sfxCols = $hasSuffixCols ? ', suffix, suffix_position' : '';
            $sfxMarks = $hasSuffixCols ? ',?,?' : '';
            $stmt = $pdo->prepare(
                "INSERT INTO enrollees
                    (student_id, surname, first_name, middle_name" . $sfxCols . ", sex, civil_status, student_type, birth_date, birth_place, address, mobile_number, guardian_name,
                     email, prev_school_junior_hs, prev_school_senior_hs, junior_hs_graduated, senior_hs_graduated,
                     program_code, department_id, course, major, year_level, trimester, school_year, subjects_json,
                     enrolled_by_user_id, status, approved_by_user_id, approved_at)
                 VALUES (?,?,?,?" . $sfxMarks . ",?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            );
            $insertParams = array(
                $studentId,
                $surname,
                $firstName,
                $middleName !== '' ? $middleName : null,
            );
            if ($hasSuffixCols) {
                $insertParams[] = $suffix !== '' ? $suffix : null;
                $insertParams[] = $suffixPosition;
            }
            $stmt->execute(array_merge($insertParams, array(
                $sex !== '' ? $sex : null,
                $civilStatus !== '' ? $civilStatus : null,
                $studentType !== '' ? $studentType : null,
                $birthDateValue,
                $birthPlace !== '' ? $birthPlace : null,
                $address !== '' ? $address : null,
                $mobileNumber !== '' ? $mobileNumber : null,
                $guardianName !== '' ? $guardianName : null,
                $emailValue,
                $prevSchoolJuniorHs !== '' ? $prevSchoolJuniorHs : null,
                $prevSchoolSeniorHs !== '' ? $prevSchoolSeniorHs : null,
                $juniorHsGraduated,
                $seniorHsGraduated,
                $programCode !== '' ? $programCode : null,
                ascb_enrollment_department_id($pdo, $programCode),
                $course !== '' ? $course : null,
                $major !== '' ? $major : null,
                $yearLevel !== '' ? $yearLevel : null,
                $trimester !== '' ? $trimester : null,
                $schoolYear !== '' ? $schoolYear : null,
                $subjectsJson,
                ascb_get($ascbUser, 'id', null),
                $status,
                $approvedByUserId,
                $approvedAt,
            )));

            $newId = $pdo->lastInsertId();
            ascb_sync_enrollment_subjects($pdo, $newId, $subjects);

            /* MASTER RECORD: make sure this Student ID has its one permanent
               master row (INSERT IGNORE - never overwrites an existing one). */
            ascb_master_ensure($pdo, $studentId, array(
                'surname' => $surname, 'first_name' => $firstName, 'middle_name' => $middleName,
                'suffix' => $suffix, 'suffix_position' => $suffixPosition,
                'sex' => $sex, 'civil_status' => $civilStatus, 'birth_date' => $birthDateValue,
                'birth_place' => $birthPlace, 'address' => $address, 'mobile_number' => $mobileNumber,
                'email' => $emailValue, 'guardian_name' => $guardianName,
            ), ascb_get($ascbUser, 'id', null));
            /* (2026-09-27 fix) Existing master row: update the personal
               details typed on this form (Birthplace, Address, etc.). */
            ascb_master_sync_details($pdo, $studentId, $isNewTerm ? $ntTyped : array(
                'sex' => $sex, 'civil_status' => $civilStatus, 'birth_date' => $birthDateValue,
                'birth_place' => $birthPlace, 'address' => $address, 'mobile_number' => $mobileNumber,
                'email' => $emailValue, 'guardian_name' => $guardianName,
            ), ascb_get($ascbUser, 'id', null));
            /* (fix) Suffix / PSA placement na TINYPE sa New Term: isulat sa Master
               Record at ipasa sa lahat ng term ng estudyante para pareho sa exports. */
            if ($isNewTerm && $ntSuffixTyped && $hasSuffixCols) {
                ascb_master_sync_suffix($pdo, $studentId, $suffix, $suffixPosition, ascb_get($ascbUser, 'id', null));
            }

                ascb_log_activity($pdo, $ascbUser, 'ENROLLEE_ADD', 'enrollee', $surname . ', ' . $firstName . ' (' . $studentId . ')',
                    ($status === 'pending') ? 'Naghihintay ng approval ng Unit Head o School Registrar.' : null);

                $pdo->commit();

                /* AUTO STUDENT ACCOUNT — after the enrollment is safely saved.
                   Only an APPROVED enrollment gets an account right away
                   (an ADMIN STAFF entry is 'pending' -> account is created
                   when the Unit Head / Registrar approves it). Existing
                   account for this Student ID (New Term, next school year)
                   => nothing is created and no new password is generated. */
                $studentAccount = null;
                if ($status === 'approved') {
                    $studentAccount = ascb_sa_public_result(
                        ascb_sa_ensure_account($pdo, $studentId, (array) ascb_sa_name_for_student($pdo, $studentId), $ascbUser)
                    );
                }
                header('Cache-Control: no-store');
                echo json_encode(array('ok' => true, 'id' => $newId, 'studentId' => $studentId, 'status' => $status, 'studentAccount' => $studentAccount));
                exit;
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                error_log('ASCB enrollment create failed: ' . $e->getMessage());
                /* (2026-09-22 fix) Do not rely on the index NAME appearing in the
                   driver message. Older databases may carry an auto-named unique
                   key, and MySQL wording differs per version. Treat any
                   duplicate-key (SQLSTATE 23000 / errno 1062) failure on a New
                   Term save as the duplicate-term case. */
                $isDuplicateDb = false;
                if ($e instanceof PDOException) {
                    $errno = isset($e->errorInfo[1]) ? (int)$e->errorInfo[1] : 0;
                    $msg = $e->getMessage();
                    $isDuplicateDb = ($e->getCode() === '23000' || $errno === 1062)
                        && ($isNewTerm
                            || stripos($msg, 'uq_enrollee_student_term') !== false
                            || stripos($msg, 'student_id') !== false);
                }
                if ($isDuplicateDb) {
                    http_response_code(409);
                    echo json_encode(array('ok' => false, 'error' => 'Duplicate New Term: this student already has an enrollment record for the selected trimester and school year. Please choose a different term.'));
                } else {
                    http_response_code(500);
                    echo json_encode(array('ok' => false, 'error' => $e instanceof RuntimeException ? $e->getMessage() : 'Unable to save the enrollment record.'));
                }
                exit;
            }

        } else {

            $id = (int) ascb_get($input, 'id', 0);
            if ($id <= 0) {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
                exit;
            }

            $check = $pdo->prepare("SELECT * FROM enrollees WHERE id = ?");
            $check->execute(array($id));
            $oldEnrollRow = $check->fetch();
            if (!$oldEnrollRow) {
                http_response_code(404);
                echo json_encode(array('ok' => false, 'error' => 'Enrollee not found.'));
                exit;
            }

            $pdo->beginTransaction();
            try {

            // Anumang pag-edit ng enrollment ay kinukuha muli ang status: kung ADMIN
            // STAFF ang nag-edit, babalik itong "pending" (kailangan
            // ulit ng approval ng UNIT HEAD o SCHOOL REGISTRAR, kahit
            // approved na ito dati) — kung UNIT HEAD o SCHOOL REGISTRAR,
            // "approved" agad.
            $status = ascb_enrollment_default_status(ascb_get($ascbUser, 'role', ''));
            $approvedByUserId = ($status === 'approved') ? ascb_get($ascbUser, 'id', null) : null;
            $approvedAt = ($status === 'approved') ? date('Y-m-d H:i:s') : null;

            $stmt = $pdo->prepare(
                "UPDATE enrollees
                    SET surname = ?, first_name = ?, middle_name = ?" . ($hasSuffixCols ? ", suffix = ?, suffix_position = ?" : "") . ", sex = ?, civil_status = ?, student_type = ?, birth_date = ?, birth_place = ?,
                        address = ?, mobile_number = ?, guardian_name = ?, email = ?,
                        prev_school_junior_hs = ?, prev_school_senior_hs = ?,
                        junior_hs_graduated = ?, senior_hs_graduated = ?,
                        program_code = ?, department_id = ?, course = ?, major = ?, year_level = ?,
                        trimester = ?, school_year = ?, subjects_json = ?,
                        status = ?, approved_by_user_id = ?, approved_at = ?, approval_remarks = NULL
                  WHERE id = ?"
            );
            $updateParams = array(
                $surname,
                $firstName,
                $middleName !== '' ? $middleName : null,
            );
            if ($hasSuffixCols) {
                $updateParams[] = $suffix !== '' ? $suffix : null;
                $updateParams[] = $suffixPosition;
            }
            $stmt->execute(array_merge($updateParams, array(
                $sex !== '' ? $sex : null,
                $civilStatus !== '' ? $civilStatus : null,
                $studentType !== '' ? $studentType : null,
                $birthDateValue,
                $birthPlace !== '' ? $birthPlace : null,
                $address !== '' ? $address : null,
                $mobileNumber !== '' ? $mobileNumber : null,
                $guardianName !== '' ? $guardianName : null,
                $emailValue,
                $prevSchoolJuniorHs !== '' ? $prevSchoolJuniorHs : null,
                $prevSchoolSeniorHs !== '' ? $prevSchoolSeniorHs : null,
                $juniorHsGraduated,
                $seniorHsGraduated,
                $programCode !== '' ? $programCode : null,
                ascb_enrollment_department_id($pdo, $programCode),
                $course !== '' ? $course : null,
                $major !== '' ? $major : null,
                $yearLevel !== '' ? $yearLevel : null,
                $trimester !== '' ? $trimester : null,
                $schoolYear !== '' ? $schoolYear : null,
                $subjectsJson,
                $status,
                $approvedByUserId,
                $approvedAt,
                $id,
            )));
            ascb_sync_enrollment_subjects($pdo, $id, $subjects);

            /* (2026-09-27 fix) Keep the Master Record in sync on Edit too. */
            $sidStmt = $pdo->prepare("SELECT student_id FROM enrollees WHERE id = ?");
            $sidStmt->execute(array($id));
            $editSid = (string) $sidStmt->fetchColumn();
            if ($editSid !== '') {
                /* (fix) Ipadala lang sa Master Record ang detalyeng TALAGANG binago
                   sa Edit - para ang pag-edit ng lumang term ay hindi magbalik
                   sa luma ng na-update na master. */
                $editNew = array(
                    'sex' => $sex, 'civil_status' => $civilStatus, 'birth_date' => $birthDateValue,
                    'birth_place' => $birthPlace, 'address' => $address, 'mobile_number' => $mobileNumber,
                    'email' => $emailValue, 'guardian_name' => $guardianName,
                );
                $editOldCols = array(
                    'sex' => 'sex', 'civil_status' => 'civil_status', 'birth_date' => 'birth_date',
                    'birth_place' => 'birth_place', 'address' => 'address', 'mobile_number' => 'mobile_number',
                    'email' => 'email', 'guardian_name' => 'guardian_name',
                );
                $editChanged = array();
                foreach ($editNew as $k => $v) {
                    $ov = trim((string) (isset($oldEnrollRow[$editOldCols[$k]]) ? $oldEnrollRow[$editOldCols[$k]] : ''));
                    $nv = trim((string) $v);
                    if ($k === 'birth_date') $ov = substr($ov, 0, 10);
                    if (strcasecmp($ov, $nv) !== 0) $editChanged[$k] = $v;
                }
                ascb_master_sync_details($pdo, $editSid, $editChanged, ascb_get($ascbUser, 'id', null));

                /* (fix) Kapag binago ang Suffix / PSA placement sa Edit, isulat sa Master
                   Record at ipasa sa lahat ng term rows ng estudyante (kasama ang
                   ibang term) para hindi na luma ang lumalabas sa exports. */
                if ($hasSuffixCols) {
                    $oldSfx = trim((string) (isset($oldEnrollRow['suffix']) ? $oldEnrollRow['suffix'] : ''));
                    $oldPos = $oldSfx !== '' ? ascb_normalize_suffix_position(isset($oldEnrollRow['suffix_position']) ? $oldEnrollRow['suffix_position'] : '') : 'separate';
                    $newPos = $suffix !== '' ? $suffixPosition : 'separate';
                    if (strcasecmp($oldSfx, $suffix) !== 0 || $oldPos !== $newPos) {
                        ascb_master_sync_suffix($pdo, $editSid, $suffix, $suffixPosition, ascb_get($ascbUser, 'id', null));
                    }
                }
            }

                ascb_log_activity($pdo, $ascbUser, 'ENROLLEE_UPDATE', 'enrollee', $surname . ', ' . $firstName,
                    ($status === 'pending') ? 'Naibalik sa "pending" — naghihintay ulit ng approval ng Unit Head o School Registrar.' : null);

                $pdo->commit();
                echo json_encode(array('ok' => true, 'status' => $status));
                exit;
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                error_log('ASCB enrollment update failed: ' . $e->getMessage());
                http_response_code(500);
                echo json_encode(array('ok' => false, 'error' => $e instanceof RuntimeException ? $e->getMessage() : 'Unable to update the enrollment record.'));
                exit;
            }
        }
    }

    /* ----------------------------------------- APPROVE / REJECT */
    if ($action === 'approve' || $action === 'reject') {

        if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'approve_enrollment')) {
            http_response_code(403);
            echo json_encode(array('ok' => false, 'error' => 'You do not have access to approve/reject an enrollment record. Only Unit Head or School Registrar can do this.'));
            exit;
        }

        $id = (int) ascb_get($input, 'id', 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM enrollees WHERE id = ?");
        $stmt->execute(array($id));
        $existing = $stmt->fetch();

        if (!$existing) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Enrollee not found.'));
            exit;
        }

        $remarks = trim(ascb_get($input, 'remarks', ''));
        if ($remarks !== '' && ascb_text_too_long($remarks, 255)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Remarks is too long (max 255 characters).'));
            exit;
        }

        $newStatus = ($action === 'approve') ? 'approved' : 'rejected';

        /*
         * Approval is a state transition. Only pending, non-archived
         * enrollments may be approved/rejected through this endpoint.
         * This prevents old approved/rejected records from being silently
         * re-opened by a stale request.
         */
        if (ascb_get($existing, 'archived_at', null) !== null) {
            http_response_code(409);
            echo json_encode(array('ok' => false, 'error' => 'This enrollment record has already been archived.'));
            exit;
        }
        if (ascb_get($existing, 'status', '') !== 'pending') {
            http_response_code(409);
            echo json_encode(array('ok' => false, 'error' => 'This enrollment is no longer pending, so it can no longer be changed in the approval workflow.'));
            exit;
        }

        $stmt = $pdo->prepare(
            "UPDATE enrollees
                SET status = ?, approved_by_user_id = ?, approved_at = ?, approval_remarks = ?
              WHERE id = ? AND status = 'pending' AND archived_at IS NULL"
        );
        $stmt->execute(array(
            $newStatus,
            ascb_get($ascbUser, 'id', null),
            date('Y-m-d H:i:s'),
            $remarks !== '' ? $remarks : null,
            $id,
        ));
        if ($stmt->rowCount() !== 1) {
            http_response_code(409);
            echo json_encode(array('ok' => false, 'error' => 'Unable to update the enrollment. It may have already been changed by another user.'));
            exit;
        }

        ascb_log_activity(
            $pdo, $ascbUser,
            ($action === 'approve') ? 'ENROLLEE_APPROVE' : 'ENROLLEE_REJECT',
            'enrollee',
            $existing['surname'] . ', ' . $existing['first_name'] . ' (' . $existing['student_id'] . ')',
            $remarks !== '' ? $remarks : null
        );

        /* AUTO STUDENT ACCOUNT — an approved enrollment gets its STUDENT account
           (no duplicate if this Student ID already has one). */
        $studentAccount = null;
        if ($newStatus === 'approved') {
            $studentAccount = ascb_sa_public_result(
                ascb_sa_ensure_account($pdo, (string) $existing['student_id'], (array) ascb_sa_name_for_student($pdo, (string) $existing['student_id']), $ascbUser)
            );
        }
        header('Cache-Control: no-store');
        echo json_encode(array('ok' => true, 'status' => $newStatus, 'studentAccount' => $studentAccount));
        exit;
    }

    /* ----------------------------------------- DELETE
       ("Delete" mula sa Enrollment / New Term / Rejected Students
       list) — HINDI agad tuluyang binubura sa database ang record.
       Ang una itong "Delete" ay nag-a-ARCHIVE lang (para sa mga
       estudyanteng nag-drop o tinanggal sa listahan — makikita pa
       rin sila sa "Archive" menu). Tanging kapag NAKA-ARCHIVE NA
       ang record at "Delete" ulit ito (mula mismo sa Archive view,
       gaya ng "Delete Permanently") saka lang ito TULUYANG
       binubura sa database. */
    if ($action === 'delete') {

        if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'delete_enrollment')) {
            http_response_code(403);
            echo json_encode(array('ok' => false, 'error' => 'You do not have access to delete an enrollment record.'));
            exit;
        }

        $id = (int) ascb_get($input, 'id', 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM enrollees WHERE id = ?");
        $stmt->execute(array($id));
        $existing = $stmt->fetch();

        if (!$existing) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Enrollee not found.'));
            exit;
        }

        $alreadyArchived = !empty($existing['archived_at']);

        if (!$alreadyArchived) {

            $reason = trim(ascb_get($input, 'reason', ''));
            if ($reason !== '' && ascb_text_too_long($reason, 255)) {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Reason is too long (max 255 characters).'));
                exit;
            }

            $stmt = $pdo->prepare(
                "UPDATE enrollees
                    SET archived_at = ?, archived_by_user_id = ?, archive_reason = ?
                  WHERE id = ?"
            );
            $stmt->execute(array(
                date('Y-m-d H:i:s'),
                ascb_get($ascbUser, 'id', null),
                $reason !== '' ? $reason : null,
                $id,
            ));

            ascb_log_activity($pdo, $ascbUser, 'ENROLLEE_ARCHIVE', 'enrollee',
                $existing['surname'] . ', ' . $existing['first_name'] . ' (' . $existing['student_id'] . ')',
                $reason !== '' ? $reason : null);

            echo json_encode(array('ok' => true, 'archived' => true));
            exit;
        }

        // Naka-archive na ito — ngayon lang tuluyang mabubura sa database.
        //
        // (bug fix) Dati, walang try/catch dito — kung may Record
        // Correction request pa (record_corrections.enrollment_id ay
        // ON DELETE RESTRICT, sinasadya para hindi mawala ang audit
        // trail) na naka-link sa enrollment na ito, hinaharang ito ng
        // database sa isang foreign key constraint error. Dahil hindi
        // ito nahuhuli, bumabagsak ang buong request BAGO pa makabuo ng
        // JSON response — kaya sa browser, "Hindi ma-reach ang server.
        // Suriin ang koneksyon." (generic network-error message) ang
        // lumalabas sa user, kahit gumagana naman ang koneksyon —
        // record correction lang talaga ang dahilan.
        //
        // (bug fix 2) Ang record_corrections ay HINDI nabubura kahit
        // na-resolve na (APPROVED/REJECTED) — sinasadyang naiiwan ito
        // bilang audit trail. Pero ang activity_log (RECORD_CORRECTION_
        // REQUESTED/APPROVED/REJECTED entries) ay HIWALAY na tala ng
        // parehong pangyayari, at HINDI naka-link sa enrollees (text
        // lang ang laman nito) — kaya kahit tanggalin ang mismong
        // record_corrections rows, hindi nawawala ang audit trail sa
        // Activity Log/Student 360 Audit Timeline.
        //
        // Kaya dito: kung may PENDING pa (hindi pa naaksyunan) na
        // correction request, IHAHARANG muna ang delete — kailangan
        // munang aksyunan iyon sa Grade Management. Pero kung RESOLVED
        // na ang lahat (APPROVED/REJECTED), tatanggalin na rin ito
        // kasabay ng enrollee sa loob ng isang transaction, para hindi
        // na permanenteng naka-block ang pagbura ng isang matagal nang
        // na-archive na estudyante dahil lang sa lumang, tapos-nang
        // correction request.
        $pendingCount = $pdo->prepare("SELECT COUNT(*) FROM record_corrections WHERE enrollment_id = ? AND status = 'PENDING'");
        $pendingCount->execute(array($id));
        if ((int) $pendingCount->fetchColumn() > 0) {
            http_response_code(409);
            echo json_encode(array(
                'ok'    => false,
                'error' => 'This record cannot be permanently deleted because it still has a PENDING Record Correction request (Grade Management). Please act on that (approve/reject) first before permanently deleting this record.'
            ), JSON_UNESCAPED_UNICODE);
            exit;
        }

        try {
            $pdo->beginTransaction();
            $pdo->prepare("DELETE FROM record_corrections WHERE enrollment_id = ?")->execute(array($id));
            $stmt = $pdo->prepare("DELETE FROM enrollees WHERE id = ?");
            $stmt->execute(array($id));
            $pdo->commit();
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('ASCB enrollee permanent delete failed (id=' . $id . '): ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(array(
                'ok'    => false,
                'error' => 'This record could not be deleted due to an unexpected database error.'
            ), JSON_UNESCAPED_UNICODE);
            exit;
        }

        ascb_log_activity($pdo, $ascbUser, 'ENROLLEE_DELETE', 'enrollee', $existing['surname'] . ', ' . $existing['first_name']);

        echo json_encode(array('ok' => true, 'archived' => false));
        exit;
    }

    /* ----------------------------------------- RESTORE
       Ibinabalik ang isang naka-archive na record sa normal na
       listahan (Enrollment / New Term, o Rejected Students kung
       "rejected" pa rin ang status nito) — binubura lang ang
       archived_at / archived_by_user_id / archive_reason, hindi
       nagbabago ang status/subjects/atbp. */
    if ($action === 'restore') {

        if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'delete_enrollment')) {
            http_response_code(403);
            echo json_encode(array('ok' => false, 'error' => 'You do not have access to restore an archived record.'));
            exit;
        }

        $id = (int) ascb_get($input, 'id', 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM enrollees WHERE id = ?");
        $stmt->execute(array($id));
        $existing = $stmt->fetch();

        if (!$existing) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Enrollee not found.'));
            exit;
        }

        $stmt = $pdo->prepare(
            "UPDATE enrollees
                SET archived_at = NULL, archived_by_user_id = NULL, archive_reason = NULL
              WHERE id = ?"
        );
        $stmt->execute(array($id));

        ascb_log_activity($pdo, $ascbUser, 'ENROLLEE_RESTORE', 'enrollee',
            $existing['surname'] . ', ' . $existing['first_name'] . ' (' . $existing['student_id'] . ')');

        echo json_encode(array('ok' => true));
        exit;
    }

    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
    exit;
}


/* ========================================== OTHER METHODS */

http_response_code(405);
echo json_encode(array('ok' => false, 'error' => 'Method not allowed.'));
