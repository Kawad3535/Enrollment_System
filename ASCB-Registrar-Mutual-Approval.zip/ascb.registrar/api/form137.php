<?php
/* =========================================================
   API: FORM 137-A REQUESTS
   Nag-lo-log ng bawat Form 137-A request letter sa DB.
   Tinatawag ito ng script.js (generateForm137) kapag
   nag-preview/submit na ng request.

   POST body (JSON), default (action omitted o "create"): {
     requestDate, school, schoolAddress,
     firstRequest, secondRequest, urgentRequest,
     bearerRequest, copyForASCB,
     students: [{name, course, schoolYear, yearSection}, ...]
   }

   POST body (JSON), action="update" — itinatama ang isang
   request na nasa Records (History) na dati nang na-log,
   sa halip na gumawa ng bagong hiwalay na row:
     { action: "update", id, ...parehong fields sa itaas }
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../config/db.php';

$data = ascb_read_json_body();
$action = trim((string) ascb_get($data, 'action', 'create'));

if (empty($data['school']) || empty($data['students']) || !is_array($data['students'])) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Missing school or student list.'));
    exit;
}

if ($action === 'update') {
    $role = ascb_get($ascbUser, 'role', '');
    if (!ascb_can($role, 'manage_office_records')) {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'You do not have access to update the Records log.'));
        exit;
    }
    $id = (int) ascb_get($data, 'id', 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Invalid record id.'));
        exit;
    }
    $exists = $pdo->prepare("SELECT id FROM form137_requests WHERE id = ?");
    $exists->execute(array($id));
    if (!$exists->fetch()) {
        http_response_code(404);
        echo json_encode(array('ok' => false, 'error' => 'This record was not found.'));
        exit;
    }

    $stmt = $pdo->prepare(
        "UPDATE form137_requests SET
            request_date = ?, school_name = ?, school_address = ?, first_request = ?,
            second_request = ?, urgent_request = ?, bearer_request = ?, copy_for_ascb = ?,
            students_json = ?
         WHERE id = ?"
    );
    $stmt->execute(array(
        !empty($data['requestDate']) ? $data['requestDate'] : null,
        ascb_get($data, 'school', ''),
        ascb_get($data, 'schoolAddress', ''),
        !empty($data['firstRequest']) ? 1 : 0,
        !empty($data['secondRequest']) ? 1 : 0,
        !empty($data['urgentRequest']) ? 1 : 0,
        !empty($data['bearerRequest']) ? 1 : 0,
        !empty($data['copyForASCB']) ? 1 : 0,
        json_encode($data['students'], JSON_UNESCAPED_UNICODE),
        $id,
    ));

    ascb_log_activity($pdo, $ascbUser, 'RECORD_UPDATE', 'form137',
        ascb_get($data, 'school', ''),
        'Corrected Form 137-A request record #' . $id . ' sa Records/History.');

    echo json_encode(array('ok' => true, 'id' => $id, 'updated' => true));
    exit;
}

$stmt = $pdo->prepare(
    "INSERT INTO form137_requests
        (request_date, school_name, school_address, first_request, second_request,
         urgent_request, bearer_request, copy_for_ascb, students_json, requested_by_user_id)
     VALUES (?,?,?,?,?,?,?,?,?,?)"
);

$stmt->execute(array(
    !empty($data['requestDate']) ? $data['requestDate'] : null,
    ascb_get($data, 'school', ''),
    ascb_get($data, 'schoolAddress', ''),
    !empty($data['firstRequest']) ? 1 : 0,
    !empty($data['secondRequest']) ? 1 : 0,
    !empty($data['urgentRequest']) ? 1 : 0,
    !empty($data['bearerRequest']) ? 1 : 0,
    !empty($data['copyForASCB']) ? 1 : 0,
    json_encode($data['students'], JSON_UNESCAPED_UNICODE),
    ascb_get($ascbUser, 'id', null),
));

echo json_encode(array('ok' => true, 'id' => $pdo->lastInsertId()));
