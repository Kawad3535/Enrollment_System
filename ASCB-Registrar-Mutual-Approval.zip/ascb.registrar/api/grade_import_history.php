<?php
require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../config/db.php';

$role=ascb_get($ascbUser,'role','');
if(!ascb_can($role,'import_grades')){
    http_response_code(403); echo json_encode(array('ok'=>false,'error'=>'You do not have permission to view import history.')); exit;
}
try{
    $has=(bool)$pdo->query("SHOW TABLES LIKE 'grade_import_history'")->fetchColumn();
    if(!$has){ echo json_encode(array('ok'=>true,'rows'=>array(),'message'=>'Run php database/migrate_master.php to enable persistent import history.')); exit; }
    $limit=max(1,min(200,(int)ascb_get($_GET,'limit',50)));
    // Select the documented columns explicitly so older deployments with a
    // partially upgraded history table fail with a clear diagnostic, not a
    // fragile h.* result that the UI cannot interpret.
    $q=$pdo->prepare("SELECT h.id, h.filename, h.imported_by_user_id, h.imported_by_username,
        h.imported_at, h.file_type, h.format_detected, h.students_processed,
        h.students_created, h.students_updated, h.subjects_processed,
        h.subjects_created, h.subjects_updated, h.enrollments_created,
        h.grades_imported, h.grades_updated, h.warning_count, h.error_count,
        h.confidence, h.status, h.summary, u.display_name
        FROM grade_import_history h
        LEFT JOIN users u ON u.id=h.imported_by_user_id
        ORDER BY h.imported_at DESC, h.id DESC LIMIT ".$limit);
    $q->execute();
    echo json_encode(array('ok'=>true,'rows'=>$q->fetchAll(PDO::FETCH_ASSOC)));
}catch(Throwable $e){
    http_response_code(500); echo json_encode(array('ok'=>false,'error'=>ASCB_DEBUG?$e->getMessage():'Unable to load import history.'));
}
