<?php /* V6 Enterprise hardening applied: pagination-ready, bounded responses, secure errors. */ ?>
<?php
require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/gradebook_lock.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../includes/master_record_helper.php';
require_once __DIR__ . '/../includes/student_search.php';
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$role = strtoupper(trim((string)ascb_get($ascbUser, 'role', '')));

function ascb_grade_valid($grade) {
    $grade = trim((string)$grade);
    if ($grade === '') return true;
    /* (audit fix) Dating pattern: '5(?:\.0)?' — ibig sabihin, "5" o "5.0"
       lang ang tinatanggap na 5-family na grade. TINATANGGIHAN nito ang
       "5.00" (dalawang decimal place) — kahit ito mismo ang standard na
       paraan ng pagsulat ng FAILING grade sa Philippine grading scale
       (1.00–5.00), at kahit sinasabi mismo ng error message na "0.00–5.00"
       ang format. Ngayon: bilang (0-5, kahit ilang decimal place) o
       INC/DRP/NG lang ang tinitingnan — parehong pattern na ginagamit na
       ng ascb_gi_grade_valid() sa grade_import.php at rc_grade_valid() sa
       record_corrections.php. */
    if (preg_match('/^(INC|DRP|DR\.?|NG|P|PASSED|C|COMPETENT|[-–—])$/iu', $grade)) {
        return true;
    }
    if (is_numeric($grade)) {
        $n = (float)$grade;
        return $n >= 0 && $n <= 5;
    }
    return false;
}

if ($method === 'GET') {
    $q = trim(ascb_get($_GET, 'q', ''));
    $studentId = trim(ascb_get($_GET, 'student_id', ''));
    // Grade Evaluation is a read-only cross-department view for all authenticated roles.
    // Grade Management keeps the assigned-department restriction for DEAN / ADMIN STAFF.
    // DEAN is NOT included in the cross-department view: a Dean sees only their own Department
    // even in Grade Evaluation (server-side boundary, not just a UI filter).
    $allDepartmentsView = strtolower(trim((string)ascb_get($_GET, 'view', ''))) === 'grade_evaluation' && $role !== 'DEAN';
    /* Dating units ng subject kapag naging 0 ito dahil sa bagsak na grade (hal. INC/5.0).
       Kinukuha sa history ng grade submissions para maibalik kapag naitama na sa pasadong grade. */
    $restoreUnitsSql = 'NULL';
    try {
        if ($pdo->query("SHOW TABLES LIKE 'gradebook_approval_items'")->fetchColumn()) {
            $hasOldUnits = false;
            foreach ($pdo->query("SHOW COLUMNS FROM gradebook_approval_items")->fetchAll(PDO::FETCH_ASSOC) as $c) { if ($c['Field'] === 'old_units') $hasOldUnits = true; }
            if ($hasOldUnits) $restoreUnitsSql = "(SELECT gai.old_units FROM gradebook_approval_items gai WHERE gai.enrollment_subject_id = es.id AND gai.old_units > 0 ORDER BY gai.id ASC LIMIT 1)";
        }
    } catch (Throwable $e) { $restoreUnitsSql = 'NULL'; }
    $sql = "SELECT e.id AS enrollment_id, e.student_id, e.surname, e.first_name, e.middle_name" . ascb_suffix_sql_cols($pdo) . ",
                   e.course, e.major, e.program_code, e.year_level, e.trimester, e.school_year,
                   e.status, e.created_at,
                   es.id AS enrollment_subject_id, es.course_code, es.description, es.units, es.hidden_on_print,
                   " . $restoreUnitsSql . " AS restore_units,
                   g.grade, g.updated_at AS grade_updated_at
            FROM enrollees e
            LEFT JOIN enrollment_subjects es ON es.enrollment_id = e.id
            LEFT JOIN grades g ON g.enrollment_subject_id = es.id
            WHERE e.archived_at IS NULL AND e.status = 'approved'";
    $params = [];
    if (!$allDepartmentsView && in_array($role, ['ADMIN STAFF','DEAN'], true)) {
        $scope = ascb_role_assignment_scope_sql($pdo, $ascbUser, 'e');
        $sql .= $scope['sql']; $params = array_merge($params, $scope['params']);
    }
    if ($studentId !== '') { $sql .= " AND UPPER(TRIM(e.student_id)) = UPPER(TRIM(?))"; $params[] = $studentId; }
    if ($q !== '') {
        /* Full name o Student ID (includes/student_search.php) */
        $sc = ascb_student_search_clause($q, 'e', ascb_master_available($pdo), array('course', 'major'));
        $qClause = ($sc['sql'] !== '') ? $sc['sql'] : '1=1';
        $qLikes = $sc['params'];
        $sql .= " AND " . $qClause;
        $params = array_merge($params, $qLikes);
    }
    $studentGrouped = !isset($_GET['group']) || strtolower(trim((string)ascb_get($_GET, 'group', ''))) === 'student';

    // Pagination parameters MUST be initialized before the grouped query uses
    // them. Without this, PHP 8 emits Undefined variable warnings before the
    // JSON response, causing Grade Management / Grade Evaluation to fail when
    // their fetch() calls try to parse the response as JSON.
    $page = max(1, (int)ascb_get($_GET, 'page', 1));
    $limit = min(100, max(10, (int)ascb_get($_GET, 'limit', 25)));
    $offset = ($page - 1) * $limit;

    if ($studentGrouped) {
        /*
         * Scalable mode for Grade Management / Grade Evaluation:
         * paginate DISTINCT STUDENTS first, then fetch all subjects for
         * only those students. This preserves the flat row shape expected
         * by the existing JavaScript while preventing a database-wide
         * subject fetch.
         */
        $countSql = "SELECT COUNT(DISTINCT UPPER(TRIM(e.student_id))) FROM enrollees e
                     WHERE e.archived_at IS NULL AND e.status = 'approved'";
        $countParams = [];
        if (!$allDepartmentsView && in_array($role, ['ADMIN STAFF','DEAN'], true)) {
            $scope = ascb_role_assignment_scope_sql($pdo, $ascbUser, 'e');
            $countSql .= $scope['sql']; $countParams = array_merge($countParams, $scope['params']);
        }
        if ($studentId !== '') { $countSql .= " AND UPPER(TRIM(e.student_id)) = UPPER(TRIM(?))"; $countParams[] = $studentId; }
        if ($q !== '') {
            $countSql .= " AND " . $qClause;
            $countParams = array_merge($countParams, $qLikes);
        }
        $c = $pdo->prepare($countSql);
        $c->execute($countParams);
        $total = (int)$c->fetchColumn();

        $idSql = "SELECT UPPER(TRIM(e.student_id)) AS student_id, MIN(e.surname) AS surname, MIN(e.first_name) AS first_name,
                         MIN(e.created_at) AS created_at
                  FROM enrollees e
                  WHERE e.archived_at IS NULL AND e.status = 'approved'";
        $idParams = [];
        if (!$allDepartmentsView && in_array($role, ['ADMIN STAFF','DEAN'], true)) {
            $scope = ascb_role_assignment_scope_sql($pdo, $ascbUser, 'e');
            $idSql .= $scope['sql']; $idParams = array_merge($idParams, $scope['params']);
        }
        if ($studentId !== '') { $idSql .= " AND UPPER(TRIM(e.student_id)) = UPPER(TRIM(?))"; $idParams[] = $studentId; }
        if ($q !== '') {
            $idSql .= " AND " . $qClause;
            $idParams = array_merge($idParams, $qLikes);
        }
        $idSql .= " GROUP BY UPPER(TRIM(e.student_id)) ORDER BY surname, first_name, created_at LIMIT $limit OFFSET $offset";
        $idStmt = $pdo->prepare($idSql);
        $idStmt->execute($idParams);
        $studentIds = $idStmt->fetchAll(PDO::FETCH_COLUMN);

        if (!$studentIds) {
            echo json_encode(['ok'=>true,'page'=>$page,'limit'=>$limit,'total'=>$total,'pages'=>(int)ceil($total/max(1,$limit)),'rows'=>[]], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $studentIds = array_values(array_unique(array_map(function($v) {
            $v = trim((string)$v);
            return function_exists('mb_strtoupper') ? mb_strtoupper($v, 'UTF-8') : strtoupper($v);
        }, $studentIds)));
        $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
        $rowsSql = $sql . " AND UPPER(TRIM(e.student_id)) IN ($placeholders)
                           ORDER BY e.surname, e.first_name, e.created_at, es.id";
        $rowsStmt = $pdo->prepare($rowsSql);
        $rowsStmt->execute(array_merge($params, $studentIds));
        $rows = $rowsStmt->fetchAll();

        $rows = array_map('ascb_row_print_split', $rows); /* PSA placement ng suffix */
        echo json_encode(['ok'=>true,'page'=>$page,'limit'=>$limit,'total'=>$total,
                          'pages'=>(int)ceil($total/max(1,$limit)),'rows'=>$rows], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $countSql="SELECT COUNT(*) FROM (".$sql.") t";

    $c=$pdo->prepare($countSql); $c->execute($params); $total=(int)$c->fetchColumn();

    /* Legacy flat mode remains available only when explicitly requested
       with group=flat. Normal callers use student-group pagination so a
       large database is never fetched into PHP/browser accidentally. */
    $pagingRequested = isset($_GET['page']) || isset($_GET['limit']);
    /* Safety guard: legacy group=flat callers must never accidentally
       materialize the entire grade table into PHP/browser memory.
       Existing paged callers keep their requested page size. */
    if ($pagingRequested) {
        $sql .= " ORDER BY e.surname, e.first_name, e.created_at, es.id LIMIT $limit OFFSET $offset";
    } else {
        $legacyLimit = min(1000, max(1, $limit));
        $sql .= " ORDER BY e.surname, e.first_name, e.created_at, es.id LIMIT $legacyLimit";
    }
    $stmt=$pdo->prepare($sql); $stmt->execute($params);
    $rows=array_map('ascb_row_print_split', $stmt->fetchAll()); /* PSA placement ng suffix */
    echo json_encode(['ok'=>true,'page'=>$page,'limit'=>$limit,'total'=>$total,'pages'=>(int)ceil($total/max(1,$limit)),'rows'=>$rows], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($method === 'POST') {
    $input = ascb_read_json_body();
    $action = trim((string)($input['action'] ?? 'save'));

    /* Student visibility / "Hide on Print" toggle — Grade Evaluation.
       Isang subject lang
       kada request (checkbox click), kaya agad na-save, walang
       hiwalay na "Save" button na kailangan pang pindutin. Hindi
       nito ginagalaw ang grades table/GWA — display-only flag ito
       sa enrollment_subjects, kaya 'hide_grades' na lang ang
       kailangan dito (bukas din ito sa ADMIN STAFF), hindi na kailangan
       ang buong 'manage_grades' na para sa aktwal na pag-encode ng grade.
       Ang DEAN ay limitado sa sarili niyang Department. */
    if ($action === 'set_hidden') {
        if (!ascb_can($role, 'manage_grades') && !ascb_can($role, 'hide_grades')) {
            http_response_code(403); echo json_encode(['ok'=>false,'error'=>'You do not have permission to hide grades.']); exit;
        }
        $subjectId = (int)($input['subjectId'] ?? 0);
        $hidden = !empty($input['hidden']) ? 1 : 0;
        if ($subjectId <= 0) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid subject.']); exit; }

        $info = $pdo->prepare("SELECT es.id, es.course_code, e.surname, e.first_name, e.student_id, e.trimester, e.school_year, COALESCE(NULLIF(e.department_id,0),(SELECT p.department_id FROM programs p WHERE UPPER(TRIM(p.code))=UPPER(TRIM(COALESCE(NULLIF(e.program_code,''),e.course,''))) LIMIT 1)) AS department_id
                                FROM enrollment_subjects es
                                INNER JOIN enrollees e ON e.id = es.enrollment_id
                                WHERE es.id = ?");
        $info->execute([$subjectId]);
        $subjectInfo = $info->fetch();
        if (!$subjectInfo) { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'Subject not found.']); exit; }
        if (in_array($role, ['DEAN','ADMIN STAFF'], true)) {
            // Sundin ang Assign (department/program) ng user — pareho sa listahan ng Grade Evaluation.
            $hs = ascb_role_assignment_scope_sql($pdo, $ascbUser, 'e');
            $hc = $pdo->prepare("SELECT 1 FROM enrollees e INNER JOIN enrollment_subjects es ON es.enrollment_id = e.id WHERE es.id = ? " . $hs['sql'] . " LIMIT 1");
            $hc->execute(array_merge([$subjectId], $hs['params']));
            if (!$hc->fetchColumn()) {
                http_response_code(403); echo json_encode(['ok'=>false,'error'=>'You can only change visibility for students in your assigned Department(s).']); exit;
            }
        }

        $upd = $pdo->prepare("UPDATE enrollment_subjects SET hidden_on_print = ? WHERE id = ?");
        $upd->execute([$hidden, $subjectId]);

        ascb_log_activity($pdo, $ascbUser, 'GRADE_UPDATE', 'enrollment',
            $subjectInfo['surname'].', '.$subjectInfo['first_name'].' ('.$subjectInfo['student_id'].')',
            ($hidden ? 'Hid' : 'Unhid').' the grade and units for the student portal, and grade on print, of '.$subjectInfo['course_code'].' ('.$subjectInfo['trimester'].' / '.$subjectInfo['school_year'].') sa Grade Evaluation.');

        echo json_encode(['ok'=>true]); exit;
    }

    if ($action !== 'save') { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid grade action.']); exit; }
    if (!ascb_can($role, 'manage_grades')) {
        http_response_code(403); echo json_encode(['ok'=>false,'error'=>'You do not have permission to enter or update grades.']); exit;
    }
    /* Official grade entry is performed by Admin Staff as a staged submission.
       Unit Head and School Registrar must use gradebook_approvals.php to review
       and finalize; they cannot write official grades through this direct API.
       Authorized historical changes remain available through record_corrections.php. */
    if (!in_array($role, ['ADMIN STAFF', 'UNIT HEAD', 'SCHOOL REGISTRAR'], true)) {
        http_response_code(403);
        echo json_encode(['ok'=>false,'error'=>'You do not have permission to encode grades.']);
        exit;
    }
    $enrollmentId = (int)($input['enrollmentId'] ?? 0);
    $grades = $input['grades'] ?? [];
    if ($enrollmentId <= 0 || !is_array($grades)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid grade data.']); exit; }

    // Dapat "approved" na ang enrollment bago pwedeng bigyan ng grade —
    // kasabay ng fix na "hindi dapat mag-appear sa Grade Evaluation/
    // Grade Management hangga't hindi pa naa-approve ng UNIT HEAD".
    // Ito ang tunay na security boundary (hindi lang yung pag-hide sa
    // listahan sa frontend) — kahit direktang tawagin ang API, hindi
    // pa rin makaka-save ng grade sa isang "pending" o "rejected" pa.
    $checkSql = "SELECT e.id, e.student_id, e.surname, e.first_name, e.trimester, e.school_year,
                    COALESCE(NULLIF(e.department_id,0),(SELECT p.department_id FROM programs p WHERE UPPER(TRIM(p.code))=UPPER(TRIM(COALESCE(NULLIF(e.program_code,''),e.course,''))) LIMIT 1)) AS department_id
                 FROM enrollees e WHERE e.id = ? AND e.archived_at IS NULL AND e.status = 'approved'";
    $checkParams = [$enrollmentId];
    if ($role === 'ADMIN STAFF') {
        $scope = ascb_staff_assignment_scope_sql($pdo, $ascbUser, 'e');
        $checkSql .= $scope['sql']; $checkParams = array_merge($checkParams, $scope['params']);
    }
    $check = $pdo->prepare($checkSql);
    $check->execute($checkParams); $enrollment = $check->fetch();
    if (!$enrollment) { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'Enrollment term not found, or it has not yet been approved by the Unit Head.']); exit; }

    /* All authorized encoders submit staged grades. Admin Staff are limited
       to assigned departments; Unit Head and School Registrar may encode
       across departments, but their own entries require peer approval.
       Official grades/units remain untouched until the authorized reviewer approves. */
    if (in_array($role, ['ADMIN STAFF', 'UNIT HEAD', 'SCHOOL REGISTRAR'], true)) {
        // The enrollment itself has already been checked against the user's
        // active department/program assignments above. Use its actual department
        // for the approval workflow; ADMIN STAFF no longer needs one legacy
        // users.department_id value when assigned to multiple departments.
        $deptId = (int)($enrollment['department_id'] ?? 0);
        if ($deptId < 1) {
            http_response_code(403); echo json_encode(['ok'=>false,'error'=>'The assigned program has no resolvable department. Please ask the Unit Head to review the program catalog.']); exit;
        }
        $pdo->exec("CREATE TABLE IF NOT EXISTS gradebook_approval_submissions (
            id BIGINT AUTO_INCREMENT PRIMARY KEY, department_id INT NOT NULL, school_year VARCHAR(30) NOT NULL, term VARCHAR(50) NOT NULL,
            course_code VARCHAR(100) DEFAULT '', description VARCHAR(255) DEFAULT '', submitted_by INT NOT NULL, submitted_by_name VARCHAR(150) DEFAULT NULL,
            status ENUM('PENDING_UNIT_HEAD','PENDING_REGISTRAR','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING_UNIT_HEAD',
            unit_head_id INT DEFAULT NULL, unit_head_at DATETIME DEFAULT NULL, registrar_id INT DEFAULT NULL, registrar_at DATETIME DEFAULT NULL,
            rejection_reason VARCHAR(500) DEFAULT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX idx_gas_status_dept(status,department_id), INDEX idx_gas_created(created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS gradebook_approval_items (
            id BIGINT AUTO_INCREMENT PRIMARY KEY, submission_id BIGINT NOT NULL, enrollment_subject_id INT NOT NULL,
            student_id VARCHAR(100) DEFAULT NULL, student_name VARCHAR(255) DEFAULT NULL, old_grade VARCHAR(30) DEFAULT NULL, new_grade VARCHAR(30) DEFAULT NULL,
            old_units DECIMAL(8,2) DEFAULT NULL, new_units DECIMAL(8,2) DEFAULT NULL,
            UNIQUE KEY uq_gai_submission_subject(submission_id,enrollment_subject_id), INDEX idx_gai_submission(submission_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $itemCols = [];
        foreach ($pdo->query("SHOW COLUMNS FROM gradebook_approval_items")->fetchAll(PDO::FETCH_ASSOC) as $col) $itemCols[$col['Field']] = true;
        if (!isset($itemCols['old_units'])) $pdo->exec("ALTER TABLE gradebook_approval_items ADD COLUMN old_units DECIMAL(8,2) DEFAULT NULL");
        if (!isset($itemCols['new_units'])) $pdo->exec("ALTER TABLE gradebook_approval_items ADD COLUMN new_units DECIMAL(8,2) DEFAULT NULL");

        $prepared = [];
        $alreadyPending = 0;
        /* Iwas duplicate: kung may PENDING na submission na (Unit Head / Registrar) para sa parehong subject
           na may parehong grade at units, huwag nang gumawa ulit. */
        $dupStmt = $pdo->prepare("SELECT i.new_grade, COALESCE(i.new_units,0) AS new_units FROM gradebook_approval_items i JOIN gradebook_approval_submissions s ON s.id=i.submission_id WHERE i.enrollment_subject_id=? AND s.status IN ('PENDING_UNIT_HEAD','PENDING_REGISTRAR') ORDER BY i.id DESC LIMIT 1");
        $subjectStmt = $pdo->prepare("SELECT es.id, es.course_code, es.description, es.units, e.student_id, e.surname, e.first_name, e.middle_name, e.school_year, e.trimester, COALESCE(NULLIF(e.department_id,0),(SELECT p.department_id FROM programs p WHERE UPPER(TRIM(p.code))=UPPER(TRIM(COALESCE(NULLIF(e.program_code,''),e.course,''))) LIMIT 1)) AS department_id, g.grade
            FROM enrollment_subjects es JOIN enrollees e ON e.id=es.enrollment_id LEFT JOIN grades g ON g.enrollment_subject_id=es.id
            WHERE es.id=? AND es.enrollment_id=? AND e.status='approved' AND e.archived_at IS NULL");
        foreach ($grades as $item) {
            $subjectId = (int)($item['subjectId'] ?? 0);
            $grade = trim((string)($item['grade'] ?? ''));
            if ($subjectId <= 0 || !ascb_grade_valid($grade)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid grade data. Nothing was submitted.']); exit; }
            $grade = ascb_normalize_grade($grade);
            if ($grade !== '' && is_numeric($grade) && (float)$grade === 0.0) $grade = '';
            $subjectStmt->execute([$subjectId, $enrollmentId]); $sr = $subjectStmt->fetch(PDO::FETCH_ASSOC);
            if (!$sr || (int)$sr['department_id'] !== $deptId) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'A subject is outside your assigned department or enrollment. Nothing was submitted.']); exit; }
            $unitsInput = trim((string)($item['units'] ?? $sr['units']));
            if (preg_match('/^[-–—]$/u', $unitsInput)) $unitsInput = '0';
            if (!is_numeric($unitsInput) || (float)$unitsInput < 0 || (float)$unitsInput > 99) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid units. Nothing was submitted.']); exit; }
            /* Safeguard: kung pasado ang grade pero 0 ang units dahil dati itong na-zero ng bagsak na grade,
               ibalik ang dating units mula sa history ng submissions. */
            if ($grade !== '' && $grade !== '-' && !ascb_grade_is_failing($grade) && (float)$unitsInput === 0.0 && (float)$sr['units'] === 0.0) {
                $rs = $pdo->prepare("SELECT old_units FROM gradebook_approval_items WHERE enrollment_subject_id=? AND old_units>0 ORDER BY id ASC LIMIT 1");
                $rs->execute([$subjectId]);
                $prevUnits = $rs->fetchColumn();
                if ($prevUnits !== false && (float)$prevUnits > 0) $unitsInput = (string)(float)$prevUnits;
            }
            /* Isama LANG sa submission ang subject na may tunay na pagbabago sa grade o units.
               Hindi dapat lumabas sa Unit Head ang mga subject na hindi ginalaw. */
            $oldGradeNorm = trim((string)($sr['grade'] ?? ''));
            if ($oldGradeNorm !== '') $oldGradeNorm = ascb_normalize_grade($oldGradeNorm);
            if ($oldGradeNorm !== '' && is_numeric($oldGradeNorm) && (float)$oldGradeNorm === 0.0) $oldGradeNorm = '';
            $gradeUnchanged = ($grade === $oldGradeNorm);
            $unitsUnchanged = (abs((float)$unitsInput - (float)$sr['units']) < 0.001);
            if ($gradeUnchanged && $unitsUnchanged) continue;
            $proposedUnitsCheck = ascb_grade_is_failing($grade) ? 0.0 : (float)$unitsInput;
            $dupStmt->execute([$subjectId]);
            $pendingRow = $dupStmt->fetch(PDO::FETCH_ASSOC);
            if ($pendingRow) {
                if (trim((string)($pendingRow['new_grade'] ?? '')) === $grade && abs((float)$pendingRow['new_units'] - $proposedUnitsCheck) < 0.001) $alreadyPending++;
                else { http_response_code(409); echo json_encode(['ok'=>false,'locked'=>true,'error'=>'This subject already has a grade submission waiting for approval. The pending submission must be resolved before another change can be submitted.']); exit; }
                continue;
            }
            $prepared[] = ['row'=>$sr,'grade'=>$grade,'units'=>(float)$unitsInput];
        }
        if (!$prepared) {
            http_response_code(400);
            echo json_encode(['ok'=>false,'error'=>$alreadyPending>0 ? 'These changes are already waiting for approval. No duplicate submission was created.' : 'No changes to submit. Only grades or units you actually changed are sent to the Unit Head.']);
            exit;
        }
        try {
            $pdo->beginTransaction();
            /* Serialize submissions per enrollment_subject. A second request
               waits here, then sees the first request's pending item below. */
            $lockIds=array_values(array_unique(array_map(function($x){ return (int)$x['row']['id']; },$prepared)));
            sort($lockIds,SORT_NUMERIC);
            $lockSubject=$pdo->prepare('SELECT id FROM enrollment_subjects WHERE id=? FOR UPDATE');
            foreach($lockIds as $lockId){ $lockSubject->execute([$lockId]); if(!$lockSubject->fetchColumn()) throw new Exception('A subject was removed before submission. Please reload the gradebook.'); }
            $pendingCheck=$pdo->prepare("SELECT i.new_grade,COALESCE(i.new_units,0) AS new_units FROM gradebook_approval_items i JOIN gradebook_approval_submissions s ON s.id=i.submission_id WHERE i.enrollment_subject_id=? AND s.status IN ('PENDING_UNIT_HEAD','PENDING_REGISTRAR') ORDER BY i.id DESC LIMIT 1");
            $officialCheck=$pdo->prepare('SELECT es.units,g.grade FROM enrollment_subjects es LEFT JOIN grades g ON g.enrollment_subject_id=es.id WHERE es.id=? FOR UPDATE');
            $safePrepared=[]; $raceDuplicates=0; $alreadyApplied=0;
            foreach($prepared as $candidate){
                $subjectId=(int)$candidate['row']['id'];
                $candidateUnits=ascb_grade_is_failing($candidate['grade'])?0.0:(float)$candidate['units'];
                $pendingCheck->execute([$subjectId]); $pending=$pendingCheck->fetch(PDO::FETCH_ASSOC);
                if($pending){
                    if(trim((string)($pending['new_grade']??''))===$candidate['grade'] && abs((float)$pending['new_units']-$candidateUnits)<0.001){ $raceDuplicates++; continue; }
                    throw new Exception('A grade for one of these subjects was submitted by another request and is awaiting approval. No duplicate submission was created.');
                }
                /* If Registrar finalized while this request waited for the row lock,
                   recognize the now-official value instead of creating a second queue item. */
                $officialCheck->execute([$subjectId]); $official=$officialCheck->fetch(PDO::FETCH_ASSOC);
                if(!$official) throw new Exception('A subject was removed before submission. Please reload the gradebook.');
                $currentGrade=trim((string)($official['grade']??''));
                if($currentGrade!=='') $currentGrade=ascb_normalize_grade($currentGrade);
                $oldGrade=trim((string)($candidate['row']['grade']??''));
                if($oldGrade!=='') $oldGrade=ascb_normalize_grade($oldGrade);
                if($currentGrade===$candidate['grade'] && abs((float)$official['units']-$candidateUnits)<0.001){ $alreadyApplied++; continue; }
                if($currentGrade!==$oldGrade) throw new Exception('The official grade changed while this submission was being prepared. Please reload the gradebook before submitting again.');
                $safePrepared[]=$candidate;
            }
            $prepared=$safePrepared; $alreadyPending += $raceDuplicates;
            if(!$prepared){
                $pdo->rollBack();
                if($alreadyApplied>0 && $alreadyPending===0){ echo json_encode(['ok'=>true,'pending_approval'=>false,'already_applied'=>$alreadyApplied,'message'=>'These grades have already been finalized. No duplicate submission was created.']); exit; }
                http_response_code(409); echo json_encode(['ok'=>false,'pending_approval'=>true,'duplicates'=>$alreadyPending,'error'=>'These grades are already waiting for approval. No duplicate submission was created.']); exit;
            }
            $first=$prepared[0]['row'];
            $name=trim((string)($ascbUser['display_name']??$ascbUser['username']??'Admin Staff'));
            $initialStatus = $role === 'UNIT HEAD' ? 'PENDING_REGISTRAR' : 'PENDING_UNIT_HEAD';
            $ins=$pdo->prepare("INSERT INTO gradebook_approval_submissions(department_id,school_year,term,course_code,description,submitted_by,submitted_by_name,status) VALUES(?,?,?,?,?,?,?,?)");
            $ins->execute([$deptId,$first['school_year'],$first['trimester'],'Grade Management','Student grade entry',(int)$ascbUser['id'],$name,$initialStatus]);
            $submissionId=(int)$pdo->lastInsertId();
            $ii=$pdo->prepare("INSERT INTO gradebook_approval_items(submission_id,enrollment_subject_id,student_id,student_name,old_grade,new_grade,old_units,new_units) VALUES(?,?,?,?,?,?,?,?)");
            foreach ($prepared as $item) {
                $r=$item['row'];
                $studentName=trim($r['surname'].', '.$r['first_name'].' '.$r['middle_name']);
                $oldUnits=(float)$r['units'];
                $proposedUnits=ascb_grade_is_failing($item['grade']) ? 0.0 : (float)$item['units'];
                $ii->execute([$submissionId,(int)$r['id'],(string)$r['student_id'],$studentName,$r['grade']??null,$item['grade']!==''?$item['grade']:null,$oldUnits,$proposedUnits]);
            }
            /* RE-SUBMIT cleanup: kapag may na-reject na submission (sariling gawa) na may parehong subject, ang bagong
               submission na ito na ang pumapalit — alisin ang lumang rejected item (at ang rejected submission kapag
               wala nang natirang item) para hindi na ma-re-submit ang lumang maling grade. */
            $rejQ=$pdo->prepare("SELECT i.id,i.submission_id FROM gradebook_approval_items i JOIN gradebook_approval_submissions s ON s.id=i.submission_id WHERE i.enrollment_subject_id=? AND s.status='REJECTED' AND s.submitted_by=? AND s.id<>?");
            $delRejItem=$pdo->prepare("DELETE FROM gradebook_approval_items WHERE id=?");
            $touchedRej=[];
            foreach ($prepared as $item) {
                $rejQ->execute([(int)$item['row']['id'],(int)$ascbUser['id'],$submissionId]);
                foreach ($rejQ->fetchAll(PDO::FETCH_ASSOC) as $rj) { $delRejItem->execute([(int)$rj['id']]); $touchedRej[(int)$rj['submission_id']]=true; }
            }
            if ($touchedRej) {
                $cntRej=$pdo->prepare("SELECT COUNT(*) FROM gradebook_approval_items WHERE submission_id=?");
                $delRejSub=$pdo->prepare("DELETE FROM gradebook_approval_submissions WHERE id=? AND status='REJECTED'");
                foreach (array_keys($touchedRej) as $rsid) { $cntRej->execute([$rsid]); if ((int)$cntRej->fetchColumn()===0) $delRejSub->execute([$rsid]); }
            }
            $pdo->commit();
            $reviewTarget = $role === 'UNIT HEAD' ? 'School Registrar' : 'Unit Head';
            ascb_log_activity($pdo,$ascbUser,'GRADEBOOK_SUBMITTED_FOR_APPROVAL','gradebook_approval',(string)$submissionId,'Grade Management submission for '.$first['school_year'].' / '.$first['trimester'].' awaiting '.$reviewTarget.' review.');
            echo json_encode(['ok'=>true,'pending_approval'=>true,'submission_id'=>$submissionId,'changed'=>count($prepared),'message'=>'Grades submitted for '.$reviewTarget.' review. Official grades and units remain unchanged until the other authorized reviewer approves.'],JSON_UNESCAPED_UNICODE); exit;
        } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); error_log('ASCB grade submission failure: '.$e->getMessage()); http_response_code(500); echo json_encode(['ok'=>false,'error'=>'Unable to submit grades for approval. No official records were changed.']); exit; }
    }

    try {
        $pdo->beginTransaction();
        $subjectCheck = $pdo->prepare("SELECT es.id, es.units, es.course_code, es.description, e.school_year, e.trimester, COALESCE(NULLIF(e.department_id,0),(SELECT p.department_id FROM programs p WHERE UPPER(TRIM(p.code))=UPPER(TRIM(COALESCE(NULLIF(e.program_code,''),e.course,''))) LIMIT 1)) AS department_id
            FROM enrollment_subjects es
            INNER JOIN enrollees e ON e.id = es.enrollment_id
            WHERE es.id = ? AND es.enrollment_id = ? AND e.archived_at IS NULL AND e.status = 'approved'");
        $find = $pdo->prepare("SELECT id, grade FROM grades WHERE enrollment_subject_id = ? LIMIT 1");
        $insert = $pdo->prepare("INSERT INTO grades (enrollment_subject_id, grade, entered_by_user_id, entered_at) VALUES (?, ?, ?, ?)");
        $update = $pdo->prepare("UPDATE grades SET grade = ?, updated_by_user_id = ?, updated_at = ? WHERE id = ?");
        $updateUnits = $pdo->prepare("UPDATE enrollment_subjects SET units = ? WHERE id = ?");
        $now = date('Y-m-d H:i:s');
        $changed = 0;
        foreach ($grades as $item) {
            $subjectId = (int)($item['subjectId'] ?? 0);
            $grade = trim((string)($item['grade'] ?? ''));
            if ($subjectId <= 0 || !ascb_grade_valid($grade)) {
                throw new Exception('Invalid grade. Use 0.00–5.00, INC, Dr., NG, P, "-", or leave blank.');
            }
            $grade = ascb_normalize_grade($grade); // standardized format, e.g. "2" -> "2.0"
            // 0 / 0.0 is the system's NOT GRADED placeholder. Clear any saved grade.
            $gradeIsPending = is_numeric($grade) && (float)$grade === 0.0;
            if ($gradeIsPending) $grade = '';
            $subjectCheck->execute([$subjectId, $enrollmentId]);
            $subjectRow = $subjectCheck->fetch();
            if (!$subjectRow) throw new Exception('Invalid subject for this enrollment.');

            // Defense in depth: every grade write must remain inside the
            // authenticated user's assigned department, even if this save
            // path is reused or permissions change in the future.
            if (in_array($role, ['DEAN', 'ADMIN STAFF'], true)) {
                $assignedDepartmentId = (int)ascb_require_dean_department($pdo, $ascbUser);
                if ((int)$subjectRow['department_id'] !== $assignedDepartmentId) {
                    throw new Exception('You can encode grades only for students in your assigned department. No changes were saved.');
                }
            }
            ascb_gradebook_lock_assert_editable($pdo, $subjectRow['school_year'], $subjectRow['trimester'], $subjectRow['course_code'], $subjectRow['description'], $role);

            if (array_key_exists('units', $item) && $item['units'] !== null && $item['units'] !== '') {
                $unitsIn = trim((string)$item['units']);
                /* (Dash) Units na "-" (hal. Comprehensive Exam) = 0 units.
                   Parehong panuntunan ng grade_import.php. */
                if (preg_match('/^[-–—]$/u', $unitsIn)) $unitsIn = '0';
                if (!is_numeric($unitsIn)) throw new Exception('Invalid units. Enter a number or "-".');
                $units = (float)$unitsIn;
                if ($units < 0 || $units > 99) throw new Exception('Invalid units. Must be between 0 and 99.');
                if ((float)$subjectRow['units'] !== $units) { $updateUnits->execute([$units, $subjectId]); $changed++; }
            }

            // Preserve imported/curriculum units when a grade is entered.
            // A failing grade (4.00/5.00, INC, DRP, NG) changes the grade
            // status, not the subject's credited units. Only an explicit
            // units value supplied by the user may change units here.
            // Keep the legacy dash rule for subjects explicitly graded "-".
            if ($grade === '-') {
                // Database stores numeric units; UI/report layers render 0 units as '-' for dash grades.
                if ((float)$subjectRow['units'] !== 0.0) { $updateUnits->execute([0, $subjectId]); $changed++; }
            }

            $find->execute([$subjectId]); $old = $find->fetch();
            if ($old) {
                if ((string)$old['grade'] !== $grade) { $update->execute([$grade !== '' ? $grade : null, (int)$ascbUser['id'], $now, (int)$old['id']]); $changed++; }
            } elseif ($grade !== '') {
                $insert->execute([$subjectId, $grade, (int)$ascbUser['id'], $now]); $changed++;
            }
        }
        $pdo->commit();
        ascb_log_activity($pdo, $ascbUser, 'GRADE_UPDATE', 'enrollment', $enrollment['surname'].', '.$enrollment['first_name'].' ('.$enrollment['student_id'].')', 'Updated '.$changed.' grade(s) for '.$enrollment['trimester'].' / '.$enrollment['school_year']);
        echo json_encode(['ok'=>true,'changed'=>$changed]); exit;
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('ASCB grade save database failure: ' . $e->getMessage());
        http_response_code(500); echo json_encode(['ok'=>false,'error'=>'Unable to save grades due to a database error. No changes were committed.']); exit;
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        http_response_code(400); echo json_encode(['ok'=>false,'error'=>$e->getMessage()]); exit;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('ASCB grade save unexpected failure: ' . $e->getMessage());
        http_response_code(500); echo json_encode(['ok'=>false,'error'=>'Unable to save grades. No changes were committed.']); exit;
    }
}

http_response_code(405); echo json_encode(['ok'=>false,'error'=>'Method not allowed.']);
