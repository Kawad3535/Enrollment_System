<?php /* V6 Enterprise hardening applied: pagination-ready, bounded responses, secure errors. */ ?>
<?php
/* =========================================================
   API: HONORS (President's Lister / Dean's Lister)
   ---------------------------------------------------------
   GET params:
     trimester   (opsyonal) — hal. "1st Trimester"
     school_year (opsyonal) — hal. "2024-2025"

   Ang buong computation logic (GWA per Term, cutoffs,
   DEAN department scoping) ay nasa includes/honors_helper.php
   (ascb_honors_rows) — parehong ginagamit ng Excel export sa
   api/honors_export.php para laging magkatugma ang nakikita
   sa screen at ang na-e-export.

   Bukas ito sa kahit sinong naka-login (basa lang, walang
   binabagong data) — pero ang DEAN ay sariling Department
   lang ang makikita (nasa loob na ng helper ang filter).
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/honors_helper.php';
require_once __DIR__ . '/../config/db.php';

/* ADMIN STAFF: walang access sa President's & Dean's Lister. */
if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'view_honors')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'You do not have access to this page.'));
    exit;
}

$trimester  = trim((string) ascb_get($_GET, 'trimester', ''));
$schoolYear = trim((string) ascb_get($_GET, 'school_year', ''));

try {
    $rows = ascb_honors_rows($pdo, $ascbUser, $trimester, $schoolYear);
    echo json_encode(array('ok' => true, 'rows' => $rows), JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    error_log('ASCB honors report failed: ' . get_class($e));
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'Unable to load the honors report. Check the database connection and academic records, then try again.'), JSON_UNESCAPED_UNICODE);
}
