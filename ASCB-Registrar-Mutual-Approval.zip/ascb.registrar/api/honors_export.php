<?php
/* ASCB Registrar — Large-data Honors Export.
 * Uses SQL aggregation + unbuffered PDO fetch. No fetchAll(), no giant PHP arrays.
 */
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/honors_helper.php';
require_once __DIR__ . '/../config/db.php';

/* ADMIN STAFF: walang access sa President's & Dean's Lister. */
if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'view_honors')) {
    http_response_code(403); exit('Forbidden');
}

$csrfToken = ascb_get($_GET, 'csrf', '');
if (!ascb_verify_csrf($csrfToken)) {
    http_response_code(403); exit('Expired o invalid ang request token. I-refresh ang page at subukan muli.');
}
$trimester = trim((string) ascb_get($_GET, 'trimester', ''));
$schoolYear = trim((string) ascb_get($_GET, 'school_year', ''));

// A separate unbuffered connection keeps the result set out of PHP's memory.
$dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
$exportPdo = new PDO($dsn, DB_USER, DB_PASS, array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => false,
));
$exportPdo->exec("SET time_zone = '+08:00'");

$where = array("e.archived_at IS NULL", "LOWER(TRIM(e.status)) = 'approved'");
$params = array();
$role = ascb_get($ascbUser, 'role', '');
if ($role === 'DEAN') {
    $deptId = ascb_require_dean_department($pdo, $ascbUser);
    // Use the enrollment's snapshotted department when available; fallback to program mapping.
    $where[] = '(e.department_id=? OR (e.department_id IS NULL AND EXISTS (SELECT 1 FROM programs dp WHERE UPPER(TRIM(dp.code)) COLLATE utf8mb4_unicode_ci=UPPER(TRIM(e.program_code)) COLLATE utf8mb4_unicode_ci AND dp.department_id=?)))';
    $params[] = $deptId; $params[] = $deptId;
}
if ($trimester !== '') {
    // Keep the export filter identical to the on-screen honors API.
    $term = strtolower(preg_replace('/\s+/', ' ', trim($trimester)));
    $termAliases = array(
        '1st trimester' => array('1st trimester', 'first trimester', '1st'),
        '2nd trimester' => array('2nd trimester', 'second trimester', '2nd'),
        '3rd trimester' => array('3rd trimester', 'third trimester', '3rd'),
        '1st semester'  => array('1st semester', 'first semester'),
        '2nd semester'  => array('2nd semester', 'second semester'),
        'summer'        => array('summer', '3rd semester'),
        '3rd semester'  => array('summer', '3rd semester')   /* backward compatible sa lumang value */
    );
    if (isset($termAliases[$term])) {
        $aliases = $termAliases[$term];
        $where[] = 'LOWER(TRIM(e.trimester)) IN (' . implode(',', array_fill(0, count($aliases), '?')) . ')';
        foreach ($aliases as $alias) $params[] = $alias;
    } else {
        $where[] = 'LOWER(TRIM(e.trimester)) = ?';
        $params[] = $term;
    }
}
if ($schoolYear !== '') { $where[] = 'e.school_year=?'; $params[] = $schoolYear; }

/*
 * Aggregate one enrollment at a time in SQL. A term qualifies only when:
 * - it has at least one subject;
 * - every subject has a numeric grade;
 * - no subject grade is > 2.00;
 * - weighted GWA falls in the existing President/Dean ranges.
 */
$numeric = "TRIM(g.grade) REGEXP '^[0-9]+(\\.[0-9]+)?$'";
$gwaExpr = "ROUND(SUM(CASE WHEN $numeric THEN CAST(g.grade AS DECIMAL(10,4)) * CAST(es.units AS DECIMAL(10,4)) ELSE 0 END) / NULLIF(SUM(CASE WHEN $numeric THEN CAST(es.units AS DECIMAL(10,4)) ELSE 0 END),0),2)";
$sql = "SELECT e.id AS enrollment_id,e.student_id,
               e.surname,e.first_name,e.middle_name" . ascb_suffix_sql_cols($pdo) . ",
               CONCAT(e.surname,', ',e.first_name,IF(e.middle_name IS NULL OR TRIM(e.middle_name)='','',CONCAT(' ',e.middle_name))) AS student_name,
               e.course,e.major,e.program_code,e.year_level,e.trimester,e.school_year,
               COALESCE(dsnap.name,d.name,'Unspecified') AS department_name,
               $gwaExpr AS gwa
        FROM enrollees e
        INNER JOIN enrollment_subjects es ON es.enrollment_id=e.id
        LEFT JOIN grades g ON g.enrollment_subject_id=es.id
        LEFT JOIN programs p ON UPPER(TRIM(p.code))=UPPER(TRIM(e.program_code))
        LEFT JOIN departments d ON d.id=p.department_id
        LEFT JOIN departments dsnap ON dsnap.id=e.department_id
        WHERE " . implode(' AND ', $where) . "
        GROUP BY e.id,e.student_id,e.surname,e.first_name,e.middle_name" . ascb_suffix_sql_cols($pdo) . ",e.course,e.major,e.program_code,e.year_level,e.trimester,e.school_year,dsnap.name,d.name
        HAVING COUNT(es.id)>0
           AND SUM(CASE WHEN $numeric THEN 1 ELSE 0 END)=COUNT(es.id)
           AND MAX(CASE WHEN $numeric THEN CAST(g.grade AS DECIMAL(10,4)) ELSE 999 END) <= ?
           AND $gwaExpr BETWEEN ? AND ?
        ORDER BY gwa ASC, student_name ASC";

// Query twice by list range? No: one ordered stream, classify each row locally.
// This avoids holding President/Dean arrays in PHP.
$stmt = $exportPdo->prepare($sql);
$stmt->execute(array_merge($params, array(
    ASCB_HONORS_MAX_SUBJECT_GRADE,
    ASCB_HONORS_PRESIDENT_MIN,
    ASCB_HONORS_DEAN_MAX
)));

$filename = 'ASCB_Honors_' . ($schoolYear ?: 'ALL_SY') . '_' .
    ($trimester ? preg_replace('/\s+/', '_', $trimester) : 'ALL_TERMS') . '_' . date('Y-m-d') . '.csv';
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
$out = fopen('php://output', 'wb');
fwrite($out, "\xEF\xBB\xBF");
fputcsv($out, array("ASCB President's & Dean's Lister"));
fputcsv($out, array('School Year', $schoolYear ?: 'All', 'Term', $trimester ?: 'All'));
fputcsv($out, array());
fputcsv($out, array('List','Student ID','Surname','Given Name','Middle Name','Program','Major','Department','Year Level','Term','School Year','GWA'));

$written = 0;
while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $r = ascb_row_print_split($r); /* PSA placement ng suffix */
    $gwa = (float) $r['gwa'];
    if ($gwa >= ASCB_HONORS_PRESIDENT_MIN && $gwa <= ASCB_HONORS_PRESIDENT_MAX) {
        $list = 'PRESIDENT';
    } elseif ($gwa >= ASCB_HONORS_DEAN_MIN && $gwa <= ASCB_HONORS_DEAN_MAX) {
        $list = 'DEAN';
    } else {
        continue;
    }
    fputcsv($out, array($list,$r['student_id'],$r['surname'],$r['first_name'],$r['middle_name'],$r['program_code'] ?: $r['course'],$r['major'],$r['department_name'],$r['year_level'],$r['trimester'],$r['school_year'],number_format($gwa,2,'.','')));
    $written++;
    if (($written % 500) === 0) { if (function_exists('ob_flush')) @ob_flush(); flush(); }
}
$stmt->closeCursor();
if ($written === 0) fputcsv($out, array('No student is qualified for the selected filter.'));
fclose($out);
try { ascb_log_activity($pdo, $ascbUser, 'HONORS_EXCEL_EXPORT', 'honors', $schoolYear ?: 'All SY', $filename); }
catch (Exception $e) { error_log('ASCB honors export log failed: ' . $e->getMessage()); }
