<?php
/* =========================================================
   API: MASTER RECORD
   ---------------------------------------------------------
   student_master is the permanent, CURRENT profile of a
   student. The Student ID never changes. Historical tables
   (enrollees, enrollment_subjects, grades, certificates,
   form137_requests) are read here but NEVER modified.

   GET  ?action=search&q=...           live search (ID / name / previous name)
   GET  ?action=get&studentId=...      full profile + 5 tab payloads
   GET  ?action=current_names          {studentId: current name} for students
                                       whose name was ever changed here. Any
                                       logged-in role (Dean: own Department
                                       only). Used so NEW output (Grade
                                       Evaluation prints) shows the current
                                       name without touching old rows.

   POST (JSON) action=save             update the personal information
   POST (JSON) action=marriage         new surname + civil status "Married"
   POST (JSON) action=remove_photo
   POST (multipart) action=photo       studentId + photo (JPG/PNG/WebP, 2 MB)

   Everything except current_names needs the
   'manage_master_record' permission (UNIT HEAD / SCHOOL REGISTRAR).
   CSRF is enforced by includes/api_guard.php for every POST.
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../includes/master_record_helper.php';
require_once __DIR__ . '/../config/db.php';

$role = ascb_get($ascbUser, 'role', '');
$userId = (int) ascb_get($ascbUser, 'id', 0);
$method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper($_SERVER['REQUEST_METHOD']) : 'GET';
$contentType = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
$isMultipart = stripos($contentType, 'multipart/form-data') === 0;

if ($method === 'POST') {
    $input = $isMultipart ? $_POST : ascb_read_json_body();
    $action = trim((string) ascb_get($input, 'action', ''));
} else {
    $input = array();
    $action = trim((string) ascb_get($_GET, 'action', 'search'));
}

/* ----------------------------------------- small helpers */

if (!function_exists('ascb_mr_fail')) {
    function ascb_mr_fail($code, $message, $fields = null) {
        global $pdo;
        if ($pdo && $pdo->inTransaction()) $pdo->rollBack();
        http_response_code($code);
        $out = array('ok' => false, 'error' => $message);
        if (is_array($fields) && $fields) $out['fields'] = $fields;
        echo json_encode($out, JSON_UNESCAPED_UNICODE);
        exit;
    }
}

if (!function_exists('ascb_mr_clean')) {
    /* trim + collapse whitespace; null when the text is not valid UTF-8 */
    function ascb_mr_clean($value) {
        $value = trim((string) $value);
        if ($value === '') return '';
        if (function_exists('mb_check_encoding') && !mb_check_encoding($value, 'UTF-8')) return null;
        $c = preg_replace('/\s+/u', ' ', $value);
        return $c === null ? null : $c;
    }
}

if (!function_exists('ascb_mr_log_text')) {
    function ascb_mr_log_text($text, $max = 480) {
        $text = (string) $text;
        if (function_exists('mb_substr')) return mb_substr($text, 0, $max, 'UTF-8');
        return substr($text, 0, $max);
    }
}

if (!function_exists('ascb_mr_label')) {
    function ascb_mr_label($row) {
        return ascb_master_format_name($row['surname'], $row['first_name'], $row['middle_name'], $row['suffix'], isset($row['suffix_position']) ? $row['suffix_position'] : 'separate')
            . ' (' . $row['student_id'] . ')';
    }
}

/* Validate the editable profile fields. $in = request values (keys that
   are absent keep the current value). Returns array($clean, $errors). */
if (!function_exists('ascb_mr_validate_profile')) {
    function ascb_mr_validate_profile($in, $current) {
        $errors = array();

        /* Start from the current values so every key always exists, even
           when a field fails validation. */
        $clean = array();
        foreach (array_keys(ascb_mr_field_labels()) as $col) {
            $clean[$col] = isset($current[$col]) ? $current[$col] : null;
        }

        $namePattern = '/^[\p{L}\p{M}][\p{L}\p{M}\s.\'\x{2019}\-]*$/u';

        /* request value (camelCase key) or, when absent, the current value */
        $get = function ($camel, $col) use ($in, $current) {
            if (array_key_exists($camel, $in)) return $in[$camel];
            return isset($current[$col]) ? $current[$col] : '';
        };

        $fields = array(
            // camel,           column,             label,             max, required, pattern, message
            array('surname',         'surname',          'Surname',          100, true,  $namePattern, 'Surname may only contain letters, spaces, hyphens, apostrophes and periods.'),
            array('firstName',       'first_name',       'First name',       100, true,  $namePattern, 'First name may only contain letters, spaces, hyphens, apostrophes and periods.'),
            array('middleName',      'middle_name',      'Middle name',      100, false, $namePattern, 'Middle name may only contain letters, spaces, hyphens, apostrophes and periods.'),
            array('suffix',          'suffix',           'Suffix',            20, false, '/^[\p{L}\p{N}.\s]+$/u', 'Suffix may only contain letters, numbers and periods (e.g. Jr., III).'),
            array('birthplace',      'birthplace',       'Birthplace',       255, false, null, ''),
            array('nationality',     'nationality',      'Nationality',       80, false, '/^[\p{L}\p{M}\s.\'\-]+$/u', 'Nationality may only contain letters.'),
            array('address',         'address',          'Address',          255, false, null, ''),
            array('mobileNumber',    'mobile_number',    'Mobile number',     20, false, '/^[0-9+()\-\s]{7,20}$/', 'Mobile number must be 7-20 digits (numbers, +, -, spaces, parentheses).'),
            array('guardianName',    'guardian_name',    'Guardian',         150, false, null, ''),
            array('guardianContact', 'guardian_contact', 'Guardian contact',  50, false, '/^[0-9+()\-\s,\/]{7,50}$/', 'Guardian contact must be a valid phone number.'),
            array('emergencyContact','emergency_contact','Emergency contact',150, false, null, ''),
        );

        foreach ($fields as $f) {
            $raw = $get($f[0], $f[1]);
            $v = ascb_mr_clean($raw);
            if ($v === null) { $errors[$f[0]] = $f[2] . ' contains invalid characters.'; continue; }
            if ($v === '') {
                if ($f[4]) $errors[$f[0]] = $f[2] . ' is required.';
                $clean[$f[1]] = null;
                continue;
            }
            if (ascb_text_too_long($v, $f[3])) { $errors[$f[0]] = $f[2] . ' is too long (max ' . $f[3] . ' characters).'; continue; }
            if ($f[5] !== null && !preg_match($f[5], $v)) { $errors[$f[0]] = $f[6]; continue; }
            if (preg_match('/[<>]/', $v)) { $errors[$f[0]] = $f[2] . ' cannot contain < or >.'; continue; }
            $clean[$f[1]] = $v;
        }

        /* PSA placement of the suffix: 'separate' | 'first_name' | 'surname'.
           Walang suffix = laging 'separate'. */
        $clean['suffix_position'] = ($clean['suffix'] === null || $clean['suffix'] === '')
            ? 'separate'
            : ascb_normalize_suffix_position($get('suffixPosition', 'suffix_position'));

        /* email */
        $email = ascb_mr_clean($get('email', 'email'));
        if ($email === null) {
            $errors['email'] = 'Email contains invalid characters.';
        } elseif ($email === '') {
            $clean['email'] = null;
        } elseif (ascb_text_too_long($email, 254) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Enter a valid email address.';
        } else {
            $clean['email'] = $email;
        }

        /* enums */
        $civil = ascb_mr_clean($get('civilStatus', 'civil_status'));
        if ($civil === '' || $civil === null) {
            $clean['civil_status'] = null;
        } elseif (!in_array($civil, array('Single', 'Married', 'Widowed', 'Separated'), true)) {
            $errors['civilStatus'] = 'Civil status must be Single, Married, Widowed or Separated.';
        } else {
            $clean['civil_status'] = $civil;
        }

        $sex = ascb_mr_clean($get('sex', 'sex'));
        if ($sex === '' || $sex === null) {
            $clean['sex'] = null;
        } elseif (!in_array($sex, array('Male', 'Female'), true)) {
            $errors['sex'] = 'Sex must be Male or Female.';
        } else {
            $clean['sex'] = $sex;
        }

        /* birth date */
        $bd = trim((string) $get('birthDate', 'birth_date'));
        if ($bd === '' || $bd === '0000-00-00') {
            $clean['birth_date'] = null;
        } else {
            $d = DateTime::createFromFormat('Y-m-d', $bd);
            if (!$d || $d->format('Y-m-d') !== $bd || $bd < '1900-01-01' || $bd > date('Y-m-d')) {
                $errors['birthDate'] = 'Enter a valid birth date (not in the future).';
            } else {
                $clean['birth_date'] = $bd;
            }
        }

        return array($clean, $errors);
    }
}

if (!function_exists('ascb_mr_norm')) {
    function ascb_mr_norm($v) { return $v === null ? '' : (string) $v; }
}

/* Labels for the activity-log "what changed" list. */
if (!function_exists('ascb_mr_field_labels')) {
    function ascb_mr_field_labels() {
        return array(
            'surname' => 'Surname', 'first_name' => 'First name', 'middle_name' => 'Middle name', 'suffix' => 'Suffix',
            'suffix_position' => 'Suffix placement (PSA)',
            'sex' => 'Sex', 'civil_status' => 'Civil status', 'birth_date' => 'Birth date', 'birthplace' => 'Birthplace',
            'nationality' => 'Nationality', 'address' => 'Address', 'mobile_number' => 'Mobile number', 'email' => 'Email',
            'guardian_name' => 'Guardian', 'guardian_contact' => 'Guardian contact', 'emergency_contact' => 'Emergency contact',
        );
    }
}

if (!function_exists('ascb_mr_insert_history')) {
    function ascb_mr_insert_history($pdo, $studentId, $old, $new, $reason, $userId) {
        if (ascb_column_exists($pdo, 'student_name_history', 'new_suffix_position')) {
            $stmt = $pdo->prepare(
                "INSERT INTO student_name_history
                    (student_id, previous_surname, previous_first_name, previous_middle_name, previous_suffix, previous_suffix_position,
                     new_surname, new_first_name, new_middle_name, new_suffix, new_suffix_position, reason, updated_by)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)"
            );
            $stmt->execute(array(
                $studentId,
                $old['surname'], $old['first_name'], $old['middle_name'], $old['suffix'], ascb_normalize_suffix_position(isset($old['suffix_position']) ? $old['suffix_position'] : ''),
                $new['surname'], $new['first_name'], $new['middle_name'], $new['suffix'], ascb_normalize_suffix_position(isset($new['suffix_position']) ? $new['suffix_position'] : ''),
                $reason, $userId > 0 ? $userId : null,
            ));
            return;
        }
        $stmt = $pdo->prepare(
            "INSERT INTO student_name_history
                (student_id, previous_surname, previous_first_name, previous_middle_name, previous_suffix,
                 new_surname, new_first_name, new_middle_name, new_suffix, reason, updated_by)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)"
        );
        $stmt->execute(array(
            $studentId,
            $old['surname'], $old['first_name'], $old['middle_name'], $old['suffix'],
            $new['surname'], $new['first_name'], $new['middle_name'], $new['suffix'],
            $reason, $userId > 0 ? $userId : null,
        ));
    }
}

if (!function_exists('ascb_mr_term_order_sql')) {
    /* Deterministic "latest term first" ordering for enrollment rows.
       Never relies on bare auto-increment id order (rows can be
       imported/backfilled out of sequence). Ranks by the actual
       school_year and trimester/semester fields first, using the same
       term names as $GLOBALS['ASCB_TERM_RANK'] (includes/programs_helper.php),
       then falls back to created_at and id only to break exact ties. */
    function ascb_mr_term_order_sql($alias) {
        return "CAST(SUBSTRING_INDEX($alias.school_year, '-', 1) AS UNSIGNED) DESC,
                CASE $alias.trimester
                     WHEN '1st Trimester' THEN 1 WHEN '1st Semester' THEN 1
                     WHEN '2nd Trimester' THEN 2 WHEN '2nd Semester' THEN 2
                     WHEN '3rd Trimester' THEN 3 WHEN 'Summer' THEN 3
                     ELSE 9
                END DESC,
                $alias.created_at DESC,
                $alias.id DESC";
    }
}

if (!function_exists('ascb_mr_status_label')) {
    function ascb_mr_status_label($enrollment) {
        if (!$enrollment) return 'Not enrolled';
        if (!empty($enrollment['archived_at'])) return 'Archived';
        $s = strtolower((string) $enrollment['status']);
        if ($s === 'pending') return 'Pending approval';
        if ($s === 'rejected') return 'Rejected';
        return 'Enrolled';
    }
}

/* Everything the page needs for one student. Read-only. */
if (!function_exists('ascb_mr_build_profile')) {
    function ascb_mr_build_profile($pdo, $studentId) {
        $stmt = $pdo->prepare(
            "SELECT m.*, u.display_name AS updated_by_name
             FROM student_master m
             LEFT JOIN users u ON u.id = m.updated_by
             WHERE m.student_id = ? LIMIT 1"
        );
        $stmt->execute(array($studentId));
        $m = $stmt->fetch();
        if (!$m) return null;

        $student = array(
            'studentId'        => $m['student_id'],
            'surname'          => $m['surname'],
            'firstName'        => $m['first_name'],
            'middleName'       => $m['middle_name'],
            'suffix'           => $m['suffix'],
            'suffixPosition'   => ascb_normalize_suffix_position(isset($m['suffix_position']) ? $m['suffix_position'] : ''),
            'fullName'         => ascb_master_format_name($m['surname'], $m['first_name'], $m['middle_name'], $m['suffix'], isset($m['suffix_position']) ? $m['suffix_position'] : 'separate'),
            'naturalName'      => ascb_master_natural_name($m['surname'], $m['first_name'], $m['middle_name'], $m['suffix'], isset($m['suffix_position']) ? $m['suffix_position'] : 'separate'),
            'sex'              => $m['sex'],
            'civilStatus'      => $m['civil_status'],
            'birthDate'        => $m['birth_date'],
            'birthplace'       => $m['birthplace'],
            'nationality'      => $m['nationality'],
            'address'          => $m['address'],
            'mobileNumber'     => $m['mobile_number'],
            'email'            => $m['email'],
            'guardianName'     => $m['guardian_name'],
            'guardianContact'  => $m['guardian_contact'],
            'emergencyContact' => $m['emergency_contact'],
            'hasPhoto'         => !empty($m['profile_photo']),
            'photoVersion'     => !empty($m['profile_photo']) ? substr(md5($m['profile_photo']), 0, 8) : '',
            'active'           => (int) $m['active'] === 1,
            'createdAt'        => $m['created_at'],
            'updatedAt'        => $m['updated_at'],
            'updatedByName'    => $m['updated_by_name'],
            'version'          => $m['updated_at'],
        );

        /* Enrollment history (every trimester, newest first). Read-only. */
        $stmt = $pdo->prepare(
            "SELECT e.id, e.school_year, e.trimester, e.year_level, e.program_code, e.course, e.major,
                    e.student_type, e.status, e.archived_at, e.archive_reason, e.created_at,
                    d.name AS department_name
             FROM enrollees e
             LEFT JOIN departments d ON d.id = e.department_id
             WHERE e.student_id = ?
             ORDER BY " . ascb_mr_term_order_sql('e')
        );
        $stmt->execute(array($studentId));
        $terms = $stmt->fetchAll();

        $enrollments = array();
        $enrollmentIds = array();
        $current = null;
        $total = 0;
        $first = null;
        foreach ($terms as $t) {
            $enrollmentIds[] = (int) $t['id'];
            if ($current === null && empty($t['archived_at'])) $current = $t;
            if (empty($t['archived_at']) && $t['status'] === 'approved') $total++;
            if ($first === null || strcmp((string) $t['created_at'], (string) $first) < 0) $first = $t['created_at'];
            $enrollments[] = array(
                'id'             => (int) $t['id'],
                'schoolYear'     => $t['school_year'],
                'trimester'      => $t['trimester'],
                'yearLevel'      => $t['year_level'],
                'programCode'    => $t['program_code'],
                'course'         => $t['course'],
                'major'          => $t['major'],
                'studentType'    => $t['student_type'],
                'departmentName' => $t['department_name'],
                'status'         => $t['status'],
                'statusLabel'    => ascb_mr_status_label($t),
                'archived'       => !empty($t['archived_at']),
                'archiveReason'  => $t['archive_reason'],
                'createdAt'      => $t['created_at'],
            );
        }
        if ($current === null && $terms) $current = $terms[0];

        $card = array(
            'course'       => $current ? $current['course'] : null,
            'major'        => $current ? $current['major'] : null,
            'programCode'  => $current ? $current['program_code'] : null,
            'department'   => $current ? $current['department_name'] : null,
            'yearLevel'    => $current ? $current['year_level'] : null,
            'trimester'    => $current ? $current['trimester'] : null,
            'schoolYear'   => $current ? $current['school_year'] : null,
            'studentType'  => $current ? $current['student_type'] : null,
            'statusLabel'  => ascb_mr_status_label($current),
        );

        /* Grade history: subjects + grades grouped per enrollment. */
        $grades = array();
        if ($enrollmentIds) {
            $ph = implode(',', array_fill(0, count($enrollmentIds), '?'));
            $stmt = $pdo->prepare(
                "SELECT es.enrollment_id, es.course_code, es.description, es.units, g.grade
                 FROM enrollment_subjects es
                 LEFT JOIN grades g ON g.enrollment_subject_id = es.id
                 WHERE es.enrollment_id IN ($ph)
                 ORDER BY es.enrollment_id, es.id"
            );
            $stmt->execute($enrollmentIds);
            $byEnrollment = array();
            foreach ($stmt->fetchAll() as $s) {
                $eid = (int) $s['enrollment_id'];
                if (!isset($byEnrollment[$eid])) $byEnrollment[$eid] = array();
                $byEnrollment[$eid][] = array(
                    'code' => $s['course_code'], 'description' => $s['description'],
                    'units' => $s['units'], 'grade' => $s['grade'],
                );
            }
            foreach ($enrollments as $en) {
                $subs = isset($byEnrollment[$en['id']]) ? $byEnrollment[$en['id']] : array();
                $units = 0.0;
                foreach ($subs as $s) $units += (float) $s['units'];
                $grades[] = array(
                    'enrollmentId' => $en['id'], 'schoolYear' => $en['schoolYear'], 'trimester' => $en['trimester'],
                    'yearLevel' => $en['yearLevel'], 'archived' => $en['archived'],
                    'subjects' => $subs, 'totalUnits' => $units,
                );
            }
        }

        /* Certificates: they keep the name they were issued under. */
        $stmt = $pdo->prepare(
            "SELECT id, certificate_type, student_name, or_number, academic_year, trimester, year_level, gwa, created_at
             FROM certificates WHERE student_id = ? ORDER BY created_at DESC, id DESC LIMIT 200"
        );
        $stmt->execute(array($studentId));
        $certificates = array();
        foreach ($stmt->fetchAll() as $c) {
            $certificates[] = array(
                'id' => (int) $c['id'], 'type' => $c['certificate_type'], 'issuedName' => $c['student_name'],
                'orNumber' => $c['or_number'], 'academicYear' => $c['academic_year'], 'trimester' => $c['trimester'],
                'yearLevel' => $c['year_level'], 'gwa' => $c['gwa'], 'createdAt' => $c['created_at'],
            );
        }
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM certificates WHERE student_id = ?");
        $stmt->execute(array($studentId));
        $certTotal = (int) $stmt->fetchColumn();

        /* Name history (newest first). */
        $stmt = $pdo->prepare(
            "SELECT h.*, u.display_name AS by_name
             FROM student_name_history h
             LEFT JOIN users u ON u.id = h.updated_by
             WHERE h.student_id = ?
             ORDER BY h.id DESC"
        );
        $stmt->execute(array($studentId));
        $nameHistory = array();
        foreach ($stmt->fetchAll() as $h) {
            $nameHistory[] = array(
                'id'        => (int) $h['id'],
                'previous'  => ascb_master_format_name($h['previous_surname'], $h['previous_first_name'], $h['previous_middle_name'], $h['previous_suffix'], isset($h['previous_suffix_position']) ? $h['previous_suffix_position'] : 'separate'),
                'current'   => ascb_master_format_name($h['new_surname'], $h['new_first_name'], $h['new_middle_name'], $h['new_suffix'], isset($h['new_suffix_position']) ? $h['new_suffix_position'] : 'separate'),
                'reason'    => $h['reason'],
                'byName'    => $h['by_name'],
                'updatedAt' => $h['updated_at'],
            );
        }

        return array(
            'student'      => $student,
            'card'         => $card,
            'stats'        => array(
                'firstEnrollmentDate' => $first,
                'totalEnrollments'    => $total,
                'totalCertificates'   => $certTotal,
            ),
            'enrollments'  => $enrollments,
            'grades'       => $grades,
            'certificates' => $certificates,
            'nameHistory'  => $nameHistory,
        );
    }
}

/* ----------------------------------------- current_names (all roles) */

if ($method === 'GET' && $action === 'current_names') {
    $deptId = null;
    if ($role === 'DEAN') $deptId = ascb_require_dean_department($pdo, $ascbUser);
    $names = ascb_master_renamed_map($pdo, $deptId);
    echo json_encode(array('ok' => true, 'names' => (object) $names), JSON_UNESCAPED_UNICODE);
    exit;
}

/* A multipart body larger than post_max_size arrives as an empty
   $_POST/$_FILES - say so instead of "Unknown action". */
if ($method === 'POST' && $isMultipart && empty($_POST) && empty($_FILES)) {
    ascb_mr_fail(413, 'The upload is larger than the server allows. Use a smaller photo (max 2 MB).');
}

/* ----------------------------------------- access gate */

if (!ascb_can($role, 'manage_master_record')) {
    ascb_mr_fail(403, 'You do not have access to the Master Record.');
}
if (!ascb_master_available($pdo)) {
    ascb_mr_fail(503, 'The Master Record tables are not installed yet. Run "php database/migrate_master.php" once, then reload.');
}

/* ----------------------------------------- search */

if ($method === 'GET' && $action === 'search') {
    $q = trim((string) ascb_get($_GET, 'q', ''));
    $q = str_replace(array(',', '.'), ' ', $q);
    $tokens = preg_split('/\s+/u', $q, -1, PREG_SPLIT_NO_EMPTY);
    if (!$tokens) $tokens = array();
    $tokens = array_slice($tokens, 0, 4);

    $totalLen = 0;
    foreach ($tokens as $t) $totalLen += function_exists('mb_strlen') ? mb_strlen($t, 'UTF-8') : strlen($t);
    if (!$tokens || $totalLen < 2) {
        echo json_encode(array('ok' => true, 'rows' => array()));
        exit;
    }

    $where = array();
    $params = array();
    foreach ($tokens as $t) {
        $like = '%' . str_replace(array('\\', '%', '_'), array('\\\\', '\\%', '\\_'), $t) . '%';
        $where[] = "(m.student_id LIKE ? OR m.surname LIKE ? OR m.first_name LIKE ? OR m.middle_name LIKE ?
                     OR EXISTS (SELECT 1 FROM student_name_history h
                                WHERE h.student_id = m.student_id
                                  AND (h.previous_surname LIKE ? OR h.previous_first_name LIKE ? OR h.previous_middle_name LIKE ?)))";
        for ($i = 0; $i < 7; $i++) $params[] = $like;
    }
    $params[] = trim((string) ascb_get($_GET, 'q', ''));

    $sql = "SELECT m.student_id, m.surname, m.first_name, m.middle_name, m.suffix, " . (ascb_column_exists($pdo, 'student_master', 'suffix_position') ? "m.suffix_position" : "'separate' AS suffix_position") . ", m.civil_status, m.active,
                   e.program_code, e.course, e.year_level, e.trimester, e.school_year,
                   (SELECT COUNT(*) FROM student_name_history h2 WHERE h2.student_id = m.student_id) AS name_changes
            FROM student_master m
            LEFT JOIN enrollees e ON e.id = (SELECT MAX(e2.id) FROM enrollees e2 WHERE e2.student_id = m.student_id)
            WHERE " . implode(' AND ', $where) . "
            ORDER BY (m.student_id = ?) DESC, m.surname, m.first_name
            LIMIT 25";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $rows = array();
    foreach ($stmt->fetchAll() as $r) {
        $rows[] = array(
            'studentId'   => $r['student_id'],
            'fullName'    => ascb_master_format_name($r['surname'], $r['first_name'], $r['middle_name'], $r['suffix'], $r['suffix_position']),
            'civilStatus' => $r['civil_status'],
            'active'      => (int) $r['active'] === 1,
            'course'      => $r['program_code'] ? $r['program_code'] : $r['course'],
            'yearLevel'   => $r['year_level'],
            'trimester'   => $r['trimester'],
            'schoolYear'  => $r['school_year'],
            'nameChanges' => (int) $r['name_changes'],
        );
    }
    echo json_encode(array('ok' => true, 'rows' => $rows), JSON_UNESCAPED_UNICODE);
    exit;
}

/* ----------------------------------------- get */

if ($method === 'GET' && $action === 'get') {
    $studentId = trim((string) ascb_get($_GET, 'studentId', ''));
    if ($studentId === '') ascb_mr_fail(400, 'studentId is required.');

    $profile = ascb_mr_build_profile($pdo, $studentId);
    if (!$profile) {
        /* Student exists in Enrollment but has no master row yet (for
           example enrolled before the migration and imported some other
           way): create it from the latest enrollment row, then load. */
        $stmt = $pdo->prepare("SELECT * FROM enrollees e WHERE e.student_id = ? ORDER BY " . ascb_mr_term_order_sql('e') . " LIMIT 1");
        $stmt->execute(array($studentId));
        $latest = $stmt->fetch();
        if ($latest && ascb_master_ensure($pdo, $studentId, $latest, $userId)) {
            $profile = ascb_mr_build_profile($pdo, $studentId);
        }
    }
    if (!$profile) ascb_mr_fail(404, 'No student found with this Student ID.');

    echo json_encode(array('ok' => true) + $profile, JSON_UNESCAPED_UNICODE);
    exit;
}

/* ----------------------------------------- sync (backfill missing students) */

if ($method === 'POST' && $action === 'sync') {
    $before = (int) $pdo->query("SELECT COUNT(*) FROM student_master")->fetchColumn();
    $pdo->exec(
        "INSERT IGNORE INTO student_master
            (student_id, surname, first_name, middle_name, sex, civil_status, birth_date,
             birthplace, address, mobile_number, email, guardian_name, nationality, updated_by)
         SELECT e.student_id, e.surname, e.first_name, e.middle_name, e.sex, e.civil_status, e.birth_date,
                e.birth_place, e.address, e.mobile_number, e.email, e.guardian_name, 'Filipino', " . ($userId > 0 ? $userId : 'NULL') . "
         FROM enrollees e
         INNER JOIN (
             SELECT student_id, MAX(id) AS max_id FROM enrollees
             WHERE student_id IS NOT NULL AND student_id <> '' GROUP BY student_id
         ) latest ON latest.max_id = e.id"
    );
    $after = (int) $pdo->query("SELECT COUNT(*) FROM student_master")->fetchColumn();
    $added = $after - $before;
    ascb_log_activity($pdo, $ascbUser, 'MASTER_SYNC', 'student', 'Master Record', 'Added ' . $added . ' student(s) from Enrollment.');
    echo json_encode(array('ok' => true, 'added' => $added, 'total' => $after));
    exit;
}

/* ----------------------------------------- save */

if ($method === 'POST' && $action === 'save') {
    $studentId = trim((string) ascb_get($input, 'studentId', ''));
    if ($studentId === '') ascb_mr_fail(400, 'studentId is required.');
    $version = ascb_get($input, 'version', null);

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT * FROM student_master WHERE student_id = ? FOR UPDATE");
        $stmt->execute(array($studentId));
        $old = $stmt->fetch();
        if (!$old) ascb_mr_fail(404, 'No student found with this Student ID.');

        if ($version !== null && (string) $version !== (string) $old['updated_at']) {
            ascb_mr_fail(409, 'This record was changed by someone else since you opened it. Reload the student and try again.');
        }

        if (!array_key_exists('suffix_position', $old)) $old['suffix_position'] = 'separate';
        $hasPosCol = ascb_column_exists($pdo, 'student_master', 'suffix_position');
        list($clean, $errors) = ascb_mr_validate_profile($input, $old);
        if (!$hasPosCol && $clean['suffix_position'] !== 'separate') {
            $errors['suffixPosition'] = 'Run database/migrate_master.php first to install the PSA suffix placement columns.';
        }

        $nameKeys = array('surname', 'first_name', 'middle_name', 'suffix', 'suffix_position');
        $nameChanged = false;
        foreach ($nameKeys as $k) {
            if (ascb_mr_norm($clean[$k]) !== ascb_mr_norm($old[$k])) { $nameChanged = true; break; }
        }

        $reason = ascb_mr_clean(ascb_get($input, 'reason', ''));
        if ($nameChanged) {
            if ($reason === null || $reason === '') {
                $errors['reason'] = 'Enter the reason for the name change (for example: Marriage, Correction of spelling).';
            } elseif (ascb_text_too_long($reason, 255)) {
                $errors['reason'] = 'Reason is too long (max 255 characters).';
            } elseif (preg_match('/[<>]/', $reason)) {
                $errors['reason'] = 'Reason cannot contain < or >.';
            }
        }
        if ($errors) ascb_mr_fail(422, 'Please fix the highlighted fields.', $errors);

        $labels = ascb_mr_field_labels();
        $changed = array();
        foreach ($labels as $col => $label) {
            if (ascb_mr_norm($clean[$col]) !== ascb_mr_norm($old[$col])) $changed[] = $label;
        }

        if (!$changed) {
            $pdo->rollBack();
            echo json_encode(array('ok' => true, 'unchanged' => true, 'message' => 'No changes to save.') + ascb_mr_build_profile($pdo, $studentId), JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($nameChanged) {
            /* 1) preserve the old name BEFORE updating the master row */
            ascb_mr_insert_history($pdo, $studentId, $old, $clean, $reason, $userId);
        }

        $stmt = $pdo->prepare(
            "UPDATE student_master SET
                surname = ?, first_name = ?, middle_name = ?, suffix = ?," . ($hasPosCol ? " suffix_position = ?," : "") . " sex = ?, civil_status = ?,
                birth_date = ?, birthplace = ?, nationality = ?, address = ?, mobile_number = ?, email = ?,
                guardian_name = ?, guardian_contact = ?, emergency_contact = ?, updated_by = ?
             WHERE student_id = ?"
        );
        $upd = array($clean['surname'], $clean['first_name'], $clean['middle_name'], $clean['suffix']);
        if ($hasPosCol) $upd[] = $clean['suffix_position'];
        $stmt->execute(array_merge($upd, array(
            $clean['sex'], $clean['civil_status'],
            $clean['birth_date'], $clean['birthplace'], $clean['nationality'], $clean['address'], $clean['mobile_number'], $clean['email'],
            $clean['guardian_name'], $clean['guardian_contact'], $clean['emergency_contact'],
            $userId > 0 ? $userId : null, $studentId,
        )));

        /* (fix) Kapag nagbago ang Suffix o ang PSA placement, ipasa sa lahat ng
           enrollment (term) rows ng estudyante para pareho na ang lumalabas sa
           lahat ng export at print. */
        if (ascb_mr_norm($clean['suffix']) !== ascb_mr_norm($old['suffix'])
            || ascb_mr_norm($clean['suffix_position']) !== ascb_mr_norm($old['suffix_position'])) {
            ascb_master_propagate_suffix($pdo, $studentId, $clean['suffix'], $clean['suffix_position']);
        }

        $pdo->commit();
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('ASCB master save failed: ' . $e->getMessage());
        ascb_mr_fail(500, 'Unable to save the record. Nothing was changed.');
    }

    $newRow = array('student_id' => $studentId) + $clean;
    ascb_log_activity($pdo, $ascbUser, 'MASTER_UPDATE', 'student', ascb_mr_label($newRow),
        ascb_mr_log_text('Updated: ' . implode(', ', $changed) . '.'));
    if ($nameChanged) {
        ascb_log_activity($pdo, $ascbUser, 'MASTER_NAME_CHANGE', 'student', ascb_mr_label($newRow),
            ascb_mr_log_text(ascb_master_format_name($old['surname'], $old['first_name'], $old['middle_name'], $old['suffix'], isset($old['suffix_position']) ? $old['suffix_position'] : 'separate')
                . ' -> ' . ascb_master_format_name($clean['surname'], $clean['first_name'], $clean['middle_name'], $clean['suffix'], $clean['suffix_position'])
                . '. Reason: ' . $reason));
    }

    echo json_encode(array('ok' => true, 'nameChanged' => $nameChanged, 'message' => 'Master record saved.') + ascb_mr_build_profile($pdo, $studentId), JSON_UNESCAPED_UNICODE);
    exit;
}

/* ----------------------------------------- marriage */

if ($method === 'POST' && $action === 'marriage') {
    $studentId = trim((string) ascb_get($input, 'studentId', ''));
    if ($studentId === '') ascb_mr_fail(400, 'studentId is required.');
    $version = ascb_get($input, 'version', null);

    $newSurname = ascb_mr_clean(ascb_get($input, 'newSurname', ''));
    $reason = ascb_mr_clean(ascb_get($input, 'reason', ''));
    if ($reason === '') $reason = 'Marriage';

    $errors = array();
    if ($newSurname === null || $newSurname === '') {
        $errors['newSurname'] = 'New surname is required.';
    } elseif (ascb_text_too_long($newSurname, 100)) {
        $errors['newSurname'] = 'New surname is too long (max 100 characters).';
    } elseif (!preg_match('/^[\p{L}\p{M}][\p{L}\p{M}\s.\'\x{2019}\-]*$/u', $newSurname)) {
        $errors['newSurname'] = 'Surname may only contain letters, spaces, hyphens, apostrophes and periods.';
    }
    if ($reason === null) {
        $errors['reason'] = 'Reason contains invalid characters.';
    } elseif (ascb_text_too_long($reason, 255)) {
        $errors['reason'] = 'Reason is too long (max 255 characters).';
    } elseif (preg_match('/[<>]/', $reason)) {
        $errors['reason'] = 'Reason cannot contain < or >.';
    }
    if ($errors) ascb_mr_fail(422, 'Please fix the highlighted fields.', $errors);

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT * FROM student_master WHERE student_id = ? FOR UPDATE");
        $stmt->execute(array($studentId));
        $old = $stmt->fetch();
        if (!$old) ascb_mr_fail(404, 'No student found with this Student ID.');

        if ($version !== null && (string) $version !== (string) $old['updated_at']) {
            ascb_mr_fail(409, 'This record was changed by someone else since you opened it. Reload the student and try again.');
        }
        if ($newSurname === ascb_mr_norm($old['surname'])) {
            ascb_mr_fail(422, 'The new surname is the same as the current surname.', array('newSurname' => 'Enter a different surname.'));
        }

        $new = $old;
        $new['surname'] = $newSurname;
        /* Marriage surname change: the old surname is never simply
           dropped. It moves into the middle-name slot of the CURRENT
           record (e.g. JABAGAT, RECYL RAVELO -> ABANILLA, RECYL JABAGAT),
           so a single current name always prints, while the full old
           name (including the old middle name) stays queryable in
           student_name_history for audit/history purposes. */
        $new['middle_name'] = $old['surname'];

        /* old name first, then the update */
        ascb_mr_insert_history($pdo, $studentId, $old, $new, $reason, $userId);

        $stmt = $pdo->prepare("UPDATE student_master SET surname = ?, middle_name = ?, civil_status = 'Married', updated_by = ? WHERE student_id = ?");
        $stmt->execute(array($newSurname, $new['middle_name'], $userId > 0 ? $userId : null, $studentId));

        $pdo->commit();
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('ASCB master marriage update failed: ' . $e->getMessage());
        ascb_mr_fail(500, 'Unable to update the record. Nothing was changed.');
    }

    ascb_log_activity($pdo, $ascbUser, 'MASTER_MARRIAGE', 'student', ascb_mr_label($new),
        ascb_mr_log_text(ascb_master_format_name($old['surname'], $old['first_name'], $old['middle_name'], $old['suffix'], isset($old['suffix_position']) ? $old['suffix_position'] : 'separate')
            . ' -> ' . ascb_master_format_name($new['surname'], $new['first_name'], $new['middle_name'], $new['suffix'], isset($new['suffix_position']) ? $new['suffix_position'] : 'separate')
            . '. Civil status: Married. Reason: ' . $reason));

    echo json_encode(array('ok' => true, 'nameChanged' => true, 'message' => 'Record updated after marriage.') + ascb_mr_build_profile($pdo, $studentId), JSON_UNESCAPED_UNICODE);
    exit;
}

/* ----------------------------------------- photo upload / remove */

if (!function_exists('ascb_mr_photo_dir')) {
    function ascb_mr_photo_dir() {
        $dir = __DIR__ . '/../uploads/student_photos/';
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        return $dir;
    }
}

if ($method === 'POST' && ($action === 'photo' || $action === 'remove_photo')) {
    $studentId = trim((string) ascb_get($input, 'studentId', ''));
    if ($studentId === '') ascb_mr_fail(400, 'studentId is required.');

    $stmt = $pdo->prepare("SELECT student_id, surname, first_name, middle_name, suffix, profile_photo FROM student_master WHERE student_id = ?");
    $stmt->execute(array($studentId));
    $row = $stmt->fetch();
    if (!$row) ascb_mr_fail(404, 'No student found with this Student ID.');

    $newName = null;
    if ($action === 'photo') {
        if (empty($_FILES['photo']) || $_FILES['photo']['error'] === UPLOAD_ERR_NO_FILE) {
            ascb_mr_fail(400, 'Choose a photo to upload.');
        }
        if ($_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
            ascb_mr_fail(400, 'The photo could not be uploaded (upload error ' . (int) $_FILES['photo']['error'] . '). It may be larger than the server limit.');
        }
        $tmp = $_FILES['photo']['tmp_name'];
        if (!is_uploaded_file($tmp)) ascb_mr_fail(400, 'Invalid upload.');
        if ((int) $_FILES['photo']['size'] > 2 * 1024 * 1024) ascb_mr_fail(422, 'The photo is too large. Maximum size is 2 MB.');

        $info = @getimagesize($tmp);
        if ($info === false || (int) $info[0] < 1 || (int) $info[1] < 1) ascb_mr_fail(422, 'The file is not a valid image.');
        if ((int) $info[0] > 6000 || (int) $info[1] > 6000) ascb_mr_fail(422, 'The photo is too large in pixels (max 6000 x 6000).');

        $mime = '';
        if (function_exists('finfo_open')) {
            $fi = finfo_open(FILEINFO_MIME_TYPE);
            if ($fi) { $mime = (string) finfo_file($fi, $tmp); finfo_close($fi); }
        }
        if ($mime === '' && isset($info['mime'])) $mime = (string) $info['mime'];
        $ext = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp');
        if (!isset($ext[$mime])) ascb_mr_fail(422, 'Only JPG, PNG or WebP photos are allowed.');

        $dir = ascb_mr_photo_dir();
        $newName = 'sp_' . ascb_random_token(16) . '.' . $ext[$mime];
        if (!@move_uploaded_file($tmp, $dir . $newName)) {
            error_log('ASCB master photo: move_uploaded_file failed for ' . $studentId);
            ascb_mr_fail(500, 'The photo could not be saved on the server.');
        }
    }

    try {
        $stmt = $pdo->prepare("UPDATE student_master SET profile_photo = ?, updated_by = ? WHERE student_id = ?");
        $stmt->execute(array($newName, $userId > 0 ? $userId : null, $studentId));
    } catch (Exception $e) {
        if ($newName) @unlink(ascb_mr_photo_dir() . $newName);
        error_log('ASCB master photo update failed: ' . $e->getMessage());
        ascb_mr_fail(500, 'Unable to update the photo.');
    }

    /* remove the previous file only after the DB points at the new one */
    if (!empty($row['profile_photo']) && preg_match('/^sp_[a-f0-9]{32}\.(jpg|png|webp)$/', $row['profile_photo'])) {
        @unlink(ascb_mr_photo_dir() . $row['profile_photo']);
    }

    ascb_log_activity($pdo, $ascbUser, $action === 'photo' ? 'MASTER_PHOTO' : 'MASTER_PHOTO_REMOVE', 'student', ascb_mr_label($row),
        $action === 'photo' ? 'Profile photo updated.' : 'Profile photo removed.');

    echo json_encode(array('ok' => true, 'message' => $action === 'photo' ? 'Photo updated.' : 'Photo removed.') + ascb_mr_build_profile($pdo, $studentId), JSON_UNESCAPED_UNICODE);
    exit;
}

ascb_mr_fail(400, 'Unknown action.');
