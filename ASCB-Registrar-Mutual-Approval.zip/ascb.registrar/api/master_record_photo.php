<?php
/* =========================================================
   API: SERVE A STUDENT PROFILE PHOTO
   ---------------------------------------------------------
   Streams the photo stored for a student in student_master.
   Photos live in uploads/student_photos/, which is denied to
   direct web access by uploads/.htaccess, so this endpoint
   (logged-in + Master Record permission) is the only way in.

   GET param: studentId
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/file_stream.php';
require_once __DIR__ . '/../includes/master_record_helper.php';
require_once __DIR__ . '/../config/db.php';

if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'manage_master_record')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'You do not have access to the Master Record.'));
    exit;
}

$studentId = trim((string) ascb_get($_GET, 'studentId', ''));
if ($studentId === '' || !ascb_master_available($pdo)) {
    http_response_code(404);
    echo json_encode(array('ok' => false, 'error' => 'Photo not found.'));
    exit;
}

$stmt = $pdo->prepare("SELECT profile_photo FROM student_master WHERE student_id = ? LIMIT 1");
$stmt->execute(array($studentId));
$file = $stmt->fetchColumn();

/* Only ever serve a file name we generated ourselves. */
if (!$file || !preg_match('/^sp_[a-f0-9]{32}\.(jpg|png|webp)$/', $file, $m)) {
    http_response_code(404);
    echo json_encode(array('ok' => false, 'error' => 'Photo not found.'));
    exit;
}

$path = __DIR__ . '/../uploads/student_photos/' . $file;
if (!is_file($path)) {
    http_response_code(404);
    echo json_encode(array('ok' => false, 'error' => 'Photo not found.'));
    exit;
}

$types = array('jpg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp');
ascb_stream_file($path, $types[$m[1]], 'student-photo.' . $m[1], true);
