<?php
require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../config/db.php';
if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'manage_office_records')) {
    http_response_code(403);
    echo json_encode(array('ok'=>false,'error'=>'You do not have access to OCR diagnostics.'));
    exit;
}
function ascbOcrStatusFind($name) {
    if (!function_exists('shell_exec')) return '';
    $redirect = (stripos(PHP_OS, 'WIN') === 0) ? ' 2>NUL' : ' 2>/dev/null';
    $cmd = (stripos(PHP_OS, 'WIN') === 0) ? 'where ' . $name . $redirect : 'command -v ' . escapeshellarg($name) . $redirect;
    $out = @shell_exec($cmd);
    if (!is_string($out) || trim($out)==='') return '';
    $lines=preg_split('/\r?\n/',trim($out));
    return trim($lines[0] ?? '');
}
$tesseract=ascbOcrStatusFind('tesseract');
$pdftoppm=ascbOcrStatusFind('pdftoppm');
$pdftotext=ascbOcrStatusFind('pdftotext');
$configured=defined('ASCB_OCR_COMMAND') ? ASCB_OCR_COMMAND : '';
echo json_encode(array(
    'ok'=>true,
    'php_version'=>PHP_VERSION,
    'shell_exec'=>function_exists('shell_exec'),
    'configured_ocr'=>($configured!==''),
    'tesseract'=>($tesseract!==''),
    'tesseract_path'=>$tesseract,
    'pdftoppm'=>($pdftoppm!==''),
    'pdftoppm_path'=>$pdftoppm,
    'pdftotext'=>($pdftotext!==''),
    'pdftotext_path'=>$pdftotext,
    'ocr_max_pages'=>defined('ASCB_OCR_MAX_PAGES')?ASCB_OCR_MAX_PAGES:5,
    'ocr_dpi'=>defined('ASCB_OCR_DPI')?ASCB_OCR_DPI:200
),JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
