<?php
/* =========================================================
   PROFESSOR GRADE SHEET / SUBJECT GRADEBOOK
   ---------------------------------------------------------
   Workflow:
     1) Open Subject Gradebook and select one subject/term.
     2) Professor Excel contains ONLY: Student ID | Grade.
     3) Preview validates every Student ID against the selected
        subject's enrollment_subject_id.
     4) Commit updates grades in one transaction. No subject name
        is accepted from the spreadsheet, so a file cannot write
        grades into another subject.
     5) Subject locks prevent further grade edits until UNIT HEAD
        unlocks the subject.
   ========================================================= */
require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/departments.php'; // Loads department-scoping helpers used by the Gradebook API.
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/xlsx_reader.php';
require_once __DIR__ . '/../includes/csv_reader.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/gradebook_lock.php';
require_once __DIR__ . '/../config/db.php';

$role = trim((string)ascb_get($ascbUser, 'role', ''));
if (!ascb_can($role, 'manage_professor_gradebook')) {
    http_response_code(403);
    echo json_encode(['ok'=>false,'error'=>'You do not have access to the Subject Gradebook.']);
    exit;
}

/* Lightweight history table for every newly encoded/changed subject grade.
 * It is created lazily so existing installations do not need a separate
 * manual migration step before the Gradebook History can be used. */
function pgs_ensure_history_table($pdo) {
    static $done=false; if($done) return;
    $pdo->exec("CREATE TABLE IF NOT EXISTS gradebook_encoding_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        enrollment_subject_id INT NOT NULL,
        student_id VARCHAR(100) DEFAULT NULL,
        student_name VARCHAR(255) DEFAULT NULL,
        course_code VARCHAR(100) DEFAULT NULL,
        description VARCHAR(255) DEFAULT NULL,
        school_year VARCHAR(30) DEFAULT NULL,
        trimester VARCHAR(50) DEFAULT NULL,
        old_grade VARCHAR(30) DEFAULT NULL,
        new_grade VARCHAR(30) NOT NULL,
        encoded_by_user_id INT DEFAULT NULL,
        encoded_by_name VARCHAR(100) DEFAULT NULL,
        encoded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_gbhist_subject_time (enrollment_subject_id, encoded_at),
        INDEX idx_gbhist_time (encoded_at),
        INDEX idx_gbhist_student (student_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $done=true;
}

function pgs_json($payload, $status=200) {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}
function pgs_norm($v) { return ascb_gradebook_norm_text($v); }
function pgs_grade_valid($grade) {
    $grade = trim((string)$grade);
    if ($grade === '') return false;
    if (preg_match('/^(INC|DRP|DR\.?|NG|P|PASSED|C|COMPETENT|[-–—])$/iu', $grade)) return true;
    return ascb_grade_step_valid($grade);
}
function pgs_header_key($v) {
    $v = pgs_norm($v);
    return preg_replace('/[^A-Z0-9]+/', '', $v);
}
function pgs_subject_params() {
    $schoolYear = trim((string)($_POST['school_year'] ?? $_GET['school_year'] ?? ''));
    $term = trim((string)($_POST['trimester'] ?? $_GET['trimester'] ?? ''));
    $courseCode = trim((string)($_POST['course_code'] ?? $_GET['course_code'] ?? ''));
    $description = trim((string)($_POST['description'] ?? $_GET['description'] ?? ''));
    if ($schoolYear === '' || $term === '' || ($courseCode === '' && $description === '')) pgs_json(['ok'=>false,'error'=>'School Year, Term, and Subject are required.'],400);
    return [$schoolYear,$term,$courseCode,$description];
}
/* Ang subject code (hal. GE 1) ang pangunahing identity ng subject.
   Kapag may code, hindi na ginagamit ang description sa pag-match para
   hindi na mag-doble ang subject kahit magkaiba ang pagkakasulat ng pangalan
   (hal. "UNDERSTANDING SELF" vs "UNDERSTANDING THE SELF"). */
function pgs_subject_match($courseCode, $description, &$params, $alias='es') {
    $code = pgs_norm($courseCode);
    $description = pgs_norm($description);

    /*
     * Subject identity:
     * 1) Prefer the Subject/Course Code when it exists.
     * 2) IMPORTANT: imported subject rows can legitimately have no code.
     *    Those rows must still belong to the selected GradeBook subject when
     *    their description matches. Previously, a coded GradeBook subject
     *    used a code-only WHERE clause, so imported no-grade students whose
     *    subject row had a blank code disappeared from the GradeBook.
     */
    if ($code !== '') {
        /*
         * Subject identity is intentionally tolerant for imported records.
         * The import pipeline may preserve a blank code, a differently
         * formatted code, or an old code while the description is still the
         * same subject.  Code remains the first/strongest match, but the
         * description is also a valid fallback even when the stored row has
         * a non-blank code.  This prevents imported pending subjects (NULL,
         * blank, 0, 0.0, 0.00) from disappearing from Subject Gradebook.
         */
        $params[] = $code;
        $params[] = $description;
        return " AND (
            UPPER(TRIM(COALESCE({$alias}.course_code,'')))=UPPER(TRIM(?))
            OR UPPER(TRIM(COALESCE({$alias}.description,'')))=UPPER(TRIM(?))
        )";
    }

    $params[] = $description;
    return " AND UPPER(TRIM(COALESCE({$alias}.description,'')))=UPPER(TRIM(?))";
}
function pgs_course_param() {
    return trim((string)($_POST['course'] ?? $_GET['course'] ?? ''));
}
function pgs_course_clause($course, &$params, $alias='e') {
    $course = pgs_norm($course);
    if ($course === '' || $course === 'ALL') return '';
    $params[] = $course; $params[] = $course;
    return " AND (UPPER(TRIM(COALESCE({$alias}.program_code,'')))=UPPER(TRIM(?)) OR UPPER(TRIM(COALESCE({$alias}.course,'')))=UPPER(TRIM(?)))";
}
/* ---- (fix 2026-11) Helpers: staff scope fallback, department resolution, pending info ---- */
/* TRUE kapag may assignment tables pero WALANG active Assign ang Admin Staff.
   Sa ganitong kaso, ginagamit ang users.department_id (kapareho ng Dean) para hindi mawala lahat ng subject. */
function pgs_staff_needs_legacy_scope($pdo, $user) {
    static $cache = null;
    if ($cache !== null) return $cache;
    $cache = false;
    try {
        $c = $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'user_department_assignments'");
        if ((int)$c->fetchColumn() > 0) {
            $cache = !ascb_staff_has_active_assignments($pdo, (int)ascb_get($user, 'id', 0));
        }
    } catch (Throwable $e) { $cache = false; }
    return $cache;
}
/* Hinahanap ang tunay na Department ng enrollment. Fallback chain:
   1) department ng enrollee/program code  2) program ayon sa course name (+major)
   3) active Department assignment ng Admin Staff  4) users.department_id. 0 = wala talaga. */
function pgs_resolve_department($pdo, $r) {
    $d = (int)($r['department_id'] ?? 0);
    if ($d > 0) return $d;
    try {
        $name = trim((string)($r['course'] ?? ''));
        if ($name !== '') {
            $q = $pdo->prepare("SELECT department_id FROM programs WHERE UPPER(TRIM(course_name)) COLLATE utf8mb4_unicode_ci = UPPER(TRIM(?)) COLLATE utf8mb4_unicode_ci AND COALESCE(department_id,0) > 0 ORDER BY (UPPER(TRIM(COALESCE(major,''))) COLLATE utf8mb4_unicode_ci = UPPER(TRIM(?)) COLLATE utf8mb4_unicode_ci) DESC LIMIT 1");
            $q->execute([$name, (string)($r['major'] ?? '')]);
            $v = (int)$q->fetchColumn();
            if ($v > 0) return $v;
        }
    } catch (Throwable $e) { /* subukan ang susunod na paraan */ }
    $u = $GLOBALS['ascbUser'] ?? [];
    try {
        $q = $pdo->prepare("SELECT department_id FROM user_department_assignments WHERE user_id = ? AND is_active = 1 AND COALESCE(department_id,0) > 0 ORDER BY id ASC LIMIT 1");
        $q->execute([(int)ascb_get($u, 'id', 0)]);
        $v = (int)$q->fetchColumn();
        if ($v > 0) return $v;
    } catch (Throwable $e) { /* wala pang assignment tables */ }
    try {
        $v = (int)ascb_current_department_id($pdo, $u);
        if ($v > 0) return $v;
    } catch (Throwable $e) {}
    return 0;
}
/* Idinadagdag sa bawat row ang grade na naghihintay ng approval (pending_grade / pending_status),
   para makita ng encoder na naipasa na ang grade at hindi na niya ito ine-encode ulit. */
function pgs_attach_pending($pdo, array $rows) {
    if (!$rows) return $rows;
    try {
        $ids = array_values(array_unique(array_map(function($r){ return (int)$r['enrollment_subject_id']; }, $rows)));
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $q = $pdo->prepare("SELECT i.enrollment_subject_id AS esid, i.new_grade, s.status FROM gradebook_approval_items i JOIN gradebook_approval_submissions s ON s.id = i.submission_id WHERE s.status IN ('PENDING_UNIT_HEAD','PENDING_REGISTRAR') AND i.enrollment_subject_id IN ($ph) ORDER BY i.id ASC");
        $q->execute($ids);
        $map = [];
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $p) {
            $g = trim((string)($p['new_grade'] ?? ''));
            if ($g === '') continue;
            $map[(int)$p['esid']] = ['grade' => $g, 'status' => $p['status']]; // pinakabago ang mananaig
        }
        foreach ($rows as &$r) {
            $k = (int)$r['enrollment_subject_id'];
            $r['pending_grade'] = $map[$k]['grade'] ?? null;
            $r['pending_status'] = $map[$k]['status'] ?? null;
        } unset($r);
    } catch (Throwable $e) { /* wala pang approval tables: walang pending */ }
    return $rows;
}
function pgs_dept_clause($role, $pdo, &$params, $alias='e') {
    if ($role === 'ADMIN STAFF') {
        if (pgs_staff_needs_legacy_scope($pdo, $GLOBALS['ascbUser'])) {
            $legacyDept = ascb_current_department_id($pdo, $GLOBALS['ascbUser']);
            if (!$legacyDept) return ' AND 1=0 ';
            $params[] = $legacyDept; $params[] = $legacyDept;
            return " AND ({$alias}.department_id = ? OR (COALESCE({$alias}.department_id, 0) = 0 AND EXISTS (
                SELECT 1 FROM programs p WHERE p.department_id = ?
                  AND UPPER(TRIM(p.code)) = UPPER(TRIM(COALESCE(NULLIF({$alias}.program_code, ''), {$alias}.course, '')))
            )))";
        }
        $scope = ascb_staff_assignment_scope_sql($pdo, $GLOBALS['ascbUser'], $alias);
        $params = array_merge($params, $scope['params']);
        return $scope['sql'];
    }
    if ($role !== 'DEAN') return '';
    $deptId = ascb_require_dean_department($pdo, $GLOBALS['ascbUser']);
    $params[] = $deptId; $params[] = $deptId;
    return " AND ({$alias}.department_id = ? OR (COALESCE({$alias}.department_id, 0) = 0 AND EXISTS (
        SELECT 1 FROM programs p WHERE p.department_id = ?
          AND UPPER(TRIM(p.code)) = UPPER(TRIM(COALESCE(NULLIF({$alias}.program_code, ''), {$alias}.course, '')))
    )))";
}
function pgs_parse_file() {
    if (empty($_FILES['file']) || $_FILES['file']['error'] === UPLOAD_ERR_NO_FILE) throw new Exception('No professor grade sheet was uploaded.');
    if ($_FILES['file']['error'] !== UPLOAD_ERR_OK) throw new Exception('Upload failed (code '.(int)$_FILES['file']['error'].').');
    $name=(string)$_FILES['file']['name']; $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
    if (!in_array($ext,['xlsx','csv'],true)) throw new Exception('Only .xlsx or .csv files are allowed.');
    if ((int)$_FILES['file']['size'] > ASCB_MAX_UPLOAD_MB*1024*1024) throw new Exception('The uploaded file exceeds the '.ASCB_MAX_UPLOAD_MB.'MB limit.');
    $rows = $ext==='csv' ? ascb_csv_read($_FILES['file']['tmp_name']) : ascb_xlsx_read_first_sheet($_FILES['file']['tmp_name']);
    if (!$rows) throw new Exception('The professor grade sheet is empty.');
    $headerIndex=-1; $studentCol=-1; $gradeCol=-1;
    foreach ($rows as $ri=>$row) {
        $found=[];
        foreach ($row as $ci=>$cell) {
            $k=pgs_header_key($cell);
            if ($k==='STUDENTID') $found['student']=$ci;
            if ($k==='GRADE') $found['grade']=$ci;
        }
        if (isset($found['student']) && isset($found['grade'])) { $headerIndex=$ri; $studentCol=$found['student']; $gradeCol=$found['grade']; break; }
    }
    if ($headerIndex < 0) throw new Exception('Invalid format. The Excel must have headers: Student ID | Grade. Subject is intentionally NOT required.');
    $items=[]; $seen=[]; $duplicateRows=[]; $blankRows=0;
    for ($i=$headerIndex+1;$i<count($rows);$i++) {
        $row=$rows[$i]; $student=trim((string)($row[$studentCol]??'')); $grade=trim((string)($row[$gradeCol]??''));
        if ($student==='' && $grade==='') { $blankRows++; continue; }
        $line=$i+1;
        if ($student==='') throw new Exception("Row {$line}: Student ID is required.");
        if (isset($seen[$student])) { $duplicateRows[]=$line; continue; }
        $seen[$student]=true;
        if ($grade==='' ) { $items[]=['student_id'=>$student,'grade'=>'','line'=>$line,'skip'=>true]; continue; }
        if (!pgs_grade_valid($grade)) throw new Exception("Row {$line}: Invalid grade '{$grade}'. Use 1.0–3.0 (0.1 steps), 4.0, 5.0, INC, Dr., NG, P, C, or \"-\".");
        $items[]=['student_id'=>$student,'grade'=>ascb_normalize_grade($grade),'line'=>$line,'skip'=>false];
    }
    if ($duplicateRows) throw new Exception('Duplicate Student ID detected in the Excel file at row(s): '.implode(', ',$duplicateRows).'. Each Student ID must appear only once.');
    if (!$items) throw new Exception('No grade rows were found after the header.');
    return ['items'=>$items,'filename'=>$name,'blank_rows'=>$blankRows,'header_row'=>$headerIndex+1];
}
function pgs_subject_count($pdo,$role,$schoolYear,$term,$courseCode,$description,$course='',$ungradedOnly=false) {
    $params=[$schoolYear,$term];
    $sql="SELECT COUNT(*) FROM enrollment_subjects es INNER JOIN enrollees e ON e.id=es.enrollment_id
            LEFT JOIN grades g ON g.enrollment_subject_id=es.id
            WHERE e.archived_at IS NULL AND e.status='approved' AND e.school_year=? AND e.trimester=?";
    $sql.=pgs_subject_match($courseCode,$description,$params,'es');
    $sql.=pgs_dept_clause($role,$pdo,$params,'e');
    $sql.=pgs_course_clause($course,$params,'e');
    if ($ungradedOnly) $sql.=" AND (g.grade IS NULL OR TRIM(COALESCE(g.grade,''))='' OR TRIM(g.grade) REGEXP '^[[:space:]]*0([.]0+)?[[:space:]]*$')";
    $q=$pdo->prepare($sql);$q->execute($params);return (int)$q->fetchColumn();
}
function pgs_subject_rows($pdo,$role,$schoolYear,$term,$courseCode,$description,$studentIds=null,$forUpdate=false,$limit=null,$offset=0,$course='',$ungradedOnly=false,$esids=null) {
    $params=[$schoolYear,$term];
    $sql="SELECT es.id AS enrollment_subject_id,e.id AS enrollment_id,e.student_id,e.surname,e.first_name,e.middle_name".ascb_suffix_sql_cols($pdo,'e').",e.program_code,e.course,e.major,e.year_level,e.school_year,e.trimester,es.course_code,es.description,es.units,COALESCE(NULLIF(e.department_id,0),(SELECT p.department_id FROM programs p WHERE UPPER(TRIM(p.code)) COLLATE utf8mb4_unicode_ci=UPPER(TRIM(COALESCE(NULLIF(e.program_code,''),e.course,''))) COLLATE utf8mb4_unicode_ci LIMIT 1)) AS department_id,g.id AS grade_id,g.grade
            FROM enrollment_subjects es
            INNER JOIN enrollees e ON e.id=es.enrollment_id
            LEFT JOIN grades g ON g.enrollment_subject_id=es.id
           WHERE e.archived_at IS NULL AND e.status='approved'
             AND e.school_year=? AND e.trimester=?";
    $sql .= pgs_subject_match($courseCode,$description,$params,'es');
    $sql .= pgs_dept_clause($role,$pdo,$params,'e');
    $sql .= pgs_course_clause($course,$params,'e');
    if ($studentIds !== null) {
        if (!$studentIds) return [];
        $ph=implode(',',array_fill(0,count($studentIds),'?')); $sql.=" AND e.student_id IN ({$ph})"; foreach($studentIds as $sid)$params[]=$sid;
    }
    /* Encoding mode: NULL/blank/0/0.0 are pending. Dash/NG/INC/Dr./P are graded values. */
    if ($ungradedOnly) $sql.=" AND (g.grade IS NULL OR TRIM(COALESCE(g.grade,''))='' OR TRIM(g.grade) REGEXP '^[[:space:]]*0([.]0+)?[[:space:]]*$')";
    /* Targeted save: ang mga ipinasang enrollment_subject_id lang ang
       kinukuha (FOR UPDATE), sa halip na buong klase — mas mabilis at
       mas maliit ang na-lock na rows. */
    if ($esids !== null) {
        if (!$esids) return [];
        $ph=implode(',',array_fill(0,count($esids),'?')); $sql.=" AND es.id IN ({$ph})"; foreach($esids as $eid)$params[]=(int)$eid;
    }
    $sql.=" ORDER BY e.surname,e.first_name,e.student_id,es.id";
    if ($limit !== null && !$forUpdate) $sql.=" LIMIT ".(int)$limit." OFFSET ".(int)$offset;
    if ($forUpdate) $sql.=" FOR UPDATE";
    $q=$pdo->prepare($sql); $q->execute($params);
    /* PSA placement ng suffix (Jr., III...) - kasama na sa surname/first/middle. */
    return array_map('ascb_row_print_split', $q->fetchAll(PDO::FETCH_ASSOC));
}

/* Lahat ng course/program na naka-enroll sa napiling subject + term + school year. */
function pgs_subject_courses($pdo,$role,$schoolYear,$term,$courseCode,$description) {
    $params=[$schoolYear,$term];
    $sql="SELECT UPPER(TRIM(COALESCE(NULLIF(TRIM(e.program_code),''),e.course,''))) AS course,
                 COUNT(*) AS student_count,
                 SUM(CASE WHEN g.grade IS NOT NULL AND TRIM(g.grade)<>'' AND NOT (TRIM(g.grade) REGEXP '^[[:space:]]*0([.]0+)?[[:space:]]*$') THEN 1 ELSE 0 END) AS graded_count
            FROM enrollment_subjects es
            INNER JOIN enrollees e ON e.id=es.enrollment_id
            LEFT JOIN grades g ON g.enrollment_subject_id=es.id
           WHERE e.archived_at IS NULL AND e.status='approved'
             AND e.school_year=? AND e.trimester=?";
    $sql.=pgs_subject_match($courseCode,$description,$params,'es');
    $sql.=pgs_dept_clause($role,$pdo,$params,'e');
    $sql.=" GROUP BY UPPER(TRIM(COALESCE(NULLIF(TRIM(e.program_code),''),e.course,''))) HAVING course<>'' ORDER BY course";
    $q=$pdo->prepare($sql);$q->execute($params);return $q->fetchAll(PDO::FETCH_ASSOC);
}

$method=$_SERVER['REQUEST_METHOD'];
$action=trim((string)($_POST['action']??$_GET['action']??''));

try {
    if ($method==='GET' && $action==='subjects') {
        $params=[];
        $sql="SELECT e.school_year,e.trimester,
                     UPPER(TRIM(COALESCE(es.course_code,''))) AS course_code,
                     GROUP_CONCAT(DISTINCT UPPER(TRIM(es.description)) ORDER BY UPPER(TRIM(es.description)) SEPARATOR '||') AS description_variants,
                     MIN(es.units) AS units,
                     COUNT(*) AS student_count,
                     COUNT(DISTINCT e.id) AS enrollee_count,
                     SUM(CASE WHEN g.grade IS NOT NULL AND TRIM(g.grade)<>'' AND NOT (TRIM(g.grade) REGEXP '^[[:space:]]*0([.]0+)?[[:space:]]*$') THEN 1 ELSE 0 END) AS graded_count
                FROM enrollment_subjects es
                INNER JOIN enrollees e ON e.id=es.enrollment_id
                LEFT JOIN grades g ON g.enrollment_subject_id=es.id
               WHERE e.archived_at IS NULL AND e.status='approved'";
        $sql.=pgs_dept_clause($role,$pdo,$params,'e');
        // Isang row lang kada subject code (hal. GE 1). Kapag walang code,
        // ang description na lang ang gamit na identity.
        $sql.=" GROUP BY e.school_year,e.trimester,UPPER(TRIM(COALESCE(es.course_code,''))),
                        CASE WHEN TRIM(COALESCE(es.course_code,''))='' THEN UPPER(TRIM(es.description)) ELSE '' END
                 HAVING SUM(CASE WHEN g.grade IS NULL OR TRIM(g.grade)='' OR (TRIM(g.grade) REGEXP '^[[:space:]]*0([.]0+)?[[:space:]]*$') THEN 1 ELSE 0 END) > 0
                 ORDER BY e.school_year DESC,e.trimester,course_code,description_variants";
        $q=$pdo->prepare($sql);$q->execute($params);$rows=$q->fetchAll(PDO::FETCH_ASSOC);
        foreach($rows as &$r){
            // Pinakakumpletong pangalan ng subject ang ipapakita, at nakalista
            // ang iba pang bersyon ng pangalan para malinaw sa registrar.
            $variants=array_values(array_filter(array_map('trim',explode('||',(string)($r['description_variants']??'')))));
            usort($variants,fn($a,$b)=>mb_strlen($b)<=>mb_strlen($a));
            $r['description']=$variants[0]??'';
            $r['description_variants']=$variants;$lock=ascb_gradebook_lock_find($pdo,$r['school_year'],$r['trimester'],$r['course_code']??'',$r['description']);$r['locked']=!!$lock;$r['locked_at']=$lock['locked_at']??null;} unset($r);
        $hint='';
        if(!$rows && $role==='ADMIN STAFF'){
            $hint = pgs_staff_needs_legacy_scope($pdo,$ascbUser) && !ascb_current_department_id($pdo,$ascbUser) ? 'no_assignment' : 'no_match';
        }
        pgs_json(['ok'=>true,'rows'=>$rows,'hint'=>$hint]);
    }

    if ($method==='GET' && $action==='history') {
        pgs_ensure_history_table($pdo);
        $page=max(1,(int)($_GET['page']??1)); $limit=min(100,max(10,(int)($_GET['limit']??30))); $offset=($page-1)*$limit;
        $sy=trim((string)($_GET['school_year']??'')); $term=trim((string)($_GET['trimester']??''));
        $code=trim((string)($_GET['course_code']??'')); $desc=trim((string)($_GET['description']??''));
        $course=trim((string)($_GET['course']??'')); $q=trim((string)($_GET['q']??''));
        $params=[]; $where=['1=1'];
        if($sy!==''){ $where[]='h.school_year=?'; $params[]=$sy; }
        if($term!==''){ $where[]='h.trimester=?'; $params[]=$term; }
        if($code!==''){ $where[]='UPPER(TRIM(h.course_code))=UPPER(TRIM(?))'; $params[]=$code; }
        elseif($desc!==''){ $where[]='UPPER(TRIM(h.description))=UPPER(TRIM(?))'; $params[]=$desc; }
        if($course!=='') { $where[]="EXISTS (SELECT 1 FROM enrollment_subjects esy INNER JOIN enrollees ey ON ey.id=esy.enrollment_id WHERE esy.id=h.enrollment_subject_id AND (UPPER(TRIM(COALESCE(ey.program_code,''))) = UPPER(TRIM(?)) OR UPPER(TRIM(COALESCE(ey.course,''))) = UPPER(TRIM(?))))"; $params[]=$course; $params[]=$course; }
        if($q!==''){
            $idq = trim($q, " \\t\\r\\n\\0\\x0B\\'");
            $idq = str_replace(array('–','—','−','‑','‐'), '-', $idq);
            if (preg_match('/^\\d{9}$/', $idq)) $idq = substr($idq,0,4).'-'.substr($idq,4);
            $idDigits = preg_replace('/\\D+/', '', $idq);
            $where[]="((UPPER(h.student_id) LIKE UPPER(?) OR REPLACE(REPLACE(REPLACE(h.student_id, '-', ''), '–', ''), ' ', '') LIKE ?) OR UPPER(h.student_name) LIKE UPPER(?) OR UPPER(h.course_code) LIKE UPPER(?) OR UPPER(h.description) LIKE UPPER(?))";
            $like='%'.$q.'%'; $idLike='%'.$idDigits.'%';
            array_push($params,$like,$idLike,$like,$like,$like);
        }
        $deptClause='';
        if($role==='DEAN') { $deptId=ascb_require_dean_department($pdo,$ascbUser); $deptClause=' AND EXISTS (SELECT 1 FROM enrollment_subjects esx INNER JOIN enrollees ex ON ex.id=esx.enrollment_id WHERE esx.id=h.enrollment_subject_id AND ex.department_id=?)'; $params[]=$deptId; }
        $w=implode(' AND ',$where).$deptClause;
        $c=$pdo->prepare("SELECT COUNT(*) FROM gradebook_encoding_history h WHERE {$w}"); $c->execute($params); $total=(int)$c->fetchColumn();
        $sql="SELECT h.* FROM gradebook_encoding_history h WHERE {$w} ORDER BY h.encoded_at DESC,h.id DESC LIMIT {$limit} OFFSET {$offset}";
        $st=$pdo->prepare($sql); $st->execute($params); $rows=$st->fetchAll(PDO::FETCH_ASSOC);
        pgs_json(['ok'=>true,'rows'=>$rows,'page'=>$page,'limit'=>$limit,'total'=>$total,'pages'=>(int)ceil($total/max(1,$limit))]);
    }

    if ($method==='GET' && $action==='rows') {
        [$sy,$term,$code,$desc]=pgs_subject_params();
        $course=pgs_course_param();
        $page=max(1,(int)($_GET['page']??1));$limit=min(200,max(10,(int)($_GET['limit']??50)));$offset=($page-1)*$limit;
        // Subject Gradebook is an encoding queue: only students without a saved grade are shown.
        // Graded students remain available in Grade Evaluation, not in this list.
        $ungradedOnly=true;
        $courses=pgs_subject_courses($pdo,$role,$sy,$term,$code,$desc);
        $subjectTotal=pgs_subject_count($pdo,$role,$sy,$term,$code,$desc);
        $courseTotal=pgs_subject_count($pdo,$role,$sy,$term,$code,$desc,$course);
        $courseUngraded=pgs_subject_count($pdo,$role,$sy,$term,$code,$desc,$course,true);
        $total=$ungradedOnly?$courseUngraded:$courseTotal;
        if ($total===0 && $page>1) { $page=1; $offset=0; }
        $rows=pgs_subject_rows($pdo,$role,$sy,$term,$code,$desc,null,false,$limit,$offset,$course,$ungradedOnly);
        $rows=pgs_attach_pending($pdo,$rows);
        $lock=ascb_gradebook_lock_find($pdo,$sy,$term,$code,$desc);
        pgs_json(['ok'=>true,'school_year'=>$sy,'trimester'=>$term,'course_code'=>$code,'description'=>$desc,'course'=>pgs_norm($course),'courses'=>$courses,'subject_total'=>$subjectTotal,'course_total'=>$courseTotal,'course_ungraded'=>$courseUngraded,'course_graded'=>$courseTotal-$courseUngraded,'only'=>$ungradedOnly?'ungraded':'','locked'=>!!$lock,'locked_at'=>$lock['locked_at']??null,'rows'=>$rows,'page'=>$page,'limit'=>$limit,'total'=>$total,'pages'=>(int)ceil($total/max(1,$limit))]);
    }

    /* Subject locking was removed (2026-09-22): locked subjects could not be
     * reopened, which froze grade encoding and grade-sheet imports. Both
     * endpoints now simply guarantee the subject is open and clear any stale
     * lock rows left behind by the old feature. */
    if ($method==='POST' && in_array($action,['lock','unlock'],true)) {
        [$sy,$term,$code,$desc]=pgs_subject_params();
        $cleared=ascb_gradebook_locks_clear($pdo,$sy,$term,$code,$desc);
        if ($cleared>0) {
            ascb_log_activity($pdo,$ascbUser,'SUBJECT_GRADES_UNLOCKED','subject_gradebook',pgs_norm($code).' - '.pgs_norm($desc),'Cleared stale subject grade lock for '.$sy.' / '.$term.'. Locking is disabled.');
        }
        pgs_json(['ok'=>true,'locked'=>false,'locking_disabled'=>true,'cleared'=>$cleared]);
    }

    if ($method==='POST' && in_array($action,['professor_preview','professor_commit'],true)) {
        /* TEMPORARILY DISABLED: Import Professor Grade Sheet.
           Para i-enable ulit, alisin ang 2 linyang ito. */
        pgs_json(['ok'=>false,'error'=>'Import Professor Grade Sheet is temporarily disabled.'],403);
        [$sy,$term,$code,$desc]=pgs_subject_params();
        $lock=ascb_gradebook_lock_find($pdo,$sy,$term,$code,$desc);
        if ($lock) pgs_json(['ok'=>false,'error'=>'This subject is locked. The UNIT HEAD must unlock it before a new grade sheet can be imported.'],409);
        $parsed=pgs_parse_file();
        $ids=array_values(array_unique(array_map(fn($x)=>$x['student_id'],$parsed['items'])));
        $rows=pgs_subject_rows($pdo,$role,$sy,$term,$code,$desc,$ids,$action==='professor_commit');
        $byStudent=[]; foreach($rows as $r){$sid=(string)$r['student_id'];if(isset($byStudent[$sid])){pgs_json(['ok'=>false,'error'=>"Student ID {$sid} has more than one matching {$code} subject row in the selected term. The import was stopped to prevent an ambiguous grade update."],409);} $byStudent[$sid]=$r;}
        $errors=[];$matched=0;$updated=0;$unchanged=0;$skipped=0;$preview=[];
        foreach($parsed['items'] as $item){
            $sid=$item['student_id'];
            if(!isset($byStudent[$sid])){$errors[]="Row {$item['line']}: Student ID {$sid} is not enrolled in the selected subject/term.";continue;}
            $r=$byStudent[$sid];$matched++;
            if($item['skip']){$skipped++;$preview[]=['student_id'=>$sid,'name'=>trim($r['surname'].', '.$r['first_name'].' '.$r['middle_name']),'current_grade'=>$r['grade']??'','new_grade'=>'','status'=>'Blank grade skipped'];continue;}
            $same=ascb_normalize_grade((string)($r['grade']??''))===$item['grade']; if($same)$unchanged++;else $updated++;
            $preview[]=['student_id'=>$sid,'name'=>trim($r['surname'].', '.$r['first_name'].' '.$r['middle_name']),'current_grade'=>$r['grade']??'','new_grade'=>$item['grade'],'status'=>$same?'No change':'Will update'];
        }
        if($errors) pgs_json(['ok'=>false,'error'=>'Professor grade sheet validation failed. No grades were changed.','errors'=>$errors,'filename'=>$parsed['filename'],'matched'=>$matched,'rows'=>count($parsed['items'])],422);
        if($action==='professor_preview') pgs_json(['ok'=>true,'mode'=>'preview','filename'=>$parsed['filename'],'school_year'=>$sy,'trimester'=>$term,'course_code'=>$code,'description'=>$desc,'locked'=>false,'rows'=>count($parsed['items']),'matched'=>$matched,'will_update'=>$updated,'unchanged'=>$unchanged,'blank_skipped'=>$skipped,'preview'=>array_slice($preview,0,200)]);

        pgs_ensure_history_table($pdo);
        $pdo->beginTransaction();
        try {
            // Re-check the lock inside the transaction so a concurrent lock cannot be bypassed.
            if (ascb_gradebook_lock_find($pdo,$sy,$term,$code,$desc)) throw new Exception('This subject was locked before the import could be completed.');
            $now=date('Y-m-d H:i:s');
            $upd=$pdo->prepare("UPDATE grades SET grade=?,updated_by_user_id=?,updated_at=? WHERE id=?");
            $ins=$pdo->prepare("INSERT INTO grades (enrollment_subject_id,grade,entered_by_user_id,entered_at) VALUES (?,?,?,?)");
            $zeroUnits=$pdo->prepare("UPDATE enrollment_subjects SET units=0 WHERE id=? AND units<>0");
            $histIns=$pdo->prepare("INSERT INTO gradebook_encoding_history (enrollment_subject_id,student_id,student_name,course_code,description,school_year,trimester,old_grade,new_grade,encoded_by_user_id,encoded_by_name,encoded_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
            $changed=0;
            foreach($parsed['items'] as $item){if($item['skip'])continue;$r=$byStudent[$item['student_id']];$new=$item['grade'];$old=ascb_normalize_grade((string)($r['grade']??''));if($old!==$new){if(!empty($r['grade_id'])){$upd->execute([$new,(int)$ascbUser['id'],$now,(int)$r['grade_id']]);}else{$ins->execute([(int)$r['enrollment_subject_id'],$new,(int)$ascbUser['id'],$now]);}$changed++;}if(ascb_grade_is_failing($new))$zeroUnits->execute([(int)$r['enrollment_subject_id']]);}
            $pdo->commit();
            ascb_log_activity($pdo,$ascbUser,'PROFESSOR_GRADE_SHEET_IMPORTED','subject_gradebook',pgs_norm($code).' - '.pgs_norm($desc),'Imported '.$changed.' changed grade(s) from '.$parsed['filename'].' for '.$sy.' / '.$term.'. Matched '.$matched.' student(s).');
            pgs_json(['ok'=>true,'mode'=>'commit','changed'=>$changed,'matched'=>$matched,'unchanged'=>$unchanged,'blank_skipped'=>$skipped,'filename'=>$parsed['filename']]);
        } catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
    }

    if ($method==='POST' && $action==='save_grades') {
        if (!in_array($role, ['ADMIN STAFF','UNIT HEAD','SCHOOL REGISTRAR'], true)) {
            pgs_json(['ok'=>false,'error'=>'You do not have permission to encode grades.'],403);
        }
        [$sy,$term,$code,$desc]=pgs_subject_params();
        if (ascb_gradebook_lock_find($pdo,$sy,$term,$code,$desc)) pgs_json(['ok'=>false,'error'=>'This subject is locked. The UNIT HEAD must unlock it before encoding grades.'],423);
        $raw = (string)($_POST['grades'] ?? '');
        $items = json_decode($raw, true);
        if (!is_array($items) || !$items) pgs_json(['ok'=>false,'error'=>'No grades were submitted.'],400);
        $clean=[]; $errors=[];
        foreach ($items as $it) {
            $esid=(int)($it['enrollment_subject_id'] ?? 0);
            $grade=trim((string)($it['grade'] ?? ''));
            if ($esid<=0) continue;
            if ($grade!=='' && !pgs_grade_valid($grade)) { $errors[]='Invalid grade "'.$grade.'". Use 0-5, INC, Dr., NG, P, or "-".'; continue; }
            $normalized = $grade==='' ? '' : ascb_normalize_grade($grade);
            // 0 / 0.0 / 0.00 are placeholders for NOT GRADED, never a saved grade.
            $clean[$esid] = ($normalized !== '' && is_numeric($normalized) && (float)$normalized === 0.0) ? '' : $normalized;
        }
        if ($errors) pgs_json(['ok'=>false,'error'=>'Some grades are invalid. Nothing was saved.','errors'=>array_values(array_unique($errors))],422);
        if (!$clean) pgs_json(['ok'=>false,'error'=>'No valid grades were submitted.'],400);


        /* Grade encoding by Admin Staff, Unit Head, and School Registrar is staged.
           Admin Staff -> Unit Head -> School Registrar. Unit Head -> Registrar peer review.
           School Registrar -> Unit Head peer review. No encoder approves their own entry. */
        if (in_array($role, ['ADMIN STAFF','UNIT HEAD','SCHOOL REGISTRAR'], true)) {
            /* (fix) Dating: $deptId = users.department_id (iisang legacy value) ang inilalagay sa LAHAT ng submission,
               kaya kapag maraming Department ang naka-assign (o iba ang nakasave sa user), napupunta ang grades sa maling
               Department at hindi lumalabas sa Unit Head ang tamang Department (hal. College of Accounting and Business
               Education). Ngayon: ang AKTUWAL na Department ng bawat enrollment ang ginagamit, at isang submission
               bawat Department. */
            $scopeRows = pgs_subject_rows($pdo,$role,$sy,$term,$code,$desc,null,false,null,0,'',false,array_keys($clean));
            $byId=[]; foreach($scopeRows as $rr) $byId[(int)$rr['enrollment_subject_id']]=$rr;
            foreach(array_keys($clean) as $id) if(!isset($byId[(int)$id])) pgs_json(['ok'=>false,'error'=>'One or more students are outside your assigned department or no longer enrolled. Nothing was submitted.'],403);
            $byDept=[];
            foreach(array_keys($clean) as $id){
                $d=pgs_resolve_department($pdo,$byId[(int)$id]);
                if($d<1) pgs_json(['ok'=>false,'error'=>'The assigned program has no resolvable department. Please ask the Unit Head to review the program catalog. Nothing was submitted.'],403);
                $byDept[$d][]=(int)$id;
            }
            $pgsFlag=__DIR__.'/../storage/cache/pgs_schema_v1.flag';
            if(!is_file($pgsFlag)){
            $pdo->exec("CREATE TABLE IF NOT EXISTS gradebook_approval_submissions (
                id BIGINT AUTO_INCREMENT PRIMARY KEY, department_id INT NOT NULL, school_year VARCHAR(30) NOT NULL,
                term VARCHAR(50) NOT NULL, course_code VARCHAR(100) DEFAULT '', description VARCHAR(255) DEFAULT '',
                submitted_by INT NOT NULL, submitted_by_name VARCHAR(150) DEFAULT NULL,
                status ENUM('PENDING_UNIT_HEAD','PENDING_REGISTRAR','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING_UNIT_HEAD',
                unit_head_id INT DEFAULT NULL, unit_head_at DATETIME DEFAULT NULL, registrar_id INT DEFAULT NULL,
                registrar_at DATETIME DEFAULT NULL, rejection_reason VARCHAR(500) DEFAULT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_gas_status_dept(status,department_id), INDEX idx_gas_created(created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $pdo->exec("CREATE TABLE IF NOT EXISTS gradebook_approval_items (
                id BIGINT AUTO_INCREMENT PRIMARY KEY, submission_id BIGINT NOT NULL, enrollment_subject_id INT NOT NULL,
                student_id VARCHAR(100) DEFAULT NULL, student_name VARCHAR(255) DEFAULT NULL,
                old_grade VARCHAR(30) DEFAULT NULL, new_grade VARCHAR(30) DEFAULT NULL,
                old_units DECIMAL(8,2) DEFAULT NULL, new_units DECIMAL(8,2) DEFAULT NULL,
                UNIQUE KEY uq_gai_submission_subject(submission_id,enrollment_subject_id),
                INDEX idx_gai_submission(submission_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $approvalItemCols=[];
            foreach($pdo->query("SHOW COLUMNS FROM gradebook_approval_items")->fetchAll(PDO::FETCH_ASSOC) as $col) $approvalItemCols[$col['Field']]=true;
            if(!isset($approvalItemCols['old_units'])) $pdo->exec("ALTER TABLE gradebook_approval_items ADD COLUMN old_units DECIMAL(8,2) DEFAULT NULL");
            if(!isset($approvalItemCols['new_units'])) $pdo->exec("ALTER TABLE gradebook_approval_items ADD COLUMN new_units DECIMAL(8,2) DEFAULT NULL");
            @file_put_contents($pgsFlag,date('c'));
            }
            /* LOCK: kapag naipasa na ng Admin Staff ang grade at naghihintay ito ng approval, hindi na ito puwedeng i-edit.
               Parehong grade lang (hal. dobleng Enter) = tahimik na laktawan; ibang grade = harangin. */
            $dupCount=0; $lockedCount=0;
            $dupQ=$pdo->prepare("SELECT i.new_grade FROM gradebook_approval_items i JOIN gradebook_approval_submissions s ON s.id=i.submission_id WHERE i.enrollment_subject_id=? AND s.status IN ('PENDING_UNIT_HEAD','PENDING_REGISTRAR') ORDER BY i.id DESC LIMIT 1");
            foreach($byDept as $dk=>$ids){
                $keepIds=[];
                foreach($ids as $eid){
                    $dupQ->execute([(int)$eid]); $pg=$dupQ->fetchColumn();
                    if($pg===false) $keepIds[]=(int)$eid;
                    elseif(trim((string)$pg)===(string)$clean[(int)$eid]) $dupCount++;
                    else $lockedCount++;
                }
                if($keepIds) $byDept[$dk]=$keepIds; else unset($byDept[$dk]);
            }
            if(!$byDept){
                if($lockedCount) pgs_json(['ok'=>false,'locked'=>true,'error'=>'Naipasa na ang grade at naghihintay ng approval, kaya hindi na ito puwedeng i-edit ng Admin Staff. Kung may mali, ipa-reject ito sa Unit Head o School Registrar para ma-resubmit.'],409);
                pgs_json(['ok'=>true,'pending_approval'=>true,'duplicates'=>$dupCount,'submitted'=>0,'message'=>'These grades are already waiting for approval. Nothing new was submitted.']);
            }
            $pdo->beginTransaction();
            try {
              /* Serialize overlapping submissions by locking their subject rows. */
              $lockIds=[]; foreach($byDept as $ids) foreach($ids as $eid) $lockIds[]=(int)$eid;
              $lockIds=array_values(array_unique($lockIds)); sort($lockIds,SORT_NUMERIC);
              $lockSubject=$pdo->prepare('SELECT id FROM enrollment_subjects WHERE id=? FOR UPDATE');
              foreach($lockIds as $lockId){ $lockSubject->execute([$lockId]); if(!$lockSubject->fetchColumn()) throw new Exception('A subject was removed before submission. Please reload the gradebook.'); }
              $safeByDept=[]; $raceDup=0; $raceLocked=0; $alreadyApplied=0;
              $officialCheck=$pdo->prepare('SELECT es.units,g.grade FROM enrollment_subjects es LEFT JOIN grades g ON g.enrollment_subject_id=es.id WHERE es.id=? FOR UPDATE');
              foreach($byDept as $deptKey=>$ids){
                $keep=[];
                foreach($ids as $eid){
                  $eid=(int)$eid;
                  $dupQ->execute([$eid]); $pg=$dupQ->fetchColumn();
                  if($pg!==false){
                    if(trim((string)$pg)===(string)$clean[$eid]) $raceDup++;
                    else $raceLocked++;
                    continue;
                  }
                  $officialCheck->execute([$eid]); $official=$officialCheck->fetch(PDO::FETCH_ASSOC);
                  if(!$official){ $raceLocked++; continue; }
                  $current=trim((string)($official['grade']??'')); if($current!=='') $current=ascb_normalize_grade($current);
                  $old=trim((string)($byId[$eid]['grade']??'')); if($old!=='') $old=ascb_normalize_grade($old);
                  $proposedUnits=ascb_grade_is_failing($clean[$eid])?0.0:(float)($byId[$eid]['units']??0);
                  if($current===$clean[$eid] && abs((float)$official['units']-$proposedUnits)<0.001){ $alreadyApplied++; continue; }
                  if($current!==$old){ $raceLocked++; continue; }
                  $keep[]=$eid;
                }
                if($keep) $safeByDept[$deptKey]=$keep;
              }
              if($raceLocked){ $pdo->rollBack(); pgs_json(['ok'=>false,'locked'=>true,'error'=>'A grade changed or was submitted by another request while this submission was being prepared. Reload the subject before trying again. No duplicate submission was created.'],409); }
              $byDept=$safeByDept; $dupCount += $raceDup;
              if(!$byDept){ $pdo->rollBack(); if($alreadyApplied>0 && $dupCount===0) pgs_json(['ok'=>true,'pending_approval'=>false,'already_applied'=>$alreadyApplied,'submitted'=>0,'message'=>'These grades have already been finalized. No duplicate submission was created.']); pgs_json(['ok'=>true,'pending_approval'=>true,'duplicates'=>$dupCount,'submitted'=>0,'message'=>'These grades are already waiting for approval. No duplicate submission was created.']); }
              $sids=[];
              foreach($byDept as $deptId=>$deptEsids){
                $cleanD=array_intersect_key($clean,array_flip($deptEsids));
                $initialStatus = $role === 'UNIT HEAD' ? 'PENDING_REGISTRAR' : 'PENDING_UNIT_HEAD';
                $ins=$pdo->prepare("INSERT INTO gradebook_approval_submissions(department_id,school_year,term,course_code,description,submitted_by,submitted_by_name,status) VALUES(?,?,?,?,?,?,?,?)");
                $ins->execute([(int)$deptId,$sy,$term,$code,$desc,(int)$ascbUser['id'],(string)($ascbUser['display_name']??$ascbUser['username']??$role),$initialStatus]);
                $sid=(int)$pdo->lastInsertId();
                $ii=$pdo->prepare("INSERT INTO gradebook_approval_items(submission_id,enrollment_subject_id,student_id,student_name,old_grade,new_grade,old_units,new_units) VALUES(?,?,?,?,?,?,?,?)");
                foreach($cleanD as $esid=>$new) {
                    $rr=$byId[(int)$esid];
                    $nm=trim((string)$rr['surname'].', '.(string)$rr['first_name'].' '.(string)$rr['middle_name']);
                    $oldUnits=isset($rr['units']) && $rr['units']!=='' ? (float)$rr['units'] : 0.0;
                    // Pending approval must show the enrolled units; grades that normally zero units propose 0 units.
                    $proposedUnits=ascb_grade_is_failing($new) ? 0.0 : $oldUnits;
                    $ii->execute([$sid,(int)$esid,(string)$rr['student_id'],$nm,($rr['grade']??null),($new!==''?$new:null),$oldUnits,$proposedUnits]);
                }
                /* RE-SUBMIT cleanup: ang bagong submission ang pumapalit sa lumang na-reject (sariling gawa) na item ng parehong subject. */
                $rejQ=$pdo->prepare("SELECT i.id,i.submission_id FROM gradebook_approval_items i JOIN gradebook_approval_submissions s ON s.id=i.submission_id WHERE i.enrollment_subject_id=? AND s.status='REJECTED' AND s.submitted_by=? AND s.id<>?");
                $delRejItem=$pdo->prepare("DELETE FROM gradebook_approval_items WHERE id=?");
                $touchedRej=[];
                foreach(array_keys($cleanD) as $esid){
                    $rejQ->execute([(int)$esid,(int)$ascbUser['id'],$sid]);
                    foreach($rejQ->fetchAll(PDO::FETCH_ASSOC) as $rj){ $delRejItem->execute([(int)$rj['id']]); $touchedRej[(int)$rj['submission_id']]=true; }
                }
                if($touchedRej){
                    $cntRej=$pdo->prepare("SELECT COUNT(*) FROM gradebook_approval_items WHERE submission_id=?");
                    $delRejSub=$pdo->prepare("DELETE FROM gradebook_approval_submissions WHERE id=? AND status='REJECTED'");
                    foreach(array_keys($touchedRej) as $rsid){ $cntRej->execute([$rsid]); if((int)$cntRej->fetchColumn()===0) $delRejSub->execute([$rsid]); }
                }
                $sids[]=$sid;
              }
                $pdo->commit();
                $sid=$sids[0];
                $reviewTarget = $role === 'UNIT HEAD' ? 'School Registrar' : 'Unit Head';
                ascb_log_activity($pdo,$ascbUser,'GRADEBOOK_SUBMITTED_FOR_APPROVAL','subject_gradebook',$code.' - '.$desc,'Submission #'.implode(', #',$sids).' for '.$sy.' / '.$term.' awaiting '.$reviewTarget.' review.');
                pgs_json(['ok'=>true,'pending_approval'=>true,'submission_id'=>$sid,'submission_ids'=>$sids,'submitted'=>array_sum(array_map('count',$byDept)),'duplicates'=>$dupCount,'locked_count'=>$lockedCount,'message'=>'Grades submitted for '.$reviewTarget.' review. Official grades have not been changed.'.($dupCount?(' '.$dupCount.' grade(s) were already waiting for approval and were skipped.'):'')]);
            } catch(Throwable $e) { if($pdo->inTransaction())$pdo->rollBack(); throw $e; }
        }

        /* Ensure the encoding-history table exists before any grade save.
         * The history insert is part of the same transaction, so a grade can
         * never be saved without its audit record being available. */
        pgs_ensure_history_table($pdo);
        $pdo->beginTransaction();
        try {
            if (ascb_gradebook_lock_find($pdo,$sy,$term,$code,$desc)) throw new Exception('This subject was locked before the grades could be saved.');
            $rows = pgs_subject_rows($pdo,$role,$sy,$term,$code,$desc,null,true,null,0,'',false,array_keys($clean));
            $byEsid=[]; foreach($rows as $r){ $byEsid[(int)$r['enrollment_subject_id']]=$r; }
            $now=date('Y-m-d H:i:s');
            $upd=$pdo->prepare("UPDATE grades SET grade=?,updated_by_user_id=?,updated_at=? WHERE id=?");
            $ins=$pdo->prepare("INSERT INTO grades (enrollment_subject_id,grade,entered_by_user_id,entered_at) VALUES (?,?,?,?)");
            $del=$pdo->prepare("DELETE FROM grades WHERE id=?");
            $zeroUnits=$pdo->prepare("UPDATE enrollment_subjects SET units=0 WHERE id=? AND units<>0");
            $histIns=$pdo->prepare("INSERT INTO gradebook_encoding_history (enrollment_subject_id,student_id,student_name,course_code,description,school_year,trimester,old_grade,new_grade,encoded_by_user_id,encoded_by_name,encoded_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
            $changed=0; $cleared=0; $unchanged=0;
            foreach ($clean as $esid=>$new) {
                if (!isset($byEsid[$esid])) throw new Exception('One of the students is no longer enrolled in this subject. Please reload the gradebook.');
                $r=$byEsid[$esid];
                $old=ascb_normalize_grade((string)($r['grade']??''));
                if ($new==='') {
                    if (!empty($r['grade_id'])) { $del->execute([(int)$r['grade_id']]); $cleared++; } else { $unchanged++; }
                    continue;
                }
                if ($old===$new) { $unchanged++; }
                else {
                    if (!empty($r['grade_id'])) $upd->execute([$new,(int)$ascbUser['id'],$now,(int)$r['grade_id']]);
                    else $ins->execute([$esid,$new,(int)$ascbUser['id'],$now]);
                    $changed++;
                    $histName=trim(implode(', ',array_filter([(string)($r['surname']??''),(string)($r['first_name']??''),(string)($r['middle_name']??'')])));
                    $histIns->execute([$esid,(string)($r['student_id']??''),$histName,(string)($r['course_code']??$code),(string)($r['description']??$desc),(string)($r['school_year']??$sy),(string)($r['trimester']??$term),($old!==''?$old:null),$new,(int)$ascbUser['id'],(string)($ascbUser['display_name']??$ascbUser['username']??'User'),$now]);
                }
                if (ascb_grade_is_failing($new)) $zeroUnits->execute([$esid]);
            }
            $pdo->commit();
            ascb_log_activity($pdo,$ascbUser,'SUBJECT_GRADE_ENCODED','subject_gradebook',pgs_norm($code).' - '.pgs_norm($desc),'Encoded '.$changed.' grade(s), cleared '.$cleared.' for '.$sy.' / '.$term.'.');
            pgs_json(['ok'=>true,'changed'=>$changed,'cleared'=>$cleared,'unchanged'=>$unchanged]);
        } catch(Throwable $e){ if($pdo->inTransaction())$pdo->rollBack(); throw $e; }
    }

    pgs_json(['ok'=>false,'error'=>'Invalid gradebook action.'],400);
} catch(PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('ASCB professor gradebook database failure: ' . $e->getMessage());
    pgs_json(['ok'=>false,'error'=>'A database error prevented the gradebook operation. No changes were committed.'],500);
} catch(Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    pgs_json(['ok'=>false,'error'=>$e->getMessage()],400);
} catch(Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('ASCB professor gradebook unexpected failure: ' . $e->getMessage());
    pgs_json(['ok'=>false,'error'=>'The gradebook operation failed. Please retry or contact the administrator.'],500);
}
