<?php
/* =========================================================
   API: PROGRAMS & SUBJECTS
   ---------------------------------------------------------
   Pinapatakbo ang "Programs & Subjects" tab sa Admin panel.
   Dito nagmumula ang mga BAGONG Course/Program (major, term
   type: Trimester/Semester) at ang mga Subject nito bawat
   Year Level + Term — ito ang gagamitin ng Enrollment module
   (Course dropdown at "Load Subjects for Term") kasabay ng
   mga naka-hardcode nang program (structuredPrograms sa
   script.js).

   Actions (POST body JSON, { "action": "..." }):
     list             - lahat ng programs (+ subject_count)
     add              - bagong program
     update           - i-edit ang program (code/pangalan/major/
                         term type/status)
     delete           - burahin ang program (kasama ang lahat
                         ng subjects nito — delete_lookups lang)
     list_subjects    - { programId } subjects ng isang program,
                         nakaayos na (Year Level -> Term -> order)
     add_subject      - bagong subject sa isang program
     update_subject   - i-edit ang subject
     delete_subject   - burahin ang subject (delete_lookups lang)
     structured       - buong data (lahat ng active na program +
                         subjects), nasa format na direktang
                         maii-merge sa structuredPrograms/
                         programNames sa JS
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/programs_helper.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../config/db.php';

$input = ascb_read_json_body();
$action = ascb_get($input, 'action', '');

$ascbReservedProgramCodes = ascb_reserved_program_codes($pdo);
$ascbYearLevelRank = $GLOBALS['ASCB_YEAR_LEVEL_RANK'];
$ascbTermRank = $GLOBALS['ASCB_TERM_RANK'];

if ($action === 'list') {
    $sql = "SELECT p.id, p.department_id, d.name AS department_name, p.code, p.course_name, p.major, p.term_type, p.is_active, p.created_at,
                (SELECT COUNT(*) FROM program_subjects ps WHERE ps.program_id = p.id) AS subject_count
         FROM programs p LEFT JOIN departments d ON d.id=p.department_id";
    $params = array();
    if (ascb_get($ascbUser, 'role', '') === 'DEAN') {
        $deptId = ascb_require_dean_department($pdo, $ascbUser);
        $sql .= " WHERE p.department_id = ?";
        $params[] = $deptId;
    }
    $sql .= " ORDER BY p.course_name, p.major";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    echo json_encode(array('ok' => true, 'programs' => $rows));
    exit;
}

if ($action === 'assign_department_bulk') {
    // Assigning existing Programs/Courses to a Department is restricted to the top-level admin (UNIT HEAD).
    // Hiding the controls in the UI is not sufficient; enforce the same rule on the API.
    if (ascb_get($ascbUser, 'role', '') !== 'UNIT HEAD') {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'Only UNIT HEAD (Admin) can assign Programs/Courses to a Department.'));
        exit;
    }

    $departmentId = (int)ascb_get($input, 'departmentId', 0);
    $programIds = ascb_get($input, 'programIds', array());
    if (!$departmentId || !is_array($programIds) || !$programIds) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Please select a Department and at least one Program.'));
        exit;
    }

    $d = $pdo->prepare("SELECT id, code, name, is_active FROM departments WHERE id = ?");
    $d->execute(array($departmentId));
    $department = $d->fetch();
    if (!$department || !((int)$department['is_active'])) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'The target Department is invalid or inactive.'));
        exit;
    }

    $ids = array();
    foreach ($programIds as $id) {
        $id = (int)$id;
        if ($id > 0 && !in_array($id, $ids, true)) $ids[] = $id;
    }
    if (!$ids) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'No valid Program IDs.'));
        exit;
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $find = $pdo->prepare("SELECT id, code, course_name, major, department_id FROM programs WHERE id IN ($placeholders)");
    $find->execute($ids);
    $found = $find->fetchAll();
    if (!$found) {
        http_response_code(404);
        echo json_encode(array('ok' => false, 'error' => 'No Programs found.'));
        exit;
    }

    $upd = $pdo->prepare("UPDATE programs SET department_id = ? WHERE id = ?");
    $pdo->beginTransaction();
    try {
        foreach ($found as $program) {
            $upd->execute(array($departmentId, (int)$program['id']));
            ascb_log_activity($pdo, $ascbUser, 'PROGRAM_DEPARTMENT_ASSIGN', 'program', $program['code'] . ' → ' . $department['code']);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }

    echo json_encode(array('ok' => true, 'assigned_count' => count($found), 'department' => $department));
    exit;
}

if ($action === 'add') {
    $code = strtoupper(trim(ascb_get($input, 'code', '')));
    $courseName = trim(ascb_get($input, 'courseName', ''));
    $major = trim(ascb_get($input, 'major', ''));
    $termType = ascb_get($input, 'termType', 'Trimester') === 'Semester' ? 'Semester' : 'Trimester';
    $departmentId = (int)ascb_get($input, 'departmentId', 0);

    /* (2024 audit fix) DEAN accounts only see/manage their own Department's
       Programs & Subjects now — huwag payagang mag-set ng ibang departmentId
       sa request kahit galing pa sa disabled dropdown sa UI. */
    if (ascb_get($ascbUser, 'role', '') === 'DEAN') {
        $departmentId = ascb_require_dean_department($pdo, $ascbUser);
    }

    if ($code === '' || $courseName === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Course Code and Course Name are required.'));
        exit;
    }

    if (in_array($code, $ascbReservedProgramCodes, true)) {
        echo json_encode(array('ok' => false, 'error' => 'This code is already used by an existing program in the system.'));
        exit;
    }

    // Prevent the same Course + Major from being registered twice under
    // different program codes. This is the source of duplicate Course
    // entries in Enrollment after adding/managing subjects.
    $dup = $pdo->prepare("SELECT id, code FROM programs
        WHERE LOWER(TRIM(course_name)) = LOWER(TRIM(?))
          AND LOWER(TRIM(COALESCE(major, ''))) = LOWER(TRIM(COALESCE(?, '')))
          AND is_active = 1 LIMIT 1");
    $dup->execute(array($courseName, $major));
    if ($dupRow = $dup->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'This Course / Major already exists in the system (Code: ' . $dupRow['code'] . '). Add the subject to the existing Course instead of creating another Course.'));
        exit;
    }

    $check = $pdo->prepare("SELECT id FROM programs WHERE code = ?");
    $check->execute(array($code));
    if ($check->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'A program already uses this code.'));
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO programs (department_id, code, course_name, major, term_type) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute(array($departmentId ?: null, $code, $courseName, $major !== '' ? $major : null, $termType));
    $id = $pdo->lastInsertId();

    ascb_log_activity($pdo, $ascbUser, 'PROGRAM_ADD', 'program', $code . ' — ' . $courseName);

    echo json_encode(array('ok' => true, 'program' => array(
        'id' => $id, 'department_id' => $departmentId ?: null, 'code' => $code, 'course_name' => $courseName,
        'major' => $major !== '' ? $major : null, 'term_type' => $termType,
        'is_active' => 1, 'subject_count' => 0,
    )));
    exit;
}

if ($action === 'update') {
    $id = (int) ascb_get($input, 'id', 0);
    $code = strtoupper(trim(ascb_get($input, 'code', '')));
    $courseName = trim(ascb_get($input, 'courseName', ''));
    $major = trim(ascb_get($input, 'major', ''));
    $termType = ascb_get($input, 'termType', 'Trimester') === 'Semester' ? 'Semester' : 'Trimester';
    $departmentId = (int)ascb_get($input, 'departmentId', 0);
    $isActive = ascb_get($input, 'isActive', 1) ? 1 : 0;

    if (!$id || $code === '' || $courseName === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Course Code and Course Name are required.'));
        exit;
    }

    /* (2024 audit fix) Same as 'add' — DEAN can only edit a Program that's
       already in their own Department, and can't move it to another one. */
    if (ascb_get($ascbUser, 'role', '') === 'DEAN') {
        $deptId = ascb_require_dean_department($pdo, $ascbUser);
        $own = $pdo->prepare("SELECT id FROM programs WHERE id = ? AND department_id = ?");
        $own->execute(array($id, $deptId));
        if (!$own->fetch()) {
            http_response_code(403);
            echo json_encode(array('ok' => false, 'error' => 'You cannot edit this program.'));
            exit;
        }
        $departmentId = $deptId;
    }

    $check = $pdo->prepare("SELECT id FROM programs WHERE code = ? AND id <> ?");
    $check->execute(array($code, $id));
    if ($check->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'A program already uses this code.'));
        exit;
    }

    // Also prevent an edit from creating a second active record with the
    // same Course + Major under another code.
    $dup = $pdo->prepare("SELECT id, code FROM programs
        WHERE id <> ?
          AND LOWER(TRIM(course_name)) = LOWER(TRIM(?))
          AND LOWER(TRIM(COALESCE(major, ''))) = LOWER(TRIM(COALESCE(?, '')))
          AND is_active = 1 LIMIT 1");
    $dup->execute(array($id, $courseName, $major));
    if ($dupRow = $dup->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'This Course / Major already exists in the system (Code: ' . $dupRow['code'] . '). Edit the existing Course instead of creating a duplicate.'));
        exit;
    }

    $stmt = $pdo->prepare("UPDATE programs SET department_id = ?, code = ?, course_name = ?, major = ?, term_type = ?, is_active = ? WHERE id = ?");
    $stmt->execute(array($departmentId ?: null, $code, $courseName, $major !== '' ? $major : null, $termType, $isActive, $id));

    ascb_log_activity($pdo, $ascbUser, 'PROGRAM_UPDATE', 'program', $code . ' — ' . $courseName);

    echo json_encode(array('ok' => true));
    exit;
}

if ($action === 'delete') {

    if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'delete_lookups')) {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'You do not have access to delete a program.'));
        exit;
    }

    $id = (int) ascb_get($input, 'id', 0);
    if (!$id) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Missing program id.'));
        exit;
    }

    $find = $pdo->prepare("SELECT code, course_name, is_protected FROM programs WHERE id = ?");
    $find->execute(array($id));
    $row = $find->fetch();
    if (!$row) { http_response_code(404); echo json_encode(array('ok'=>false,'error'=>'Program not found.')); exit; }
    if (!empty($row['is_protected'])) { http_response_code(409); echo json_encode(array('ok'=>false,'error'=>'Protected/system programs cannot be deleted.')); exit; }

    $stmt = $pdo->prepare("DELETE FROM programs WHERE id = ?");
    $stmt->execute(array($id));

    ascb_log_activity($pdo, $ascbUser, 'PROGRAM_DELETE', 'program', $row ? ($row['code'] . ' — ' . $row['course_name']) : ('#' . $id));

    echo json_encode(array('ok' => true));
    exit;
}

if ($action === 'list_subjects') {
    $programId = (int) ascb_get($input, 'programId', 0);
    if (!$programId) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Missing program id.'));
        exit;
    }

    if (ascb_get($ascbUser, 'role', '') === 'DEAN') {
        $deptId = ascb_require_dean_department($pdo, $ascbUser);
        $own = $pdo->prepare("SELECT id FROM programs WHERE id = ? AND department_id = ?");
        $own->execute(array($programId, $deptId));
        if (!$own->fetch()) {
            http_response_code(403);
            echo json_encode(array('ok' => false, 'error' => 'You cannot view this program.'));
            exit;
        }
    }

    $stmt = $pdo->prepare("SELECT id, program_id, year_level, term_label, subject_code, description, units, sort_order FROM program_subjects WHERE program_id = ?");
    $stmt->execute(array($programId));
    $rows = $stmt->fetchAll();

    usort($rows, function ($a, $b) use ($ascbYearLevelRank, $ascbTermRank) {
        return ascb_subject_sort($a, $b, $ascbYearLevelRank, $ascbTermRank);
    });

    echo json_encode(array('ok' => true, 'subjects' => $rows));
    exit;
}

if ($action === 'add_subject') {
    $programId = (int) ascb_get($input, 'programId', 0);
    $yearLevel = trim(ascb_get($input, 'yearLevel', ''));
    $termLabel = trim(ascb_get($input, 'termLabel', ''));
    $subjectCode = trim(ascb_get($input, 'subjectCode', ''));
    $description = trim(ascb_get($input, 'description', ''));
    $units = (float) ascb_get($input, 'units', 0);

    if (!$programId || $yearLevel === '' || $termLabel === '' || $subjectCode === '' || $description === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Please complete Year Level, Term, Subject Code, and Description.'));
        exit;
    }

    if (ascb_get($ascbUser, 'role', '') === 'DEAN') {
        $deptId = ascb_require_dean_department($pdo, $ascbUser);
        $own = $pdo->prepare("SELECT id FROM programs WHERE id = ? AND department_id = ?");
        $own->execute(array($programId, $deptId));
        if (!$own->fetch()) {
            http_response_code(403);
            echo json_encode(array('ok' => false, 'error' => 'You cannot add a subject to this program.'));
            exit;
        }
    }

    $countStmt = $pdo->prepare("SELECT COUNT(*) AS c FROM program_subjects WHERE program_id = ? AND year_level = ? AND term_label = ?");
    $countStmt->execute(array($programId, $yearLevel, $termLabel));
    $sortOrder = (int) $countStmt->fetch()['c'];

    $stmt = $pdo->prepare("INSERT INTO program_subjects (program_id, year_level, term_label, subject_code, description, units, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute(array($programId, $yearLevel, $termLabel, $subjectCode, $description, $units, $sortOrder));

    ascb_log_activity($pdo, $ascbUser, 'PROGRAM_SUBJECT_ADD', 'program_subject', $subjectCode . ' — ' . $description);

    echo json_encode(array('ok' => true, 'subject' => array(
        'id' => $pdo->lastInsertId(), 'program_id' => $programId, 'year_level' => $yearLevel,
        'term_label' => $termLabel, 'subject_code' => $subjectCode, 'description' => $description,
        'units' => $units, 'sort_order' => $sortOrder,
    )));
    exit;
}

if ($action === 'update_subject') {
    $id = (int) ascb_get($input, 'id', 0);
    $yearLevel = trim(ascb_get($input, 'yearLevel', ''));
    $termLabel = trim(ascb_get($input, 'termLabel', ''));
    $subjectCode = trim(ascb_get($input, 'subjectCode', ''));
    $description = trim(ascb_get($input, 'description', ''));
    $units = (float) ascb_get($input, 'units', 0);

    if (!$id || $yearLevel === '' || $termLabel === '' || $subjectCode === '' || $description === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Please complete Year Level, Term, Subject Code, and Description.'));
        exit;
    }

    if (ascb_get($ascbUser, 'role', '') === 'DEAN') {
        $deptId = ascb_require_dean_department($pdo, $ascbUser);
        $own = $pdo->prepare("SELECT ps.id FROM program_subjects ps JOIN programs p ON p.id = ps.program_id WHERE ps.id = ? AND p.department_id = ?");
        $own->execute(array($id, $deptId));
        if (!$own->fetch()) {
            http_response_code(403);
            echo json_encode(array('ok' => false, 'error' => 'You cannot edit this subject.'));
            exit;
        }
    }

    $stmt = $pdo->prepare("UPDATE program_subjects SET year_level = ?, term_label = ?, subject_code = ?, description = ?, units = ? WHERE id = ?");
    $stmt->execute(array($yearLevel, $termLabel, $subjectCode, $description, $units, $id));

    ascb_log_activity($pdo, $ascbUser, 'PROGRAM_SUBJECT_UPDATE', 'program_subject', $subjectCode . ' — ' . $description);

    echo json_encode(array('ok' => true));
    exit;
}

if ($action === 'delete_subject') {

    if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'delete_lookups')) {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'You do not have access to delete a subject.'));
        exit;
    }

    $id = (int) ascb_get($input, 'id', 0);
    if (!$id) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Missing subject id.'));
        exit;
    }

    $find = $pdo->prepare("SELECT subject_code, description FROM program_subjects WHERE id = ?");
    $find->execute(array($id));
    $row = $find->fetch();

    $stmt = $pdo->prepare("DELETE FROM program_subjects WHERE id = ?");
    $stmt->execute(array($id));

    ascb_log_activity($pdo, $ascbUser, 'PROGRAM_SUBJECT_DELETE', 'program_subject', $row ? ($row['subject_code'] . ' — ' . $row['description']) : ('#' . $id));

    echo json_encode(array('ok' => true));
    exit;
}

if ($action === 'structured') {
    echo json_encode(array('ok' => true) + ascb_build_structured_programs($pdo));
    exit;
}

http_response_code(400);
echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
