<?php
/* =========================================================
   API: PROMOTIONAL REPORT EXPORT (tunay na .xlsx)
   ---------------------------------------------------------
   Ini-export ang student + grade records ng isang Program/Course
   (opsyonal: isang partikular na School Year + Term) gamit ang
   EKSAKTONG layout ng "Promotional Report" template:

     Row 1        : "Promotional Report"
     Row 2        : SCHOOL:          <pangalan ng paaralan>
     Row 3        : Program:         <pangalan ng kurso (+ major)>
     Row 4        : Academic Year:   <school year>
     Row 5        : Trimester: / Semester:  <term>  ("Semester:" kung
                     Semester-based ang Program, hal. MAED)
     Row 7        : header row — No | Student ID | Last Name |
                     First Name | Middle Name | Date of Birth | Gender |
                     Home Address | Year | Course Code | Course Description |
                     Grades | Units
     Row 8+       : isang estudyante = isa o higit pang row; ang mga
                     column na "No" hanggang "Year" (A-I) ay MERGED
                     patayo sa lahat ng subject row ng parehong
                     estudyante — eksaktong kagaya ng orihinal na
                     Promotional Report na na-eksport mula sa Excel.

   Ito ang PARENG format na ginagamit ng Bulk Import
   (api/grade_import.php) kapag "Promotional Report" ang na-detect
   na layout ng na-upload na .xlsx — kaya ang na-export dito ay
   pwedeng i-import ulit nang walang karagdagang pag-aayos. */

require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../includes/xlsx_writer.php';
require_once __DIR__ . '/../config/db.php';

$role = ascb_get($ascbUser, 'role', '');
if (!ascb_can($role, 'export_department')) {
    http_response_code(403); exit('Forbidden');
}

$csrfToken = ascb_get($_GET, 'csrf', '');
if (!ascb_verify_csrf($csrfToken)) {
    http_response_code(403);
    exit('Expired o invalid ang request token. I-refresh ang page at subukan muli.');
}

$departmentId = (int) ascb_get($_GET, 'department_id', 0);
$programId = (int) ascb_get($_GET, 'program_id', 0);
$sy = trim((string) ascb_get($_GET, 'school_year', ''));
$term = trim((string) ascb_get($_GET, 'term', ''));
if ($role === 'DEAN') $departmentId = ascb_require_dean_department($pdo, $ascbUser);
if (!$departmentId) { http_response_code(400); exit('Department required'); }
if (!$programId) { http_response_code(400); exit('Kailangan pumili ng isang Program/Course — isang Program bawat Promotional Report.'); }

$pc = $pdo->prepare('SELECT id, code, course_name, major, term_type FROM programs WHERE id=? AND department_id=?');
$pc->execute(array($programId, $departmentId));
$prog = $pc->fetch();
if (!$prog) { http_response_code(400); exit('Invalid Course for the selected Department'); }

$programLabel = trim($prog['course_name'] . ($prog['major'] ? ' major in ' . $prog['major'] : ''));

/* (fix Semester) Semester-based ang Program (hal. MAED) -> "Semester:" ang
   label at Semester ang term na isusulat; Trimester-based -> "Trimester:".
   Kapag Trimester ang napili sa Term filter pero Semester-based ang Program,
   ginagawa itong katumbas na Semester (1st/2nd) para tama ang label/filter. */
$isSemesterProgram = (isset($prog['term_type']) && $prog['term_type'] === 'Semester');
$termWord = $isSemesterProgram ? 'Semester' : 'Trimester';
$termFilterValues = array();
if ($term !== '' && $isSemesterProgram && preg_match('/^(\d+)\s*(?:st|nd|rd|th)?\s*(?:trimester|semester)?$/i', $term, $tm)) {
    $n = (int) $tm[1];
    if ($n >= 1 && $n <= 2) {
        $sfx = ($n === 1) ? 'st' : 'nd';
        $term = $n . $sfx . ' Semester';
        /* Kasama ang lumang record na nai-save bilang "Nth Trimester" (dating
           bug sa import) para hindi mawala sa export. */
        $termFilterValues = array($n . $sfx . ' Semester', $n . $sfx . ' Trimester');
    }
}

/* ---------- 1. kunin ang mga tugmang enrollee + subjects/grades ---------- */

$where = array(
    'e.archived_at IS NULL',
    "e.status <> 'rejected'",
    '(e.department_id=? OR (e.department_id IS NULL AND p.department_id=?))',
    '(UPPER(TRIM(e.program_code))=UPPER(TRIM(?)) OR (e.program_code IS NULL AND p.id=?))',
);
$params = array($departmentId, $departmentId, $prog['code'], $programId);
if ($sy !== '') { $where[] = 'e.school_year=?'; $params[] = $sy; }
if ($term !== '') {
    if (count($termFilterValues) > 1) {
        $where[] = 'e.trimester IN (' . implode(',', array_fill(0, count($termFilterValues), '?')) . ')';
        foreach ($termFilterValues as $tv) $params[] = $tv;
    } else {
        $where[] = 'e.trimester=?'; $params[] = $term;
    }
}
$whereSql = implode(' AND ', $where);

$sql = "SELECT e.id AS enrollment_id, e.student_id, e.surname, e.first_name, e.middle_name" . ascb_suffix_sql_cols($pdo) . ",
               e.birth_date, e.sex, e.address, e.year_level, e.subjects_json
        FROM enrollees e
        LEFT JOIN programs p ON UPPER(TRIM(p.code))=UPPER(TRIM(e.program_code))
        WHERE $whereSql
        ORDER BY e.surname ASC, e.first_name ASC, e.id ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$enrollees = array_map('ascb_row_print_split', $stmt->fetchAll(PDO::FETCH_ASSOC)); /* PSA placement ng suffix */
$stmt->closeCursor();

$byEnrollment = array();
if ($enrollees) {
    $ids = array_column($enrollees, 'enrollment_id');
    $in = implode(',', array_fill(0, count($ids), '?'));
    $es = $pdo->prepare("SELECT es.enrollment_id, es.course_code, es.description, es.units, g.grade
                         FROM enrollment_subjects es
                         LEFT JOIN grades g ON g.enrollment_subject_id=es.id
                         WHERE es.enrollment_id IN ($in)
                         ORDER BY es.enrollment_id, es.id");
    $es->execute($ids);
    while ($r = $es->fetch(PDO::FETCH_ASSOC)) {
        $byEnrollment[$r['enrollment_id']][] = $r;
    }
    $es->closeCursor();
}

// Huwag isama sa Promotional Report Excel ang Comprehensive Exam subject.
function ascb_pr_is_comprehensive_exam($code, $description) {
    $text = trim((string)$code . ' ' . (string)$description);
    return (bool) preg_match('/\bcomprehensive\s*exam\b/i', $text);
}

function ascb_pr_format_birthdate($rawDate) {
    if (!$rawDate) return '';
    $d = DateTime::createFromFormat('Y-m-d', $rawDate);
    if (!$d || $d->format('Y-m-d') !== $rawDate) return $rawDate;
    return $d->format('F j, Y'); // hal. "July 5, 2007" — kagaya ng orihinal na template
}

/* Export-only grade formatting. Numeric grades stay numeric so Excel can calculate;
   whole-number grades display with one decimal. CHED text grades stay unchanged. */
function ascb_pr_export_grade($rawGrade) {
    if ($rawGrade === null) return '';
    $grade = trim((string)$rawGrade);
    if ($grade === '' || !is_numeric($grade)) return $grade;
    return (float)$grade;
}

/* ---------- 2. buuin ang mga row ng worksheet (kasama ang mga merge) ---------- */

$rows = array();
$merges = array();

$rows[] = array(array('v' => 'Promotional Report'));
$rows[] = array(array('v' => 'SCHOOL:'), array('v' => 'Andres Soriano Colleges of Bislig'));
$rows[] = array(array('v' => 'Program:'), array('v' => $programLabel));
$rows[] = array(array('v' => 'Academic Year:'), array('v' => $sy !== '' ? ('AY ' . $sy) : 'All School Years'));
$rows[] = array(array('v' => $termWord . ':'), array('v' => $term !== '' ? $term : 'All Terms'));
$rows[] = array(); // blangkong row bago ang header, kagaya ng orihinal
$rows[] = array(
    array('v' => 'No', 'style' => 1), array('v' => 'Student ID', 'style' => 1), array('v' => 'Last Name', 'style' => 1),
    array('v' => 'First Name', 'style' => 1), array('v' => 'Middle Name', 'style' => 1), array('v' => 'Date of Birth', 'style' => 1),
    array('v' => 'Gender', 'style' => 1), array('v' => 'Home Address', 'style' => 1), array('v' => 'Year', 'style' => 1),
    array('v' => 'Course Code', 'style' => 1), array('v' => 'Course Description', 'style' => 1), array('v' => 'Grades', 'style' => 1),
    array('v' => 'Units', 'style' => 1),
);

$no = 0;
$totalSubjectRows = 0;
foreach ($enrollees as $e) {
    $subjects = isset($byEnrollment[$e['enrollment_id']]) ? $byEnrollment[$e['enrollment_id']] : array();
    if (!$subjects && !empty($e['subjects_json'])) {
        $legacy = json_decode($e['subjects_json'], true);
        if (is_array($legacy)) {
            foreach ($legacy as $lsub) {
                $subjects[] = array(
                    'course_code' => ascb_get($lsub, 'code', ''),
                    'description' => ascb_get($lsub, 'description', ''),
                    'grade' => ascb_clean_numeric_string(ascb_get($lsub, 'grade', '')),
                    'units' => ascb_clean_numeric_string(ascb_get($lsub, 'units', '')),
                );
            }
        }
    }
    $subjects = array_values(array_filter($subjects, function ($sub) {
        return !ascb_pr_is_comprehensive_exam(
            isset($sub['course_code']) ? $sub['course_code'] : '',
            isset($sub['description']) ? $sub['description'] : ''
        );
    }));

    if (!$subjects) $subjects = array(array('course_code' => '', 'description' => '', 'grade' => '', 'units' => ''));

    $no++;
    $startRow = count($rows); // 0-indexed row kung saan magsisimula ang block na ito

    foreach ($subjects as $i => $sub) {
        $bodyStyle = 2;
        if ($i === 0) {
            $rows[] = array(
                array('v' => $no, 'style' => $bodyStyle),
                array('v' => (string) $e['student_id'], 'style' => 5, 'type' => 's'),
                array('v' => $e['surname'], 'style' => $bodyStyle),
                array('v' => $e['first_name'], 'style' => $bodyStyle),
                array('v' => $e['middle_name'], 'style' => $bodyStyle),
                array('v' => ascb_pr_format_birthdate($e['birth_date']), 'style' => $bodyStyle),
                array('v' => $e['sex'], 'style' => $bodyStyle),
                array('v' => $e['address'], 'style' => $bodyStyle),
                array('v' => $e['year_level'], 'style' => $bodyStyle),
                array('v' => $sub['course_code'], 'style' => 2),
                array('v' => $sub['description'], 'style' => 2),
                array('v' => ascb_pr_export_grade($sub['grade']), 'style' => 4, 'type' => (is_numeric(trim((string)$sub['grade'])) ? 'n' : 's')),
                array('v' => ascb_clean_numeric_string($sub['units']), 'style' => 3),
            );
        } else {
            $rows[] = array(
                array('v' => '', 'style' => $bodyStyle), array('v' => '', 'style' => $bodyStyle), array('v' => '', 'style' => $bodyStyle),
                array('v' => '', 'style' => $bodyStyle), array('v' => '', 'style' => $bodyStyle), array('v' => '', 'style' => $bodyStyle),
                array('v' => '', 'style' => $bodyStyle), array('v' => '', 'style' => $bodyStyle), array('v' => '', 'style' => $bodyStyle),
                array('v' => $sub['course_code'], 'style' => 2),
                array('v' => $sub['description'], 'style' => 2),
                array('v' => ascb_pr_export_grade($sub['grade']), 'style' => 4, 'type' => (is_numeric(trim((string)$sub['grade'])) ? 'n' : 's')),
                array('v' => ascb_clean_numeric_string($sub['units']), 'style' => 3),
            );
        }
        $totalSubjectRows++;
    }

    $endRow = count($rows) - 1; // 0-indexed huling row ng block na ito
    if ($endRow > $startRow) {
        // I-merge ang mga info column (A-I) patayo mula sa unang subject row
        // hanggang sa huling subject row ng estudyanteng ito.
        foreach (range(0, 8) as $colIdx) {
            $letter = ascb_xlsx_col_letter($colIdx);
            $merges[] = $letter . ($startRow + 1) . ':' . $letter . ($endRow + 1);
        }
    }
}

if (!$enrollees) {
    $rows[] = array(array('v' => 'Walang nahanap na student record para sa napiling Program/filters.'));
}

$colWidths = array('A' => 6, 'B' => 16, 'C' => 16, 'D' => 16, 'E' => 16, 'F' => 16, 'G' => 10, 'H' => 30, 'I' => 10, 'J' => 18, 'K' => 45, 'L' => 9, 'M' => 8);

try {
    $bytes = ascb_xlsx_build('Student Grades', $rows, $merges, $colWidths);
} catch (Throwable $e) {
    http_response_code(500);
    exit(ASCB_DEBUG ? $e->getMessage() : 'Hindi nagawa ang Promotional Report .xlsx.');
}

$safeProgram = preg_replace('/[^A-Za-z0-9_-]+/', '_', $prog['code']);
$safeSy = $sy !== '' ? preg_replace('/[^A-Za-z0-9]+/', '_', $sy) : 'AllYears';
$safeTerm = $term !== '' ? preg_replace('/\s+/', '_', $term) : 'AllTerms';
$filename = 'Promotional_Report_' . $safeProgram . '_' . $safeSy . '_' . $safeTerm . '_' . date('Ymd') . '.xlsx';

/* api_guard/auth_check ay maaaring naka-set na ng Content-Type: application/json —
   i-override dito dahil totoong .xlsx file ang ipapadala. */
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($bytes));
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
echo $bytes;

try {
    $b = $pdo->prepare("INSERT INTO backup_history(backup_type,department_id,school_year,term_label,filename,created_by_user_id) VALUES('PROMO_REPORT_EXCEL',?,?,?,?,?)");
    $b->execute(array($departmentId, $sy ?: null, $term ?: null, $filename, (int) ascb_get($ascbUser, 'id', 0)));
    ascb_log_activity($pdo, $ascbUser, 'PROMO_REPORT_EXPORT', 'program', $prog['code'], $filename . ' (' . $no . ' estudyante, ' . $totalSubjectRows . ' subject row)');
} catch (Exception $e) {
    error_log('ASCB promotional report export log failed: ' . $e->getMessage());
}
exit;
