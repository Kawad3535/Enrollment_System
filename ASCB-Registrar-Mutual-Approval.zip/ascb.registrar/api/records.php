<?php
/* =========================================================
   API: RECORDS
   Ibinabalik ang listahan ng mga naka-log na Certificates o
   Form 137-A requests (pinaka-bago muna), para sa Records
   view sa dashboard.php.

   GET params:
     type   = "certificates" (default) | "form137"
     q      = optional search text (student / OR # / school)
     limit  = optional, default 500, max 1000
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/student_search.php';
require_once __DIR__ . '/../config/db.php';

/* (2024 audit fix) Dati, WALANG role check dito — kahit sinong naka-login
   (kasama ang DEAN) ay nakikita ang BUONG log ng certificates/Form 137
   requests ng LAHAT ng estudyante sa buong paaralan, hindi lang ng sariling
   Department nila — hindi ito tugma sa "sariling Department lang" na
   prinsipyo na sinusunod na ng Enrollment/Grades/Department Export.

   Ang `certificates`/`form137_requests` tables ay walang department_id
   (o maaasahang paraan para malaman kung aling Department ang may-ari ng
   isang record — `program`/`course` ay malayang text lang na na-type sa
   oras ng paggawa ng certificate/request, hindi guaranteed na tumutugma
   sa isang Program/Department row). Sa halip na gumawa ng hindi maaasahang
   JOIN na baka magkamali (magpakita o magtago ng maling records), ang
   pinakaligtas na ayos ay: DEAN lang ang wala nang access sa buong
   Records log na ito (tulad ng ginagawa na rin sa ibang write-actions).
   Kung kailangan talaga ng DEAN ang view na ito, dagdagan muna ng
   department_id column ang dalawang table sa itaas bago ibalik ang
   access nila dito. */
if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'view_records_log')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'You do not have access to this Records log.'));
    exit;
}

$type  = ascb_get($_GET, 'type', 'certificates');
$q     = trim(ascb_get($_GET, 'q', ''));
$limit = (int) ascb_get($_GET, 'limit', 500);
if ($limit <= 0 || $limit > 1000) {
    $limit = 500;
}

if ($type === 'form137') {

    $sql = "SELECT f.*, u.display_name AS requested_by_name
            FROM form137_requests f
            LEFT JOIN users u ON u.id = f.requested_by_user_id";
    $params = array();

    if ($q !== '') {
        $sql .= " WHERE f.school_name LIKE ? OR f.students_json LIKE ?";
        $like = '%' . $q . '%';
        $params[] = $like;
        $params[] = $like;
    }

    $sql .= " ORDER BY f.created_at DESC LIMIT " . $limit;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    foreach ($rows as &$row) {
        $decodedStudents = json_decode($row['students_json'], true);
        $row['students'] = is_array($decodedStudents) ? $decodedStudents : array();
        unset($row['students_json']);
    }
    unset($row);

} else {

    $type = 'certificates';

    require_once __DIR__ . '/../includes/certificate_verify_helper.php';
    ascb_cert_verify_ensure_schema($pdo); // may verify_token column bago mag-SELECT

    $sql = "SELECT c.*, u.display_name AS issued_by_name
            FROM certificates c
            LEFT JOIN users u ON u.id = c.issued_by_user_id";
    $params = array();

    if ($q !== '') {
        /* Full name (kahit anong ayos) o Student ID o OR number */
        $sc = ascb_text_search_clause($q, array('c.student_name', 'c.student_id', 'c.or_number'));
        if ($sc['sql'] !== '') {
            $sql .= " WHERE " . $sc['sql'];
            $params = $sc['params'];
        }
    }

    $sql .= " ORDER BY c.created_at DESC LIMIT " . $limit;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    foreach ($rows as &$row) {
        $decodedSubjects = json_decode($row['subjects_json'], true);
        $row['subjects'] = is_array($decodedSubjects) ? $decodedSubjects : array();
        unset($row['subjects_json']);

        /* QR verification info para sa reprint. Ang mga lumang record na
           wala pang token ay binibigyan dito (isang beses lang). */
        $row['verify'] = null;
        if (in_array($row['certificate_type'], ascb_cert_verify_types(), true)) {
            $row['verify'] = ascb_cert_verify_info_from_row($row);
            if ($row['verify'] === null) {
                $row['verify'] = ascb_cert_verify_info($pdo, (int) $row['id']);
            }
        }
        unset($row['verify_token']);
    }
    unset($row);
}

echo json_encode(array('ok' => true, 'type' => $type, 'rows' => $rows), JSON_UNESCAPED_UNICODE);
