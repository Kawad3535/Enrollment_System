<?php
/* =========================================================
   API: REGISTRAR ANALYTICS
   Read-only operational dashboard metrics.
   Uses the same school-year/trimester/Dean scope as Dashboard Stats.
   ========================================================= */
require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../config/db.php';

$trimester = trim((string)ascb_get($_GET, 'trimester', ''));
$schoolYear = trim((string)ascb_get($_GET, 'school_year', ''));
$departmentId = ascb_get($ascbUser, 'role', '') === 'DEAN' ? ascb_require_dean_department($pdo, $ascbUser) : null;

/* Build the same scope filter for any table alias. (Dati: str_replace('e.', 'e2.', ...)
   — marupok dahil pinapalitan nito ang kahit anong "e." sa loob ng SQL text.) */
function analytics_scope_filter($alias, $trimester, $schoolYear, $departmentId) {
    $sql = " WHERE {$alias}.archived_at IS NULL AND {$alias}.status != 'rejected'";
    $p = [];
    if ($trimester !== '') { $sql .= " AND {$alias}.trimester = ?"; $p[] = $trimester; }
    if ($schoolYear !== '') { $sql .= " AND {$alias}.school_year = ?"; $p[] = $schoolYear; }
    if ($departmentId) {
        /* COLLATE: programs may have been created by schema_upgrade.php without an explicit
           collation (server default, e.g. utf8mb4_0900_ai_ci) while enrollees is
           utf8mb4_unicode_ci -> "Illegal mix of collations" for DEAN accounts. */
        $sql .= " AND ({$alias}.department_id = ? OR ({$alias}.department_id IS NULL AND EXISTS (
            SELECT 1 FROM programs dp WHERE UPPER(TRIM(dp.code)) COLLATE utf8mb4_unicode_ci = UPPER(TRIM({$alias}.program_code)) COLLATE utf8mb4_unicode_ci AND dp.department_id = ?
        )))";
        $p[] = (int)$departmentId; $p[] = (int)$departmentId;
    }
    return [$sql, $p];
}
list($filters2, $params2) = analytics_scope_filter('e2', $trimester, $schoolYear, $departmentId);
list($filters3, $params3) = analytics_scope_filter('e3', $trimester, $schoolYear, $departmentId);
$latest = "SELECT MAX(e2.id) AS id FROM enrollees e2" . $filters2 . " AND e2.student_id IS NOT NULL AND TRIM(e2.student_id) <> '' GROUP BY e2.student_id
UNION ALL SELECT e3.id AS id FROM enrollees e3" . $filters3 . " AND (e3.student_id IS NULL OR TRIM(e3.student_id) = '')";

function analytics_query($pdo, $sql, $params = []) { $s=$pdo->prepare($sql); $s->execute($params); return $s; }

$base = "FROM enrollees e INNER JOIN ($latest) l ON l.id=e.id";
$latestParams = array_merge($params2, $params3);

$summary = analytics_query($pdo, "SELECT COUNT(*) total, SUM(CASE WHEN e.sex='Male' THEN 1 ELSE 0 END) male, SUM(CASE WHEN e.sex='Female' THEN 1 ELSE 0 END) female,
    SUM(CASE WHEN e.student_type='Regular' THEN 1 ELSE 0 END) regular_students,
    SUM(CASE WHEN e.student_type='Transferee' THEN 1 ELSE 0 END) transferees,
    SUM(CASE WHEN e.student_type='Irregular' THEN 1 ELSE 0 END) irregular_students $base", $latestParams)->fetch();

$courseRows = analytics_query($pdo, "SELECT lbl AS course, COUNT(*) total FROM (SELECT COALESCE(NULLIF(TRIM(e.program_code),''), NULLIF(TRIM(e.course),''), 'Unspecified') AS lbl $base) x GROUP BY lbl ORDER BY total DESC, lbl ASC LIMIT 12", $latestParams)->fetchAll();
$yearRows = analytics_query($pdo, "SELECT lbl AS year_level, COUNT(*) total FROM (SELECT COALESCE(NULLIF(TRIM(e.year_level),''),'Unspecified') AS lbl $base) x GROUP BY lbl ORDER BY total DESC, lbl ASC", $latestParams)->fetchAll();

// Operational queues: these are record counts, not unique students.
function scoped_record_count($pdo, $statusMode, $trimester, $schoolYear, $departmentId) {
    if ($statusMode === 'pending') $where = " WHERE e.status='pending' AND e.archived_at IS NULL";
    elseif ($statusMode === 'rejected') $where = " WHERE e.status='rejected' AND e.archived_at IS NULL";
    else $where = " WHERE e.archived_at IS NOT NULL";
    $p=[];
    if ($trimester !== '') { $where .= ' AND e.trimester = ?'; $p[]=$trimester; }
    if ($schoolYear !== '') { $where .= ' AND e.school_year = ?'; $p[]=$schoolYear; }
    if ($departmentId) { $where .= " AND (e.department_id=? OR (e.department_id IS NULL AND EXISTS (SELECT 1 FROM programs dp WHERE UPPER(TRIM(dp.code)) COLLATE utf8mb4_unicode_ci=UPPER(TRIM(e.program_code)) COLLATE utf8mb4_unicode_ci AND dp.department_id=?)))"; $p[]=(int)$departmentId; $p[]=(int)$departmentId; }
    return (int)analytics_query($pdo, "SELECT COUNT(*) c FROM enrollees e".$where, $p)->fetch()['c'];
}
$pending = scoped_record_count($pdo,'pending',$trimester,$schoolYear,$departmentId);
$rejected = scoped_record_count($pdo,'rejected',$trimester,$schoolYear,$departmentId);
$archived = scoped_record_count($pdo,'archived',$trimester,$schoolYear,$departmentId);

function table_count($pdo, $table, $trimester, $schoolYear) {
    $allowed=['record_corrections','document_transactions','certificates','approved_so'];
    if (!in_array($table,$allowed,true)) return 0;
    $where=' WHERE 1=1'; $p=[];
    if ($trimester !== '' && in_array($table,['record_corrections'],true)) { $where .= ' AND 1=1'; }
    if ($schoolYear !== '' && $table === 'record_corrections') { $where .= ' AND YEAR(requested_at) >= ?'; $p[]=(int)substr($schoolYear,0,4); }
    // These service modules are optional across older installations. If a table
    // has not been installed yet, report zero for that panel instead of failing
    // the entire Registrar Analytics endpoint.
    try {
        return (int)analytics_query($pdo,"SELECT COUNT(*) c FROM `$table`".$where,$p)->fetch()['c'];
    } catch (Throwable $e) {
        error_log('Registrar analytics optional table '.$table.' unavailable: '.$e->getMessage());
        return 0;
    }
}
$correctionPending = 0;
try { $p=[]; $w=" WHERE status='PENDING'"; if($schoolYear!==''){ $w.=' AND YEAR(requested_at) >= ?'; $p[]=(int)substr($schoolYear,0,4); } $correctionPending=(int)analytics_query($pdo,"SELECT COUNT(*) c FROM record_corrections".$w,$p)->fetch()['c']; } catch(Throwable $e) {}
$documents = table_count($pdo,'document_transactions',$trimester,$schoolYear);
$certificates = table_count($pdo,'certificates',$trimester,$schoolYear);
$approvedSO = table_count($pdo,'approved_so',$trimester,$schoolYear);

$activityRows=[];
try { $activityRows=analytics_query($pdo,"SELECT action, COUNT(*) total FROM activity_log WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY action ORDER BY total DESC LIMIT 8")->fetchAll(); } catch(Throwable $e) {}

$dailyRows=[];
try {
    $dailyRows=analytics_query($pdo,"SELECT DATE(e.created_at) day, COUNT(*) total FROM enrollees e WHERE e.created_at >= DATE_SUB(CURDATE(), INTERVAL 29 DAY) AND e.archived_at IS NULL AND e.status!='rejected' GROUP BY DATE(e.created_at) ORDER BY day ASC")->fetchAll();
} catch(Throwable $e) {}

$avgPerCourse = count($courseRows) ? round((int)$summary['total'] / count($courseRows),1) : 0;
$summary = array_map(function($v){ return (int)$v; }, [
    'total'=>$summary['total'] ?? 0, 'male'=>$summary['male'] ?? 0, 'female'=>$summary['female'] ?? 0,
    'regular_students'=>$summary['regular_students'] ?? 0, 'transferees'=>$summary['transferees'] ?? 0, 'irregular_students'=>$summary['irregular_students'] ?? 0
]);

echo json_encode(['ok'=>true,'summary'=>$summary,'queues'=>['pending'=>$pending,'rejected'=>$rejected,'archived'=>$archived,'correctionPending'=>$correctionPending],
    'services'=>['documents'=>$documents,'certificates'=>$certificates,'approvedSO'=>$approvedSO],
    'byCourse'=>$courseRows,'byYearLevel'=>$yearRows,'activity30'=>$activityRows,'daily30'=>$dailyRows,'averagePerCourse'=>$avgPerCourse], JSON_UNESCAPED_UNICODE);
