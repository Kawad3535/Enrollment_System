<?php
/* =========================================================
   API: SCHOOLS
   POST body (JSON): { "action": "add", "name": "...", "address": "..." }
                   or { "action": "delete", "name": "..." }
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../config/db.php';

$input = ascb_read_json_body();
$action = ascb_get($input, 'action', '');

// Only UNIT HEAD and ADMIN STAFF may manage Schools & Courses.
// Keep the read-only "list" action available for existing system dropdowns.
if (in_array($action, array('add', 'delete'), true) && !ascb_can(ascb_get($ascbUser, 'role', ''), 'manage_lookups')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'Only UNIT HEAD and ADMIN STAFF can manage Schools & Courses.'));
    exit;
}

if ($action === 'add') {
    $name    = trim(ascb_get($input, 'name', ''));
    $address = trim(ascb_get($input, 'address', ''));

    if ($name === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Enter the school name.'));
        exit;
    }

    $check = $pdo->prepare("SELECT id FROM schools WHERE LOWER(name) = LOWER(?)");
    $check->execute(array($name));
    if ($check->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'This school is already saved.'));
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO schools (name, address) VALUES (?, ?)");
    try {
        $stmt->execute(array($name, $address));
    } catch (PDOException $e) {
        // Tingnan ang parehong komento sa api/courses.php — proteksyon
        // laban sa race condition sa pagitan ng pre-check SELECT at ng
        // totoong INSERT, gamit ang UNIQUE constraint ng database.
        if ($e->getCode() === '23000') {
            echo json_encode(array('ok' => false, 'error' => 'This school is already saved.'));
            exit;
        }
        throw $e;
    }

    ascb_log_activity($pdo, $ascbUser, 'SCHOOL_ADD', 'school', $name);

    echo json_encode(array(
        'ok'     => true,
        'school' => array('id' => $pdo->lastInsertId(), 'name' => $name, 'address' => $address),
    ));
    exit;
}

if ($action === 'delete') {

    /* Sensitibo ito (permanenteng pagbura ng dropdown option na
       posibleng ginagamit na sa mga naka-log nang records) — kaya
       limitado lang sa UNIT HEAD / SCHOOL REGISTRAR. Ang pag-ADD
       sa itaas ay bukas pa rin sa lahat, tulad ng dati. */
    if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'manage_lookups')) {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'You do not have access to delete a school.'));
        exit;
    }

    $name = trim(ascb_get($input, 'name', ''));

    if ($name === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Missing school name.'));
        exit;
    }

    $stmt = $pdo->prepare("DELETE FROM schools WHERE name = ?");
    $stmt->execute(array($name));

    ascb_log_activity($pdo, $ascbUser, 'SCHOOL_DELETE', 'school', $name);

    echo json_encode(array('ok' => true));
    exit;
}

if ($action === 'list') {
    $rows = $pdo->query("SELECT id, name, address FROM schools ORDER BY name")->fetchAll();
    echo json_encode(array('ok' => true, 'schools' => $rows));
    exit;
}

http_response_code(400);
echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
