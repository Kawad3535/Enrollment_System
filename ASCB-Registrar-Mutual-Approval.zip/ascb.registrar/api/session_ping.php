<?php
/* =========================================================
   API: SESSION PING (keep-alive ng Student Portal)
   ---------------------------------------------------------
   Walang data na ibinabalik at walang binabago. Ang pagtawag lang
   dito ay nagre-refresh ng 'last activity' ng session (ginagawa ng
   ascb_start_session), para hindi ma-timeout ang STUDENT habang
   aktibo siya sa page. 401 kapag expired na ang session.
   ========================================================= */
define('ASCB_ALLOW_STUDENT', true);
require_once __DIR__ . '/../includes/api_guard.php';
echo json_encode(array('ok' => true));
