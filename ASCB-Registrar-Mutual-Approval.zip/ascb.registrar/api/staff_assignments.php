<?php
/* Flexible department/program assignments for ADMIN STAFF and DEAN accounts. */
require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json; charset=utf-8');
if (!ascb_can((string)($ascbUser['role'] ?? ''), 'manage_users')) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'Only authorized user managers may change staff assignments.']); exit; }
$input = ascb_read_json_body();
$action = (string)ascb_get($input,'action','list');
function asa_tables(PDO $pdo): bool {
  foreach (['user_department_assignments','user_program_assignments'] as $t) {
    $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?"); $q->execute([$t]); if (!(int)$q->fetchColumn()) return false;
  } return true;
}
if (!asa_tables($pdo)) { http_response_code(503); echo json_encode(['ok'=>false,'error'=>'Staff assignment tables are not installed. Run php database/migrate_master.php first.']); exit; }
try {
 if ($action==='list') {
  $users=$pdo->query("SELECT id,display_name,username,role,is_active FROM users WHERE role IN ('ADMIN STAFF','DEAN') ORDER BY FIELD(role,'DEAN','ADMIN STAFF'), display_name")->fetchAll(PDO::FETCH_ASSOC);
  $depts=$pdo->query("SELECT id,code,name FROM departments WHERE COALESCE(is_active,1)=1 ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
  $programs=$pdo->query("SELECT id,department_id,code,course_name,major FROM programs WHERE COALESCE(is_active,1)=1 ORDER BY course_name,major")->fetchAll(PDO::FETCH_ASSOC);
  $assign=$pdo->query("SELECT a.id,a.user_id,a.department_id,a.all_programs,a.is_active,d.name department_name FROM user_department_assignments a JOIN departments d ON d.id=a.department_id WHERE a.is_active=1")->fetchAll(PDO::FETCH_ASSOC);
  $pa=$pdo->query("SELECT p.user_department_assignment_id,p.program_id FROM user_program_assignments p JOIN user_department_assignments a ON a.id=p.user_department_assignment_id WHERE a.is_active=1")->fetchAll(PDO::FETCH_ASSOC);
  echo json_encode(['ok'=>true,'users'=>$users,'departments'=>$depts,'programs'=>$programs,'assignments'=>$assign,'programAssignments'=>$pa],JSON_UNESCAPED_UNICODE); exit;
 }
 if ($action==='save') {
  $uid=(int)ascb_get($input,'userId',0); $items=ascb_get($input,'assignments',[]);
  if($uid<1 || !is_array($items)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid staff or assignment payload.']); exit; }
  $q=$pdo->prepare("SELECT id,role FROM users WHERE id=? AND role IN ('ADMIN STAFF','DEAN')");$q->execute([$uid]);if(!$q->fetch()){http_response_code(404);echo json_encode(['ok'=>false,'error'=>'Admin Staff / Dean account not found.']);exit;}
  $clean=[]; foreach($items as $it){$did=(int)($it['departmentId']??0);if($did<1)continue;$all=!empty($it['allPrograms']);$pids=array_values(array_unique(array_filter(array_map('intval',(array)($it['programIds']??[])),fn($v)=>$v>0)));if(!$all&&!count($pids)){http_response_code(400);echo json_encode(['ok'=>false,'error'=>'Choose at least one program or explicitly enable all programs for each assigned department.']);exit;}$dq=$pdo->prepare('SELECT id FROM departments WHERE id=?');$dq->execute([$did]);if(!$dq->fetchColumn()){http_response_code(400);echo json_encode(['ok'=>false,'error'=>'Invalid department selected.']);exit;}if($pids){$ph=implode(',',array_fill(0,count($pids),'?'));$pq=$pdo->prepare("SELECT id FROM programs WHERE department_id=? AND id IN ($ph)");$pq->execute(array_merge([$did],$pids));if(count($pq->fetchAll(PDO::FETCH_COLUMN))!==count($pids)){http_response_code(400);echo json_encode(['ok'=>false,'error'=>'A selected program does not belong to its selected department.']);exit;}}$clean[$did]=['all'=>$all,'programs'=>$pids];}
  $pdo->beginTransaction();
  $old=$pdo->prepare('SELECT id FROM user_department_assignments WHERE user_id=?');$old->execute([$uid]);$oldIds=$old->fetchAll(PDO::FETCH_COLUMN);if($oldIds){$ph=implode(',',array_fill(0,count($oldIds),'?'));$pdo->prepare("DELETE FROM user_program_assignments WHERE user_department_assignment_id IN ($ph)")->execute($oldIds);}
  $pdo->prepare('UPDATE user_department_assignments SET is_active=0,updated_at=NOW() WHERE user_id=?')->execute([$uid]);
  foreach($clean as $did=>$item){$find=$pdo->prepare('SELECT id FROM user_department_assignments WHERE user_id=? AND department_id=?');$find->execute([$uid,$did]);$aid=$find->fetchColumn();if($aid){$pdo->prepare('UPDATE user_department_assignments SET all_programs=?,is_active=1,assigned_by=?,updated_at=NOW() WHERE id=?')->execute([$item['all']?1:0,(int)$ascbUser['id'],$aid]);}else{$pdo->prepare('INSERT INTO user_department_assignments(user_id,department_id,all_programs,is_active,assigned_by,assigned_at,updated_at) VALUES(?,?,?,1,?,NOW(),NOW())')->execute([$uid,$did,$item['all']?1:0,(int)$ascbUser['id']]);$aid=$pdo->lastInsertId();}foreach($item['programs'] as $pid){$pdo->prepare('INSERT INTO user_program_assignments(user_department_assignment_id,program_id,created_at) VALUES(?,?,NOW())')->execute([$aid,$pid]);}}
  if(function_exists('ascb_log_activity')){} $pdo->commit(); echo json_encode(['ok'=>true,'message'=>'Staff assignments saved.']);exit;
 }
 http_response_code(400);echo json_encode(['ok'=>false,'error'=>'Unknown action.']);
} catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
