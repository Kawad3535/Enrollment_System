<?php
/* =========================================================
   API: STUDENT 360
   ---------------------------------------------------------
   Read-only, single-page view ng LAHAT ng tungkol sa isang
   estudyante — hindi ito gumagawa ng bagong table o bagong
   write-action, kinukuha lang nito ang datos na nasa ibang
   modules na (Enrollment, Grade Evaluation, Certificates/
   Records, Activity Log) at pinagsasama sa isang response.

   GET params:
     action=search  : q (required, min 2 chars) — humahanap sa
                       surname/first name/middle name/student ID,
                       ibinabalik ang PINAKA-BAGONG record per
                       estudyante (max 30).
     action=profile : studentId (required) — buong 360 view ng
                       ISANG estudyante (lahat ng term niya).

   PERMISSIONS:
     - Student Information / Enrollment History / Grade
       Evaluation: bukas sa lahat ng naka-login na role, dahil
       nakikita na rin nila ito nang hiwalay sa Enrollment at
       Grade Evaluation menus.
     - Certificates section: kailangan ng 'view_records_log'
       permission (parehong tulad ng Records menu — hindi
       kasama ang DEAN doon).
     - Audit Timeline section: kailangan ng 'view_activity_log'
       permission (parehong tulad ng History/Activity Log sa
       Admin panel — UNIT HEAD / SCHOOL REGISTRAR lang).
     Kung wala ang isang permission, hindi lang itinatago sa UI
     ang seksyong iyon — HINDI rin ito ipinapasok/kina-query sa
     response (tunay na security boundary, hindi UI convenience
     lang).

     DEAN: read-only at sariling Department lang, gaya ng ibang
     modules — kinukumpirma munang kabilang sa Department nila
     ang estudyanteng hinahanap (base sa department_id snapshot
     ng kanilang mga enrollment record) bago ipakita kahit ano.
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../includes/master_record_helper.php';
require_once __DIR__ . '/../includes/student_search.php';
require_once __DIR__ . '/../config/db.php';

$action = ascb_get($_GET, 'action', 'search');
$role = ascb_get($ascbUser, 'role', '');

/* ----------------------------------------- helpers */

if (!function_exists('ascb_s360_full_name')) {
    function ascb_s360_full_name($row) {
        $row = ascb_row_master_suffix($row); /* (fix) CURRENT suffix mula sa Master Record */
        return ascb_name_print($row['surname'], $row['first_name'], ascb_get($row, 'middle_name', ''),
            ascb_get($row, 'suffix', ''), ascb_get($row, 'suffix_position', 'separate'));
    }
}

/* Parehong formula gaya ng includes/honors_helper.php: weighted
   average (grade x units) — numeric grades lang ang isinasama
   (hindi INC/DRP/blangko). Sinadyang hiwalay na maliit na copy
   dito (hindi require ang honors_helper.php) dahil display-only
   ito sa Student 360 — walang honors classification/cutoff na
   kailangan, GWA lang bawat term ang ipinapakita. */
if (!function_exists('ascb_s360_term_gwa')) {
    function ascb_s360_term_gwa($subjects) {
        $weightedSum = 0.0;
        $gradedUnits = 0.0;
        foreach ($subjects as $s) {
            $g = trim((string) $s['grade']);
            if ($g === '' || !is_numeric($g)) continue;
            $weightedSum += (float) $g * (float) $s['units'];
            $gradedUnits += (float) $s['units'];
        }
        if ($gradedUnits <= 0) return null;
        return round($weightedSum / $gradedUnits, 2);
    }
}

/* ----------------------------------------- action=search */

if ($action === 'search') {
    $q = trim(ascb_get($_GET, 'q', ''));
    if (function_exists('mb_strlen')) {
        $qTooShort = mb_strlen($q, 'UTF-8') < 2;
    } else {
        $qTooShort = strlen($q) < 2;
    }
    if ($qTooShort) {
        echo json_encode(array('ok' => true, 'rows' => array()));
        exit;
    }

    /* Full name o Student ID (includes/student_search.php) */
    $masterOn = ascb_master_available($pdo);
    $sc = ascb_student_search_clause($q, 'e', $masterOn);
    if ($sc['sql'] === '') {
        echo json_encode(array('ok' => true, 'rows' => array()));
        exit;
    }

    $sql = "SELECT e.*, d.name AS department_name
            FROM enrollees e
            INNER JOIN (
                SELECT student_id, MAX(id) AS max_id
                FROM enrollees
                WHERE student_id IS NOT NULL AND student_id <> ''
                GROUP BY student_id
            ) latest ON latest.max_id = e.id
            LEFT JOIN departments d ON d.id = e.department_id
            WHERE " . $sc['sql'];
    $params = $sc['params'];

    if ($role === 'DEAN') {
        $deptId = ascb_require_dean_department($pdo, $ascbUser);
        $sql .= " AND e.department_id = ?";
        $params[] = $deptId;
    }

    $sql .= " ORDER BY e.surname, e.first_name LIMIT 30";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    /* MASTER RECORD: show the CURRENT name (old enrollment rows are never edited). */
    $currentNames = array();
    if ($masterOn && $rows) {
        $ids = array();
        foreach ($rows as $r) { $ids[] = (string) $r['student_id']; }
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $ms = $pdo->prepare("SELECT * FROM student_master WHERE student_id IN ($ph)");
        $ms->execute($ids);
        foreach ($ms->fetchAll() as $m) {
            $currentNames[$m['student_id']] = ascb_master_format_name($m['surname'], $m['first_name'], $m['middle_name'], $m['suffix'], isset($m['suffix_position']) ? $m['suffix_position'] : 'separate');
        }
    }

    $out = array();
    foreach ($rows as $r) {
        $out[] = array(
            'studentId'      => $r['student_id'],
            'name'           => isset($currentNames[$r['student_id']]) ? $currentNames[$r['student_id']] : ascb_s360_full_name($r),
            'course'         => $r['course'],
            'major'          => $r['major'],
            'yearLevel'      => $r['year_level'],
            'trimester'      => $r['trimester'],
            'schoolYear'     => $r['school_year'],
            'departmentName' => $r['department_name'],
            'status'         => $r['status'],
        );
    }

    echo json_encode(array('ok' => true, 'rows' => $out), JSON_UNESCAPED_UNICODE);
    exit;
}

/* ----------------------------------------- action=profile */

if ($action === 'profile') {
    $studentId = trim(ascb_get($_GET, 'studentId', ''));
    if ($studentId === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'studentId is required.'));
        exit;
    }

    $stmt = $pdo->prepare(
        "SELECT e.*, u.display_name AS enrolled_by_name,
                a.display_name AS approved_by_name,
                ar.display_name AS archived_by_name,
                d.name AS department_name
         FROM enrollees e
         LEFT JOIN users u ON u.id = e.enrolled_by_user_id
         LEFT JOIN users a ON a.id = e.approved_by_user_id
         LEFT JOIN users ar ON ar.id = e.archived_by_user_id
         LEFT JOIN departments d ON d.id = e.department_id
         WHERE e.student_id = ?
         ORDER BY e.id DESC"
    );
    $stmt->execute(array($studentId));
    $terms = $stmt->fetchAll();

    if (!$terms) {
        http_response_code(404);
        echo json_encode(array('ok' => false, 'error' => 'No student found with this Student ID.'));
        exit;
    }

    if ($role === 'DEAN') {
        $deptId = ascb_require_dean_department($pdo, $ascbUser);
        $belongsToDept = false;
        foreach ($terms as $t) {
            if ((int) $t['department_id'] === (int) $deptId) { $belongsToDept = true; break; }
        }
        if (!$belongsToDept) {
            http_response_code(403);
            echo json_encode(array('ok' => false, 'error' => 'You do not have access to this student.'));
            exit;
        }
    }

    $latest = $terms[0];

    $profile = array(
        'studentId'          => $latest['student_id'],
        'fullName'           => ascb_s360_full_name($latest),
        'surname'            => $latest['surname'],
        'firstName'          => $latest['first_name'],
        'middleName'         => $latest['middle_name'],
        'sex'                => $latest['sex'],
        'civilStatus'        => $latest['civil_status'],
        'studentType'        => $latest['student_type'],
        'birthDate'          => $latest['birth_date'],
        'birthPlace'         => $latest['birth_place'],
        'address'            => $latest['address'],
        'mobileNumber'       => $latest['mobile_number'],
        'guardianName'       => $latest['guardian_name'],
        'email'              => $latest['email'],
        'prevSchoolJuniorHs' => $latest['prev_school_junior_hs'],
        'prevSchoolSeniorHs' => $latest['prev_school_senior_hs'],
        'juniorHsGraduated'  => $latest['junior_hs_graduated'],
        'seniorHsGraduated'  => $latest['senior_hs_graduated'],
        'currentProgramCode' => $latest['program_code'],
        'currentCourse'      => $latest['course'],
        'currentMajor'       => $latest['major'],
        'currentYearLevel'   => $latest['year_level'],
        'currentTrimester'   => $latest['trimester'],
        'currentSchoolYear'  => $latest['school_year'],
        'currentStatus'      => $latest['status'],
        'departmentName'     => $latest['department_name'],
    );

    /* MASTER RECORD: the profile shows the CURRENT personal information.
       Enrollment History / Grade Evaluation / Certificates below are still
       the untouched historical rows. */
    $masterNow = ascb_master_current($pdo, $studentId);
    if ($masterNow) {
        $profile['fullName']     = ascb_master_format_name($masterNow['surname'], $masterNow['first_name'], $masterNow['middle_name'], $masterNow['suffix'], isset($masterNow['suffix_position']) ? $masterNow['suffix_position'] : 'separate');
        $profile['surname']      = $masterNow['surname'];
        $profile['firstName']    = $masterNow['first_name'];
        $profile['middleName']   = $masterNow['middle_name'];
        $profile['sex']          = $masterNow['sex'];
        $profile['civilStatus']  = $masterNow['civil_status'];
        $profile['birthDate']    = $masterNow['birth_date'];
        $profile['birthPlace']   = $masterNow['birthplace'];
        $profile['address']      = $masterNow['address'];
        $profile['mobileNumber'] = $masterNow['mobile_number'];
        $profile['guardianName'] = $masterNow['guardian_name'];
        $profile['email']        = $masterNow['email'];
    }

    $enrollmentHistory = array();
    $gradeEvaluation = array();
    $enrollmentIds = array();

    foreach ($terms as $t) {
        $enrollmentIds[] = (int) $t['id'];
        $enrollmentHistory[] = array(
            'id'             => (int) $t['id'],
            'schoolYear'     => $t['school_year'],
            'trimester'      => $t['trimester'],
            'yearLevel'      => $t['year_level'],
            'course'         => $t['course'],
            'major'          => $t['major'],
            'programCode'    => $t['program_code'],
            'status'         => $t['status'],
            'archived'       => !empty($t['archived_at']),
            'archiveReason'  => $t['archive_reason'],
            'enrolledByName' => $t['enrolled_by_name'],
            'approvedByName' => $t['approved_by_name'],
            'approvalRemarks'=> $t['approval_remarks'],
            'createdAt'      => $t['created_at'],
        );
    }

    if ($enrollmentIds) {
        $placeholders = implode(',', array_fill(0, count($enrollmentIds), '?'));
        $stmt = $pdo->prepare(
            "SELECT es.id, es.enrollment_id, es.course_code, es.description, es.units, es.hidden_on_print, g.grade
             FROM enrollment_subjects es
             LEFT JOIN grades g ON g.enrollment_subject_id = es.id
             WHERE es.enrollment_id IN ($placeholders)
             ORDER BY es.enrollment_id, es.id"
        );
        $stmt->execute($enrollmentIds);
        $subjectRows = $stmt->fetchAll();

        $byEnrollment = array();
        foreach ($subjectRows as $s) {
            $eid = (int) $s['enrollment_id'];
            if (!isset($byEnrollment[$eid])) $byEnrollment[$eid] = array();
            $byEnrollment[$eid][] = $s;
        }

        foreach ($terms as $t) {
            $eid = (int) $t['id'];
            $subjects = isset($byEnrollment[$eid]) ? $byEnrollment[$eid] : array();
            $subjectsOut = array();
            $totalUnits = 0.0;
            foreach ($subjects as $s) {
                $totalUnits += (float) $s['units'];
                $subjectsOut[] = array(
                    'code'         => $s['course_code'],
                    'description'  => $s['description'],
                    'units'        => $s['units'],
                    'grade'        => $s['grade'],
                    'hiddenOnPrint'=> !empty($s['hidden_on_print']),
                );
            }
            $gradeEvaluation[] = array(
                'enrollmentId' => $eid,
                'schoolYear'   => $t['school_year'],
                'trimester'    => $t['trimester'],
                'yearLevel'    => $t['year_level'],
                'subjects'     => $subjectsOut,
                'totalUnits'   => $totalUnits,
                'gwa'          => ascb_s360_term_gwa($subjects),
            );
        }
    }

    $canViewCertificates = ascb_can($role, 'view_records_log');
    $canViewAuditTimeline = ascb_can($role, 'view_activity_log');

    $certificates = null;
    if ($canViewCertificates) {
        $stmt = $pdo->prepare(
            "SELECT id, certificate_type, or_number, academic_year, trimester, year_level, gwa, total_units, created_at
             FROM certificates WHERE student_id = ? ORDER BY created_at DESC, id DESC LIMIT 100"
        );
        $stmt->execute(array($studentId));
        $certRows = $stmt->fetchAll();
        $certificates = array();
        foreach ($certRows as $c) {
            $certificates[] = array(
                'id'              => (int) $c['id'],
                'certificateType' => $c['certificate_type'],
                'orNumber'        => $c['or_number'],
                'academicYear'    => $c['academic_year'],
                'trimester'       => $c['trimester'],
                'yearLevel'       => $c['year_level'],
                'gwa'             => $c['gwa'],
                'totalUnits'      => $c['total_units'],
                'createdAt'       => $c['created_at'],
            );
        }
    }

    $auditTimeline = null;
    if ($canViewAuditTimeline) {
        /* Best-effort match: karamihan ng activity_log entries
           tungkol sa isang enrollee ay may "(STUDENT_ID)" sa
           entity_label (tingnan api/enrollment.php, api/grades.php,
           api/record_corrections.php) — pero ilang label (hal.
           ENROLLEE_UPDATE, ENROLLEE_DELETE) ay "Surname, Given
           Name" lang, walang student ID. Isinasama rin ito bilang
           fallback match sa pangalan, dahil walang direktang
           enrollment_id/student_id column ang activity_log table
           (generic log ito, ginagamit din ng Admin/Schools/Courses). */
        $stmt = $pdo->prepare(
            "SELECT id, action, entity_type, entity_label, details, display_name, role, created_at
             FROM activity_log
             WHERE entity_type IN ('enrollee','enrollment')
               AND (entity_label LIKE ? OR entity_label LIKE ?)
             ORDER BY created_at DESC, id DESC LIMIT 200"
        );
        $likeId = '%(' . $studentId . ')%';
        $likeName = $latest['surname'] . ', ' . $latest['first_name'] . '%';
        $stmt->execute(array($likeId, $likeName));
        $logRows = $stmt->fetchAll();
        $auditTimeline = array();
        foreach ($logRows as $l) {
            $auditTimeline[] = array(
                'id'          => (int) $l['id'],
                'action'      => $l['action'],
                'entityLabel' => $l['entity_label'],
                'details'     => $l['details'],
                'byName'      => $l['display_name'],
                'byRole'      => $l['role'],
                'createdAt'   => $l['created_at'],
            );
        }
    }

    echo json_encode(array(
        'ok'                => true,
        'profile'           => $profile,
        'enrollmentHistory' => $enrollmentHistory,
        'gradeEvaluation'   => $gradeEvaluation,
        'certificates'      => $certificates,
        'auditTimeline'     => $auditTimeline,
        'permissions'       => array(
            'canViewCertificates'  => $canViewCertificates,
            'canViewAuditTimeline' => $canViewAuditTimeline,
        ),
    ), JSON_UNESCAPED_UNICODE);
    exit;
}

http_response_code(400);
echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
