<?php
/* =========================================================
   API: STUDENT GRADES EXPORT (.xlsx) — Grade Evaluation
   ---------------------------------------------------------
   Ini-export ang buong grade record ng ISANG estudyante (lahat ng
   approved na term) bilang .xlsx na KATULAD ng LONG BOND (8.5 x 13 in)
   na "Print All" ng Grade Evaluation: student details, isang table kada term
   (Course Code | Course Description | Grades | Units). Walang header/
   letterhead, TOTAL UNITS, GWA, Overall, signature, o school seal sa Excel. Naka-set ang
   Excel page setup sa Folio 8.5 x 13 in, kasya sa lapad.
   Visibility: kapareho ng Grade Evaluation (DEAN / ADMIN STAFF = assigned
   Department lang, server-side). Mga rule ng screen/print ay sinusunod:
   INC/DRP/NG = 0 units, "-" grade = "-" units, "Hide on Print" = ★.
   ========================================================= */
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../includes/master_record_helper.php';
require_once __DIR__ . '/../includes/programs_helper.php';
require_once __DIR__ . '/../includes/xlsx_writer.php';
require_once __DIR__ . '/../config/db.php';

$role = strtoupper(trim((string) ascb_get($ascbUser, 'role', '')));

$csrfToken = ascb_get($_GET, 'csrf', '');
if (!ascb_verify_csrf($csrfToken)) {
    http_response_code(403);
    exit('Expired o invalid ang request token. I-refresh ang page at subukan muli.');
}

$studentId = trim((string) ascb_get($_GET, 'student_id', ''));
if ($studentId === '') { http_response_code(400); exit('Student ID is required.'); }

$sql = "SELECT e.id AS enrollment_id, e.student_id, e.surname, e.first_name, e.middle_name" . ascb_suffix_sql_cols($pdo) . ",
               e.course, e.major, e.program_code, e.year_level, e.trimester, e.school_year, e.created_at,
               es.id AS enrollment_subject_id, es.course_code, es.description, es.units, es.hidden_on_print,
               g.grade
        FROM enrollees e
        LEFT JOIN enrollment_subjects es ON es.enrollment_id = e.id
        LEFT JOIN grades g ON g.enrollment_subject_id = es.id
        WHERE e.archived_at IS NULL AND e.status = 'approved'
          AND UPPER(TRIM(e.student_id)) = UPPER(TRIM(?))";
$params = array($studentId);
if (in_array($role, array('DEAN', 'ADMIN STAFF'), true)) {
    $scope = ascb_role_assignment_scope_sql($pdo, $ascbUser, 'e');
    $sql .= $scope['sql'];
    $params = array_merge($params, $scope['params']);
}
$sql .= " ORDER BY e.created_at, e.id, es.id";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$data = array_map('ascb_row_print_split', $stmt->fetchAll(PDO::FETCH_ASSOC));

if (!$data) { http_response_code(404); exit('Walang nahanap na approved na record para sa estudyanteng ito (o wala sa assigned Department mo).'); }

/* Pangalan: CURRENT name mula sa Master Record kung meron (kapareho ng Grade Evaluation). */
$latest = $data[count($data) - 1];
$fullName = '';
$master = function_exists('ascb_master_current') ? ascb_master_current($pdo, $studentId) : null;
if ($master && !empty($master['surname'])) {
    $fullName = ascb_master_format_name(
        $master['surname'],
        isset($master['first_name']) ? $master['first_name'] : '',
        isset($master['middle_name']) ? $master['middle_name'] : '',
        isset($master['suffix']) ? $master['suffix'] : '',
        isset($master['suffix_position']) ? $master['suffix_position'] : 'separate'
    );
}
if ($fullName === '') {
    $fullName = trim($latest['surname'] . ', ' . trim($latest['first_name'] . ' ' . $latest['middle_name']));
}
$courseCode = trim((string) (($latest['program_code'] !== '' && $latest['program_code'] !== null) ? $latest['program_code'] : $latest['course']));
$major = trim((string) $latest['major']);

/* Buong pangalan ng Program (kapareho ng programNames sa screen/print). */
$programNames = array();
try {
    $pd = ascb_build_structured_programs($pdo);
    $programNames = is_array($pd['names']) ? $pd['names'] : (array) $pd['names'];
} catch (Throwable $e) { $programNames = array(); }

function sge_norm($v) { return preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $v)); }
/* PHP port ng ascbGradeEvalFormatCourseMajor() */
function sge_course_major($c, $m, $names) {
    $c = trim((string) $c); $m = trim((string) $m);
    if ($c !== '' && !empty($names[$c])) return $names[$c];
    if ($m === '') return $c !== '' ? $c : '—';
    if ($c === '') return $m;
    if (strpos(sge_norm($c), sge_norm($m)) !== false) return $c;
    $words = preg_split('/\s+/', $m, -1, PREG_SPLIT_NO_EMPTY);
    $acr = '';
    foreach ($words as $w) { $acr .= strtoupper(substr($w, 0, 1)); }
    $segs = preg_split('/[^A-Z0-9]+/', strtoupper($c), -1, PREG_SPLIT_NO_EMPTY);
    if (strlen($acr) > 1 && in_array($acr, $segs, true)) return $c;
    $first = $words ? sge_norm($words[0]) : '';
    if (strlen($first) >= 3) {
        foreach ($segs as $seg) {
            if ($seg === $first || (strlen($seg) >= 3 && (strpos($first, $seg) === 0 || strpos($seg, $first) === 0))) return $c;
        }
    }
    return $c . ' — ' . $m;
}
function sge_term_name($v) {
    $raw = trim((string) $v);
    if ($raw === '') return '';
    $parts = array_values(array_filter(array_map('trim', explode('|', $raw)), 'strlen'));
    if (count($parts) > 1 && strtolower($parts[count($parts) - 1]) === 'summer') return 'Summer';
    return $raw;
}
/* Kapareho ng ascbGradeFlagClass(): INC/NG = inc, DR/DRP/DROP = drop */
function sge_flag($grade) {
    $g = strtoupper(trim((string) $grade));
    if (in_array($g, array('INC', 'INCOMPLETE', 'NG'), true)) return 'inc';
    if (in_array($g, array('DR.', 'DR', 'DRP', 'DROP', 'DROPPED'), true)) return 'drop';
    return '';
}
/* Kapareho ng ascbGradeEvalUnitsForDisplay(): INC/DRP = 0 units (display lang). */
function sge_units_display($grade, $units) {
    return sge_flag($grade) !== '' ? 0.0 : (float) $units;
}

$programLabel = sge_course_major($courseCode, $major, $programNames);

/* I-group sa term (enrollment). */
$terms = array();
foreach ($data as $r) {
    $k = (int) $r['enrollment_id'];
    if (!isset($terms[$k])) $terms[$k] = array('meta' => $r, 'subjects' => array());
    if (!empty($r['enrollment_subject_id'])) $terms[$k]['subjects'][] = $r;
}
$distinct = array();
foreach ($terms as $t) {
    $code = strtoupper(trim((string) (($t['meta']['program_code'] !== '' && $t['meta']['program_code'] !== null) ? $t['meta']['program_code'] : $t['meta']['course'])));
    if ($code !== '') $distinct[$code] = true;
}
$courseChanged = count($distinct) > 1;

/* ---------- LAYOUT (4 column: A Code | B Description | C Grades | D Units) ---------- */
$S_TITLE = 6; $S_CENTER = 7; $S_BOLDL = 8; $S_PLAINL = 9; $S_BOLDC = 10; $S_TOTL = 11; $S_TOTV = 12; $S_RED = 13; $S_TERM = 14;
$rows = array(); $merges = array(); $heights = array();
$add = function ($cells, $height = null) use (&$rows, &$heights) {
    if ($height !== null) $heights[count($rows)] = $height;
    $rows[] = $cells;
    return count($rows); // 1-based row number
};
$blank4 = function () { return array(); };

/* Tinanggal na sa Excel: letterhead image, Office of the Registrar, email/phone, at GRADE EVALUATION title. */

$detail = function ($label, $value) use ($add, &$merges, $S_BOLDL, $S_PLAINL) {
    $r = $add(array(
        array('v' => $label, 'style' => $S_BOLDL),
        array('v' => ': ' . $value, 'style' => $S_PLAINL, 'type' => 's'),
        array('v' => '', 'style' => $S_PLAINL), array('v' => '', 'style' => $S_PLAINL),
    ), 18);
    $merges[] = 'B' . $r . ':D' . $r;
};
$detail('Student Name', $fullName);
$detail('Student ID', $studentId);
$detail('Course / Program', $programLabel);
$add(array(), 8);

$overallW = 0.0; $overallU = 0.0; $overallTotalUnits = 0.0; $subjectCount = 0;
foreach ($terms as $t) {
    $m = $t['meta'];
    $label = sge_term_name($m['trimester'] !== '' ? $m['trimester'] : '—') . ' AY ' . ($m['school_year'] !== '' ? $m['school_year'] : '—');
    $tc = trim((string) (($m['program_code'] !== '' && $m['program_code'] !== null) ? $m['program_code'] : $m['course']));
    if ($courseChanged && $tc !== '') $label .= ' (' . $tc . ')';
    if (trim((string) $m['year_level']) !== '') $label .= ' (' . trim((string) $m['year_level']) . ')';

    $r = $add(array(array('v' => $label, 'style' => $S_TERM)), 20);
    $merges[] = 'A' . $r . ':D' . $r;
    $add(array(
        array('v' => 'Course Code', 'style' => 1), array('v' => 'Course Description', 'style' => 1),
        array('v' => 'Grades', 'style' => 1), array('v' => 'Units', 'style' => 1),
    ), 20);

    $tw = 0.0; $tu = 0.0; $totalUnits = 0.0;
    if (!$t['subjects']) {
        $r = $add(array(
            array('v' => 'Walang subjects na naka-record para sa term na ito.', 'style' => 2),
            array('v' => '', 'style' => 2), array('v' => '', 'style' => 2), array('v' => '', 'style' => 2),
        ));
        $merges[] = 'A' . $r . ':D' . $r;
    }
    foreach ($t['subjects'] as $sj) {
        $grade = trim((string) $sj['grade']);
        $hidden = !empty($sj['hidden_on_print']) && (int) $sj['hidden_on_print'] === 1;
        $ud = sge_units_display($grade, $sj['units']);
        $totalUnits += $ud;
        if ($grade !== '' && is_numeric($grade) && (float) $sj['units'] > 0) {
            $tw += (float) $grade * (float) $sj['units']; $tu += (float) $sj['units'];
        }
        $subjectCount++;
        $gradeText = $hidden ? '★' : ($grade !== '' ? $grade : '—');
        $gradeStyle = (!$hidden && sge_flag($grade) !== '') ? $S_RED : 3;
        $unitsCell = ($grade === '-') ? array('v' => '-', 'style' => 3, 'type' => 's') : array('v' => $ud, 'style' => 3);
        $add(array(
            array('v' => (string) ($sj['course_code'] !== '' ? $sj['course_code'] : '—'), 'style' => 2, 'type' => 's'),
            array('v' => (string) ($sj['description'] !== '' ? $sj['description'] : '—'), 'style' => 2, 'type' => 's'),
            array('v' => $gradeText, 'style' => $gradeStyle, 'type' => 's'),
            $unitsCell,
        ), 18);
    }
    $gwa = $tu > 0 ? $tw / $tu : null;
    if ($gwa !== null) { $overallW += $tw; $overallU += $tu; }
    $overallTotalUnits += $totalUnits;

    /* Tinanggal na sa Excel: TOTAL UNITS at GWA row ng bawat term. */
    $add(array(), 10);
}

/* Tinanggal na sa Excel: Overall Total Units / Overall GWA. */

/* Lapad ng 4 na column (A Code | B Description | C Grades | D Units). */
$colWidths = array('A' => 18, 'B' => 52, 'C' => 12, 'D' => 10);
$opts = array(
    'rowHeights' => $heights,
    'pageSetup' => true,
    'paperSize' => 14,          // Folio 8.5 x 13 in (long bond)
    'hideGridlines' => true,
);

try {
    $bytes = ascb_xlsx_build('Grade Evaluation', $rows, $merges, $colWidths, $opts);
} catch (Throwable $e) {
    http_response_code(500);
    exit(ASCB_DEBUG ? $e->getMessage() : 'Hindi nagawa ang .xlsx file.');
}

$filename = 'Grade_Evaluation_' . preg_replace('/[^A-Za-z0-9_-]+/', '_', $studentId) . '_' . date('Ymd') . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($bytes));
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
echo $bytes;

try {
    ascb_log_activity($pdo, $ascbUser, 'STUDENT_GRADES_EXPORT', 'student', $studentId, $filename . ' (' . count($terms) . ' term, ' . $subjectCount . ' subject)');
} catch (Throwable $e) {
    error_log('ASCB student grades export log failed: ' . $e->getMessage());
}
exit;
