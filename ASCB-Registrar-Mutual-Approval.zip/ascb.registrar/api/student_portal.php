<?php
/* =========================================================
   API: STUDENT PORTAL  (READ-ONLY, SARILING RECORD LANG)
   ---------------------------------------------------------
   GET api/student_portal.php
     -> { ok, profile{studentId,name,program,major,yearLevel},
          overall{gwa,gradedUnits,totalUnits},
          academicYears[ { schoolYear, terms[ { trimester, yearLevel,
          program, totalUnits, gradedUnits, gwa, subjects[ { courseCode, description,
          units, grade, remarks, status } ] } ] } ] }

   SEGURIDAD:
   1. Naka-opt-in sa deny-by-default guard (ASCB_ALLOW_STUDENT).
   2. STUDENT role lang ang pinapayagan dito.
   3. GET lang. Walang write na posible (walang POST/PUT/DELETE).
   4. WALANG request parameter na binabasa. Ang Student ID ay galing
      lang sa users.student_id ng naka-login na account (DB-refreshed
      ng api_guard), kaya imposibleng makahingi ng record ng iba.
   5. Fail-closed: walang naka-link na Student ID = 403.
   ========================================================= */

define('ASCB_ALLOW_STUDENT', true);

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/student_portal_helper.php';
require_once __DIR__ . '/../config/db.php';

function ascb_student_api_fail($code, $message) {
    http_response_code($code);
    echo json_encode(array('ok' => false, 'error' => $message));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    ascb_student_api_fail(405, 'This endpoint is read-only.');
}

if (!ascb_is_student(ascb_get($ascbUser, 'role', ''))) {
    ascb_student_api_fail(403, 'This endpoint is for Student accounts only.');
}

$studentId = ascb_get($ascbUser, 'studentId', null);
if ($studentId === null || trim((string) $studentId) === '') {
    ascb_student_api_fail(403, 'Your account is not linked to a Student ID yet. Please contact the Registrar\'s Office.');
}

$profile = ascb_student_portal_profile($pdo, $studentId);
$records = ascb_student_portal_records($pdo, $studentId);

echo json_encode(
    array(
        'ok'            => true,
        'profile'       => $profile,
        'academicYears' => $records['academicYears'],
        'overall'       => $records['overall'], /* cumulative GWA */
        'hasHiddenSubjects' => $records['hasHiddenSubjects'],
    ),
    JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR
);
