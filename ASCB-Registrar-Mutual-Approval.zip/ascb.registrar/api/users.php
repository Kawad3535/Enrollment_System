<?php
/* =========================================================
   API: USERS (Admin panel — User Management)
   ---------------------------------------------------------
   POST body (JSON), "action" ang nagsasabi kung ano:

     action: "list"
       -> ibinabalik ang listahan ng lahat ng user accounts
          (walang password_hash). Kailangan: manage_users.

     action: "add"
       fields: displayName, role, username (required), preparedByCode (optional), password
               studentId (REQUIRED kapag role = STUDENT; dapat umiiral sa Master Record /
               Enrollment records at hindi pa naka-link sa ibang account)
       Kailangan: manage_users.

     action: "update"
       fields: id, displayName, role, username, preparedByCode, studentId (STUDENT lang),
       password (optional — kung binigyan, papalitan; kung
       iniwang blangko, hindi na gagalawin)
       Kailangan: manage_users.

     action: "toggle_active"
       fields: id
       Kailangan: manage_users. Hindi pwedeng i-deactivate ang
       sarili mong account, at hindi pwedeng i-deactivate ang
       huling natitirang aktibong UNIT HEAD (safety net para
       hindi ma-lock-out ang lahat sa Admin panel).

     action: "delete"
       fields: id
       Kailangan: manage_users. Hindi pwedeng i-delete ang
       sarili mong account.

     action: "change_password"  (BUKAS SA LAHAT — sariling
       account lang, hindi kailangan ng manage_users)
       fields: currentPassword, newPassword
   ========================================================= */

/* STUDENT role: pinapayagan LANG ang self-service na 'change_password' dito.
   Lahat ng ibang action ay dumadaan pa rin sa manage_users check sa ibaba,
   na wala sa STUDENT — kaya 403 sila roon. */
define('ASCB_ALLOW_STUDENT', true);
/* Pinapayagan ang api/users.php kahit may temporary password pa ang account —
   pero 'change_password' LANG ang tatanggapin sa ganoong account (tingnan sa ibaba). */
define('ASCB_ALLOW_PASSWORD_CHANGE', true);

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/student_portal_helper.php';
require_once __DIR__ . '/../includes/student_account_helper.php';
require_once __DIR__ . '/../config/db.php';

$input = ascb_read_json_body();
$action = ascb_get($input, 'action', '');

$myId   = (int) ascb_get($ascbUser, 'id', 0);
$myRole = ascb_get($ascbUser, 'role', '');

/* Habang may temporary password pa ang account, ang 'change_password' LANG ang pwede. */
if (!empty($ascbUser['mustChangePassword']) && $action !== 'change_password') {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'mustChangePassword' => true, 'error' => 'You must change your temporary password first.'));
    exit;
}

$VALID_ROLES = array('ADMIN STAFF', 'UNIT HEAD', 'SCHOOL REGISTRAR', 'DEAN', 'STUDENT');
$HAS_STUDENT_COL = ascb_column_exists($pdo, 'users', 'student_id');


/* STUDENT role: i-validate ang Student ID link. Ibinabalik ang canonical
   Student ID (o null kung hindi STUDENT). Lumalabas agad (JSON error) kapag
   may mali. */
function ascb_users_resolve_student_link($pdo, $role, $input, $excludeUserId, $hasCol) {
    if ($role !== 'STUDENT') return null;
    if (!$hasCol) {
        http_response_code(500);
        echo json_encode(array('ok' => false, 'error' => 'The Student role is not installed yet. Run the database migration first (php database/migrate_master.php).'));
        exit;
    }
    $raw = trim((string) ascb_get($input, 'studentId', ''));
    if ($raw === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Student ID is required for a STUDENT account.'));
        exit;
    }
    $canonical = ascb_student_canonical_id($pdo, $raw);
    if ($canonical === null) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Student ID not found in the Master Record / Enrollment records. Please check the Student ID.'));
        exit;
    }
    $takenBy = ascb_student_id_taken_by($pdo, $canonical, $excludeUserId);
    if ($takenBy !== null) {
        http_response_code(409);
        echo json_encode(array('ok' => false, 'error' => 'This Student ID is already linked to another account (' . $takenBy . '). One Student ID can only have one account.'));
        exit;
    }
    return $canonical;
}


/* ---------- self-service: bukas sa LAHAT, hindi kailangan ng manage_users ---------- */

if ($action === 'change_password') {

    $currentPassword = ascb_get($input, 'currentPassword', '');
    $newPassword     = ascb_get($input, 'newPassword', '');

    if ($currentPassword === '' || $newPassword === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Please fill in the current and new password.'));
        exit;
    }
    if (strlen($newPassword) < 8) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'The new password must be at least 8 characters.'));
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute(array($myId));
    $me = $stmt->fetch();

    $onTemp = $me && !empty($me['must_change_password']);

    $okCurrent = $me && password_verify($currentPassword, $me['password_hash']);
    if (!$okCurrent && $onTemp) {
        /* Temporary password: tanggap ang may dash / lowercase (gaya sa slip). */
        $okCurrent = password_verify(ascb_sa_normalize_temp_password($currentPassword), $me['password_hash']);
    }
    if (!$okCurrent) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => $onTemp ? 'The temporary password is incorrect.' : 'The current password is incorrect.'));
        exit;
    }

    /* Bago ay dapat IBA sa dati / sa temporary password. */
    if (password_verify($newPassword, $me['password_hash'])
        || ($onTemp && password_verify(ascb_sa_normalize_temp_password($newPassword), $me['password_hash']))) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'The new password must be different from the ' . ($onTemp ? 'temporary' : 'current') . ' password.'));
        exit;
    }
    /* Password strength para sa first-login (pinipili ng estudyante): letra + numero. */
    if ($onTemp && (!preg_match('/[A-Za-z]/', $newPassword) || !preg_match('/[0-9]/', $newPassword))) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'The new password needs at least one letter and one number.'));
        exit;
    }
    /* Huwag gawing password ang sariling username / Student ID. */
    if (strcasecmp(trim($newPassword), (string) $me['username']) === 0
        || (!empty($me['student_id']) && strcasecmp(trim($newPassword), (string) $me['student_id']) === 0)) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'The new password cannot be your username / Student ID.'));
        exit;
    }

    /* Palitan ang hash (secure hashing) AT patayin ang temporary-password
       state sa iisang UPDATE — kaya hindi na kailanman gagana ang temporary
       password pagkatapos nito (wala na ang lumang hash). */
    $sets   = "password_hash = ?";
    $params = array(password_hash($newPassword, PASSWORD_DEFAULT));
    if (ascb_column_exists($pdo, 'users', 'must_change_password')) {
        $sets .= ", must_change_password = 0";
    }
    if (ascb_column_exists($pdo, 'users', 'temp_password_expires_at')) {
        $sets .= ", temp_password_expires_at = NULL";
    }
    if (ascb_column_exists($pdo, 'users', 'password_changed_at')) {
        $sets .= ", password_changed_at = NOW()";
    }
    $params[] = $myId;
    $stmt = $pdo->prepare("UPDATE users SET " . $sets . " WHERE id = ?");
    $stmt->execute($params);

    /* Bagong session ID pagkatapos magpalit ng credentials, at alisin ang flag. */
    if (!empty($_SESSION['ascb_user'])) {
        $_SESSION['ascb_user']['mustChangePassword'] = false;
    }
    if (function_exists('session_regenerate_id')) session_regenerate_id(true);

    ascb_log_activity($pdo, $ascbUser, $onTemp ? 'PASSWORD_CHANGE_FIRST_LOGIN' : 'PASSWORD_CHANGE_SELF', 'user', $me['display_name']);

    echo json_encode(array('ok' => true));
    exit;
}


/* ---------- Registrar / Unit Head: mag-issue / mag-reset ng STUDENT temporary password ----------
   POST { action: 'issue_student_account', studentId }
   - Walang account pa  -> gagawa (username = Student ID).
   - May account na     -> bagong one-time temporary password (invalid na ang luma),
                           at kailangang magpalit ulit sa susunod na login.
   Hindi kailangan ng manage_users; 'issue_student_account' ang permission. */
if ($action === 'issue_student_account') {
    if (!ascb_can($myRole, 'issue_student_account')) {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'You do not have access to issue student accounts.'));
        exit;
    }
    $sidIn = ascb_get($input, 'studentId', '');
    $sid   = ascb_student_canonical_id($pdo, $sidIn);
    if ($sid === null) {
        http_response_code(404);
        echo json_encode(array('ok' => false, 'error' => 'Student ID not found in the Master Record / Enrollment records.'));
        exit;
    }
    $existing = ascb_sa_find_by_student($pdo, $sid);
    if ($existing) {
        $result = ascb_sa_reset_temp_password($pdo, (int) $existing['id'], $ascbUser);
    } else {
        $nm = ascb_sa_name_for_student($pdo, $sid);
        $result = ascb_sa_ensure_account($pdo, $sid, $nm ? $nm : array(), $ascbUser);
    }
    if (!in_array($result['status'], array('created'), true)) {
        http_response_code(409);
        echo json_encode(array('ok' => false, 'error' => isset($result['message']) ? $result['message'] : 'Unable to issue the student account.'));
        exit;
    }
    header('Cache-Control: no-store');
    echo json_encode(array('ok' => true, 'studentAccount' => ascb_sa_public_result($result)), JSON_UNESCAPED_UNICODE);
    exit;
}


/* ---------- lahat ng iba pa: kailangan ng manage_users ---------- */

if (!ascb_can($myRole, 'manage_users')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'You do not have access to User Management. UNIT HEAD only.'));
    exit;
}

if ($action === 'list') {
    $rows = $pdo->query(
        "SELECT u.id, u.username, u.display_name, u.role, u.prepared_by_code, u.department_id, " . ($HAS_STUDENT_COL ? "u.student_id, " : "NULL AS student_id, ") . "d.name AS department_name, u.is_active, u.created_at
         FROM users u LEFT JOIN departments d ON d.id=u.department_id ORDER BY display_name"
    )->fetchAll();
    echo json_encode(array('ok' => true, 'users' => $rows), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'add') {

    $displayName    = trim(ascb_get($input, 'displayName', ''));
    $role           = trim(ascb_get($input, 'role', ''));
    $username       = trim(ascb_get($input, 'username', ''));
    $preparedByCode = trim(ascb_get($input, 'preparedByCode', ''));
    $password       = ascb_get($input, 'password', '');
    $departmentId   = (int) ascb_get($input, 'departmentId', 0);

    if ($username === '' || $displayName === '' || $password === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Username, name, and password are required.'));
        exit;
    }
    if (!in_array($role, $VALID_ROLES, true)) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Invalid role.'));
        exit;
    }
    if (in_array($role, array('DEAN','ADMIN STAFF'), true) && $departmentId <= 0) { http_response_code(400); echo json_encode(array('ok'=>false,'error'=>'Please assign a Department to this DEAN / ADMIN STAFF account.')); exit; }
    $linkedStudentId = ascb_users_resolve_student_link($pdo, $role, $input, 0, $HAS_STUDENT_COL);
    if (strlen($password) < 8) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'The password must be at least 8 characters.'));
        exit;
    }

    $check = $pdo->prepare("SELECT id FROM users WHERE display_name = ?");
    $check->execute(array($displayName));
    if ($check->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'An account already exists with this name.'));
        exit;
    }

    $checkUser = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $checkUser->execute(array($username));
    if ($checkUser->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'This username is already in use. Please choose a different username.'));
        exit;
    }

    if ($HAS_STUDENT_COL) {
        $stmt = $pdo->prepare(
            "INSERT INTO users (username, password_hash, display_name, role, department_id, student_id, prepared_by_code, is_active)
             VALUES (?, ?, ?, ?, ?, ?, ?, 1)"
        );
        $insertParams = array(
            $username,
            password_hash($password, PASSWORD_DEFAULT),
            $displayName,
            $role,
            in_array($role, array('DEAN','ADMIN STAFF'), true) ? $departmentId : null,
            $linkedStudentId,
            $preparedByCode !== '' ? $preparedByCode : null,
        );
    } else {
        $stmt = $pdo->prepare(
            "INSERT INTO users (username, password_hash, display_name, role, department_id, prepared_by_code, is_active)
             VALUES (?, ?, ?, ?, ?, ?, 1)"
        );
        $insertParams = array(
            $username,
            password_hash($password, PASSWORD_DEFAULT),
            $displayName,
            $role,
            in_array($role, array('DEAN','ADMIN STAFF'), true) ? $departmentId : null,
            $preparedByCode !== '' ? $preparedByCode : null,
        );
    }
    try {
        $pdo->beginTransaction();
        $stmt->execute($insertParams);
        $newId = $pdo->lastInsertId();
        if ($role === 'STUDENT' && ascb_column_exists($pdo, 'users', 'must_change_password')) {
            $mc = $pdo->prepare("UPDATE users SET must_change_password = 1" . (ascb_column_exists($pdo, 'users', 'temp_password_expires_at') ? ", temp_password_expires_at = ?" : "") . " WHERE id = ?");
            $mc->execute(ascb_column_exists($pdo, 'users', 'temp_password_expires_at') ? array(ascb_sa_expiry(), $newId) : array($newId));
        }
        ascb_log_activity($pdo, $ascbUser, 'USER_ADD', 'user', $displayName, 'Role: ' . $role . ($linkedStudentId !== null ? ' / Student ID: ' . $linkedStudentId : ''));
        $pdo->commit();
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        /* DATABASE TRANSACTION HANDLING — kung dalawang request ang
           halos sabay-sabay na nag-"add" ng parehong username/display
           name (nakalusot sa pre-check SELECT sa itaas dahil hindi pa
           nakikita ng isa ang commit ng isa), ang UNIQUE constraint ng
           database (hindi ang pre-check lang) ang huling proteksyon.
           SQLSTATE 23000 = integrity constraint violation. */
        if ($e->getCode() === '23000') {
            http_response_code(409);
            echo json_encode(array('ok' => false, 'error' => 'An account already exists with this username, name, or Student ID. Please choose a different one.'));
            exit;
        }
        throw $e; // ibang klaseng DB error — hawakan ng global error handler
    }

    echo json_encode(array('ok' => true, 'id' => $newId));
    exit;
}

if ($action === 'update') {

    $id             = (int) ascb_get($input, 'id', 0);
    $displayName    = trim(ascb_get($input, 'displayName', ''));
    $role           = trim(ascb_get($input, 'role', ''));
    $username       = trim(ascb_get($input, 'username', ''));
    $preparedByCode = trim(ascb_get($input, 'preparedByCode', ''));
    $password       = ascb_get($input, 'password', '');
    $departmentId   = (int) ascb_get($input, 'departmentId', 0);

    if ($username === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Username is required.'));
        exit;
    }

    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute(array($id));
    $existing = $stmt->fetch();

    if (!$existing) {
        http_response_code(404);
        echo json_encode(array('ok' => false, 'error' => 'Account not found.'));
        exit;
    }

    if ($displayName === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Name is required.'));
        exit;
    }
    if (!in_array($role, $VALID_ROLES, true)) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Invalid role.'));
        exit;
    }
    if (in_array($role, array('DEAN','ADMIN STAFF'), true) && $departmentId <= 0) { http_response_code(400); echo json_encode(array('ok'=>false,'error'=>'Please assign a Department to this DEAN / ADMIN STAFF account.')); exit; }
    $linkedStudentId = ascb_users_resolve_student_link($pdo, $role, $input, $id, $HAS_STUDENT_COL);

    /* PERMANENT LINK: ang STUDENT account na naka-link na sa isang Student ID ay
       hindi na pwedeng palitan ng role / username / Student ID (username = Student ID).
       Pwede pa ring baguhin ang pangalan, at mag-reset ng password. */
    if ($existing['role'] === 'STUDENT' && trim((string) ascb_get($existing, 'student_id', '')) !== '') {
        if ($role !== 'STUDENT'
            || strcasecmp(trim($username), (string) $existing['username']) !== 0
            || strcasecmp((string) $linkedStudentId, trim((string) $existing['student_id'])) !== 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'A student account is permanently linked to its Student ID. The role, username and Student ID cannot be changed.'));
            exit;
        }
    }

    if ($existing['role'] === 'UNIT HEAD' && $role !== 'UNIT HEAD' && !empty($existing['is_active'])) {
        $countStmt = $pdo->prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'UNIT HEAD' AND is_active = 1 AND id <> ?");
        $countStmt->execute(array($id));
        if ((int) $countStmt->fetch()['c'] < 1) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'The role cannot be changed — this is the last active UNIT HEAD.'));
            exit;
        }
    }

    $check = $pdo->prepare("SELECT id FROM users WHERE display_name = ? AND id <> ?");
    $check->execute(array($displayName, $id));
    if ($check->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'Another account already uses this name.'));
        exit;
    }

    $checkUser = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id <> ?");
    $checkUser->execute(array($username, $id));
    if ($checkUser->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'Another account already uses this username.'));
        exit;
    }

    if ($password !== '') {
        if (strlen($password) < 8) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'The password must be at least 8 characters.'));
            exit;
        }
        $stmt = $pdo->prepare(
            "UPDATE users SET display_name = ?, role = ?, department_id = ?, username = ?, prepared_by_code = ?, password_hash = ?" . ($HAS_STUDENT_COL ? ", student_id = ?" : "") . " WHERE id = ?"
        );
        $execParams = array(
            $displayName, $role, in_array($role, array('DEAN','ADMIN STAFF'), true) ? $departmentId : null, $username,
            $preparedByCode !== '' ? $preparedByCode : null,
            password_hash($password, PASSWORD_DEFAULT),
        );
        if ($HAS_STUDENT_COL) $execParams[] = $linkedStudentId; // NULL kung hindi STUDENT
        $execParams[] = $id;
    } else {
        $stmt = $pdo->prepare(
            "UPDATE users SET display_name = ?, role = ?, department_id = ?, username = ?, prepared_by_code = ?" . ($HAS_STUDENT_COL ? ", student_id = ?" : "") . " WHERE id = ?"
        );
        $execParams = array(
            $displayName, $role, in_array($role, array('DEAN','ADMIN STAFF'), true) ? $departmentId : null, $username,
            $preparedByCode !== '' ? $preparedByCode : null,
        );
        if ($HAS_STUDENT_COL) $execParams[] = $linkedStudentId; // NULL kung hindi STUDENT
        $execParams[] = $id;
    }

    try {
        $pdo->beginTransaction();
        $stmt->execute($execParams);

        /* Password na itinakda ng Unit Head para sa STUDENT = temporary lang:
           kailangang palitan ng estudyante sa susunod na login. */
        if ($password !== '' && $role === 'STUDENT' && ascb_column_exists($pdo, 'users', 'must_change_password')) {
            $mc = $pdo->prepare("UPDATE users SET must_change_password = 1" . (ascb_column_exists($pdo, 'users', 'temp_password_expires_at') ? ", temp_password_expires_at = ?" : "") . " WHERE id = ?");
            $mc->execute(ascb_column_exists($pdo, 'users', 'temp_password_expires_at') ? array(ascb_sa_expiry(), $id) : array($id));
        }

        /* Kung nabago natin ang sariling account, i-refresh ang session
           data para tama agad ang makikita sa sidebar (walang kailangang
           mag-re-login). */
        if ($id === $myId) {
            $_SESSION['ascb_user']['displayName'] = $displayName;
            $_SESSION['ascb_user']['role']        = $role;
            $_SESSION['ascb_user']['preparedBy']  = $preparedByCode !== '' ? $preparedByCode : null;
        }

        ascb_log_activity($pdo, $ascbUser, 'USER_UPDATE', 'user', $displayName, 'Role: ' . $role . ($linkedStudentId !== null ? ' / Student ID: ' . $linkedStudentId : ''));
        $pdo->commit();
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        // Tingnan ang komento sa 'add' action sa itaas — parehong
        // proteksyon laban sa race condition sa pagitan ng pre-check
        // SELECT at ng totoong UPDATE.
        if ($e->getCode() === '23000') {
            http_response_code(409);
            echo json_encode(array('ok' => false, 'error' => 'Another account already uses this username, name, or Student ID.'));
            exit;
        }
        throw $e;
    }

    echo json_encode(array('ok' => true));
    exit;
}

if ($action === 'toggle_active') {

    $id = (int) ascb_get($input, 'id', 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
        exit;
    }

    if ($id === $myId) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'You cannot deactivate your own account.'));
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute(array($id));
    $existing = $stmt->fetch();

    if (!$existing) {
        http_response_code(404);
        echo json_encode(array('ok' => false, 'error' => 'Account not found.'));
        exit;
    }

    $newStatus = $existing['is_active'] ? 0 : 1;

    /* Safety net: kung ito ang huling natitirang AKTIBONG UNIT
       HEAD, huwag payagang i-deactivate — mawawalan ng access
       sa User Management ang lahat. */
    if ($newStatus === 0 && $existing['role'] === 'UNIT HEAD') {
        $countStmt = $pdo->prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'UNIT HEAD' AND is_active = 1 AND id <> ?");
        $countStmt->execute(array($id));
        $remaining = (int) $countStmt->fetch()['c'];
        if ($remaining < 1) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'This account cannot be deactivated — this is the last active UNIT HEAD.'));
            exit;
        }
    }

    $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
    $stmt->execute(array($newStatus, $id));

    ascb_log_activity(
        $pdo, $ascbUser,
        $newStatus ? 'USER_ACTIVATE' : 'USER_DEACTIVATE',
        'user', $existing['display_name']
    );

    echo json_encode(array('ok' => true, 'isActive' => (bool) $newStatus));
    exit;
}

if ($action === 'delete') {

    $id = (int) ascb_get($input, 'id', 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
        exit;
    }

    if ($id === $myId) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'You cannot delete your own account.'));
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute(array($id));
    $existing = $stmt->fetch();

    if (!$existing) {
        http_response_code(404);
        echo json_encode(array('ok' => false, 'error' => 'Account not found.'));
        exit;
    }

    if ($existing['role'] === 'UNIT HEAD') {
        $countStmt = $pdo->prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'UNIT HEAD' AND is_active = 1 AND id <> ?");
        $countStmt->execute(array($id));
        $remaining = (int) $countStmt->fetch()['c'];
        if ($remaining < 1) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'This account cannot be deleted — this is the last active UNIT HEAD.'));
            exit;
        }
    }

    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute(array($id));

    ascb_log_activity($pdo, $ascbUser, 'USER_DELETE', 'user', $existing['display_name']);

    echo json_encode(array('ok' => true));
    exit;
}

http_response_code(400);
echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
