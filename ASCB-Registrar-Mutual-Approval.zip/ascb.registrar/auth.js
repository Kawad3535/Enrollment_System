/* =========================================================
   ASCB REGISTRAR SYSTEM
   UI HELPERS (login/logout is now handled server-side by
   PHP + MySQL — see index.php, logout.php, includes/auth_check.php)
   ---------------------------------------------------------
   Ang mga sumusunod na dating nandito ay pinalitan na ng PHP:
     - ASCB_USERS (hardcoded accounts)       -> `users` table
     - ascbHandleLogin / ascbGetSession/etc  -> index.php ($_SESSION)
     - ascbGuardPage                         -> includes/auth_check.php
     - ascbInitHeaderSession/ascbInitPreparedBy -> server-rendered na
       diretso sa dashboard.php (walang JS na kailangan)
   ========================================================= */

function ascbConfirmLogout() {
    const overlay = document.getElementById("ascbLogoutModal");
    if (overlay) overlay.classList.add("active");
}

function ascbCancelLogout() {
    const overlay = document.getElementById("ascbLogoutModal");
    if (overlay) overlay.classList.remove("active");
}

function ascbLogout() {
    window.location.href = "logout";
}


/* =========================================================
   LOGIN PAGE — show/hide password only
   (ang pag-verify ng username/password ay ginagawa na ng
   index.php sa server, hindi na dito sa browser)
   ========================================================= */

function ascbTogglePasswordVisibility() {
    const passwordInput = document.getElementById("loginPassword");
    const toggleBtn = document.getElementById("loginTogglePw");
    if (!passwordInput || !toggleBtn) return;

    const isHidden = passwordInput.type === "password";
    passwordInput.type = isHidden ? "text" : "password";
    toggleBtn.textContent = isHidden ? "Hide" : "Show";
}


/* =========================================================
   LEFT NAVBAR — VIEW SWITCHING
   Dashboard, Certificates, and Form 137 are all shown/hidden
   in-place as pages — nothing opens as an overlay anymore.
   ========================================================= */

const ASCB_LAST_VIEW_KEY = "ascb_reg_last_view";

function ascbNavigate(view) {
    document.querySelectorAll(".main-nav-link[data-view]").forEach(function (btn) {
        btn.classList.toggle("active", btn.dataset.view === view);
    });

    document.querySelectorAll(".app-view").forEach(function (section) {
        section.classList.toggle("active-view", section.id === view + "View");
    });

    sessionStorage.setItem(ASCB_LAST_VIEW_KEY, view);

    ascbToggleSidebar(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
}

/* (bug fix) Bawat view sa kaliwang navbar (Enrollment, Records,
   Grade Management, Releasing, Archive, Admin, atbp.) ay may
   kaparehong "loader" function na tinatawag sa onclick ng nav
   button nito sa dashboard.php (hal. onclick="ascbNavigate(...);
   ascbLoadEnrollment();"). Ito ang parehong listahan, para
   magamit din ni ascbRestoreLastView() sa ibaba. */
const ASCB_VIEW_LOADERS = {
    dashboard: function () { if (typeof ascbLoadDashboardStats === "function") ascbLoadDashboardStats(); if (typeof ascbLoadRegistrarAnalytics === "function") ascbLoadRegistrarAnalytics(); },
    student360: function () { if (typeof ascbLoadStudent360 === "function") ascbLoadStudent360(); },
    masterrecord: function () { if (!document.getElementById("masterrecordView")) { ascbNavigate("dashboard"); return; } if (typeof ascbLoadMasterRecord === "function") ascbLoadMasterRecord(); },
    enrollment: function () { if (typeof ascbLoadEnrollment === "function") ascbLoadEnrollment(); },
    newterm: function () { if (typeof ascbLoadEnrollment === "function") ascbLoadEnrollment(); },
    grademanagement: function () { if (typeof ascbLoadGradeManagement === "function") ascbLoadGradeManagement(); },
    gradeevaluation: function () { if (typeof ascbLoadGradeEvaluation === "function") ascbLoadGradeEvaluation(); },
    honors: function () { if (typeof ascbLoadHonors === "function") ascbLoadHonors(); },
    records: function () { if (typeof ascbLoadRecords === "function") ascbLoadRecords(); },
    approvedso: function () { if (typeof ascbLoadApprovedSO === "function") ascbLoadApprovedSO(); },
    rejected: function () { if (typeof ascbLoadRejectedStudents === "function") ascbLoadRejectedStudents(); },
    archive: function () { if (typeof ascbLoadArchive === "function") ascbLoadArchive(); },
    admin: function () { if (typeof ascbAdminOpen === "function") ascbAdminOpen(); }
};

/* Puts the page back on whichever view the user was last on
   (Dashboard / Certificates / Form 137), so reloading the page
   doesn't bounce back to the Dashboard. Call this once, right
   after the view sections exist in the DOM.

   (bug fix) Dati, dito lang natatapos ang function pagkatapos
   ilipat ang "active" CSS classes papunta sa lastView — kaya pag
   nag Ctrl+F5 (o normal refresh) habang naka-open sa halimbawang
   Enrollment o Records, babalik man sa tamang view pero EMPTY o
   LUMANG datos pa rin ang laman ng table sa loob nito, dahil hindi
   na muling tinatawag ang loader function nito (ang
   ascbLoadEnrollment(), ascbLoadRecords(), atbp. ay tinatawag lang
   dati sa loob ng onclick ng nav button — hindi dito). Ngayon,
   tinatawag na rin agad ang kaparehong loader ng na-restore na view
   para sabay na ma-refresh ang lahat ng tables pagbukas/pag-reload
   ng page, hindi lang yung Dashboard stats. */
function ascbRestoreLastView() {
    const lastView = sessionStorage.getItem(ASCB_LAST_VIEW_KEY);
    if (!lastView || lastView === "dashboard") return;

    document.querySelectorAll(".main-nav-link[data-view]").forEach(function (btn) {
        btn.classList.toggle("active", btn.dataset.view === lastView);
    });

    document.querySelectorAll(".app-view").forEach(function (section) {
        section.classList.toggle("active-view", section.id === lastView + "View");
    });

    const loadView = ASCB_VIEW_LOADERS[lastView];
    if (typeof loadView === "function") {
        try {
            loadView();
        } catch (err) {
            console.error("ascbRestoreLastView: load failed for view '" + lastView + "'", err);
        }
    }
}

/* ---------- Actions panel (collapsible, on the Certificates view) ---------- */

function ascbToggleActionsPanel() {
    const panel = document.getElementById("actionsPanel");
    if (panel) panel.classList.toggle("collapsed");
}

/* ---------- Mobile off-canvas sidebar ---------- */

function ascbToggleSidebar(forceOpen) {
    const sidebar = document.getElementById("mainSidebar");
    const backdrop = document.getElementById("sidebarBackdrop");
    if (!sidebar || !backdrop) return;

    const shouldOpen =
        typeof forceOpen === "boolean" ? forceOpen : !sidebar.classList.contains("open");

    sidebar.classList.toggle("open", shouldOpen);
    backdrop.classList.toggle("open", shouldOpen);
}


/* ---------- logout confirmation modal: dismiss helpers ---------- */

document.addEventListener("click", function (event) {
    const overlay = document.getElementById("ascbLogoutModal");
    if (overlay && event.target === overlay) {
        ascbCancelLogout();
    }
});

document.addEventListener("keydown", function (event) {
    if (event.key !== "Escape") return;
    const overlay = document.getElementById("ascbLogoutModal");
    if (overlay && overlay.classList.contains("active")) {
        ascbCancelLogout();
    }
});
