<?php
/* =========================================================
   ASCB REGISTRAR SYSTEM — FORCED PASSWORD CHANGE (FIRST LOGIN)
   ---------------------------------------------------------
   Ang account na may must_change_password = 1 (bagong auto-created
   STUDENT account, o na-reset ang temporary password) ay DITO lang
   makakapunta. Ang server guard (includes/auth_check.php /
   includes/api_guard.php) ang nagpapatupad nito — hindi lang ang
   browser — kaya hindi mabubuksan ang Student Dashboard hangga't
   hindi napapalitan ang temporary password.

   Ang pagpapalit ay dumadaan sa api/users.php (action: change_password),
   na nagve-verify ng temporary password, nag-hash ng bago
   (password_hash), nagki-clear ng must_change_password, at kaya
   hindi na gagana ang temporary password.
   ========================================================= */
define('ASCB_ALLOW_STUDENT', true);
define('ASCB_ALLOW_PASSWORD_CHANGE', true);
define('ASCB_PASSWORD_CHANGE_ONLY', true);

require_once __DIR__ . '/includes/auth_check.php';

$isStudent   = ($ascbUser['role'] === 'STUDENT');
$afterChange = './'; // router sa index.php ang pipili ng tamang screen
$displayName = (string) ascb_get($ascbUser, 'displayName', '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <link rel="icon" type="image/png" href="ASCB_LOGO.png">
    <title>Change Your Password | ASCB Registrar</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="student.css">
    <link rel="stylesheet" href="responsive.css?v=<?php echo (int) @filemtime(__DIR__ . '/responsive.css'); ?>">
    <style>
        .cp-wrap { max-width: 460px; margin: 36px auto; padding: 0 16px; }
        .cp-card { background: var(--card); border: 1px solid var(--line); border-radius: var(--r-lg); box-shadow: var(--shadow-md); padding: 26px; }
        .cp-card h1 { margin: 0 0 6px; font-size: 20px; }
        .cp-card p { margin: 0 0 16px; color: var(--muted); font-size: 13.5px; }
        .cp-card label { display: block; font-size: 12.5px; font-weight: 600; margin: 10px 0 4px; }
        .cp-card input { width: 100%; font: inherit; padding: 10px 12px; border: 1px solid var(--line); border-radius: var(--r-sm); background: var(--paper); color: var(--ink); }
        .cp-hint { font-size: 12px; color: var(--muted); margin-top: 6px; }
        .cp-msg { min-height: 20px; font-size: 13px; margin: 12px 0 4px; }
        .cp-msg.err { color: var(--danger); }
        .cp-msg.good { color: var(--success); }
        .cp-btn { width: 100%; margin-top: 8px; padding: 11px; font: inherit; font-weight: 600; border: 0; border-radius: var(--r-sm); background: var(--blue); color: #fff; cursor: pointer; }
        .cp-btn:disabled { opacity: .6; cursor: not-allowed; }
    </style>
    <script>
        (function () {
            var t = localStorage.getItem("ascbTheme") === "dark" ? "dark" : "light";
            document.documentElement.setAttribute("data-theme", t);
        })();
    </script>
</head>
<body>

<header class="sp-top">
    <div class="sp-top-inner">
        <img class="sp-logo" src="ASCB_LOGO.png" alt="ASCB Logo">
        <div class="sp-brand">
            <small>Andres Soriano Colleges of Bislig, Inc.</small>
            <strong><?php echo $isStudent ? 'Student Portal' : 'Registrar System'; ?></strong>
        </div>
        <div class="sp-top-actions">
            <a class="sp-btn" href="logout">Log out</a>
        </div>
    </div>
</header>

<main class="cp-wrap">
    <div class="cp-card">
        <h1>Set your own password</h1>
        <p>
            Welcome<?php echo $displayName !== '' ? ', ' . htmlspecialchars($displayName, ENT_QUOTES, 'UTF-8') : ''; ?>!
            You signed in with a <strong>temporary password</strong>. For your security, you must choose a
            new password before you can continue. The temporary password will stop working right after.
        </p>

        <label for="cpCur">Temporary password</label>
        <input type="password" id="cpCur" autocomplete="current-password" autocapitalize="characters" spellcheck="false">

        <label for="cpNew">New password</label>
        <input type="password" id="cpNew" autocomplete="new-password">
        <div class="cp-hint">At least 8 characters, with at least one letter and one number. It must be different from the temporary password.</div>

        <label for="cpNew2">Confirm new password</label>
        <input type="password" id="cpNew2" autocomplete="new-password">

        <div class="cp-msg" id="cpMsg" role="status"></div>
        <button type="button" class="cp-btn" id="cpSave">Save and continue</button>
    </div>
</main>

<script>
(function () {
    "use strict";
    var CSRF  = <?php echo json_encode(ascb_csrf_token(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    var NEXT  = <?php echo json_encode($afterChange); ?>;
    var msg   = document.getElementById("cpMsg");
    var btn   = document.getElementById("cpSave");

    function say(text, cls) { msg.textContent = text || ""; msg.className = "cp-msg" + (cls ? " " + cls : ""); }

    function submit() {
        var cur = document.getElementById("cpCur").value,
            nw  = document.getElementById("cpNew").value,
            nw2 = document.getElementById("cpNew2").value;
        if (!cur || !nw || !nw2) { say("Please fill in all fields.", "err"); return; }
        if (nw.length < 8) { say("The new password must be at least 8 characters.", "err"); return; }
        if (!/[A-Za-z]/.test(nw) || !/[0-9]/.test(nw)) { say("The new password needs at least one letter and one number.", "err"); return; }
        if (nw !== nw2) { say("The new passwords do not match.", "err"); return; }
        btn.disabled = true; say("Saving…");
        fetch("api/users.php", {
            method: "POST", credentials: "same-origin",
            headers: { "Content-Type": "application/json", "X-CSRF-Token": CSRF },
            body: JSON.stringify({ action: "change_password", currentPassword: cur, newPassword: nw })
        }).then(function (r) { return r.json(); }).then(function (j) {
            if (j && j.ok) {
                say("Password changed. Redirecting…", "good");
                setTimeout(function () { window.location.href = NEXT; }, 700);
            } else {
                btn.disabled = false;
                say((j && j.error) || "Unable to change the password.", "err");
            }
        }).catch(function () { btn.disabled = false; say("Unable to reach the server.", "err"); });
    }

    btn.addEventListener("click", submit);
    ["cpCur", "cpNew", "cpNew2"].forEach(function (id) {
        document.getElementById(id).addEventListener("keydown", function (e) { if (e.key === "Enter") submit(); });
    });
})();
</script>
</body>
</html>
