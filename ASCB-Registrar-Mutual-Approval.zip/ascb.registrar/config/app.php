<?php
/* =========================================================
   ASCB REGISTRAR SYSTEM — APPLICATION CONFIGURATION
   ---------------------------------------------------------
   Production-safe defaults. Values can be overridden through
   environment variables without editing PHP source files.
   ========================================================= */

if (!function_exists('ascb_env')) {
    function ascb_env($name, $default = null) {
        $value = getenv($name);
        return ($value === false || $value === '') ? $default : $value;
    }
}

if (!defined('ASCB_DEBUG')) {
    define('ASCB_DEBUG', ascb_env('ASCB_DEBUG', '0') === '1');
}

/* PUBLIC BASE URL na nakasulat sa QR code ng Certificate of Enrollment /
 * Registration (hal. https://registrar.ascb.edu.ph  o  https://yourdomain.com/registrar).
 * Walang trailing slash. Kapag walang laman, awtomatikong kukunin ang address
 * na ginamit ng staff sa pag-generate — OK sa live hosting, PERO kung
 * localhost/XAMPP ang ginagamit, hindi mabubuksan ng cellphone ang
 * "localhost" na link. Itakda ito sa tunay na domain ng system. */
if (!defined('ASCB_PUBLIC_BASE_URL')) {
    define('ASCB_PUBLIC_BASE_URL', rtrim((string) ascb_env('ASCB_PUBLIC_BASE_URL', ''), '/'));
}

if (!defined('ASCB_TIMEZONE')) {
    define('ASCB_TIMEZONE', ascb_env('ASCB_TIMEZONE', 'Asia/Manila'));
}
date_default_timezone_set(ASCB_TIMEZONE);

/* Upload limit enforced by the application. The PHP/web-server
   limits must be equal to or higher than this value. */
if (!defined('ASCB_MAX_UPLOAD_MB')) {
    $uploadMb = (int) ascb_env('ASCB_MAX_UPLOAD_MB', '100');
    if ($uploadMb < 1) $uploadMb = 100;
    if ($uploadMb > 250) $uploadMb = 250; // safety ceiling
    define('ASCB_MAX_UPLOAD_MB', $uploadMb);
}

/* PAYLOAD LIMIT for plain JSON API request bodies (action=add/update/
 * delete forms, etc — NOT file uploads, which have their own, much
 * higher ASCB_MAX_UPLOAD_MB limit above and use multipart/form-data,
 * not a JSON body). Every JSON-body endpoint (and, going forward,
 * any AI/LLM-backed feature that accepts a JSON prompt/context body)
 * should read its body through ascb_read_json_body() in helpers.php,
 * which enforces this limit BEFORE json_decode() runs — this avoids
 * decoding (and holding in memory) an oversized or abusive payload
 * that has no legitimate reason to be that large.
 */
if (!defined('ASCB_MAX_JSON_PAYLOAD_KB')) {
    $jsonKb = (int) ascb_env('ASCB_MAX_JSON_PAYLOAD_KB', '512');
    if ($jsonKb < 16) $jsonKb = 16;
    if ($jsonKb > 8192) $jsonKb = 8192; // safety ceiling (8 MB)
    define('ASCB_MAX_JSON_PAYLOAD_KB', $jsonKb);
}

if (ASCB_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}
