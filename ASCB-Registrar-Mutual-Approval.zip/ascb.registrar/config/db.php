<?php
/* ASCB Registrar System — protected database bootstrap.
 * Configure ASCB_DB_HOST, ASCB_DB_PORT, ASCB_DB_NAME, ASCB_DB_USER,
 * ASCB_DB_PASS in the hosting environment, OR create config/local.php in
 * this protected config directory. Never commit or distribute local.php.
 */
require_once __DIR__ . '/app.php';

$localConfig = __DIR__ . '/local.php';
if (is_file($localConfig)) {
    // This file must be server-managed and excluded from all distributable archives.
    $localValues = require $localConfig;
    if (is_array($localValues)) {
        foreach (['host'=>'ASCB_DB_HOST','port'=>'ASCB_DB_PORT','name'=>'ASCB_DB_NAME','user'=>'ASCB_DB_USER','pass'=>'ASCB_DB_PASS'] as $key=>$envName) {
            if (!defined($envName) && array_key_exists($key, $localValues)) define($envName, (string)$localValues[$key]);
        }
    }
    unset($localValues);
}

$required = ['ASCB_DB_HOST','ASCB_DB_NAME','ASCB_DB_USER','ASCB_DB_PASS'];
foreach ($required as $constant) {
    if (!defined($constant)) {
        $value = getenv($constant);
        if ($value !== false && $value !== '') define($constant, $value);
    }
}
if (!defined('ASCB_DB_PORT')) {
    $port = getenv('ASCB_DB_PORT');
    define('ASCB_DB_PORT', ($port !== false && $port !== '') ? $port : '3306');
}

$missing = [];
foreach ($required as $constant) {
    if (!defined($constant)) {
        $missing[] = $constant;
    } elseif ($constant !== 'ASCB_DB_PASS' && constant($constant) === '') {
       $missing[] = $constant;
   }
}

//foreach ($required as $constant) if (!defined($constant) || constant($constant) === '') $missing[] = $constant;
if ($missing) {
    error_log('ASCB database configuration missing required settings: ' . implode(', ', $missing));
    http_response_code(500);
    if (!headers_sent()) header('Content-Type: text/plain; charset=utf-8');
    echo 'Database connection unavailable. Please contact the system administrator.';
    exit;
}

/* Backward-compatible aliases for legacy modules (backup_engine.php and
 * deployment_check.php) that still use DB_* names. Keep one source of truth:
 * all aliases are derived from the validated ASCB_DB_* configuration. */
$ascbLegacyDbAliases = [
    'ASCB_DB_HOST' => 'DB_HOST',
    'ASCB_DB_PORT' => 'DB_PORT',
    'ASCB_DB_NAME' => 'DB_NAME',
    'ASCB_DB_USER' => 'DB_USER',
    'ASCB_DB_PASS' => 'DB_PASS',
];
foreach ($ascbLegacyDbAliases as $source => $legacy) {
    if (!defined($legacy)) define($legacy, constant($source));
}
unset($ascbLegacyDbAliases, $source, $legacy);

$pdo = null;
try {
    $dsn = 'mysql:host=' . ASCB_DB_HOST . ';port=' . ASCB_DB_PORT . ';dbname=' . ASCB_DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, ASCB_DB_USER, ASCB_DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->query('SELECT 1');
    try { $pdo->exec("SET time_zone = '+08:00'"); }
    catch (Throwable $e) { error_log('ASCB timezone setup unavailable; using server default.'); }
} catch (Throwable $e) {
    // Do not log PDO exception text: some drivers include host/user/DSN details.
    error_log('ASCB database connection failed; inspect protected server diagnostics.');
    http_response_code(500);
    if (!headers_sent()) header('Content-Type: text/plain; charset=utf-8');
    echo 'Database connection unavailable. Please contact the system administrator.';
    exit;
}
