<?php
/* Copy to config/local.php ONLY on the server; never commit or distribute it.
 * Prefer environment variables if supported by the hosting provider.
 * Restrict filesystem permissions and verify direct HTTP access is denied.
 */
return [
    'host' => '127.0.0.1',
    'port' => '3306',
    'name' => 'ascb_registrar',
    'user' => 'root',
    'pass' => '',
];
