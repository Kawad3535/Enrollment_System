<?php
/* Apply Surname/First Name/Middle Name change across ALL terms of ONE
 * Student ID -- REPORT by default, ?apply=1 to actually save.
 *
 * BAKIT ITO KAILANGAN:
 * Wala talagang "isang master student profile" ang system na ito --
 * bawat Term/School Year ng isang estudyante ay may sariling
 * Surname/First Name/Middle Name column sa "enrollees" table (tingnan
 * api/grade_import.php / find_name_mismatches_once.php). Kaya kapag
 * nagpalit ng apelyido ang isang estudyante (hal. nag-asawa: "Jabagat"
 * -> "Abanilla"), hindi ito ONE update lang -- kailangang i-update ang
 * SETI ng Enrollment row niya, term-by-term, kung gusto mong makita ang
 * bagong pangalan sa lahat ng nakaraan niyang record.
 *
 * Ang Record Corrections module (api/record_corrections.php) ay para
 * lang sa Grade/Subject corrections -- WALANG suporta para sa personal
 * info tulad ng Surname. Ang Enrollment "Edit" naman (api/enrollment.php,
 * action=update) ay isang Enrollment row (isang Term) LANG sa bawat
 * pag-save -- kailangan mo pang ulit-ulitin ito nang manu-mano kung
 * maraming Term na ang estudyante. Ito ang shortcut para doon.
 *
 * Paano gamitin:
 *
 *   1) REPORT (walang binabago) -- CLI only:
 *      php database/apply_surname_change_once.php student_id=2024110692
 *
 *   2) Kapag tama na ang laman ng report, idagdag ang bagong
 *      value(s) -- LAKTAWAN ang field na ayaw mong galawin (hal. kung
 *      Surname lang ang gusto mong palitan, huwag isama ang
 *      first_name/middle_name sa URL):
 *
 *      php database/apply_surname_change_once.php student_id=2024110692 surname=Abanilla
 *
 *   3) Kapag OK na ang preview, idagdag ang &apply=1 sa dulo ng
 *      PAREHONG URL para talagang i-save:
 *
 *      php database/apply_surname_change_once.php student_id=2024110692 surname=Abanilla apply=1
 *
 * Ino-update lang nito ang mga field na eksaktong ibinigay mo sa URL
 * (surname / first_name / middle_name) -- lahat ng ibang column
 * (grades, subjects, term, program, atbp.) ay hindi nagagalaw. Bawat
 * naka-apply na pagbabago ay naka-log sa Activity Log para may audit
 * trail. */

// Student-name changes affect historical enrollment records. Keep this
// maintenance utility CLI-only; URL parameters must never authorize writes.
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Not found. Run this maintenance script from the command line.\n";
    exit;
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/activity_log.php';

header('Content-Type: text/plain; charset=utf-8');

/* (CLI support) Kapag pinatakbo ito sa command line (php script.php
   student_id=... surname=... apply=1), walang $_GET na napo-populate
   dahil walang HTTP query string -- ang mga argument ay nasa $argv
   bilang "key=value" na text. Dito, kinukuha ang mga iyon at inilalagay
   sa $_GET para parehong browser (?student_id=...) at CLI (student_id=...,
   walang "?") ang gumana nang walang dagdag na hakbang (hindi na
   kailangang i-off ang database/.htaccess kapag CLI). */
if (PHP_SAPI === 'cli' && !empty($argv)) {
    foreach (array_slice($argv, 1) as $arg) {
        if (strpos($arg, '=') === false) continue;
        list($k, $v) = explode('=', $arg, 2);
        $_GET[trim($k)] = $v;
    }
}

function out($line = '') { echo $line . "\n"; }

try {
    if (!$pdo) { throw new RuntimeException('No database connection.'); }

    $studentId = trim((string) ($_GET['student_id'] ?? ''));
    if ($studentId === '') {
        out('Kulang ang student_id. Halimbawa:');
        out('  ?student_id=2024110692');
        out('  ?student_id=2024110692&surname=Abanilla');
        out('  ?student_id=2024110692&surname=Abanilla&apply=1');
        exit;
    }

    // Field na ibinigay lang sa URL (isset check, hindi lang blangko o hindi)
    // ang gagalawin -- kaya ligtas na hindi mo isama ang first_name/middle_name
    // kung Surname lang ang gusto mong ayusin.
    $fields = array();
    if (isset($_GET['surname']))     $fields['surname']     = trim((string) $_GET['surname']);
    if (isset($_GET['first_name']))  $fields['first_name']  = trim((string) $_GET['first_name']);
    if (isset($_GET['middle_name'])) $fields['middle_name'] = trim((string) $_GET['middle_name']);

    $apply = ((string) ($_GET['apply'] ?? '') === '1');

    $st = $pdo->prepare(
        "SELECT id, surname, first_name, middle_name, course, major, trimester, school_year, created_at
           FROM enrollees WHERE student_id = ? ORDER BY id ASC"
    );
    $st->execute(array($studentId));
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);

    if (!$rows) {
        out("Walang nahanap na Enrollment record para sa Student ID \"$studentId\".");
        exit;
    }

    out("Student ID: $studentId — " . count($rows) . ' Enrollment record(s) nahanap.');
    out('');
    foreach ($rows as $r) {
        out(sprintf('  [id=%d] %s, %s %s | %s | %s | created %s',
            $r['id'], $r['surname'], $r['first_name'],
            $r['middle_name'] !== null ? '(' . $r['middle_name'] . ')' : '',
            $r['trimester'] . ' / ' . $r['school_year'],
            $r['course'] !== null ? $r['course'] : '-',
            $r['created_at']
        ));
    }
    out('');

    if (!$fields) {
        out('Walang binigay na bagong value (surname / first_name / middle_name sa URL) --');
        out('ito lang ang listahan ng mga kasalukuyang record. Idagdag ang gustong baguhin, hal.:');
        out("  &surname=Abanilla");
        exit;
    }

    out('BAGONG VALUE na ilalapat sa LAHAT ng ' . count($rows) . ' record sa itaas:');
    foreach ($fields as $k => $v) out("  $k -> \"$v\"");
    out('');

    if (!$apply) {
        out('REPORT ONLY. Idagdag ang &apply=1 sa URL para talagang i-save ang pagbabagong ito.');
        exit;
    }

    $setSql = array();
    $params = array();
    foreach ($fields as $k => $v) {
        $setSql[] = "$k = ?";
        $params[] = ($v === '' && $k !== 'surname' && $k !== 'first_name') ? null : $v;
    }
    $params[] = $studentId;

    $pdo->beginTransaction();
    $upd = $pdo->prepare('UPDATE enrollees SET ' . implode(', ', $setSql) . ' WHERE student_id = ?');
    $upd->execute($params);
    $affected = $upd->rowCount();
    $pdo->commit();

    $ascbUser = array('id' => null, 'displayName' => 'database/apply_surname_change_once.php', 'role' => 'SYSTEM');
    ascb_log_activity(
        $pdo, $ascbUser, 'NAME_CORRECTION_SCRIPT', 'enrollee', $studentId,
        'Na-update ang ' . implode(', ', array_keys($fields)) . ' sa ' . $affected . ' Enrollment record(s) -- '
        . implode('; ', array_map(function ($k, $v) { return "$k=\"$v\""; }, array_keys($fields), $fields))
    );

    out("TAPOS NA. Na-update ang $affected record(s).");
} catch (Throwable $e) {
    if (isset($pdo) && $pdo && $pdo->inTransaction()) $pdo->rollBack();
    out('ERROR: ' . $e->getMessage());
}
