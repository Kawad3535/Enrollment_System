<?php
/* Non-destructive audit for duplicate Course/Program labels.
   It reports exact Course + Major duplicates so the registrar can
   decide which legacy program code to retain. It does NOT delete
   programs, subjects, enrollments, or grades. */
require_once __DIR__ . '/../config/db.php';

$sql = "SELECT LOWER(TRIM(course_name)) AS course_key,
               LOWER(TRIM(COALESCE(major,''))) AS major_key,
               COUNT(*) AS duplicate_count,
               GROUP_CONCAT(CONCAT(id, ':', code) ORDER BY id SEPARATOR ', ') AS records,
               MAX(course_name) AS course_name, MAX(major) AS major
        FROM programs
        GROUP BY LOWER(TRIM(course_name)), LOWER(TRIM(COALESCE(major,'')))
        HAVING COUNT(*) > 1
        ORDER BY course_name, major";

$rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
header('Content-Type: text/plain; charset=utf-8');
if (!$rows) { echo "NO EXACT DUPLICATE COURSE/MAJOR RECORDS FOUND.\n"; exit; }
echo "EXACT DUPLICATE COURSE/MAJOR RECORDS (NON-DESTRUCTIVE):\n\n";
foreach ($rows as $r) {
    echo $r['course_name'];
    if (trim((string)$r['major']) !== '') echo ' Major in ' . $r['major'];
    echo "\n  Records: " . $r['records'] . "\n\n";
}
