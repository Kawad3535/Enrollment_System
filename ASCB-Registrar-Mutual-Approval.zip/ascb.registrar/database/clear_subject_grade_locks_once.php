<?php
/* One-time cleanup: removes every stored Subject Gradebook lock.
 *
 * Locking was removed from the Subject Gradebook because locked subjects could
 * no longer be unlocked, which permanently blocked grade encoding and grade
 * sheet imports. Run this one-time maintenance operation from CLI only:
 *
 *   php database/clear_subject_grade_locks_once.php
 *
 * Never expose this destructive operation through a browser request.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Not found. Run this maintenance script from the command line.\n";
    exit;
}

require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/plain; charset=utf-8');

try {
    $exists = $pdo->query("SHOW TABLES LIKE 'subject_grade_locks'")->fetchColumn();
    if (!$exists) {
        echo "subject_grade_locks table not found — nothing to clear.\n";
        exit;
    }
    $before = (int)$pdo->query("SELECT COUNT(*) FROM subject_grade_locks")->fetchColumn();
    $pdo->exec("DELETE FROM subject_grade_locks");
    echo "Cleared {$before} subject grade lock row(s). All subjects are now open for grade encoding and import.\n";
} catch (Throwable $e) {
    http_response_code(500);
    echo 'Failed to clear subject grade locks: ' . $e->getMessage() . "\n";
}
