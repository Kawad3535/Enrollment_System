<?php
require_once __DIR__ . '/setup_guard.php';
require_once __DIR__ . '/../config/app.php';

function line_status($ok, $label, $detail = '') {
    echo ($ok ? '[OK]   ' : '[FAIL] ') . $label;
    if ($detail !== '') echo ' — ' . $detail;
    echo PHP_EOL;
}

echo "ASCB Registrar deployment check\n===============================\n";
line_status(version_compare(PHP_VERSION, '5.6.0', '>='), 'PHP version', PHP_VERSION);
line_status(extension_loaded('pdo_mysql'), 'PDO MySQL extension');
line_status(function_exists('password_hash'), 'Password hashing support');
line_status(function_exists('finfo_open'), 'Fileinfo extension', function_exists('finfo_open') ? 'available' : 'recommended for PDF validation');
line_status(function_exists('mb_substr'), 'mbstring extension', function_exists('mb_substr') ? 'available' : 'optional; fallback is enabled');

foreach (array('documents','approved_so') as $dir) {
    $path = __DIR__ . '/../uploads/' . $dir;
    line_status(is_dir($path) && is_writable($path), 'Writable uploads/' . $dir);
}

$uploadMax = ini_get('upload_max_filesize');
$postMax = ini_get('post_max_size');
echo '[INFO] PHP upload_max_filesize = ' . $uploadMax . PHP_EOL;
echo '[INFO] PHP post_max_size       = ' . $postMax . PHP_EOL;
echo '[INFO] App max per file         = ' . ASCB_MAX_UPLOAD_MB . 'M' . PHP_EOL;

if (!extension_loaded('pdo_mysql')) {
    line_status(false, 'Database connection', 'cannot test because pdo_mysql is not installed');
} else {
    define('ASCB_DB_OPTIONAL', true);
    require __DIR__ . '/../config/db.php';
    if (!$pdo) {
        line_status(false, 'Database connection', 'check DB service/credentials');
    } else {
        line_status(true, 'Database connection', DB_HOST . ':' . DB_PORT . '/' . DB_NAME);
        $required = array('users','schools','courses','enrollees','enrollment_subjects','grades','certificates','form137_requests','document_transactions','document_transaction_files','approved_so','activity_log','subject_grade_locks');
        foreach ($required as $table) {
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE " . $pdo->quote($table));
                line_status((bool) $stmt->fetchColumn(), 'Table ' . $table);
            } catch (Exception $e) {
                line_status(false, 'Table ' . $table, ASCB_DEBUG ? $e->getMessage() : 'schema check failed');
            }
        }

        // 500k-readiness: verify the indexes used by the large-data query paths.
        $requiredIndexes = array(
            array('enrollees', 'idx_enr_active_latest'),
            array('enrollees', 'idx_enr_program_term'),
            array('enrollees', 'idx_enr_status_created'),
            array('enrollment_subjects', 'idx_es_enrollment_id'),
            array('grades', 'idx_grades_updated')
        );
        foreach ($requiredIndexes as $ix) {
            try {
                $st = $pdo->prepare("SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?");
                $st->execute(array($ix[0], $ix[1]));
                line_status((int)$st->fetchColumn() > 0, '500k index ' . $ix[1], $ix[0]);
            } catch (Exception $e) {
                line_status(false, '500k index ' . $ix[1], ASCB_DEBUG ? $e->getMessage() : 'index check failed');
            }
        }
    }
}
