<?php
/* Name mismatch finder — REPORT ONLY, walang binabago sa database.
 *
 * BAKIT ITO KAILANGAN:
 * Bawat Term/School Year ng isang estudyante ay hiwalay na ROW sa
 * "enrollees" table (walang iisang "master student" record) — tingnan
 * api/grade_import.php. Ang Bulk Import ay nagtutugma lang batay sa
 * Student ID + School Year + Term; hindi nito hinahawakan/ ina-update
 * ang Surname/First Name/Middle Name kapag NATUGMAAN na ang isang
 * existing row. Kapag WALANG match (bagong Term), gumagawa ito ng
 * BAGONG row gamit ang eksaktong pangalan na nasa in-import na file --
 * kahit iba ito sa nakasave na sa mga naunang Term.
 *
 * Dahil dito, posibleng magkaroon ng magkaibang Surname/First
 * Name/Middle Name ang PAREHONG Student ID sa magkaibang Term (typo,
 * naipasok na maling Surname/Middle Name noon, nag-asawa/nagpalit ng
 * pangalan, atbp.) -- at ang "current" na Surname na ipinapakita sa
 * Student 360 (api/student_360.php) ay ang row na may PINAKAMALAKING
 * id (pinakabagong naidagdag na row), HINDI kinakalkula/beripikado
 * laban sa ibang row ng parehong estudyante.
 *
 * Ang script na ito ay REPORT ONLY -- naglilista lang ito ng lahat ng
 * Student ID na may higit sa isang magkaibang Surname/First
 * Name/Middle Name combination sa kanilang mga row, para ma-review at
 * maituwid manually (gamit ang Record Corrections o direktang pag-edit)
 * kung alin ang tama. Walang awtomatikong ginagawang pagbabago dito --
 * hindi ito katulad ng ibang "fix_*_once.php" na may ?apply=1 mode,
 * dahil walang paraan ang system na malaman kung alin sa magkaibang
 * pangalan ang TAMA -- desisyon iyon ng Registrar/UNIT HEAD.
 *
 * Paano patakbuhin:
 *   http://localhost/ascb.registrar/database/find_name_mismatches_once.php
 *   o sa CLI: php find_name_mismatches_once.php
 */
require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/plain; charset=utf-8');

function out($line = '') { echo $line . "\n"; }

function ascb_fnm_norm($v) {
    $v = trim((string) $v);
    $v = preg_replace('/\s+/u', ' ', $v);
    return function_exists('mb_strtoupper') ? mb_strtoupper($v, 'UTF-8') : strtoupper($v);
}

try {
    if (!$pdo) { throw new RuntimeException('No database connection.'); }

    $rows = $pdo->query(
        "SELECT id, student_id, surname, first_name, middle_name, program_code,
                course, major, year_level, trimester, school_year, created_at
           FROM enrollees
          WHERE student_id IS NOT NULL AND student_id <> ''
          ORDER BY student_id, id ASC"
    )->fetchAll(PDO::FETCH_ASSOC);

    $byStudent = array();
    foreach ($rows as $r) {
        $byStudent[$r['student_id']][] = $r;
    }

    $mismatches = array();
    foreach ($byStudent as $sid => $group) {
        if (count($group) < 2) continue;
        $seen = array();
        foreach ($group as $r) {
            $key = ascb_fnm_norm($r['surname']) . '|' . ascb_fnm_norm($r['first_name']) . '|' . ascb_fnm_norm($r['middle_name']);
            $seen[$key] = true;
        }
        if (count($seen) > 1) {
            $mismatches[$sid] = $group;
        }
    }

    out('Name mismatch finder (REPORT ONLY -- walang binago sa database)');
    out('Total Student IDs checked (2+ Enrollment rows): ' . count(array_filter($byStudent, function ($g) { return count($g) > 1; })));
    out('Student IDs na may MAGKAIBANG Surname/First Name/Middle Name sa kanilang mga row: ' . count($mismatches));
    out('');

    foreach ($mismatches as $sid => $group) {
        // Row na may pinakamalaking id ang "current" ayon sa student_360.php
        $currentId = 0;
        foreach ($group as $r) { if ((int) $r['id'] > $currentId) $currentId = (int) $r['id']; }

        out("Student ID: $sid");
        foreach ($group as $r) {
            $tag = ((int) $r['id'] === $currentId) ? '  <-- CURRENT (Student 360 shows this)' : '';
            out(sprintf(
                '  [id=%d] %s, %s %s | %s | %s %s | created %s%s',
                $r['id'],
                $r['surname'], $r['first_name'], $r['middle_name'] !== null ? '(' . $r['middle_name'] . ')' : '',
                $r['program_code'] !== null ? $r['program_code'] : '-',
                $r['trimester'], $r['school_year'],
                $r['created_at'],
                $tag
            ));
        }
        out('');
    }

    if (!$mismatches) {
        out('Wala pang nakitang mismatch. Malinis ang data.');
    } else {
        out('Tandaan: HINDI kayang malaman ng script na ito kung alin sa magkaibang pangalan');
        out('ang TAMA -- iyon ang dapat i-verify laban sa aktwal na Registrar record (SF10/Form 137,');
        out('o School ID) bago ituwid gamit ang Record Corrections o direktang edit.');
    }
} catch (Throwable $e) {
    out('ERROR: ' . $e->getMessage());
}
