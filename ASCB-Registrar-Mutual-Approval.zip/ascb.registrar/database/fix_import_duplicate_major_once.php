<?php
/* Doble ang Major (galing sa Import) — repair tool para sa lumang record.
 *
 * Dati, kapag ang "Program:" sa Excel ay buo na ang label (hal. "Bachelor of
 * Secondary Education major in Social Studies"), iyon mismo ang na-save sa
 * enrollees.course, at idinagdag pa ang enrollees.major ("Social Studies") —
 * kaya doble ang Major kapag pinagdugtong sa display.
 *
 * Inaayos nito: course = pangalan ng kurso LANG, major = major LANG
 * (kapareho ng manual Enrollment).
 *
 * Patakbuhin sa command line (naka-block sa web ng setup_guard):
 *   php database/fix_import_duplicate_major_once.php          -> REPORT ONLY
 *   php database/fix_import_duplicate_major_once.php --apply  -> isasagawa
 *
 * Mga ligtas na patakaran:
 *  - Walang binubura; `course` (at `major` kung blangko) lang ang binabago.
 *  - Kung may major na ibang-iba sa nasa course text, lalaktawan at ililista
 *    para ma-review nang manu-mano.
 *  - Mag-Full SQL Backup muna bago mag-apply.
 */
require_once __DIR__ . '/setup_guard.php';
require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/plain; charset=utf-8');
$apply = in_array('--apply', $argv ?? [], true) || (isset($_GET['apply']) && (string) $_GET['apply'] === '1');
function out($line = '') { echo $line . "\n"; }
function norm_key($v) { return strtoupper(preg_replace('/[^A-Za-z0-9]+/', '', (string) $v)); }

try {
    if (!$pdo) throw new RuntimeException('No database connection.');

    $rows = $pdo->query("SELECT id, student_id, program_code, course, major FROM enrollees WHERE course IS NOT NULL AND course <> '' ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    $cat  = $pdo->prepare("SELECT course_name, major FROM programs WHERE UPPER(TRIM(code)) = UPPER(TRIM(?)) LIMIT 1");
    $upd  = $pdo->prepare("UPDATE enrollees SET course = ?, major = ? WHERE id = ?");

    $fixed = 0; $review = 0; $seen = 0;
    foreach ($rows as $r) {
        $course = trim((string) $r['course']);
        $major  = trim((string) $r['major']);
        $newCourse = $course; $newMajor = $major;

        if (preg_match('/^(.*?)[\s,\-–—]*\bmajor(?:ing)?\s+in\s+(.+)$/iu', $course, $m) && trim($m[1]) !== '') {
            $inText = trim($m[2]);
            if ($major !== '' && norm_key($major) !== norm_key($inText)) {
                out(sprintf('  REVIEW (magkaiba ang major): id %d | %s | course="%s" | major="%s"', $r['id'], $r['student_id'], $course, $major));
                $review++; continue;
            }
            $newCourse = trim($m[1]);
            if ($newMajor === '') $newMajor = $inText;
        } elseif ($major !== '') {
            $q = preg_quote($major, '/');
            if (preg_match('/^(.*?)[\s,:\-–—]+' . $q . '\s*$/iu', $course, $m) && trim($m[1]) !== '') {
                $newCourse = trim($m[1]);
            }
        }
        if ($newCourse === $course && $newMajor === $major) continue;
        $seen++;

        /* Gamitin ang standard na pangalan ng kurso mula sa Programs kapag tugma ang major. */
        if ($r['program_code'] !== null && trim((string) $r['program_code']) !== '') {
            $cat->execute(array($r['program_code']));
            $c = $cat->fetch(PDO::FETCH_ASSOC);
            if ($c && trim((string) $c['course_name']) !== '' && norm_key($c['major']) === norm_key($newMajor)) {
                $newCourse = trim((string) $c['course_name']);
            }
        }

        out(sprintf('  id %d | %s | "%s" / "%s"  ->  "%s" / "%s"', $r['id'], $r['student_id'], $course, $major, $newCourse, $newMajor));
        if ($apply) { $upd->execute(array($newCourse, $newMajor !== '' ? $newMajor : null, $r['id'])); $fixed++; }
    }

    out('');
    out('Nahanap na may doble/dikit na Major: ' . $seen);
    out('Para i-review nang manu-mano: ' . $review);
    out($apply ? ('Naayos: ' . $fixed) : 'REPORT ONLY — idagdag ang --apply para isagawa ang pagbabago.');
} catch (Throwable $e) {
    http_response_code(500);
    out('ERROR: ' . $e->getMessage());
}
