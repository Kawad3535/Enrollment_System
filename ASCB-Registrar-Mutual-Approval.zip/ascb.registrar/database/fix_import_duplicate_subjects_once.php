<?php
/* Duplicate subject (A1 / A1A, BAa, A&B1, PATH Fit 1...) galing sa lumang Import — repair tool.
 *
 * Dati, kapag hindi nakilala ng Import ang code ng subject (lalo na sa BSA),
 * ang code (hal. "A1A") ang na-save bilang DESCRIPTION. Dahil iba iyon sa
 * tunay na description ("Fundamentals of Accounting"), nagkaroon ng
 * panibagong subject row sa parehong Enrollment.
 *
 * Inaayos nito ang mga row na iyon:
 *   - Kung may "tunay" na kapatid na row (parehong code/description sa kurikulum)
 *     sa parehong Enrollment -> pinagsasama (ililipat ang grade kung kailangan),
 *     tapos buburahin ang placeholder row.
 *   - Kung wala -> pinapalitan lang ang description/code ng tama mula sa kurikulum.
 *   - Kung parehong may grade pero MAGKAIBA -> hindi ginagalaw, nililista para sa review.
 *
 * Patakbuhin sa command line (naka-block sa web ng setup_guard):
 *   php database/fix_import_duplicate_subjects_once.php          -> REPORT ONLY
 *   php database/fix_import_duplicate_subjects_once.php --apply  -> isasagawa
 *
 * Mag-Full SQL Backup muna bago mag-apply.
 */
require_once __DIR__ . '/setup_guard.php';
require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/plain; charset=utf-8');
$apply = in_array('--apply', $argv ?? [], true) || (isset($_GET['apply']) && (string) $_GET['apply'] === '1');
function out($line = '') { echo $line . "\n"; }
function ckey($v) { return strtoupper(preg_replace('/[^A-Za-z0-9]+/', '', trim((string) $v))); }
function dkey($v) { return ckey(preg_replace('/\s+/u', ' ', trim((string) $v))); }

try {
    if (!$pdo) throw new RuntimeException('No database connection.');
    out($apply ? '== APPLY MODE ==' : '== REPORT ONLY (gamitin ang --apply para isagawa) ==');

    /* Kurikulum ayon sa program code: [PROGRAMCODE][CODEKEY] => entry */
    $cur = array();
    $cq = $pdo->query("SELECT UPPER(TRIM(p.code)) AS pc, ps.subject_code, ps.description, ps.units
                         FROM program_subjects ps JOIN programs p ON p.id = ps.program_id");
    foreach ($cq->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $k = ckey($r['subject_code']);
        if ($k === '') continue;
        $cur[$r['pc']][$k] = array('code' => trim($r['subject_code']), 'description' => trim($r['description']),
                                   'descKey' => dkey($r['description']), 'units' => $r['units']);
    }

    $sql = "SELECT es.id, es.enrollment_id, es.course_code, es.description, es.units,
                   g.id AS grade_id, g.grade,
                   e.student_id, e.school_year, e.trimester, UPPER(TRIM(e.program_code)) AS pc
              FROM enrollment_subjects es
              JOIN enrollees e ON e.id = es.enrollment_id
              LEFT JOIN grades g ON g.enrollment_subject_id = es.id
             ORDER BY es.enrollment_id, es.id";
    $byEnroll = array();
    foreach ($pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) as $r) $byEnroll[$r['enrollment_id']][] = $r;

    $renamed = 0; $merged = 0; $review = 0;
    if ($apply) $pdo->beginTransaction();

    foreach ($byEnroll as $eid => $rows) {
        foreach ($rows as $r) {
            $rowCode = ckey($r['course_code']);
            $rowDesc = dkey($r['description']);
            if ($rowDesc === '') continue;
            $codeKey = $rowCode !== '' ? $rowCode : $rowDesc;
            if ($rowDesc !== $codeKey) continue;                      /* hindi placeholder ang description */
            if (!isset($cur[$r['pc']][$codeKey])) continue;           /* wala sa kurikulum -> huwag galawin */
            $entry = $cur[$r['pc']][$codeKey];
            if ($entry['descKey'] === $rowDesc) continue;             /* mismong description ay code (bihira) */

            /* May tunay na kapatid na row ba? */
            $sibling = null;
            foreach ($rows as $o) {
                if ((int) $o['id'] === (int) $r['id']) continue;
                if (dkey($o['description']) === $codeKey) continue;   /* isa ring placeholder */
                if (ckey($o['course_code']) === $codeKey || dkey($o['description']) === $entry['descKey']) { $sibling = $o; break; }
            }
            $label = sprintf('enrollment %d | %s | %s %s | "%s" -> %s - %s', $eid, $r['student_id'], $r['school_year'], $r['trimester'], $r['description'], $entry['code'], $entry['description']);

            if (!$sibling) {
                out('  RENAME  ' . $label);
                if ($apply) {
                    $u = $pdo->prepare("UPDATE enrollment_subjects SET description = ?, course_code = ?, units = IF(units <= 0, ?, units) WHERE id = ?");
                    $u->execute(array($entry['description'], $entry['code'], $entry['units'], $r['id']));
                }
                $renamed++;
                continue;
            }

            $myGrade = trim((string) $r['grade']);
            $sbGrade = trim((string) $sibling['grade']);
            if ($myGrade !== '' && $sbGrade !== '' && strtoupper($myGrade) !== strtoupper($sbGrade)) {
                out('  REVIEW  (magkaibang grade: ' . $myGrade . ' vs ' . $sbGrade . ') ' . $label);
                $review++;
                continue;
            }
            out('  MERGE   ' . $label . ($myGrade !== '' && $sbGrade === '' ? '  [ililipat ang grade ' . $myGrade . ']' : ''));
            if ($apply) {
                if ($myGrade !== '' && $sbGrade === '') {
                    if ($sibling['grade_id'] !== null) {
                        $pdo->prepare("UPDATE grades SET grade = ? WHERE id = ?")->execute(array($r['grade'], $sibling['grade_id']));
                    } elseif ($r['grade_id'] !== null) {
                        $pdo->prepare("UPDATE grades SET enrollment_subject_id = ? WHERE id = ?")->execute(array($sibling['id'], $r['grade_id']));
                    }
                }
                $pdo->prepare("DELETE FROM enrollment_subjects WHERE id = ?")->execute(array($r['id']));
            }
            $merged++;
        }
    }

    if ($apply) $pdo->commit();
    out();
    out("Renamed: $renamed | Merged: $merged | Needs review: $review");
    if (!$apply) out('Walang binago. Patakbuhin ulit na may --apply pagkatapos ng backup.');
} catch (Throwable $e) {
    if (isset($pdo) && $pdo && $pdo->inTransaction()) $pdo->rollBack();
    out('ERROR: ' . $e->getMessage());
    exit(1);
}
