<?php
/* New Term duplicate protection — repair tool.
 *
 * The UNIQUE KEY uq_enrollee_student_term (student_id, school_year, trimester)
 * is the concurrency-safe guard that stops the same student from being enrolled
 * twice in the same term. It is installed automatically on connect
 * (includes/schema_upgrade.php), but MySQL refuses to create it while duplicate
 * rows already exist in an upgraded database.
 *
 * Run this in the browser or CLI:
 *   http://localhost/ascb.registrar/database/fix_new_term_duplicates.php
 *       -> REPORT ONLY (nothing is changed)
 *   http://localhost/ascb.registrar/database/fix_new_term_duplicates.php?apply=1
 *       -> archives the extra duplicate rows (keeps the newest row per group),
 *          then installs the UNIQUE KEY
 *
 * Nothing is ever deleted: extra rows are archived (archived_at) and, when the
 * table allows it, marked with an archive reason. Review the report first.
 */
require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/plain; charset=utf-8');
$apply = isset($_GET['apply']) ? (string)$_GET['apply'] === '1' : (in_array('--apply', $argv ?? [], true));

function out($line = '') { echo $line . "\n"; }

try {
    if (!$pdo) { throw new RuntimeException('No database connection.'); }

    $hasKey = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'enrollees'
          AND index_name = 'uq_enrollee_student_term'")->fetchColumn();

    $groups = $pdo->query("SELECT student_id, school_year, trimester, COUNT(*) AS cnt,
                                  GROUP_CONCAT(id ORDER BY id) AS ids
                             FROM enrollees
                            GROUP BY student_id, school_year, trimester
                           HAVING COUNT(*) > 1
                            ORDER BY cnt DESC, student_id")->fetchAll(PDO::FETCH_ASSOC);

    out('New Term duplicate protection');
    out('UNIQUE KEY uq_enrollee_student_term installed: ' . ($hasKey ? 'YES' : 'NO'));
    out('Duplicate student/term groups found: ' . count($groups));
    out('');

    foreach ($groups as $g) {
        out(sprintf('  %s | %s | %s -> %d rows (ids: %s)',
            $g['student_id'], $g['school_year'], $g['trimester'], (int)$g['cnt'], $g['ids']));
    }

    if (!$groups && $hasKey) {
        out('');
        out('Nothing to do. Duplicate protection is active.');
        exit;
    }

    if (!$apply) {
        out('');
        out('REPORT ONLY. No records were changed.');
        out('');
        out('Automatic repair is intentionally disabled in this production-safe patch.');
        out('Do not archive a duplicate enrollment until its subjects, grades, certificates,');
        out('document transactions, and approval history have been reviewed by an authorized registrar.');
        out('After manual review, prepare a targeted, backed-up migration for the approved row IDs.');
        exit;
    }

    http_response_code(409);
    out('BLOCKED: automatic duplicate archiving is disabled to protect historical records.');
    out('This script does not modify data. Use the read-only audit report and an approved,');
    out('reviewed migration that preserves subject/grade/document relationships.');
    exit;

    /* Legacy destructive implementation intentionally unreachable. */
    $hasReason = (bool)$pdo->query("SHOW COLUMNS FROM enrollees LIKE 'archive_reason'")->fetch();
    $archived = 0;

    foreach ($groups as $g) {
        $ids = array_map('intval', explode(',', (string)$g['ids']));
        sort($ids);
        array_pop($ids); // keep the newest row
        foreach ($ids as $id) {
            $sql = $hasReason
                ? "UPDATE enrollees SET archived_at = COALESCE(archived_at, NOW()), archive_reason = COALESCE(archive_reason, 'Duplicate New Term (auto-archived by fix_new_term_duplicates.php)') WHERE id = ?"
                : "UPDATE enrollees SET archived_at = COALESCE(archived_at, NOW()) WHERE id = ?";
            $q = $pdo->prepare($sql);
            $q->execute([$id]);
            $archived++;
        }
    }
    out('');
    out("Archived {$archived} duplicate enrollment row(s). No record was deleted.");

    /* Archiving does not remove the rows, so the UNIQUE KEY still cannot be
       created while duplicates remain. Report clearly instead of guessing. */
    $left = (int)$pdo->query("SELECT COUNT(*) FROM (SELECT 1 FROM enrollees
        GROUP BY student_id, school_year, trimester HAVING COUNT(*) > 1) d")->fetchColumn();

    if ($left > 0) {
        out("{$left} duplicate group(s) still remain in the table.");
        out('Open Enrollment > Archived, confirm which archived duplicate rows are safe to delete,');
        out('delete them from the app, then reload any page — the guard installs itself automatically.');
        exit;
    }

    if (!$hasKey) {
        $pdo->exec("ALTER TABLE enrollees ADD UNIQUE KEY uq_enrollee_student_term (student_id, school_year, trimester)");
        out('Installed UNIQUE KEY uq_enrollee_student_term. New Term duplicate protection is now active.');
    }
} catch (Throwable $e) {
    http_response_code(500);
    out('Failed: ' . $e->getMessage());
}
