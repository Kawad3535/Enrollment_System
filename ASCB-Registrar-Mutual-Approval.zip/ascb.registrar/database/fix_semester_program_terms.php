<?php
/* Semester-based Program (hal. MAED) — repair tool para sa lumang record.
 *
 * Dati, ang Bulk Import ay laging "Trimester" ang idinidikit sa Term kapag
 * walang nakasulat na salita (hal. "2ND"), kaya ang mga estudyante ng
 * Semester-based na Program (Programs > Term System = Semester) ay may
 * enrollment na ang trimester column ay "1st Trimester" / "2nd Trimester"
 * sa halip na "1st Semester" / "2nd Semester".
 *
 * Ito ang nag-aayos ng mga iyon: "1st/2nd Trimester" -> "1st/2nd Semester"
 * para SA MGA ENROLLMENT NG SEMESTER-BASED NA PROGRAM LANG.
 *
 * Patakbuhin sa command line (naka-block ito sa web ng setup_guard):
 *   php database/fix_semester_program_terms.php            -> REPORT ONLY
 *   php database/fix_semester_program_terms.php --apply    -> isasagawa ang pagbabago
 *
 * Mga ligtas na patakaran:
 *  - Walang binubura; term label lang ang binabago.
 *  - "3rd Trimester" ay HINDI ginagalaw (walang katumbas sa Semester) —
 *    inililista lang para ma-review nang manu-mano.
 *  - Kapag may umiiral nang "Nth Semester" ang parehong estudyante at
 *    school year (unique key student_id + school_year + trimester),
 *    lalaktawan ang row na iyon at ililista bilang conflict.
 *  - Mag-Full SQL Backup muna bago mag-apply.
 *  - Ang "subject grade lock" (Professor Gradebook) ay naka-key sa term
 *    label; kung may lock ang isang subject sa "1st Trimester", i-lock
 *    ulit ito sa "1st Semester" pagkatapos ng apply.
 */
require_once __DIR__ . '/setup_guard.php';
require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/plain; charset=utf-8');
$apply = in_array('--apply', $argv ?? [], true) || (isset($_GET['apply']) && (string) $_GET['apply'] === '1');
function out($line = '') { echo $line . "\n"; }

try {
    if (!$pdo) throw new RuntimeException('No database connection.');

    $sql = "SELECT e.id, e.student_id, e.school_year, e.trimester, e.program_code, p.code AS pcode
              FROM enrollees e
              INNER JOIN programs p
                 ON UPPER(TRIM(p.code)) = UPPER(TRIM(e.program_code))
             WHERE p.term_type = 'Semester'
               AND e.trimester LIKE '%Trimester%'
             ORDER BY e.program_code, e.student_id, e.school_year, e.trimester";
    $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

    out('Semester-based Program: enrollment na naka-"Trimester"');
    out('Nahanap: ' . count($rows));
    out('');

    $find = $pdo->prepare("SELECT COUNT(*) FROM enrollees WHERE student_id = ? AND school_year = ? AND trimester = ?");
    $upd  = $pdo->prepare("UPDATE enrollees SET trimester = ? WHERE id = ?");

    $fixed = 0; $skippedConflict = 0; $skippedNoEquivalent = 0;
    foreach ($rows as $r) {
        if (!preg_match('/^\s*(\d+)/', (string) $r['trimester'], $m) || (int) $m[1] < 1 || (int) $m[1] > 2) {
            out(sprintf('  SKIP (walang katumbas na Semester): id %d | %s | %s | %s | %s',
                $r['id'], $r['program_code'], $r['student_id'], $r['school_year'], $r['trimester']));
            $skippedNoEquivalent++;
            continue;
        }
        $n = (int) $m[1];
        $target = $n . ($n === 1 ? 'st' : 'nd') . ' Semester';

        $find->execute(array($r['student_id'], $r['school_year'], $target));
        if ((int) $find->fetchColumn() > 0) {
            out(sprintf('  CONFLICT (may "%s" na ang estudyante): id %d | %s | %s | %s',
                $target, $r['id'], $r['program_code'], $r['student_id'], $r['school_year']));
            $skippedConflict++;
            continue;
        }

        out(sprintf('  %s id %d | %s | %s | %s : "%s" -> "%s"',
            $apply ? 'FIX' : 'would fix', $r['id'], $r['program_code'], $r['student_id'], $r['school_year'], $r['trimester'], $target));
        if ($apply) $upd->execute(array($target, $r['id']));
        $fixed++;
    }

    out('');
    out(($apply ? 'Naayos: ' : 'Maaayos: ') . $fixed . ' | Conflict: ' . $skippedConflict . ' | Walang katumbas: ' . $skippedNoEquivalent);
    if (!$apply) out('REPORT ONLY. Patakbuhin ulit na may --apply para isagawa (mag-backup muna).');
} catch (Throwable $e) {
    out('ERROR: ' . $e->getMessage());
    exit(1);
}
