<?php
/* =========================================================================
   ASCB REGISTRAR SYSTEM — SINGLE MASTER DATABASE MIGRATION
   -------------------------------------------------------------------------
   Pinagsama-sama ang LAHAT ng dating hiwalay na migration file
   (database/*.php, database/migrations/*.sql, at ang idempotent
   schema-upgrade helper sa includes/schema_upgrade.php, at migrate_intelligent_grade_import.php) sa IISANG file.

   ANO ANG GINAGAWA NITO:
     - Gumagawa ng database (kung naka-enable ang create_database) at ng LAHAT ng tables, columns,
       indexes, foreign keys, constraints, default values.
     - Idempotent / safe patakbuhin nang paulit-ulit: chine-check muna
       kada column/index/constraint bago idagdag — hinding-hindi
       gagawa ng duplicate at hindi kailanman nagde-DELETE o
       nagt-TRUNCATE ng records.
     - Safe kahit pang-fresh/walang laman na database (gagawa ng lahat
       mula sa simula) AT kahit existing na installation na iba-iba
       ang tinatakbong bersyon ng lumang migration files (chine-check
       bawat piraso, dinaragdag lang ang kulang).
     - Naglalagay ng starter/seed data (schools, courses, program
       catalog, at — ISANG BESES lang, kapag talagang walang laman pa
       ang `users` table — 6 starter user account kasama ang
       naka-hash na random na temporary password).
     - Panghuli, nag-ve-verify na kumpleto ang schema (tinitignan ang
       lahat ng inaasahang tables/columns sa information_schema) at
       nagpi-print ng summary report.

   DATABASE PROFILES (LOCAL vs LIVE):
     - LOCAL/XAMPP: config/local.php can use ascb_registrar_local and
       create_database=true.
     - LIVE/HOSTING: copy config/live.php.example to config/local.php,
       use the hosting database credentials, and normally keep
       create_database=false because shared hosts often manage database
       creation through cPanel/hosting tools.
     - The application always uses only the active config/local.php, so
       Local and Live records remain in separate databases.

   PAANO GAMITIN (client PC / production):
     Command line (inirerekomenda):
         php database\\migrate_master.php
     O kung web-based ang deployment mo at hindi available ang CLI,
     puwede itong buksan sa browser basta't naka-set ang environment
     variable na ASCB_ALLOW_WEB_SETUP=1 habang isinasagawa ang setup
     (tingnan ang database/setup_guard.php — parehong patakaran dito).

   SAAN ILALAGAY:
     Ilagay ang file na ito sa loob ng ascb.registrar/database/ folder
     (kasabay ng config/db.php at config/app.php sa parent directory),
     tapos patakbuhin gaya ng nasa itaas.

   MGA FLAG (opsyonal, CLI lang):
         php database\\migrate_master.php                      -> migrate + REPORT ng mga hindi kailangang table
         php database\\migrate_master.php --drop-unused --yes  -> pagkatapos ng matagumpay na migrate, i-DROP ang
                                                                mga hindi kailangang table na WALANG LAMAN
         ... --include-nonempty  -> isama rin ang may laman (MAG-BACKUP MUNA!)
         ... --keep=tbl1,tbl2    -> mga table na hindi dapat galawin
       Walang table na dino-drop kung may kulang pa sa schema (VERIFICATION failed).

   ROLLBACK:
     Kasama ang migrate_master_rollback.php — tingnan ang mga
     komento roon; SADYANG hiwalay ito at may paalala/confirmation
     bago mag-drop ng kahit anong table, dahil ang schema na ito
     mismo ang naglalaman ng buong istruktura ng datos ng system.
   ========================================================================= */

// ---------------------------------------------------------------------
// 0. GUARD — huwag patakbuhin nang basta-basta lang sa public web.
// ---------------------------------------------------------------------
require_once __DIR__ . '/../config/app.php';

$isCli = (PHP_SAPI === 'cli');
$allowWebSetup = ascb_env('ASCB_ALLOW_WEB_SETUP', '0') === '1';
if (!$isCli && !$allowWebSetup) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Ang migration script ay naka-disable sa web. Patakbuhin ito sa command\n"
       . "line (php migrate_master.php), o sadyang i-set ang ASCB_ALLOW_WEB_SETUP=1\n"
       . "sa environment habang kontrolado ang pag-install.\n";
    exit;
}

if (!$isCli) {
    header('Content-Type: text/plain; charset=utf-8');
}

function ascb_out($msg) { echo $msg . "\n"; }

// ---------------------------------------------------------------------
// 1. KONEKSYON — gumawa muna ng database kung wala pa, tapos kumonekta.
//    (Hindi tayo umaasa sa config/db.php dahil kailangan nating gawin
//    ang CREATE DATABASE IF NOT EXISTS bago pa man pumili ng database —
//    para talagang gumana ito kahit sa isang ganap na walang laman na
//    MySQL/MariaDB server.)
// ---------------------------------------------------------------------
$ascbLocalDb = array();
if (is_file(__DIR__ . '/../config/local.php')) {
    $loaded = require __DIR__ . '/../config/local.php';
    if (is_array($loaded)) $ascbLocalDb = $loaded;
}

$dbHost = isset($ascbLocalDb['host']) ? $ascbLocalDb['host'] : ascb_env('ASCB_DB_HOST', 'localhost');
$dbPort = isset($ascbLocalDb['port']) ? $ascbLocalDb['port'] : ascb_env('ASCB_DB_PORT', '3306');
$dbName = isset($ascbLocalDb['name']) ? $ascbLocalDb['name'] : ascb_env('ASCB_DB_NAME', 'ascb_registrar');
$dbUser = isset($ascbLocalDb['user']) ? $ascbLocalDb['user'] : ascb_env('ASCB_DB_USER', 'root');
$dbPass = isset($ascbLocalDb['pass']) ? $ascbLocalDb['pass'] : ascb_env('ASCB_DB_PASS', '');
$dbEnvironment = isset($ascbLocalDb['environment']) ? strtolower(trim((string)$ascbLocalDb['environment'])) : strtolower(trim((string)ascb_env('ASCB_DB_ENV', 'local')));
$createDatabase = isset($ascbLocalDb['create_database']) ? (bool)$ascbLocalDb['create_database'] : ($dbEnvironment !== 'live');

try {
    $bootDsn = 'mysql:host=' . $dbHost . ';port=' . $dbPort . ';charset=utf8mb4';
    $boot = new PDO($bootDsn, $dbUser, $dbPass, array(
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ));
    if ($createDatabase) {
        $boot->exec(
            "CREATE DATABASE IF NOT EXISTS `" . str_replace('`', '', $dbName) . "` "
            . "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
        );
    }
    $boot = null;

    $dsn = 'mysql:host=' . $dbHost . ';port=' . $dbPort . ';dbname=' . $dbName . ';charset=utf8mb4';
    $pdo = new PDO($dsn, $dbUser, $dbPass, array(
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_TIMEOUT            => 10,
    ));
    $pdo->exec("SET time_zone = '+08:00'");
} catch (Exception $e) {
    fwrite(STDERR, "Hindi makakonekta sa MySQL/MariaDB server: " . $e->getMessage() . "\n");
    exit(1);
}

ascb_out("==============================================================");
ascb_out(" ASCB REGISTRAR — MASTER MIGRATION");
ascb_out(" Environment: {$dbEnvironment}");
ascb_out(" Database: {$dbName}  @  {$dbHost}:{$dbPort}");
ascb_out(" Create database: " . ($createDatabase ? "YES" : "NO (hosting-managed)"));
ascb_out("==============================================================");

// ---------------------------------------------------------------------
// 2. HELPER FUNCTIONS — lahat ng check ay information_schema-based,
//    kaya gumagana ito kahit anong bersyon ng MySQL/MariaDB (walang
//    "ADD COLUMN IF NOT EXISTS" na ginagamit — hindi portable 'yon sa
//    mas lumang MySQL).
// ---------------------------------------------------------------------
function ascb_table_exists(PDO $pdo, $table) {
    $q = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?");
    $q->execute(array($table));
    return ((int)$q->fetchColumn()) > 0;
}

function ascb_col_exists(PDO $pdo, $table, $col) {
    $q = $pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?");
    $q->execute(array($table, $col));
    return ((int)$q->fetchColumn()) > 0;
}

function ascb_idx_exists(PDO $pdo, $table, $idx) {
    $q = $pdo->prepare("SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?");
    $q->execute(array($table, $idx));
    return ((int)$q->fetchColumn()) > 0;
}

function ascb_fk_exists(PDO $pdo, $table, $fk) {
    $q = $pdo->prepare("SELECT COUNT(*) FROM information_schema.table_constraints WHERE table_schema = DATABASE() AND table_name = ? AND constraint_name = ? AND constraint_type = 'FOREIGN KEY'");
    $q->execute(array($table, $fk));
    return ((int)$q->fetchColumn()) > 0;
}

/** Gumawa ng table (CREATE TABLE IF NOT EXISTS). Ligtas ulitin. */
function ascb_create_table(PDO $pdo, $table, $sql, array &$log) {
    $existed = ascb_table_exists($pdo, $table);
    $pdo->exec($sql);
    $log[] = ($existed ? "OK    " : "CREATE") . "  table  `{$table}`";
}

/** Magdagdag ng column kung wala pa. $afterSql ay yung buong column
 *  definition + (opsyonal) AFTER clause, hindi kasama ang "ALTER TABLE x ADD COLUMN". */
function ascb_add_column(PDO $pdo, $table, $col, $defSql, array &$log) {
    if (!ascb_table_exists($pdo, $table)) {
        $log[] = "SKIP   column `{$table}.{$col}` (table does not exist yet — will be created with this column already included)";
        return;
    }
    if (ascb_col_exists($pdo, $table, $col)) {
        $log[] = "OK     column `{$table}.{$col}`";
        return;
    }
    $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN {$defSql}");
    $log[] = "ADD    column `{$table}.{$col}`";
}

/** Magdagdag ng index kung wala pa. */
function ascb_add_index(PDO $pdo, $table, $idx, $defSql, array &$log) {
    if (!ascb_table_exists($pdo, $table)) { return; }
    if (ascb_idx_exists($pdo, $table, $idx)) {
        $log[] = "OK     index   `{$table}.{$idx}`";
        return;
    }
    try {
        $pdo->exec("ALTER TABLE `{$table}` ADD {$defSql}");
        $log[] = "ADD    index   `{$table}.{$idx}`";
    } catch (Throwable $e) {
        $log[] = "WARN   index   `{$table}.{$idx}` NOT added (" . $e->getMessage() . ")";
    }
}

/** Magdagdag ng foreign key kung wala pa. Hindi kritikal kung mabigo
 *  (hal. dahil sa orphaned data sa mga napakalumang rows) — babala
 *  lang, hindi ihihinto ang buong migration. */
function ascb_add_fk(PDO $pdo, $table, $fk, $defSql, array &$log) {
    if (!ascb_table_exists($pdo, $table)) { return; }
    if (ascb_fk_exists($pdo, $table, $fk)) {
        $log[] = "OK     FK      `{$table}.{$fk}`";
        return;
    }
    try {
        $pdo->exec("ALTER TABLE `{$table}` ADD {$defSql}");
        $log[] = "ADD    FK      `{$table}.{$fk}`";
    } catch (Throwable $e) {
        $log[] = "WARN   FK      `{$table}.{$fk}` NOT added (" . $e->getMessage() . ") — hindi kritikal, tuloy pa rin.";
    }
}

$log = array();

// =======================================================================
// 3. BASE / INDEPENDENT TABLES — sunod-sunod ayon sa dependency order
//    para maiwasan ang foreign-key errors (parent tables muna).
// =======================================================================

ascb_create_table($pdo, 'departments', "
    CREATE TABLE IF NOT EXISTS departments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        code VARCHAR(30) NOT NULL,
        name VARCHAR(200) NOT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_department_code (code),
        UNIQUE KEY uniq_department_name (name(191))
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'schools', "
    CREATE TABLE IF NOT EXISTS schools (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        name        VARCHAR(255) NOT NULL,
        address     VARCHAR(255) DEFAULT NULL,
        created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_school_name (name(191))
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'courses', "
    CREATE TABLE IF NOT EXISTS courses (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        name        VARCHAR(100) NOT NULL,
        created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_course_name (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'users', "
    CREATE TABLE IF NOT EXISTS users (
        id                INT AUTO_INCREMENT PRIMARY KEY,
        username          VARCHAR(50)  NOT NULL,
        password_hash     VARCHAR(255) NOT NULL,
        display_name      VARCHAR(100) NOT NULL,
        role              VARCHAR(50)  NOT NULL DEFAULT 'ADMIN STAFF',
        department_id     INT          DEFAULT NULL,
        student_id        VARCHAR(50)  DEFAULT NULL,
        must_change_password TINYINT(1) NOT NULL DEFAULT 0,
        temp_password_expires_at DATETIME DEFAULT NULL,
        password_changed_at DATETIME DEFAULT NULL,
        prepared_by_code  VARCHAR(50)  DEFAULT NULL,
        is_active         TINYINT(1)   NOT NULL DEFAULT 1,
        created_at        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_display_name (display_name),
        UNIQUE KEY uniq_username (username),
        UNIQUE KEY uq_users_student_id (student_id),
        INDEX idx_users_department (department_id),
        CONSTRAINT fk_users_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'programs', "
    CREATE TABLE IF NOT EXISTS programs (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        department_id INT DEFAULT NULL,
        code          VARCHAR(30)   NOT NULL,
        course_name   VARCHAR(200)  NOT NULL,
        major         VARCHAR(150)  DEFAULT NULL,
        term_type     ENUM('Trimester','Semester') NOT NULL DEFAULT 'Trimester',
        is_active     TINYINT(1)    NOT NULL DEFAULT 1,
        created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_program_code (code),
        INDEX idx_programs_department (department_id),
        CONSTRAINT fk_programs_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'program_subjects', "
    CREATE TABLE IF NOT EXISTS program_subjects (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        program_id    INT           NOT NULL,
        year_level    VARCHAR(30)   NOT NULL,
        term_label    VARCHAR(30)   NOT NULL,
        subject_code  VARCHAR(50)   NOT NULL,
        description   VARCHAR(255)  NOT NULL,
        units         DECIMAL(4,1)  NOT NULL DEFAULT 3,
        sort_order    INT           NOT NULL DEFAULT 0,
        created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_programsubject_program FOREIGN KEY (program_id) REFERENCES programs(id) ON DELETE CASCADE,
        INDEX idx_programsubject_program (program_id),
        INDEX idx_programsubject_term (program_id, year_level, term_label)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'enrollees', "
    CREATE TABLE IF NOT EXISTS enrollees (
        id                      INT AUTO_INCREMENT PRIMARY KEY,
        student_id              VARCHAR(20)   DEFAULT NULL,
        surname                 VARCHAR(100)  NOT NULL,
        first_name              VARCHAR(100)  NOT NULL,
        middle_name             VARCHAR(100)  DEFAULT NULL,
        suffix                  VARCHAR(20)   DEFAULT NULL,
        suffix_position         VARCHAR(12)   NOT NULL DEFAULT 'separate',
        sex                     ENUM('Male','Female') DEFAULT NULL,
        civil_status            ENUM('Single','Married','Widowed','Separated') DEFAULT NULL,
        student_type            ENUM('Regular','Transferee','Irregular') DEFAULT NULL,
        birth_date              DATE          DEFAULT NULL,
        birth_place             VARCHAR(255)  DEFAULT NULL,
        address                 VARCHAR(255)  DEFAULT NULL,
        mobile_number           VARCHAR(20)   DEFAULT NULL,
        guardian_name           VARCHAR(150)  DEFAULT NULL,
        email                   VARCHAR(254)  DEFAULT NULL,
        prev_school_junior_hs   VARCHAR(255)  DEFAULT NULL,
        prev_school_senior_hs   VARCHAR(255)  DEFAULT NULL,
        junior_hs_graduated     CHAR(9)       DEFAULT NULL,
        senior_hs_graduated     CHAR(9)       DEFAULT NULL,
        program_code            VARCHAR(30)   DEFAULT NULL,
        department_id           INT           DEFAULT NULL,
        course                  VARCHAR(150)  DEFAULT NULL,
        major                   VARCHAR(150)  DEFAULT NULL,
        year_level              VARCHAR(30)   DEFAULT NULL,
        trimester                VARCHAR(30)   DEFAULT NULL,
        school_year             VARCHAR(20)   DEFAULT NULL,
        subjects_json           TEXT          DEFAULT NULL,
        enrolled_by_user_id     INT           DEFAULT NULL,
        status                  ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved',
        approved_by_user_id     INT           DEFAULT NULL,
        approved_at             DATETIME      DEFAULT NULL,
        approval_remarks        VARCHAR(255)  DEFAULT NULL,
        archived_at             DATETIME      DEFAULT NULL,
        archived_by_user_id     INT           DEFAULT NULL,
        archive_reason          VARCHAR(255)  DEFAULT NULL,
        created_at              TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_enrollee_user       FOREIGN KEY (enrolled_by_user_id)  REFERENCES users(id)       ON DELETE SET NULL,
        CONSTRAINT fk_enrollee_approver   FOREIGN KEY (approved_by_user_id)  REFERENCES users(id)       ON DELETE SET NULL,
        CONSTRAINT fk_enrollee_archiver   FOREIGN KEY (archived_by_user_id)  REFERENCES users(id)       ON DELETE SET NULL,
        CONSTRAINT fk_enrollee_department FOREIGN KEY (department_id)       REFERENCES departments(id) ON DELETE SET NULL,
        INDEX idx_enrollee_created (created_at),
        INDEX idx_enrollee_name (surname, first_name),
        INDEX idx_enrollee_student_id (student_id),
        INDEX idx_enrollee_department (department_id),
        INDEX idx_enrollee_status (status),
        INDEX idx_enrollee_archived (archived_at),
        INDEX idx_enrollee_student_latest (student_id, id),
        INDEX idx_enrollee_active_student (archived_at, status, student_id, id),
        INDEX idx_enrollee_dept_active_student (department_id, archived_at, status, student_id, id),
        UNIQUE KEY uq_enrollee_student_term (student_id, school_year, trimester)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'enrollment_subjects', "
    CREATE TABLE IF NOT EXISTS enrollment_subjects (
        id                  INT AUTO_INCREMENT PRIMARY KEY,
        enrollment_id       INT NOT NULL,
        course_code         VARCHAR(50)  DEFAULT NULL,
        description         VARCHAR(255) NOT NULL,
        units               DECIMAL(6,2) NOT NULL DEFAULT 0,
        hidden_on_print     TINYINT(1)   NOT NULL DEFAULT 0,
        created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT fk_es_enrollment FOREIGN KEY (enrollment_id) REFERENCES enrollees(id) ON DELETE CASCADE,
        INDEX idx_es_enrollment (enrollment_id),
        INDEX idx_es_code (course_code)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'grades', "
    CREATE TABLE IF NOT EXISTS grades (
        id                    INT AUTO_INCREMENT PRIMARY KEY,
        enrollment_subject_id INT NOT NULL,
        grade                 VARCHAR(20) DEFAULT NULL,
        entered_by_user_id    INT DEFAULT NULL,
        entered_at            DATETIME DEFAULT NULL,
        updated_by_user_id    INT DEFAULT NULL,
        updated_at            DATETIME DEFAULT NULL,
        CONSTRAINT fk_grade_subject     FOREIGN KEY (enrollment_subject_id) REFERENCES enrollment_subjects(id) ON DELETE CASCADE,
        CONSTRAINT fk_grade_entered_by  FOREIGN KEY (entered_by_user_id)    REFERENCES users(id) ON DELETE SET NULL,
        CONSTRAINT fk_grade_updated_by  FOREIGN KEY (updated_by_user_id)    REFERENCES users(id) ON DELETE SET NULL,
        UNIQUE KEY uq_grade_subject (enrollment_subject_id),
        INDEX idx_grade_value (grade),
        INDEX idx_grade_subject_updated (enrollment_subject_id, updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'subject_grade_locks', "
    CREATE TABLE IF NOT EXISTS subject_grade_locks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        school_year VARCHAR(20) NOT NULL,
        trimester VARCHAR(30) NOT NULL,
        course_code VARCHAR(50) NOT NULL DEFAULT '',
        description VARCHAR(255) NOT NULL,
        locked_by_user_id INT DEFAULT NULL,
        locked_at DATETIME DEFAULT NULL,
        unlocked_by_user_id INT DEFAULT NULL,
        unlocked_at DATETIME DEFAULT NULL,
        CONSTRAINT fk_sgl_locked_by   FOREIGN KEY (locked_by_user_id)   REFERENCES users(id) ON DELETE SET NULL,
        CONSTRAINT fk_sgl_unlocked_by FOREIGN KEY (unlocked_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
        UNIQUE KEY uq_sgl_subject (school_year, trimester, course_code, description),
        INDEX idx_sgl_term (school_year, trimester),
        INDEX idx_sgl_locked (locked_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'record_corrections', "
    CREATE TABLE IF NOT EXISTS record_corrections (
        id INT AUTO_INCREMENT PRIMARY KEY,
        enrollment_id INT NOT NULL,
        student_id VARCHAR(50) DEFAULT NULL,
        correction_type VARCHAR(30) NOT NULL DEFAULT 'SUBJECT_GRADE',
        reason VARCHAR(500) NOT NULL,
        changes_json MEDIUMTEXT NOT NULL,
        status ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
        requested_by_user_id INT DEFAULT NULL,
        requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        reviewed_by_user_id INT DEFAULT NULL,
        reviewed_at DATETIME DEFAULT NULL,
        review_remarks VARCHAR(500) DEFAULT NULL,
        CONSTRAINT fk_rc_enrollment   FOREIGN KEY (enrollment_id)       REFERENCES enrollees(id) ON DELETE RESTRICT,
        CONSTRAINT fk_rc_requested_by FOREIGN KEY (requested_by_user_id) REFERENCES users(id)     ON DELETE SET NULL,
        CONSTRAINT fk_rc_reviewed_by  FOREIGN KEY (reviewed_by_user_id)  REFERENCES users(id)     ON DELETE SET NULL,
        INDEX idx_rc_enrollment (enrollment_id),
        INDEX idx_rc_student (student_id),
        INDEX idx_rc_status (status),
        INDEX idx_rc_requested (requested_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'record_correction_items', "
    CREATE TABLE IF NOT EXISTS record_correction_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        correction_id INT NOT NULL,
        entity_type VARCHAR(40) NOT NULL,
        entity_id INT DEFAULT NULL,
        field_name VARCHAR(80) NOT NULL,
        old_value TEXT DEFAULT NULL,
        new_value TEXT DEFAULT NULL,
        CONSTRAINT fk_rci_correction FOREIGN KEY (correction_id) REFERENCES record_corrections(id) ON DELETE CASCADE,
        INDEX idx_rci_correction (correction_id),
        INDEX idx_rci_entity (entity_type, entity_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'certificates', "
    CREATE TABLE IF NOT EXISTS certificates (
        id                 INT AUTO_INCREMENT PRIMARY KEY,
        certificate_type   VARCHAR(30)   NOT NULL,
        student_name       VARCHAR(150)  NOT NULL,
        student_id         VARCHAR(50)   NOT NULL,
        program            VARCHAR(50)   NOT NULL,
        year_level         VARCHAR(30)   NOT NULL,
        trimester          VARCHAR(30)   NOT NULL,
        academic_year      VARCHAR(20)   NOT NULL,
        enrollment_date    DATE          DEFAULT NULL,
        status             VARCHAR(30)   DEFAULT NULL,
        or_number          VARCHAR(50)   DEFAULT NULL,
        total_units        DECIMAL(6,2)  DEFAULT NULL,
        gwa                DECIMAL(4,2)  DEFAULT NULL,
        subjects_json      TEXT          DEFAULT NULL,
        prepared_by        VARCHAR(50)   DEFAULT NULL,
        issued_by_user_id  INT           DEFAULT NULL,
        created_at         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        verify_token       VARCHAR(40)   DEFAULT NULL,
        CONSTRAINT fk_certificates_user FOREIGN KEY (issued_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_cert_student (student_id),
        INDEX idx_cert_created (created_at),
        UNIQUE KEY uq_cert_verify_token (verify_token)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

/* QR verification (Certificate of Enrollment / Registration): para sa
   existing database na walang verify_token pa. */
ascb_add_column($pdo, 'certificates', 'verify_token', "verify_token VARCHAR(40) DEFAULT NULL", $log);
ascb_add_index($pdo, 'certificates', 'uq_cert_verify_token', "UNIQUE KEY uq_cert_verify_token (verify_token)", $log);

ascb_create_table($pdo, 'form137_requests', "
    CREATE TABLE IF NOT EXISTS form137_requests (
        id                    INT AUTO_INCREMENT PRIMARY KEY,
        request_date          DATE          DEFAULT NULL,
        school_name           VARCHAR(255)  NOT NULL,
        school_address        VARCHAR(255)  DEFAULT NULL,
        first_request         TINYINT(1)    NOT NULL DEFAULT 0,
        second_request        TINYINT(1)    NOT NULL DEFAULT 0,
        urgent_request        TINYINT(1)    NOT NULL DEFAULT 0,
        bearer_request        TINYINT(1)    NOT NULL DEFAULT 0,
        copy_for_ascb         TINYINT(1)    NOT NULL DEFAULT 0,
        students_json         TEXT          NOT NULL,
        requested_by_user_id  INT           DEFAULT NULL,
        created_at            TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_f137_user FOREIGN KEY (requested_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_f137_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'document_transactions', "
    CREATE TABLE IF NOT EXISTS document_transactions (
        id                   INT AUTO_INCREMENT PRIMARY KEY,
        direction            VARCHAR(10)   NOT NULL,
        document_name        VARCHAR(255)  NOT NULL,
        party_name           VARCHAR(255)  NOT NULL,
        transaction_date     DATE          DEFAULT NULL,
        remarks              VARCHAR(500)  DEFAULT NULL,
        handled_by_user_id   INT           DEFAULT NULL,
        created_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_doctx_user FOREIGN KEY (handled_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_doctx_created (created_at),
        INDEX idx_doctx_direction (direction)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'document_transaction_files', "
    CREATE TABLE IF NOT EXISTS document_transaction_files (
        id                   INT AUTO_INCREMENT PRIMARY KEY,
        transaction_id       INT           NOT NULL,
        original_filename    VARCHAR(255)  NOT NULL,
        stored_filename      VARCHAR(255)  NOT NULL,
        filesize_bytes       BIGINT        DEFAULT NULL,
        created_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_doctxfile_tx FOREIGN KEY (transaction_id) REFERENCES document_transactions(id) ON DELETE CASCADE,
        INDEX idx_doctxfile_tx (transaction_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'approved_so', "
    CREATE TABLE IF NOT EXISTS approved_so (
        id                   INT AUTO_INCREMENT PRIMARY KEY,
        name                 VARCHAR(255)  NOT NULL,
        stored_filename      VARCHAR(255)  NOT NULL,
        original_filename    VARCHAR(255)  NOT NULL,
        filesize_bytes       BIGINT        DEFAULT NULL,
        uploaded_by_user_id  INT           DEFAULT NULL,
        created_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_approvedso_user FOREIGN KEY (uploaded_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_approvedso_created (created_at),
        INDEX idx_approvedso_name (name),
        INDEX idx_approvedso_original_filename (original_filename)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'activity_log', "
    CREATE TABLE IF NOT EXISTS activity_log (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        user_id       INT           DEFAULT NULL,
        display_name  VARCHAR(100)  DEFAULT NULL,
        role          VARCHAR(50)   DEFAULT NULL,
        action        VARCHAR(50)   NOT NULL,
        entity_type   VARCHAR(30)   DEFAULT NULL,
        entity_label  VARCHAR(255)  DEFAULT NULL,
        details       VARCHAR(500)  DEFAULT NULL,
        created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_activitylog_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_activitylog_created (created_at),
        INDEX idx_activitylog_action (action)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'student_id_sequences', "
    CREATE TABLE IF NOT EXISTS student_id_sequences (
        year_key VARCHAR(4) PRIMARY KEY,
        next_number INT NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'login_attempts', "
    CREATE TABLE IF NOT EXISTS login_attempts (
        username VARCHAR(50) PRIMARY KEY,
        failed_count INT NOT NULL DEFAULT 0,
        first_failed_at DATETIME DEFAULT NULL,
        locked_until DATETIME DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'backup_history', "
    CREATE TABLE IF NOT EXISTS backup_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        backup_type VARCHAR(30) NOT NULL,
        department_id INT DEFAULT NULL,
        school_year VARCHAR(20) DEFAULT NULL,
        term_label VARCHAR(30) DEFAULT NULL,
        filename VARCHAR(255) NOT NULL,
        created_by_user_id INT DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_backup_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
        CONSTRAINT fk_backup_user       FOREIGN KEY (created_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_backup_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'student_master', "
    CREATE TABLE IF NOT EXISTS student_master (
        id                 INT AUTO_INCREMENT PRIMARY KEY,
        student_id         VARCHAR(50)  NOT NULL,
        surname            VARCHAR(100) NOT NULL,
        first_name         VARCHAR(100) NOT NULL,
        middle_name        VARCHAR(100) DEFAULT NULL,
        suffix             VARCHAR(20)  DEFAULT NULL,
        suffix_position    VARCHAR(12)  NOT NULL DEFAULT 'separate',
        sex                ENUM('Male','Female') DEFAULT NULL,
        civil_status       ENUM('Single','Married','Widowed','Separated') DEFAULT NULL,
        birth_date         DATE         DEFAULT NULL,
        birthplace         VARCHAR(255) DEFAULT NULL,
        nationality        VARCHAR(80)  DEFAULT NULL,
        address            VARCHAR(255) DEFAULT NULL,
        mobile_number      VARCHAR(20)  DEFAULT NULL,
        email              VARCHAR(254) DEFAULT NULL,
        guardian_name      VARCHAR(150) DEFAULT NULL,
        guardian_contact   VARCHAR(50)  DEFAULT NULL,
        emergency_contact  VARCHAR(150) DEFAULT NULL,
        profile_photo      VARCHAR(255) DEFAULT NULL,
        active             TINYINT(1)   NOT NULL DEFAULT 1,
        created_at         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        updated_by         INT          DEFAULT NULL,
        UNIQUE KEY uq_sm_student_id (student_id),
        INDEX idx_sm_name (surname, first_name),
        INDEX idx_sm_active (active),
        CONSTRAINT fk_sm_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'student_name_history', "
    CREATE TABLE IF NOT EXISTS student_name_history (
        id                    INT AUTO_INCREMENT PRIMARY KEY,
        student_id            VARCHAR(50)  NOT NULL,
        previous_surname      VARCHAR(100) NOT NULL,
        previous_first_name   VARCHAR(100) NOT NULL,
        previous_middle_name  VARCHAR(100) DEFAULT NULL,
        previous_suffix       VARCHAR(20)  DEFAULT NULL,
        previous_suffix_position VARCHAR(12) NOT NULL DEFAULT 'separate',
        new_surname           VARCHAR(100) NOT NULL,
        new_first_name        VARCHAR(100) NOT NULL,
        new_middle_name       VARCHAR(100) DEFAULT NULL,
        new_suffix            VARCHAR(20)  DEFAULT NULL,
        new_suffix_position   VARCHAR(12)  NOT NULL DEFAULT 'separate',
        reason                VARCHAR(255) NOT NULL,
        updated_by            INT          DEFAULT NULL,
        updated_at            TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_snh_student (student_id, id),
        INDEX idx_snh_prev_surname (previous_surname),
        CONSTRAINT fk_snh_student    FOREIGN KEY (student_id) REFERENCES student_master(student_id) ON DELETE RESTRICT ON UPDATE RESTRICT,
        CONSTRAINT fk_snh_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_out("");
ascb_out("--- Tables: " . count($log) . " checked/created ---");
foreach ($log as $l) ascb_out("  " . $l);

// =======================================================================
// 4. BACKWARD-COMPATIBILITY — magdagdag ng mga column/index/FK na
//    dinagdag sa paglipas ng panahon ng mga naunang migration files,
//    PARA SA MGA TABLE NA NAUNA NANG NAGAWA (mas lumang install na
//    hindi pa nakatakbo ang lahat ng naunang migration). Kung bagong
//    install/fresh na table, wala nang gagawin dito dahil kasama na
//    ang lahat sa CREATE TABLE sa itaas.
// =======================================================================
$log2 = array();

// ---- users ----
ascb_add_column($pdo, 'users', 'department_id', "department_id INT DEFAULT NULL AFTER role", $log2);
ascb_add_column($pdo, 'users', 'student_id', "student_id VARCHAR(50) DEFAULT NULL AFTER department_id", $log2);
ascb_add_column($pdo, 'users', 'must_change_password', "must_change_password TINYINT(1) NOT NULL DEFAULT 0", $log2);
ascb_add_column($pdo, 'users', 'temp_password_expires_at', "temp_password_expires_at DATETIME DEFAULT NULL", $log2);
ascb_add_column($pdo, 'users', 'password_changed_at', "password_changed_at DATETIME DEFAULT NULL", $log2);
ascb_add_index($pdo, 'users', 'uq_users_student_id', "UNIQUE KEY uq_users_student_id (student_id)", $log2);
ascb_add_index($pdo, 'users', 'idx_users_department', "INDEX idx_users_department (department_id)", $log2);
ascb_add_index($pdo, 'users', 'idx_users_dept_role_active', "INDEX idx_users_dept_role_active (department_id, role, is_active)", $log2);
ascb_add_fk($pdo, 'users', 'fk_users_department', "CONSTRAINT fk_users_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL", $log2);

// ---- programs ----
ascb_add_column($pdo, 'programs', 'department_id', "department_id INT DEFAULT NULL AFTER id", $log2);
ascb_add_index($pdo, 'programs', 'idx_programs_department', "INDEX idx_programs_department (department_id)", $log2);
ascb_add_index($pdo, 'programs', 'idx_programs_dept_active', "INDEX idx_programs_dept_active (department_id, is_active, code)", $log2);
ascb_add_fk($pdo, 'programs', 'fk_programs_department', "CONSTRAINT fk_programs_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL", $log2);

// ---- program_subjects ----
ascb_add_index($pdo, 'program_subjects', 'idx_programsubject_lookup', "INDEX idx_programsubject_lookup (program_id, year_level, term_label, sort_order)", $log2);

// ---- enrollees : lahat ng column na naidagdag ng magkakahiwalay na migration ----
ascb_add_column($pdo, 'enrollees', 'student_id', "student_id VARCHAR(20) DEFAULT NULL AFTER id", $log2);
ascb_add_column($pdo, 'enrollees', 'sex', "sex ENUM('Male','Female') DEFAULT NULL AFTER middle_name", $log2);
ascb_add_column($pdo, 'enrollees', 'civil_status', "civil_status ENUM('Single','Married','Widowed','Separated') DEFAULT NULL AFTER sex", $log2);
ascb_add_column($pdo, 'enrollees', 'student_type', "student_type ENUM('Regular','Transferee','Irregular') DEFAULT NULL AFTER civil_status", $log2);
ascb_add_column($pdo, 'enrollees', 'birth_place', "birth_place VARCHAR(255) DEFAULT NULL AFTER birth_date", $log2);
ascb_add_column($pdo, 'enrollees', 'mobile_number', "mobile_number VARCHAR(20) DEFAULT NULL AFTER address", $log2);
ascb_add_column($pdo, 'enrollees', 'guardian_name', "guardian_name VARCHAR(150) DEFAULT NULL AFTER mobile_number", $log2);
ascb_add_column($pdo, 'enrollees', 'email', "email VARCHAR(254) DEFAULT NULL AFTER guardian_name", $log2);
ascb_add_column($pdo, 'enrollees', 'junior_hs_graduated', "junior_hs_graduated CHAR(9) DEFAULT NULL AFTER prev_school_senior_hs", $log2);
ascb_add_column($pdo, 'enrollees', 'senior_hs_graduated', "senior_hs_graduated CHAR(9) DEFAULT NULL AFTER junior_hs_graduated", $log2);
ascb_add_column($pdo, 'enrollees', 'program_code', "program_code VARCHAR(30) DEFAULT NULL AFTER senior_hs_graduated", $log2);
ascb_add_column($pdo, 'enrollees', 'department_id', "department_id INT DEFAULT NULL AFTER program_code", $log2);
ascb_add_column($pdo, 'enrollees', 'course', "course VARCHAR(150) DEFAULT NULL AFTER department_id", $log2);
ascb_add_column($pdo, 'enrollees', 'major', "major VARCHAR(150) DEFAULT NULL AFTER course", $log2);
ascb_add_column($pdo, 'enrollees', 'year_level', "year_level VARCHAR(30) DEFAULT NULL AFTER major", $log2);
ascb_add_column($pdo, 'enrollees', 'trimester', "trimester VARCHAR(30) DEFAULT NULL AFTER year_level", $log2);
ascb_add_column($pdo, 'enrollees', 'school_year', "school_year VARCHAR(20) DEFAULT NULL AFTER trimester", $log2);
ascb_add_column($pdo, 'enrollees', 'subjects_json', "subjects_json TEXT DEFAULT NULL AFTER school_year", $log2);
ascb_add_column($pdo, 'enrollees', 'status', "status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved' AFTER enrolled_by_user_id", $log2);
ascb_add_column($pdo, 'enrollees', 'approved_by_user_id', "approved_by_user_id INT DEFAULT NULL AFTER status", $log2);
ascb_add_column($pdo, 'enrollees', 'approved_at', "approved_at DATETIME DEFAULT NULL AFTER approved_by_user_id", $log2);
ascb_add_column($pdo, 'enrollees', 'approval_remarks', "approval_remarks VARCHAR(255) DEFAULT NULL AFTER approved_at", $log2);
ascb_add_column($pdo, 'enrollees', 'archived_at', "archived_at DATETIME DEFAULT NULL AFTER approval_remarks", $log2);
ascb_add_column($pdo, 'enrollees', 'archived_by_user_id', "archived_by_user_id INT DEFAULT NULL AFTER archived_at", $log2);
ascb_add_column($pdo, 'enrollees', 'archive_reason', "archive_reason VARCHAR(255) DEFAULT NULL AFTER archived_by_user_id", $log2);

if (ascb_table_exists($pdo, 'enrollees')) {
    try { $pdo->exec("ALTER TABLE enrollees MODIFY student_id VARCHAR(20) NULL"); } catch (Throwable $e) { /* harmless */ }
}

ascb_add_index($pdo, 'enrollees', 'idx_enrollee_student_id', "INDEX idx_enrollee_student_id (student_id)", $log2);
ascb_add_index($pdo, 'enrollees', 'idx_enrollee_department', "INDEX idx_enrollee_department (department_id)", $log2);
ascb_add_index($pdo, 'enrollees', 'idx_enrollee_status', "INDEX idx_enrollee_status (status)", $log2);
ascb_add_index($pdo, 'enrollees', 'idx_enrollee_archived', "INDEX idx_enrollee_archived (archived_at)", $log2);
ascb_add_index($pdo, 'enrollees', 'idx_enrollee_student_latest', "INDEX idx_enrollee_student_latest (student_id, id)", $log2);
ascb_add_index($pdo, 'enrollees', 'idx_enrollee_active_student', "INDEX idx_enrollee_active_student (archived_at, status, student_id, id)", $log2);
ascb_add_index($pdo, 'enrollees', 'idx_enrollee_dept_active_student', "INDEX idx_enrollee_dept_active_student (department_id, archived_at, status, student_id, id)", $log2);
ascb_add_index($pdo, 'enrollees', 'idx_enr_active_latest', "INDEX idx_enr_active_latest (student_id, archived_at, status, id)", $log2);
ascb_add_index($pdo, 'enrollees', 'idx_enr_program_term', "INDEX idx_enr_program_term (program_code, school_year, trimester, id)", $log2);
ascb_add_index($pdo, 'enrollees', 'idx_enr_status_created', "INDEX idx_enr_status_created (status, archived_at, created_at, id)", $log2);
ascb_add_index($pdo, 'enrollees', 'idx_enrollee_scope_created', "INDEX idx_enrollee_scope_created (archived_at, status, created_at, id)", $log2);
ascb_add_index($pdo, 'enrollees', 'idx_enrollee_dept_scope_created', "INDEX idx_enrollee_dept_scope_created (department_id, archived_at, status, created_at, id)", $log2);

ascb_add_fk($pdo, 'enrollees', 'fk_enrollee_department', "CONSTRAINT fk_enrollee_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL", $log2);
ascb_add_fk($pdo, 'enrollees', 'fk_enrollee_approver', "CONSTRAINT fk_enrollee_approver FOREIGN KEY (approved_by_user_id) REFERENCES users(id) ON DELETE SET NULL", $log2);
ascb_add_fk($pdo, 'enrollees', 'fk_enrollee_archiver', "CONSTRAINT fk_enrollee_archiver FOREIGN KEY (archived_by_user_id) REFERENCES users(id) ON DELETE SET NULL", $log2);

// uq_enrollee_student_term (3-col, the real concurrency guard) — only add
// when it can be added without conflict; otherwise report and let the
// registrar clean up duplicates first (never delete rows automatically).
if (ascb_table_exists($pdo, 'enrollees') && !ascb_idx_exists($pdo, 'enrollees', 'uq_enrollee_student_term')) {
    $dupRow = (int) $pdo->query("SELECT COUNT(*) FROM (
            SELECT 1 FROM enrollees GROUP BY student_id, school_year, trimester HAVING COUNT(*) > 1
        ) d")->fetchColumn();
    if ($dupRow === 0) {
        try {
            $pdo->exec("ALTER TABLE enrollees ADD UNIQUE KEY uq_enrollee_student_term (student_id, school_year, trimester)");
            $log2[] = "ADD    unique  `enrollees.uq_enrollee_student_term`";
        } catch (Throwable $e) {
            $log2[] = "WARN   unique  `enrollees.uq_enrollee_student_term` NOT added (" . $e->getMessage() . ")";
        }
    } else {
        $log2[] = "WARN   unique  `enrollees.uq_enrollee_student_term` NOT added — {$dupRow} duplicate student/term group(s) exist. Review with the existing database/fix_new_term_duplicates.php helper, then re-run this migration.";
    }
}

// uq_enrollee_term (4-col variant incl. program_code, from the large-data
// hardening migration) — same non-destructive guard.
if (ascb_table_exists($pdo, 'enrollees') && !ascb_idx_exists($pdo, 'enrollees', 'uq_enrollee_term')) {
    $dupRow2 = (int) $pdo->query("SELECT COUNT(*) FROM (
            SELECT 1 FROM enrollees WHERE archived_at IS NULL
             GROUP BY student_id, school_year, trimester, program_code HAVING COUNT(*) > 1
        ) d")->fetchColumn();
    if ($dupRow2 === 0) {
        try {
            $pdo->exec("ALTER TABLE enrollees ADD UNIQUE KEY uq_enrollee_term (student_id, school_year, trimester, program_code)");
            $log2[] = "ADD    unique  `enrollees.uq_enrollee_term`";
        } catch (Throwable $e) {
            $log2[] = "WARN   unique  `enrollees.uq_enrollee_term` NOT added (" . $e->getMessage() . ")";
        }
    } else {
        $log2[] = "WARN   unique  `enrollees.uq_enrollee_term` NOT added — {$dupRow2} duplicate active student/term/program group(s) exist.";
    }
}

// ---- enrollment_subjects ----
ascb_add_column($pdo, 'enrollment_subjects', 'hidden_on_print', "hidden_on_print TINYINT(1) NOT NULL DEFAULT 0 AFTER units", $log2);
ascb_add_index($pdo, 'enrollment_subjects', 'idx_es_enrollment_id', "INDEX idx_es_enrollment_id (enrollment_id, id)", $log2);
ascb_add_index($pdo, 'enrollment_subjects', 'idx_es_enrollment_code_desc', "INDEX idx_es_enrollment_code_desc (enrollment_id, course_code, description(100))", $log2);

// ---- grades ----
ascb_add_index($pdo, 'grades', 'idx_grade_subject_updated', "INDEX idx_grade_subject_updated (enrollment_subject_id, updated_at)", $log2);
ascb_add_index($pdo, 'grades', 'idx_grade_updated', "INDEX idx_grade_updated (updated_at)", $log2);
ascb_add_index($pdo, 'grades', 'idx_grades_updated', "INDEX idx_grades_updated (updated_at)", $log2);

// ---- activity_log ----
ascb_add_index($pdo, 'activity_log', 'idx_activitylog_created_id', "INDEX idx_activitylog_created_id (created_at, id)", $log2);
ascb_add_index($pdo, 'activity_log', 'idx_activity_created_id', "INDEX idx_activity_created_id (created_at, id)", $log2);
ascb_add_index($pdo, 'activity_log', 'idx_activity_user_created', "INDEX idx_activity_user_created (user_id, created_at, id)", $log2);

// ---- document_transactions / files ----
ascb_add_index($pdo, 'document_transactions', 'idx_doctx_created_id', "INDEX idx_doctx_created_id (created_at, id)", $log2);
ascb_add_index($pdo, 'document_transactions', 'idx_doctx_direction_created', "INDEX idx_doctx_direction_created (direction, created_at, id)", $log2);
ascb_add_index($pdo, 'document_transaction_files', 'idx_doctxfile_tx_id', "INDEX idx_doctxfile_tx_id (transaction_id, id)", $log2);

// ---- approved_so ----
ascb_add_index($pdo, 'approved_so', 'idx_approvedso_created_id', "INDEX idx_approvedso_created_id (created_at, id)", $log2);
ascb_add_index($pdo, 'approved_so', 'idx_approvedso_original', "INDEX idx_approvedso_original (original_filename)", $log2);
ascb_add_index($pdo, 'approved_so', 'idx_approvedso_original_filename', "INDEX idx_approvedso_original_filename (original_filename)", $log2);


// ---- login_attempts ----
ascb_add_index($pdo, 'login_attempts', 'idx_login_locked', "INDEX idx_login_locked (locked_until)", $log2);

// ---- users: unique username (safe add — never renames/guesses data) ----
if (ascb_table_exists($pdo, 'users') && !ascb_idx_exists($pdo, 'users', 'uniq_username')) {
    $dupUser = (int) $pdo->query("SELECT COUNT(*) FROM (SELECT username FROM users GROUP BY username HAVING COUNT(*) > 1) d")->fetchColumn();
    if ($dupUser === 0) {
        try {
            $pdo->exec("ALTER TABLE users ADD UNIQUE KEY uniq_username (username)");
            $log2[] = "ADD    unique  `users.uniq_username`";
        } catch (Throwable $e) {
            $log2[] = "WARN   unique  `users.uniq_username` NOT added (" . $e->getMessage() . ")";
        }
    } else {
        $log2[] = "WARN   unique  `users.uniq_username` NOT added — {$dupUser} duplicate username(s) exist. Review with the existing database/migrate_unique_usernames_module.php helper, then re-run this migration.";
    }
}

ascb_out("");
ascb_out("--- Backward-compatibility columns/indexes/FKs: " . count($log2) . " checked ---");
foreach ($log2 as $l) ascb_out("  " . $l);

// =======================================================================
// 5. DATA BACKFILL — walang record na tinatanggal, UPDATE/INSERT IGNORE
//    lang ang ginagawa, at laging naka-guard sa "kung kulang lang".
// =======================================================================
$log3 = array();

// 5a. department_id backfill mula sa mapping ng programs.
if (ascb_table_exists($pdo, 'enrollees') && ascb_col_exists($pdo, 'enrollees', 'department_id')
    && ascb_table_exists($pdo, 'programs') && ascb_col_exists($pdo, 'programs', 'department_id')) {
    $n = $pdo->exec("UPDATE enrollees e INNER JOIN programs p ON UPPER(TRIM(p.code)) = UPPER(TRIM(e.program_code))
                      SET e.department_id = p.department_id
                      WHERE e.department_id IS NULL AND p.department_id IS NOT NULL");
    $log3[] = "Backfilled enrollees.department_id for " . (int)$n . " row(s).";
}

// 5b. student_id backfill — isang Student ID bawat estudyante (grouped by pangalan).
if (ascb_table_exists($pdo, 'enrollees') && ascb_col_exists($pdo, 'enrollees', 'student_id')) {
    $rows = $pdo->query(
        "SELECT id, surname, first_name, middle_name, created_at FROM enrollees
          WHERE student_id IS NULL OR student_id = '' ORDER BY created_at ASC, id ASC"
    )->fetchAll();

    if ($rows) {
        $groups = array();
        foreach ($rows as $row) {
            $key = mb_strtolower(trim($row['surname'])) . '|' . mb_strtolower(trim($row['first_name'])) . '|' . mb_strtolower(trim((string)$row['middle_name']));
            $groups[$key][] = $row;
        }

        $yearMax = array();
        $stmt = $pdo->query("SELECT student_id FROM enrollees WHERE student_id LIKE '____-%'");
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $sid) {
            if (preg_match('/^(\d{4})-(\d+)$/', $sid, $m)) {
                $y = $m[1]; $n = (int)$m[2];
                if (!isset($yearMax[$y]) || $n > $yearMax[$y]) $yearMax[$y] = $n;
            }
        }

        $updateStmt = $pdo->prepare("UPDATE enrollees SET student_id = ? WHERE id = ?");
        $backfilled = 0;
        foreach ($groups as $terms) {
            $first = $terms[0];
            $year = $first['created_at'] ? date('Y', strtotime($first['created_at'])) : date('Y');
            if (!isset($yearMax[$year])) $yearMax[$year] = 0;
            $yearMax[$year] += 1;
            $studentId = $year . '-' . str_pad($yearMax[$year], 5, '0', STR_PAD_LEFT);
            foreach ($terms as $termRow) {
                $updateStmt->execute(array($studentId, $termRow['id']));
                $backfilled++;
            }
        }
        $log3[] = "Backfilled enrollees.student_id for {$backfilled} row(s) that had none.";
    }
}

// 5c. status backfill (defensive — ADD COLUMN ... NOT NULL DEFAULT 'approved'
//     already fills existing rows automatically, this just covers any edge case).
if (ascb_table_exists($pdo, 'enrollees') && ascb_col_exists($pdo, 'enrollees', 'status')) {
    $n = $pdo->exec("UPDATE enrollees SET status = 'approved' WHERE status IS NULL OR status = ''");
    if ($n > 0) $log3[] = "Backfilled enrollees.status ('approved') for {$n} row(s).";
}

// 5d. student_master — one row per existing Student ID, from that student's
//     most recent enrollment row. Never overwrites an existing master row.
if (ascb_table_exists($pdo, 'student_master') && ascb_table_exists($pdo, 'enrollees') && ascb_col_exists($pdo, 'enrollees', 'student_id')) {
    $n = $pdo->exec("INSERT IGNORE INTO student_master
            (student_id, surname, first_name, middle_name, sex, civil_status, birth_date,
             birthplace, address, mobile_number, email, guardian_name, nationality)
        SELECT e.student_id, e.surname, e.first_name, e.middle_name, e.sex, e.civil_status, e.birth_date,
               e.birth_place, e.address, e.mobile_number, e.email, e.guardian_name, 'Filipino'
        FROM enrollees e
        INNER JOIN (
            SELECT student_id, MAX(id) AS max_id FROM enrollees
            WHERE student_id IS NOT NULL AND student_id <> '' GROUP BY student_id
        ) latest ON latest.max_id = e.id");
    $log3[] = "student_master: inserted {$n} new master record(s) from latest enrollment snapshot (existing rows untouched).";
}

ascb_out("");
ascb_out("--- Data backfill (no deletions, INSERT IGNORE / UPDATE-only-when-blank) ---");
foreach ($log3 as $l) ascb_out("  " . $l);

// =======================================================================
// 6. SEED / STARTER DATA — safe to re-run (ON DUPLICATE KEY UPDATE / INSERT IGNORE).
// =======================================================================
$log4 = array();

$schools = array(
    array('ANDRES SORIANO COLLEGES OF BISLIG, INC.', 'Mangagoy, Bislig City'),
    array('TABON M. ESTRELLA NATIONAL HIGH SCHOOL', 'Tabon, Bislig City'),
    array('STAND ALONE SENIOR HIGH SCHOOL', 'Comawas, Bislig City'),
    array('SOUTHERN TECHNOLOGICAL INSTITUTE OF THE PHILIPPINES, INC.', 'Andres Soriano Avenue, Mangagoy, Bislig City'),
    array('AGUSAN NATIONAL HIGH SCHOOL', 'Butuan City, Surigao del Sur'),
    array('BERNARDO D. CARPIO NATIONAL HIGH SCHOOL', 'Pioneer Village, Buhangin, Davao City'),
    array('BISLIG CITY NATIONAL HIGH SCHOOL', 'Purok 10 Villa Josefa Poblacion, Bislig City'),
    array('HINATUAN NATIONAL COMPREHENSIVE HIGH SCHOOL', 'Sto. Niño, Hinatuan, Surigao del Sur'),
    array('LAWIGAN NATIONAL HIGH SCHOOL', 'Lawigan, Bislig City'),
    array('LINGIG NATIONAL HIGH SCHOOL', 'Lingig 1 District'),
    array('MAHARLIKA NATIONAL HIGH SCHOOL', 'Maharlika, Bislig City'),
);
$insSchool = $pdo->prepare("INSERT INTO schools (name, address) VALUES (?, ?) ON DUPLICATE KEY UPDATE address = VALUES(address)");
foreach ($schools as $s) { $insSchool->execute($s); }
$log4[] = "Seeded/updated " . count($schools) . " starter school(s).";

$courses = array('BSIT', 'BSCS', 'BSIS', 'BEED', 'BSBA-MM', 'BSBA-FM', 'BSBA-HRDM', 'BSED-ENGLISH');
$insCourse = $pdo->prepare("INSERT INTO courses (name) VALUES (?) ON DUPLICATE KEY UPDATE name = VALUES(name)");
foreach ($courses as $c) { $insCourse->execute(array($c)); }
$log4[] = "Seeded/updated " . count($courses) . " starter course(s).";

$builtinPrograms = array(
    array('BSCS', 'Bachelor of Science in Computer Science', null),
    array('BSIS', 'Bachelor of Science in Information Systems', null),
    array('BSIT', 'Bachelor of Science in Information Technology', null),
    array('BSCRIM', 'Bachelor of Science in Criminology', null),
    array('BSA', 'Bachelor of Science in Accountancy', null),
    array('BSBA-FM', 'Bachelor of Science in Business Administration', 'Financial Management'),
    array('BSBA-HRDM', 'Bachelor of Science in Business Administration', 'Human Resource Development Management'),
    array('BSBA-MM', 'Bachelor of Science in Business Administration', 'Marketing Management'),
    array('BEED', 'Bachelor of Elementary Education', null),
    array('BSED-ENGLISH', 'Bachelor of Secondary Education', 'English'),
    array('BSED-MATH', 'Bachelor of Secondary Education', 'Mathematics'),
    array('BSED-SOCIAL', 'Bachelor of Secondary Education', 'Social Studies'),
);
$insProgram = $pdo->prepare("INSERT IGNORE INTO programs (code, course_name, major, term_type, is_active) VALUES (?, ?, ?, 'Trimester', 1)");
foreach ($builtinPrograms as $bp) { $insProgram->execute($bp); }
$log4[] = "Seeded (INSERT IGNORE) " . count($builtinPrograms) . " builtin program(s)/catalog code(s).";

// One-time bootstrap of starter user accounts — ONLY when `users` is
// completely empty, exactly like the original seed_users.php safety
// check. Never runs again once at least one account exists, so it can
// never overwrite or duplicate real accounts.
if (ascb_table_exists($pdo, 'users')) {
    $existingUsers = (int) $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($existingUsers === 0) {
        $staff = array(
            array('username' => 'rbamparo',    'display_name' => 'REYNALYN AMPARO',        'role' => 'ADMIN STAFF',      'prepared_by_code' => 'rbamparo'),
            array('username' => 'accastillo',  'display_name' => 'ARCHIE CASTILLO',        'role' => 'ADMIN STAFF',      'prepared_by_code' => 'accastillo'),
            array('username' => 'rmyasona',    'display_name' => 'R.M. SMITH YASOÑA',      'role' => 'ADMIN STAFF',      'prepared_by_code' => 'rmyasoña'),
            array('username' => 'francelmae',  'display_name' => 'FRANCEL MAE SALUBRE',    'role' => 'ADMIN STAFF',      'prepared_by_code' => 'francelmae'),
            array('username' => 'jgbontia',    'display_name' => 'JOSELITO BONTIA, MAEd',  'role' => 'UNIT HEAD',        'prepared_by_code' => 'jgbontia'),
            array('username' => 'rcaponong',   'display_name' => 'REBECCA CAPONONG, MAEd', 'role' => 'SCHOOL REGISTRAR', 'prepared_by_code' => 'rcaponong'),
        );
        $insUser = $pdo->prepare("INSERT INTO users (username, password_hash, display_name, role, prepared_by_code) VALUES (?, ?, ?, ?, ?)");
        $credentials = array();
        foreach ($staff as $s) {
            $password = rtrim(strtr(base64_encode(random_bytes(12)), '+/', '-_'), '=');
            $insUser->execute(array($s['username'], password_hash($password, PASSWORD_DEFAULT), $s['display_name'], $s['role'], $s['prepared_by_code']));
            $credentials[] = array('name' => $s['display_name'], 'username' => $s['username'], 'password' => $password);
        }
        $log4[] = "Bootstrapped " . count($credentials) . " starter user account(s) (users table was empty).";
        ascb_out("");
        ascb_out("!!! ONE-TIME BOOTSTRAP CREDENTIALS — SAVE THESE SECURELY, THEN CHANGE PASSWORD AFTER FIRST LOGIN !!!");
        foreach ($credentials as $c) {
            ascb_out("  " . str_pad($c['name'], 30) . str_pad($c['username'], 14) . $c['password']);
        }
    } else {
        $log4[] = "users table already has {$existingUsers} account(s) — starter account bootstrap skipped (no data touched).";
    }
}

ascb_out("");
ascb_out("--- Seed / starter data ---");
foreach ($log4 as $l) ascb_out("  " . $l);


// =======================================================================
// 7. CONSOLIDATED LEGACY DATA / CATALOG MIGRATIONS
// -----------------------------------------------------------------------
// Ang mga dating hiwalay na `migrate_*.php` ay isinama rito para ISANG
// migration file na lang ang kailangang patakbuhin.
//
// Mga kasama:
//   - unique username cleanup (safe known starter accounts only)
//   - numeric grade normalization
//   - enrollment program_code backfill
//   - suffix/PSA schema compatibility (schema already handled above)
//   - M.Ed. School Administration & Supervision curriculum
//   - protected-program flag used by the current program helpers
//
// Lahat ay idempotent. Walang DELETE/TRUNCATE at walang automatic archival
// ng enrollment duplicates. Kapag may ambiguous/conflicting legacy data,
// magre-report lang at hindi pipilitin ang pagbabago.
// =====================================================================

$log5 = array();

// ---- programs.is_protected (required by current program helpers) ----
if (ascb_table_exists($pdo, 'programs')) {
    ascb_add_column(
        $pdo,
        'programs',
        'is_protected',
        "is_protected TINYINT(1) NOT NULL DEFAULT 0 AFTER is_active",
        $log5
    );
}

// ---- Protected built-in program catalog + legacy curriculum seed ----
// Preserve the behavior of migrate_programs_db_only.php: built-in catalog
// codes are protected, and the bundled curriculum seed is inserted only when
// a program currently has no curriculum rows.
$builtinProtectedCodes = array(
    'BSCS','BSIS','BSIT','BSCRIM','BSA',
    'BSBA-FM','BSBA-HRDM','BSBA-MM',
    'BEED','BSED-ENGLISH','BSED-MATH','BSED-SOCIAL'
);
if (ascb_table_exists($pdo, 'programs') && ascb_col_exists($pdo, 'programs', 'is_protected')) {
    $marks = implode(',', array_fill(0, count($builtinProtectedCodes), '?'));
    try {
        $markProtected = $pdo->prepare(
            "UPDATE programs SET is_protected = 1 WHERE UPPER(code) IN ({$marks})"
        );
        $markProtected->execute($builtinProtectedCodes);
        $log5[] = "Protected built-in program catalog: " . count($builtinProtectedCodes) . " code(s).";
    } catch (Throwable $e) {
        $log5[] = "WARN   could not mark built-in programs protected: " . $e->getMessage();
    }

    $seedFile = __DIR__ . '/program_curriculum_seed.json';
    if (is_file($seedFile) && is_readable($seedFile)) {
        try {
            $seed = json_decode(
                file_get_contents($seedFile),
                true,
                512,
                defined('JSON_THROW_ON_ERROR') ? JSON_THROW_ON_ERROR : 0
            );
            if (!is_array($seed)) {
                throw new RuntimeException('Invalid curriculum seed JSON.');
            }

            $findProgram = $pdo->prepare(
                "SELECT id FROM programs WHERE UPPER(code) = UPPER(?) LIMIT 1"
            );
            $countSubjects = $pdo->prepare(
                "SELECT COUNT(*) FROM program_subjects WHERE program_id = ?"
            );
            $insertSeedSubject = $pdo->prepare(
                "INSERT INTO program_subjects
                    (program_id, year_level, term_label, subject_code, description, units, sort_order)
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            $seedInserted = 0;

            foreach ($seed as $code => $groups) {
                $findProgram->execute(array($code));
                $pid = $findProgram->fetchColumn();
                if (!$pid || !is_array($groups)) {
                    continue;
                }

                $countSubjects->execute(array((int)$pid));
                if ((int)$countSubjects->fetchColumn() > 0) {
                    continue; // Never overwrite an existing curriculum.
                }

                foreach ($groups as $group) {
                    if (!is_array($group) || !isset($group['year'])) continue;
                    $term = isset($group['trimester']) ? $group['trimester'] : (isset($group['term']) ? $group['term'] : '');
                    foreach (($group['subjects'] ?? array()) as $i => $subject) {
                        if (!is_array($subject) || empty($subject['code'])) continue;
                        $insertSeedSubject->execute(array(
                            (int)$pid,
                            (string)$group['year'],
                            (string)$term,
                            (string)$subject['code'],
                            (string)($subject['description'] ?? ''),
                            (float)($subject['units'] ?? 0),
                            (int)$i
                        ));
                        $seedInserted++;
                    }
                }
            }
            $log5[] = "Legacy program curriculum seed: {$seedInserted} row(s) inserted where curriculum was empty.";
        } catch (Throwable $e) {
            $log5[] = "WARN   legacy program curriculum seed skipped: " . $e->getMessage();
        }
    } else {
        $log5[] = "INFO   program_curriculum_seed.json not found; built-in program rows remain available.";
    }
}

// ---- Legacy unique-usernames migration ----
// The old migration renamed only known starter accounts that still had
// username='admin'. Preserve that exact narrow behavior.
if (ascb_table_exists($pdo, 'users') && ascb_col_exists($pdo, 'users', 'prepared_by_code')) {
    $legacyUserMap = array(
        'rbamparo'  => 'rbamparo',
        'accastillo' => 'accastillo',
        'rmyasoña'  => 'rmyasona',
        'francelmae' => 'francelmae',
        'jgbontia'  => 'jgbontia',
        'rcaponong' => 'rcaponong',
    );
    $renamed = 0;
    $stRename = $pdo->prepare(
        "UPDATE users SET username = ? WHERE prepared_by_code = ? AND username = 'admin'"
    );
    foreach ($legacyUserMap as $code => $username) {
        try {
            $stRename->execute(array($username, $code));
            $renamed += $stRename->rowCount();
        } catch (Throwable $e) {
            $log5[] = "WARN   legacy username rename for {$code}: " . $e->getMessage();
        }
    }
    if ($renamed > 0) {
        $log5[] = "Renamed {$renamed} legacy starter username(s) from 'admin'.";
    }
}

// Ensure unique username when there are no duplicate usernames.
// Never auto-delete, merge, or rename unknown duplicate accounts.
if (ascb_table_exists($pdo, 'users') && !ascb_idx_exists($pdo, 'users', 'uniq_username')) {
    $dupUser = (int) $pdo->query(
        "SELECT COUNT(*) FROM (SELECT username FROM users GROUP BY username HAVING COUNT(*) > 1) d"
    )->fetchColumn();
    if ($dupUser === 0) {
        try {
            $pdo->exec("ALTER TABLE users ADD UNIQUE KEY uniq_username (username)");
            $log5[] = "Added unique constraint users.uniq_username.";
        } catch (Throwable $e) {
            $log5[] = "WARN   users.uniq_username could not be added: " . $e->getMessage();
        }
    } else {
        $log5[] = "WARN   users.uniq_username skipped: {$dupUser} duplicate username group(s) still exist.";
    }
}

// ---- Normalize existing numeric grades ----
// Same behavior as migrate_normalize_grades_module.php:
// numeric values only; status grades such as INC/DRP/NG remain untouched.
if (ascb_table_exists($pdo, 'grades') && ascb_col_exists($pdo, 'grades', 'grade')) {
    $rows = $pdo->query(
        "SELECT id, grade FROM grades WHERE grade IS NOT NULL AND TRIM(grade) <> ''"
    )->fetchAll(PDO::FETCH_ASSOC);
    $gradeUpdate = $pdo->prepare("UPDATE grades SET grade = ? WHERE id = ?");
    $normalizedGrades = 0;

    foreach ($rows as $gr) {
        $raw = trim((string)$gr['grade']);
        // Accept integer/decimal numeric grades only.
        if (preg_match('/^-?\d+(?:\.\d+)?$/', $raw)) {
            $num = (float)$raw;
            $normalized = number_format($num, 1, '.', '');
            if ($raw !== $normalized) {
                $gradeUpdate->execute(array($normalized, (int)$gr['id']));
                $normalizedGrades += $gradeUpdate->rowCount();
            }
        }
    }
    if ($normalizedGrades > 0) {
        $log5[] = "Normalized {$normalizedGrades} existing numeric grade value(s).";
    }
}

// ---- Backfill blank / mismatched enrollment program_code ----
// Uses the same resolver as the application so legacy course labels such as
// "Bachelor of Science in Information System" can be matched to a catalog code.
if (ascb_table_exists($pdo, 'enrollees')
    && ascb_col_exists($pdo, 'enrollees', 'program_code')
    && ascb_table_exists($pdo, 'programs')) {

    require_once __DIR__ . '/../includes/programs_helper.php';

    $programRows = $pdo->query(
        "SELECT id, program_code, course, major, department_id
           FROM enrollees
          WHERE (program_code IS NULL OR TRIM(program_code) = ''
                 OR NOT EXISTS (
                     SELECT 1 FROM programs p
                      WHERE UPPER(TRIM(p.code)) = UPPER(TRIM(enrollees.program_code))
                 ))"
    )->fetchAll(PDO::FETCH_ASSOC);

    $fixProgram = $pdo->prepare(
        "UPDATE enrollees SET program_code = ?, department_id = CASE
            WHEN department_id IS NULL AND ? IS NOT NULL THEN ?
            ELSE department_id END
         WHERE id = ?"
    );
    $fixedPrograms = 0;

    foreach ($programRows as $er) {
        try {
            $resolved = ascb_resolve_program(
                $pdo,
                (string)$er['program_code'],
                (string)$er['course'],
                (string)$er['major']
            );
        } catch (Throwable $e) {
            $resolved = null;
        }

        if ($resolved && !empty($resolved['code'])) {
            $deptId = isset($resolved['department_id']) ? $resolved['department_id'] : null;
            $fixProgram->execute(array(
                $resolved['code'],
                $deptId,
                $deptId,
                (int)$er['id']
            ));
            $fixedPrograms += $fixProgram->rowCount();
        }
    }
    if ($fixedPrograms > 0) {
        $log5[] = "Backfilled program_code/department_id for {$fixedPrograms} enrollment row(s).";
    }
}

// ---- M.Ed. Administration & Supervision curriculum ----
// Natural key: program + year + term + subject code.
// Existing rows are updated only for description/units/order; student records
// are never touched.
if (ascb_table_exists($pdo, 'programs') && ascb_table_exists($pdo, 'program_subjects')) {
    $programCode = 'MAED-AS';
    $courseName  = 'Master of Arts in Education';
    $major       = 'Administration and Supervision';
    $termType    = 'Semester';

    $curriculum = array(
        array('year' => '1st Year', 'term' => '1st Semester', 'subjects' => array(
            array('ED 201', 'Advanced Methods of Research', 3),
            array('ED 202', 'Advanced Statistics in Education', 3),
            array('ED 203', 'Philo-Sociological Foundations of Education', 3),
        )),
        array('year' => '1st Year', 'term' => '2nd Semester', 'subjects' => array(
            array('ED 205', 'Legal Aspects in School Administration and Supervision', 3),
            array('ED 206', 'Theories and Practices in School Administration and Supervision', 3),
            array('ED 207', 'Advanced Curriculum Development', 3),
        )),
        array('year' => '1st Year', 'term' => 'Summer', 'subjects' => array(
            array('ED 208', 'Research Seminar and Practicum', 3),
            array('COGNATE 1', 'Cognate Course 1', 3),
        )),
        array('year' => '2nd Year', 'term' => '1st Semester', 'subjects' => array(
            array('ED 204', 'Psychological Foundations of Education', 3),
            array('ED 209', 'Educational Planning', 3),
            array('COGNATE 2', 'Cognate Course 2', 3),
        )),
        array('year' => '2nd Year', 'term' => '2nd Semester', 'subjects' => array(
            array('ED 210', 'Public Policy Analysis', 3),
            array('THESIS 1', 'Thesis Writing 1', 3),
        )),
        array('year' => '2nd Year', 'term' => 'Summer', 'subjects' => array(
            array('THESIS 2', 'Thesis Writing 2', 3),
        )),
        array('year' => '3rd Year', 'term' => '1st Semester', 'subjects' => array(
            array('Comprehensive Exam', 'Comprehensive Examination', 0),
        )),
    );

    try {
        $findProgram = $pdo->prepare(
            "SELECT id, code, term_type FROM programs
              WHERE UPPER(code) = UPPER(?)
                 OR (LOWER(TRIM(course_name)) = LOWER(TRIM(?))
                     AND LOWER(TRIM(COALESCE(major,''))) = LOWER(TRIM(?)))
              ORDER BY CASE WHEN UPPER(code) = UPPER(?) THEN 0 ELSE 1 END, id ASC
              LIMIT 1"
        );
        $findProgram->execute(array($programCode, $courseName, $major, $programCode));
        $program = $findProgram->fetch(PDO::FETCH_ASSOC);

        if ($program) {
            $programId = (int)$program['id'];
            if ((string)$program['term_type'] !== $termType) {
                $stTerm = $pdo->prepare("UPDATE programs SET term_type = ? WHERE id = ?");
                $stTerm->execute(array($termType, $programId));
            }
        } else {
            $insProgram = $pdo->prepare(
                "INSERT INTO programs (code, course_name, major, term_type, is_active, is_protected)
                 VALUES (?, ?, ?, ?, 1, 0)"
            );
            $insProgram->execute(array($programCode, $courseName, $major, $termType));
            $programId = (int)$pdo->lastInsertId();
        }

        $findSubject = $pdo->prepare(
            "SELECT id FROM program_subjects
              WHERE program_id = ? AND year_level = ? AND term_label = ?
                AND UPPER(TRIM(subject_code)) = UPPER(TRIM(?))
              LIMIT 1"
        );
        $insSubject = $pdo->prepare(
            "INSERT INTO program_subjects
             (program_id, year_level, term_label, subject_code, description, units, sort_order)
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        $updSubject = $pdo->prepare(
            "UPDATE program_subjects
                SET description = ?, units = ?, sort_order = ?
              WHERE id = ?"
        );

        $inserted = 0;
        $updated = 0;
        foreach ($curriculum as $group) {
            foreach ($group['subjects'] as $idx => $subject) {
                $findSubject->execute(array(
                    $programId, $group['year'], $group['term'], $subject[0]
                ));
                $existingId = $findSubject->fetchColumn();

                if ($existingId) {
                    $updSubject->execute(array(
                        $subject[1], (float)$subject[2], (int)$idx, (int)$existingId
                    ));
                    $updated += $updSubject->rowCount();
                } else {
                    $insSubject->execute(array(
                        $programId, $group['year'], $group['term'],
                        $subject[0], $subject[1], (float)$subject[2], (int)$idx
                    ));
                    $inserted++;
                }
            }
        }

        $log5[] = "M.Ed. Administration & Supervision curriculum: {$inserted} inserted, {$updated} updated.";
    } catch (Throwable $e) {
        $log5[] = "WARN   M.Ed. curriculum migration skipped: " . $e->getMessage();
    }
}

ascb_out("");
ascb_out("--- Consolidated legacy migrations ---");
foreach ($log5 as $l) ascb_out("  " . $l);

// =======================================================================
// 7.6 INTELLIGENT GRADE IMPORT HISTORY — dating hiwalay na migration
//      (migrate_intelligent_grade_import.php) ay isinama rito.
//      Schema-only ito; hindi binabago ang existing grades/enrollments.
// =======================================================================
ascb_create_table($pdo, 'grade_import_history', "
    CREATE TABLE IF NOT EXISTS grade_import_history (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        filename VARCHAR(255) NOT NULL,
        imported_by_user_id INT DEFAULT NULL,
        imported_by_username VARCHAR(100) DEFAULT NULL,
        imported_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        file_type VARCHAR(20) DEFAULT NULL,
        format_detected VARCHAR(80) DEFAULT NULL,
        sheets_processed INT NOT NULL DEFAULT 0,
        students_processed INT NOT NULL DEFAULT 0,
        students_created INT NOT NULL DEFAULT 0,
        students_updated INT NOT NULL DEFAULT 0,
        subjects_processed INT NOT NULL DEFAULT 0,
        subjects_created INT NOT NULL DEFAULT 0,
        subjects_updated INT NOT NULL DEFAULT 0,
        enrollments_created INT NOT NULL DEFAULT 0,
        grades_imported INT NOT NULL DEFAULT 0,
        grades_updated INT NOT NULL DEFAULT 0,
        skipped_records INT NOT NULL DEFAULT 0,
        warning_count INT NOT NULL DEFAULT 0,
        error_count INT NOT NULL DEFAULT 0,
        confidence VARCHAR(30) DEFAULT NULL,
        status ENUM('completed','failed','preview') NOT NULL DEFAULT 'completed',
        summary TEXT NULL,
        INDEX idx_gih_imported_at (imported_at),
        INDEX idx_gih_user (imported_by_user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

// =======================================================================
// 7B. MGA TABLE NA DATING NALILIKHA LANG SA IBANG FILE / SA RUNTIME
//     Isinama na rito para IISANG migration na lang ang kailangan:
//       - backup_schedule                (dating includes/backup_engine.php)
//       - user_department_assignments    (dating database/migrate_staff_assignments.php)
//       - user_program_assignments       (dating database/migrate_staff_assignments.php)
//       - gradebook_approval_submissions (dating api/gradebook_approvals.php, grades.php, professor_gradebook.php)
//       - gradebook_approval_items       (dating api/gradebook_approvals.php, grades.php, professor_gradebook.php)
//       - gradebook_encoding_history     (dating api/professor_gradebook.php)
//     Pareho ang definition sa mga lumang lugar, kaya hindi nagbabago ang
//     gamit ng system. Mananatili ang runtime "CREATE TABLE IF NOT EXISTS"
//     sa mga API bilang safety net; hindi ito magdo-duplicate.
// =======================================================================

ascb_create_table($pdo, 'backup_schedule', "
    CREATE TABLE IF NOT EXISTS backup_schedule (
        id TINYINT NOT NULL PRIMARY KEY,
        is_enabled TINYINT(1) NOT NULL DEFAULT 0,
        frequency VARCHAR(10) NOT NULL DEFAULT 'daily',
        run_time CHAR(5) NOT NULL DEFAULT '02:00',
        run_weekday TINYINT NOT NULL DEFAULT 1,
        include_sql TINYINT(1) NOT NULL DEFAULT 1,
        include_departments TINYINT(1) NOT NULL DEFAULT 1,
        keep_count INT NOT NULL DEFAULT 7,
        next_run_at DATETIME DEFAULT NULL,
        last_run_at DATETIME DEFAULT NULL,
        last_status VARCHAR(10) DEFAULT NULL,
        last_message VARCHAR(500) DEFAULT NULL,
        running_until DATETIME DEFAULT NULL,
        cron_token VARCHAR(64) DEFAULT NULL,
        updated_by_user_id INT DEFAULT NULL,
        updated_at DATETIME DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
", $log);

/* Ang iisang settings row (id=1) at ang cron token nito. */
try {
    $hasRow = (int) $pdo->query("SELECT COUNT(*) FROM backup_schedule WHERE id = 1")->fetchColumn();
    $newToken = bin2hex(function_exists('random_bytes') ? random_bytes(16) : openssl_random_pseudo_bytes(16));
    if (!$hasRow) {
        $ins = $pdo->prepare("INSERT INTO backup_schedule (id, cron_token) VALUES (1, ?)");
        $ins->execute(array($newToken));
        $log[] = "SEED   backup_schedule row id=1";
    } else {
        $up = $pdo->prepare("UPDATE backup_schedule SET cron_token = ? WHERE id = 1 AND (cron_token IS NULL OR cron_token = '')");
        $up->execute(array($newToken));
        $log[] = "OK     backup_schedule row id=1";
    }
} catch (Throwable $e) {
    $log[] = "WARN   backup_schedule seed row skipped (" . $e->getMessage() . ")";
}

ascb_create_table($pdo, 'user_department_assignments', "
    CREATE TABLE IF NOT EXISTS user_department_assignments (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL, department_id INT NOT NULL,
        all_programs TINYINT(1) NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        assigned_by INT NULL, assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_user_department (user_id,department_id),
        KEY idx_uda_department_active (department_id,is_active), KEY idx_uda_user_active (user_id,is_active)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

ascb_create_table($pdo, 'user_program_assignments', "
    CREATE TABLE IF NOT EXISTS user_program_assignments (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        user_department_assignment_id BIGINT UNSIGNED NOT NULL,
        program_id INT NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_assignment_program (user_department_assignment_id,program_id),
        KEY idx_upa_program (program_id),
        CONSTRAINT fk_upa_department_assignment FOREIGN KEY (user_department_assignment_id) REFERENCES user_department_assignments(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

/* Panatilihin ang dating department scope ng ADMIN STAFF / DEAN bilang
   tahasang all-program access (INSERT IGNORE = hindi magdo-duplicate, hindi
   nagbabago ng existing assignment). Walang binubura. */
try {
    $pdo->exec("INSERT IGNORE INTO user_department_assignments (user_id,department_id,all_programs,is_active,assigned_at,updated_at)
        SELECT id,department_id,1,1,NOW(),NOW() FROM users
        WHERE role IN ('ADMIN STAFF','DEAN') AND department_id IS NOT NULL AND department_id>0");
    $log[] = "OK     user_department_assignments backfill (existing staff scopes preserved)";
} catch (Throwable $e) {
    $log[] = "WARN   user_department_assignments backfill skipped (" . $e->getMessage() . ")";
}

ascb_create_table($pdo, 'gradebook_approval_submissions', "
    CREATE TABLE IF NOT EXISTS gradebook_approval_submissions (
        id BIGINT AUTO_INCREMENT PRIMARY KEY, department_id INT NOT NULL, school_year VARCHAR(30) NOT NULL, term VARCHAR(50) NOT NULL,
        course_code VARCHAR(100) DEFAULT '', description VARCHAR(255) DEFAULT '', submitted_by INT NOT NULL, submitted_by_name VARCHAR(150) DEFAULT NULL,
        status ENUM('PENDING_UNIT_HEAD','PENDING_REGISTRAR','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING_UNIT_HEAD',
        unit_head_id INT DEFAULT NULL, unit_head_at DATETIME DEFAULT NULL, registrar_id INT DEFAULT NULL, registrar_at DATETIME DEFAULT NULL,
        rejection_reason VARCHAR(500) DEFAULT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        rejected_by_role VARCHAR(30) DEFAULT NULL, rejected_at DATETIME DEFAULT NULL,
        last_rejection_reason VARCHAR(500) DEFAULT NULL, resubmit_count INT NOT NULL DEFAULT 0,
        resubmitted_at DATETIME DEFAULT NULL, resubmit_note VARCHAR(500) DEFAULT NULL,
        INDEX idx_gas_status_dept(status,department_id), INDEX idx_gas_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
", $log);

/* Para sa existing table na nalikha ng lumang bersyon (kulang ang columns). */
ascb_add_column($pdo, 'gradebook_approval_submissions', 'rejected_by_role',      "rejected_by_role VARCHAR(30) DEFAULT NULL", $log);
ascb_add_column($pdo, 'gradebook_approval_submissions', 'rejected_at',           "rejected_at DATETIME DEFAULT NULL", $log);
ascb_add_column($pdo, 'gradebook_approval_submissions', 'last_rejection_reason', "last_rejection_reason VARCHAR(500) DEFAULT NULL", $log);
ascb_add_column($pdo, 'gradebook_approval_submissions', 'resubmit_count',        "resubmit_count INT NOT NULL DEFAULT 0", $log);
ascb_add_column($pdo, 'gradebook_approval_submissions', 'resubmitted_at',        "resubmitted_at DATETIME DEFAULT NULL", $log);
ascb_add_column($pdo, 'gradebook_approval_submissions', 'resubmit_note',         "resubmit_note VARCHAR(500) DEFAULT NULL", $log);

ascb_create_table($pdo, 'gradebook_approval_items', "
    CREATE TABLE IF NOT EXISTS gradebook_approval_items (
        id BIGINT AUTO_INCREMENT PRIMARY KEY, submission_id BIGINT NOT NULL, enrollment_subject_id INT NOT NULL,
        student_id VARCHAR(100) DEFAULT NULL, student_name VARCHAR(255) DEFAULT NULL,
        old_grade VARCHAR(30) DEFAULT NULL, new_grade VARCHAR(30) DEFAULT NULL,
        old_units DECIMAL(8,2) DEFAULT NULL, new_units DECIMAL(8,2) DEFAULT NULL,
        UNIQUE KEY uq_gai_submission_subject(submission_id,enrollment_subject_id),
        INDEX idx_gai_submission(submission_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
", $log);
ascb_add_column($pdo, 'gradebook_approval_items', 'old_units', "old_units DECIMAL(8,2) DEFAULT NULL", $log);
ascb_add_column($pdo, 'gradebook_approval_items', 'new_units', "new_units DECIMAL(8,2) DEFAULT NULL", $log);

ascb_create_table($pdo, 'gradebook_encoding_history', "
    CREATE TABLE IF NOT EXISTS gradebook_encoding_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        enrollment_subject_id INT NOT NULL,
        student_id VARCHAR(100) DEFAULT NULL,
        student_name VARCHAR(255) DEFAULT NULL,
        course_code VARCHAR(100) DEFAULT NULL,
        description VARCHAR(255) DEFAULT NULL,
        school_year VARCHAR(30) DEFAULT NULL,
        trimester VARCHAR(50) DEFAULT NULL,
        old_grade VARCHAR(30) DEFAULT NULL,
        new_grade VARCHAR(30) NOT NULL,
        encoded_by_user_id INT DEFAULT NULL,
        encoded_by_name VARCHAR(100) DEFAULT NULL,
        encoded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_gbhist_subject_time (enrollment_subject_id, encoded_at),
        INDEX idx_gbhist_time (encoded_at),
        INDEX idx_gbhist_student (student_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
", $log);

// =======================================================================
// 8. VERIFICATION — tignan na kumpleto ang schema; i-report kung may
//    kulang (dapat wala pagkatapos ng matagumpay na run).
// =======================================================================
$expectedTables = array(
    'departments', 'schools', 'courses', 'users', 'programs', 'program_subjects',
    'enrollees', 'enrollment_subjects', 'grades', 'subject_grade_locks',
    'record_corrections', 'record_correction_items', 'certificates',
    'form137_requests', 'document_transactions', 'document_transaction_files',
    'student_id_sequences', 'login_attempts', 'backup_history',
    'student_master', 'student_name_history', 'grade_import_history',
    'backup_schedule', 'user_department_assignments', 'user_program_assignments',
    'gradebook_approval_submissions', 'gradebook_approval_items', 'gradebook_encoding_history',
    'approved_so', 'activity_log',
);

$missingTables = array();
foreach ($expectedTables as $t) {
    if (!ascb_table_exists($pdo, $t)) $missingTables[] = $t;
}

$expectedEnrolleeColumns = array(
    'student_id', 'sex', 'civil_status', 'student_type', 'birth_place',
    'mobile_number', 'guardian_name', 'email', 'junior_hs_graduated',
    'senior_hs_graduated', 'program_code', 'department_id', 'course', 'major',
    'year_level', 'trimester', 'school_year', 'subjects_json', 'status',
    'approved_by_user_id', 'approved_at', 'approval_remarks', 'archived_at',
    'archived_by_user_id', 'archive_reason',
);
$missingColumns = array();
foreach ($expectedEnrolleeColumns as $c) {
    if (!ascb_col_exists($pdo, 'enrollees', $c)) $missingColumns[] = "enrollees.$c";
}

ascb_out("");
ascb_out("==============================================================");
if (empty($missingTables) && empty($missingColumns)) {
    ascb_out(" VERIFICATION: OK — kumpleto ang lahat ng inaasahang tables at columns.");
} else {
    ascb_out(" VERIFICATION: MAY KULANG!");
    if ($missingTables)  ascb_out("   Missing tables : " . implode(', ', $missingTables));
    if ($missingColumns) ascb_out("   Missing columns: " . implode(', ', $missingColumns));
}
// =======================================================================
// 9. HINDI KAILANGANG TABLE — hinahanap ang mga table sa database na wala
//    sa listahan ng ginagamit ng system (hal. mga lumang/test na table).
//    REPORT LANG bilang default. Dino-drop lang kapag:
//      - CLI ang takbo, at
//      - may --drop-unused AT --yes, at
//      - kumpleto ang VERIFICATION sa itaas (tapos na ang migration), at
//      - walang laman ang table (maliban kung may --include-nonempty).
//    Ang mga table sa --keep=... ay hindi kailanman ginagalaw.
// =======================================================================
$cliArgs = (isset($argv) && is_array($argv)) ? $argv : array();
$optDrop     = in_array('--drop-unused', $cliArgs, true);
$optYes      = in_array('--yes', $cliArgs, true);
$optNonEmpty = in_array('--include-nonempty', $cliArgs, true);
$keepList = array();
foreach ($cliArgs as $a) {
    if (strpos($a, '--keep=') === 0) {
        foreach (explode(',', substr($a, 7)) as $k) { $k = strtolower(trim($k)); if ($k !== '') $keepList[$k] = true; }
    }
}
$schemaComplete = (empty($missingTables) && empty($missingColumns));
$needed = array();
foreach ($expectedTables as $t) $needed[strtolower($t)] = true;

$unused = array();
try {
    $q = $pdo->query("SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE' ORDER BY table_name");
    foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $tn) {
        $tl = strtolower($tn);
        if (isset($needed[$tl])) continue;
        $rowsCount = -1;
        try { $rowsCount = (int) $pdo->query("SELECT COUNT(*) FROM `" . str_replace('`', '', $tn) . "`")->fetchColumn(); } catch (Throwable $e) {}
        $unused[] = array('name' => $tn, 'rows' => $rowsCount, 'keep' => isset($keepList[$tl]));
    }
} catch (Throwable $e) {
    ascb_out(" WARN: hindi nabasa ang listahan ng table (" . $e->getMessage() . ")");
}

ascb_out("");
ascb_out("--------------------------------------------------------------");
if (!$unused) {
    ascb_out(" UNUSED TABLES: wala. Lahat ng table sa database ay ginagamit ng system.");
} else {
    ascb_out(" UNUSED TABLES (wala sa schema ng system): " . count($unused));
    foreach ($unused as $u) {
        ascb_out(sprintf("   - %-38s %s%s", $u['name'],
            ($u['rows'] < 0 ? 'rows: ?' : 'rows: ' . $u['rows']),
            ($u['keep'] ? '   [--keep]' : '')));
    }
    $canDrop = $isCli && $optDrop && $optYes && $schemaComplete;
    if (!$optDrop) {
        ascb_out(" Walang binura. Para i-drop ang mga WALANG LAMAN: php database/migrate_master.php --drop-unused --yes");
    } elseif (!$isCli) {
        ascb_out(" Hindi nagdro-drop sa web. Patakbuhin sa command line.");
    } elseif (!$optYes) {
        ascb_out(" Kailangan ng --yes para kumpirmahin ang pag-drop.");
    } elseif (!$schemaComplete) {
        ascb_out(" HINDI nagdro-drop: may kulang pa sa schema (tingnan ang VERIFICATION). Ayusin muna.");
    }
    if ($canDrop) {
        $dropped = 0; $skipped = 0;
        try { $pdo->exec("SET FOREIGN_KEY_CHECKS = 0"); } catch (Throwable $e) {}
        foreach ($unused as $u) {
            if ($u['keep']) { $skipped++; continue; }
            if ($u['rows'] !== 0 && !$optNonEmpty) {
                ascb_out("   SKIP  {$u['name']} (may laman: " . ($u['rows'] < 0 ? '?' : $u['rows']) . " rows; gamitin ang --include-nonempty kung sigurado)");
                $skipped++; continue;
            }
            try {
                $pdo->exec("DROP TABLE `" . str_replace('`', '', $u['name']) . "`");
                ascb_out("   DROP  {$u['name']}");
                $dropped++;
            } catch (Throwable $e) {
                ascb_out("   FAIL  {$u['name']}: " . $e->getMessage());
                $skipped++;
            }
        }
        try { $pdo->exec("SET FOREIGN_KEY_CHECKS = 1"); } catch (Throwable $e) {}
        ascb_out(" Dropped: {$dropped} | Skipped: {$skipped}");
    }
}
ascb_out("==============================================================");
ascb_out(" Master migration finished.");
ascb_out("==============================================================");