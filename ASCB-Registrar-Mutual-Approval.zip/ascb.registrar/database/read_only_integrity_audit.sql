-- ASCB Registrar read-only data integrity audit (no UPDATE/DELETE/ALTER).
-- Run against a PRIVATE staging copy first. Export results securely; they may
-- contain student identifiers. Schema observed in database/migrate_master.php.

-- 1) Duplicate identity snapshots in enrollees. Review only; same student_id
-- across terms is expected. This query flags same ID with differing names.
SELECT student_id, COUNT(DISTINCT CONCAT_WS('|', UPPER(TRIM(surname)), UPPER(TRIM(first_name)), UPPER(TRIM(COALESCE(middle_name,''))))) AS name_variants,
       COUNT(*) AS enrollment_rows, GROUP_CONCAT(id ORDER BY id) AS enrollment_row_ids
FROM enrollees WHERE student_id IS NOT NULL AND TRIM(student_id) <> ''
GROUP BY student_id HAVING name_variants > 1 ORDER BY enrollment_rows DESC;

-- 2) Duplicate enrollment-period groups. NULL/blank keys are separately shown
-- because MySQL UNIQUE indexes permit multiple NULL values.
SELECT student_id, school_year, trimester, COUNT(*) AS row_count,
       GROUP_CONCAT(id ORDER BY id) AS enrollment_ids
FROM enrollees
WHERE student_id IS NOT NULL AND TRIM(student_id) <> ''
GROUP BY student_id, school_year, trimester HAVING COUNT(*) > 1
ORDER BY row_count DESC;
SELECT id, student_id, school_year, trimester, status, archived_at
FROM enrollees
WHERE student_id IS NULL OR TRIM(student_id) = '' OR school_year IS NULL OR TRIM(school_year) = '' OR trimester IS NULL OR TRIM(trimester) = ''
ORDER BY id;

-- 3) Duplicate subject assignments in one enrollment; same code/description
-- can sometimes be legitimate, so review before applying any constraint.
SELECT enrollment_id, UPPER(TRIM(COALESCE(course_code,''))) AS normalized_code,
       UPPER(TRIM(description)) AS normalized_description, COUNT(*) AS row_count,
       GROUP_CONCAT(id ORDER BY id) AS subject_ids
FROM enrollment_subjects
GROUP BY enrollment_id, normalized_code, normalized_description
HAVING COUNT(*) > 1 ORDER BY row_count DESC;

-- 4) Orphan grades (normally prevented by fk_grade_subject).
SELECT g.id AS grade_id, g.enrollment_subject_id
FROM grades g LEFT JOIN enrollment_subjects es ON es.id = g.enrollment_subject_id
WHERE es.id IS NULL;

-- 5) Orphan enrollment-subject rows (normally prevented by fk_es_enrollment).
SELECT es.id AS subject_id, es.enrollment_id
FROM enrollment_subjects es LEFT JOIN enrollees e ON e.id = es.enrollment_id
WHERE e.id IS NULL;

-- 6) Student master consistency: missing master identities and IDs that have
-- enrollments but no master row. Do not auto-create/merge until reviewed.
SELECT DISTINCT e.student_id
FROM enrollees e LEFT JOIN student_master sm ON sm.student_id = e.student_id
WHERE e.student_id IS NOT NULL AND TRIM(e.student_id) <> '' AND sm.student_id IS NULL;

-- 7) Grade rows and term context; the correct path is grade -> enrollment_subject
-- -> enrollees. Grades do not store term independently in the inspected schema.
SELECT g.id AS grade_id, es.id AS enrollment_subject_id, es.course_code, es.description,
       e.id AS enrollment_id, e.student_id, e.school_year, e.trimester, g.grade
FROM grades g JOIN enrollment_subjects es ON es.id = g.enrollment_subject_id
JOIN enrollees e ON e.id = es.enrollment_id
WHERE e.student_id IS NULL OR e.school_year IS NULL OR e.trimester IS NULL
ORDER BY e.student_id, e.school_year, e.trimester, es.id;

-- 8) Dashboard test reference: approved, unarchived enrollment rows by term.
SELECT school_year, trimester, COUNT(*) AS enrollment_count,
       COUNT(DISTINCT student_id) AS unique_students
FROM enrollees WHERE archived_at IS NULL AND status = 'approved'
GROUP BY school_year, trimester ORDER BY school_year, trimester;
