<?php
/* One-time backfill: ipasa ang Suffix + PSA placement ng Master Record sa lahat
 * ng enrollment (term) rows ng bawat estudyante, para pareho na ang lumalabas
 * sa exports (Department / Honors / Promotional / Gradebook / TOR).
 *
 *   php database/sync_enrollee_suffix_from_master_once.php          (DRY RUN - listahan lang)
 *   php database/sync_enrollee_suffix_from_master_once.php --apply  (isinusulat)
 *
 * - Master ang masusunod, pero LAMANG kung may suffix ang master row.
 *   Kung walang suffix ang master pero may suffix ang enrollment row, HINDI ito
 *   binubura (ililista lang bilang "CONFLICT" para ikaw ang magdesisyon).
 * - Surname / First / Middle ng mga row ay hindi ginagalaw.
 * - Back up the database muna bago mag --apply.
 */
require_once __DIR__ . '/setup_guard.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: text/plain; charset=utf-8');
$apply = PHP_SAPI === 'cli' ? in_array('--apply', $argv, true) : (isset($_GET['apply']) && $_GET['apply'] === '1');

if (!ascb_column_exists($pdo, 'enrollees', 'suffix') || !ascb_column_exists($pdo, 'enrollees', 'suffix_position')
    || !ascb_column_exists($pdo, 'student_master', 'suffix') || !ascb_column_exists($pdo, 'student_master', 'suffix_position')) {
    echo "Run database/migrate_master.php first.\n";
    exit;
}

echo $apply ? "MODE: APPLY\n\n" : "MODE: DRY RUN (walang binabago). Idagdag ang --apply para isulat.\n\n";

$rows = $pdo->query(
    "SELECT m.student_id, m.suffix AS m_suffix, m.suffix_position AS m_pos,
            e.id AS enrollment_id, e.suffix AS e_suffix, e.suffix_position AS e_pos, e.trimester, e.school_year
       FROM student_master m
       JOIN enrollees e ON e.student_id = m.student_id
      WHERE m.suffix IS NOT NULL AND TRIM(m.suffix) <> ''
        AND (e.suffix IS NULL OR e.suffix <> m.suffix OR e.suffix_position <> m.suffix_position)"
)->fetchAll(PDO::FETCH_ASSOC);

$upd = $pdo->prepare("UPDATE enrollees SET suffix = ?, suffix_position = ? WHERE id = ?");
$n = 0;
foreach ($rows as $r) {
    $pos = ascb_normalize_suffix_position($r['m_pos']);
    echo sprintf("%s  enrollment #%d (%s %s): [%s / %s] -> [%s / %s]\n",
        $r['student_id'], $r['enrollment_id'], $r['trimester'], $r['school_year'],
        (string) $r['e_suffix'], (string) $r['e_pos'], $r['m_suffix'], $pos);
    if ($apply) { $upd->execute(array($r['m_suffix'], $pos, $r['enrollment_id'])); }
    $n++;
}
echo "\n" . ($apply ? "Updated" : "Would update") . " $n enrollment row(s).\n";

$conf = $pdo->query(
    "SELECT DISTINCT m.student_id, e.suffix AS e_suffix, e.suffix_position AS e_pos
       FROM student_master m JOIN enrollees e ON e.student_id = m.student_id
      WHERE (m.suffix IS NULL OR TRIM(m.suffix) = '') AND e.suffix IS NOT NULL AND TRIM(e.suffix) <> ''"
)->fetchAll(PDO::FETCH_ASSOC);
if ($conf) {
    echo "\nCONFLICT (walang suffix sa Master pero may suffix sa enrollment - hindi ginalaw, i-check nang mano-mano):\n";
    foreach ($conf as $c) echo "  {$c['student_id']}: enrollment has [{$c['e_suffix']} / {$c['e_pos']}]\n";
}
