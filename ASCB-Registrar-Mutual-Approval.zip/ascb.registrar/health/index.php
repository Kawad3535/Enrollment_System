<?php
// Lightweight health endpoint. Does not reveal database credentials or errors.
require_once __DIR__ . '/../config/app.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
if (getenv('ASCB_HEALTH_ENABLED') !== '1') { http_response_code(404); echo json_encode(['ok'=>false]); exit; }
try {
    require_once __DIR__ . '/../config/db.php';
    if (!$pdo) throw new Exception('db');
    $pdo->query('SELECT 1');
    echo json_encode(['ok'=>true,'app'=>'ascb-registrar','time'=>date('c')]);
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['ok'=>false,'app'=>'ascb-registrar']);
}
