<?php
/* API authentication + CSRF guard. */
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/error_handler.php';
require_once __DIR__ . '/../config/app.php'; // para defined na ang ASCB_DEBUG bago i-install ang handler

/* PHP ERROR HANDLING — pangkalahatang huling-linya-ng-depensa para sa
   LAHAT ng api/*.php na dumaraan dito (nangangahulugang halos lahat).
   Tingnan ang includes/error_handler.php para sa detalye. */
ascb_install_error_handler('json');

ascb_start_session();
ascb_send_security_headers();
header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['ascb_user'])) {
    http_response_code(401);
    echo json_encode(array('ok' => false, 'error' => 'Not logged in. Please log in again.'));
    exit;
}

$ascbUser = $_SESSION['ascb_user'];

/* Re-check the account on every API request. A deactivated or
   deleted account must not keep working through an old session. */
require_once __DIR__ . '/../config/db.php';
/* (STUDENT role) Kasama na ang users.student_id. Kung hindi pa naitatakbo ang
   schema upgrade (wala pa ang column), mag-fallback sa dating query para hindi
   ma-lock-out ang buong staff — ang STUDENT login lang ang hindi gagana
   hanggang hindi pa naitatakbo ang migration. */
$ascbBaseSelect = "SELECT u.id, u.username, u.display_name, u.role, u.department_id, %s d.name AS department_name, u.prepared_by_code, u.is_active FROM users u LEFT JOIN departments d ON d.id=u.department_id WHERE u.id = ?";
/* (Auto STUDENT account) Kasama rin ang users.must_change_password (forced
   change ng temporary password). Fallback chain para sa lumang schema. */
try {
    $stmt = $pdo->prepare(sprintf($ascbBaseSelect, 'u.student_id, u.must_change_password,'));
} catch (PDOException $e) {
    if ($e->getCode() !== '42S22') throw $e; // unknown column
    try {
        $stmt = $pdo->prepare(sprintf($ascbBaseSelect, 'u.student_id,'));
    } catch (PDOException $e2) {
        if ($e2->getCode() !== '42S22') throw $e2;
        $stmt = $pdo->prepare(sprintf($ascbBaseSelect, ''));
    }
}
$stmt->execute(array((int) ascb_get($ascbUser, 'id', 0)));
$freshUser = $stmt->fetch();
if (!$freshUser || !(int) $freshUser['is_active']) {
    $_SESSION = array();
    session_destroy();
    http_response_code(401);
    echo json_encode(array('ok' => false, 'error' => 'The account session is inactive or expired. Please log in again.'));
    exit;
}
$_SESSION['ascb_user'] = array(
    'id' => (int) $freshUser['id'],
    'username' => $freshUser['username'],
    'displayName' => $freshUser['display_name'],
    'role' => $freshUser['role'],
    'departmentId' => isset($freshUser['department_id']) ? (int)$freshUser['department_id'] : null,
    'departmentName' => isset($freshUser['department_name']) ? $freshUser['department_name'] : null,
    'preparedBy' => $freshUser['prepared_by_code'],
    'studentId' => (isset($freshUser['student_id']) && trim((string) $freshUser['student_id']) !== '') ? trim((string) $freshUser['student_id']) : null,
    'mustChangePassword' => !empty($freshUser['must_change_password']),
);
$ascbUser = $_SESSION['ascb_user'];

/* FORCED PASSWORD CHANGE (temporary password) — SERVER-SIDE.
   Habang may must_change_password = 1 ang account, lahat ng API ay 403
   maliban sa mga nag-define ng ASCB_ALLOW_PASSWORD_CHANGE (api/users.php,
   na ang 'change_password' lang ang pinapayagan para sa ganitong account). */
if (!empty($ascbUser['mustChangePassword']) && !defined('ASCB_ALLOW_PASSWORD_CHANGE')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'mustChangePassword' => true, 'error' => 'You must change your temporary password first.'));
    exit;
}

/* STUDENT ROLE — DENY BY DEFAULT.
   Ang STUDENT ay hindi pwedeng gumamit ng kahit anong API endpoint maliban
   sa mga nag-define ng ASCB_ALLOW_STUDENT bago i-require ang file na ito.
   Sa ganitong paraan, kahit may endpoint na "logged-in lang" ang tinitingnan
   (walang role check), hindi pa rin makakalusot ang STUDENT. */
if ($ascbUser['role'] === 'STUDENT' && !defined('ASCB_ALLOW_STUDENT')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'Access denied. Student accounts cannot use this feature.'));
    exit;
}
ascb_require_api_csrf();
