<?php
/* Protected-page authentication guard. */
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/error_handler.php';
require_once __DIR__ . '/../config/app.php'; // para defined na ang ASCB_DEBUG bago i-install ang handler

/* PHP ERROR HANDLING — tingnan ang includes/error_handler.php.
   'html' mode dito dahil mga buong pahina (dashboard.php) at ilang
   CSV/Excel export ang dumadaan sa auth_check.php, hindi JSON API. */
ascb_install_error_handler('html');

ascb_start_session();
ascb_send_security_headers();

if (empty($_SESSION['ascb_user'])) {
    header('Location: ./');
    exit;
}

$ascbUser = $_SESSION['ascb_user'];

/* Refresh role/status from the database so deactivation and role
   changes take effect without waiting for the old session to expire. */
require_once __DIR__ . '/../config/db.php';
/* (STUDENT role) Kasama na ang users.student_id. Kung hindi pa naitatakbo ang
   schema upgrade (wala pa ang column), mag-fallback sa dating query para hindi
   ma-lock-out ang buong staff — ang STUDENT login lang ang hindi gagana
   hanggang hindi pa naitatakbo ang migration. */
$ascbBaseSelect = "SELECT u.id, u.username, u.display_name, u.role, u.department_id, %s d.name AS department_name, u.prepared_by_code, u.is_active FROM users u LEFT JOIN departments d ON d.id=u.department_id WHERE u.id = ?";
/* (Auto STUDENT account) Kasama rin ang users.must_change_password (forced
   change ng temporary password). Fallback chain para sa lumang schema. */
try {
    $stmt = $pdo->prepare(sprintf($ascbBaseSelect, 'u.student_id, u.must_change_password,'));
} catch (PDOException $e) {
    if ($e->getCode() !== '42S22') throw $e; // unknown column
    try {
        $stmt = $pdo->prepare(sprintf($ascbBaseSelect, 'u.student_id,'));
    } catch (PDOException $e2) {
        if ($e2->getCode() !== '42S22') throw $e2;
        $stmt = $pdo->prepare(sprintf($ascbBaseSelect, ''));
    }
}
$stmt->execute(array((int) ascb_get($ascbUser, 'id', 0)));
$freshUser = $stmt->fetch();
if (!$freshUser || !(int) $freshUser['is_active']) {
    $_SESSION = array();
    session_destroy();
    header('Location: ./');
    exit;
}
$_SESSION['ascb_user'] = array(
    'id' => (int) $freshUser['id'],
    'username' => $freshUser['username'],
    'displayName' => $freshUser['display_name'],
    'role' => $freshUser['role'],
    'departmentId' => isset($freshUser['department_id']) ? (int)$freshUser['department_id'] : null,
    'departmentName' => isset($freshUser['department_name']) ? $freshUser['department_name'] : null,
    'preparedBy' => $freshUser['prepared_by_code'],
    'studentId' => (isset($freshUser['student_id']) && trim((string) $freshUser['student_id']) !== '') ? trim((string) $freshUser['student_id']) : null,
    'mustChangePassword' => !empty($freshUser['must_change_password']),
);
$ascbUser = $_SESSION['ascb_user'];

/* FORCED PASSWORD CHANGE (temporary password) — SERVER-SIDE.
   Habang may must_change_password = 1 ang account, WALANG ibang page /
   export / download ang mabubuksan maliban sa change_password.php (na
   nag-define ng ASCB_ALLOW_PASSWORD_CHANGE). Hindi ito mapapalusutan ng
   pag-type ng URL o pag-skip sa JavaScript. */
if (!empty($ascbUser['mustChangePassword']) && !defined('ASCB_ALLOW_PASSWORD_CHANGE')) {
    header('Location: ./');
    exit;
}
/* Kabaligtaran: kung tapos na ang pagpapalit, hindi na kailangan ang page. */
if (empty($ascbUser['mustChangePassword']) && defined('ASCB_PASSWORD_CHANGE_ONLY')) {
    header('Location: ./');
    exit;
}

/* STUDENT ROLE — DENY BY DEFAULT (mga buong page / export / download).
   Ang STUDENT ay ibinabalik sa Student Portal maliban kung ang page mismo
   ay nag-define ng ASCB_ALLOW_STUDENT (student.php lang). */
if ($ascbUser['role'] === 'STUDENT' && !defined('ASCB_ALLOW_STUDENT')) {
    header('Location: ./');
    exit;
}
/* Kabaligtaran: ang staff ay hindi nagagamit ang student.php. */
if ($ascbUser['role'] !== 'STUDENT' && defined('ASCB_STUDENT_ONLY')) {
    header('Location: ./');
    exit;
}
