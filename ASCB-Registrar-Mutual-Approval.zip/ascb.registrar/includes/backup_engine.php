<?php
/* =========================================================
   ASCB REGISTRAR — AUTOMATIC / SCHEDULED BACKUP ENGINE
   ---------------------------------------------------------
   Ginagamit ng:
     api/backup_schedule.php  (Save schedule, Run Now, tick)
     api/backup_cron.php      (external pinger / cron URL)
     tools/run_scheduled_backup.php (totoong cron, CLI)

   Ang schedule ay nakatago sa `backup_schedule` table (isang row
   lang, id=1). Ang mga file ay isinusulat sa storage/backups/auto/
   (protektado ng .htaccess — hindi madadownload via URL; dumadaan
   sa api/backup_download.php na may login + CSRF).

   Kailangang naka-require na ang config/db.php (DB_* constants)
   ng tumatawag bago gamitin ang file na ito.
   ========================================================= */
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/activity_log.php';
require_once __DIR__ . '/xlsx_writer.php';

function ascb_backup_deny_file($dir) {
    $ht = $dir . '/.htaccess';
    if (is_dir($dir) && !file_exists($ht)) {
        @file_put_contents($ht, "Options -Indexes\n<IfModule mod_authz_core.c>\n Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n Order allow,deny\n Deny from all\n</IfModule>\n");
    }
}

function ascb_backup_dir() {
    $base = dirname(__DIR__) . '/storage/backups';
    $dir = $base . '/auto';
    if (!is_dir($dir)) { @mkdir($dir, 0750, true); }
    ascb_backup_deny_file($base);
    ascb_backup_deny_file($dir);
    return $dir;
}

/* Mga backup_type ng automatic backup. AUTO_DEPT_CSV = luma (CSV) — iniwan para
   madownload pa rin ang mga lumang file; AUTO_DEPT_XLSX = bago (Excel .xlsx). */
function ascb_backup_auto_types_sql() {
    return "'AUTO_FULL_SQL','AUTO_DEPT_CSV','AUTO_DEPT_XLSX'";
}

function ascb_backup_new_token() {
    if (function_exists('random_bytes')) {
        try { return bin2hex(random_bytes(20)); } catch (Exception $e) { /* fall through */ }
    }
    if (function_exists('openssl_random_pseudo_bytes')) {
        return bin2hex(openssl_random_pseudo_bytes(20));
    }
    return sha1(uniqid((string) mt_rand(), true) . microtime(true));
}

function ascb_backup_ensure_schema($pdo) {
    static $done = false;
    if ($done) return;
    $pdo->exec("CREATE TABLE IF NOT EXISTS backup_schedule (
        id TINYINT NOT NULL PRIMARY KEY,
        is_enabled TINYINT(1) NOT NULL DEFAULT 0,
        frequency VARCHAR(10) NOT NULL DEFAULT 'daily',
        run_time CHAR(5) NOT NULL DEFAULT '02:00',
        run_weekday TINYINT NOT NULL DEFAULT 1,
        include_sql TINYINT(1) NOT NULL DEFAULT 1,
        include_departments TINYINT(1) NOT NULL DEFAULT 1,
        keep_count INT NOT NULL DEFAULT 7,
        next_run_at DATETIME DEFAULT NULL,
        last_run_at DATETIME DEFAULT NULL,
        last_status VARCHAR(10) DEFAULT NULL,
        last_message VARCHAR(500) DEFAULT NULL,
        running_until DATETIME DEFAULT NULL,
        cron_token VARCHAR(64) DEFAULT NULL,
        updated_by_user_id INT DEFAULT NULL,
        updated_at DATETIME DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $has = $pdo->query("SELECT COUNT(*) FROM backup_schedule WHERE id=1")->fetchColumn();
    if (!(int) $has) {
        $ins = $pdo->prepare("INSERT INTO backup_schedule(id,cron_token) VALUES(1,?)");
        $ins->execute(array(ascb_backup_new_token()));
    } else {
        $tk = $pdo->query("SELECT cron_token FROM backup_schedule WHERE id=1")->fetchColumn();
        if (!$tk) {
            $up = $pdo->prepare("UPDATE backup_schedule SET cron_token=? WHERE id=1");
            $up->execute(array(ascb_backup_new_token()));
        }
    }
    $done = true;
}

function ascb_backup_get_settings($pdo) {
    ascb_backup_ensure_schema($pdo);
    $row = $pdo->query("SELECT * FROM backup_schedule WHERE id=1")->fetch(PDO::FETCH_ASSOC);
    return $row ? $row : null;
}

/* Susunod na oras ng takbo (Asia/Manila — sumusunod sa date_default_timezone_set ng config/app.php).
   $weekday: 0 = Sunday ... 6 = Saturday */
function ascb_backup_compute_next($frequency, $runTime, $weekday, $fromTs = null) {
    $now = ($fromTs === null) ? time() : (int) $fromTs;
    $m = array();
    if (!preg_match('/^([01]\d|2[0-3]):([0-5]\d)$/', (string) $runTime, $m)) {
        $m = array('', '02', '00');
    }
    $h = (int) $m[1];
    $i = (int) $m[2];
    $cand = mktime($h, $i, 0, (int) date('n', $now), (int) date('j', $now), (int) date('Y', $now));
    if ($frequency === 'weekly') {
        $wd = (int) $weekday;
        if ($wd < 0) $wd = 0;
        if ($wd > 6) $wd = 6;
        $diff = ($wd - (int) date('w', $cand) + 7) % 7;
        if ($diff > 0) $cand = strtotime('+' . $diff . ' day', $cand);
        if ($cand <= $now) $cand = strtotime('+7 day', $cand);
    } else {
        if ($cand <= $now) $cand = strtotime('+1 day', $cand);
    }
    return date('Y-m-d H:i:s', $cand);
}

/* ---------- FULL SQL DUMP (streamed, memory-bounded) ---------- */
function ascb_backup_write_sql($path) {
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $db = new PDO($dsn, DB_USER, DB_PASS, array(
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => false,
    ));
    $db->exec("SET time_zone = '+08:00'");
    $tmp = $path . '.part';
    $fh = fopen($tmp, 'wb');
    if (!$fh) throw new Exception('Cannot write the SQL backup file (check storage/backups permissions).');
    try {
        fwrite($fh, "-- ASCB Registrar Full Database Backup (automatic)\n-- Generated: " . date('c') . "\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n");
        $tablesStmt = $db->query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'");
        $tables = array();
        while ($r = $tablesStmt->fetch(PDO::FETCH_NUM)) $tables[] = $r[0];
        $tablesStmt->closeCursor();
        foreach ($tables as $table) {
            $safe = str_replace('`', '``', $table);
            $create = $db->query("SHOW CREATE TABLE `$safe`")->fetch(PDO::FETCH_NUM);
            fwrite($fh, "DROP TABLE IF EXISTS `$safe`;\n" . $create[1] . ";\n\n");
            $stmt = $db->query("SELECT * FROM `$safe`");
            $columns = null;
            $batch = array();
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if ($columns === null) {
                    $columns = array_map(function ($c) { return '`' . str_replace('`', '``', $c) . '`'; }, array_keys($row));
                }
                $vals = array();
                foreach ($row as $v) $vals[] = ($v === null ? 'NULL' : $db->quote((string) $v));
                $batch[] = '(' . implode(',', $vals) . ')';
                if (count($batch) >= 250) {
                    fwrite($fh, 'INSERT INTO `' . $safe . '` (' . implode(',', $columns) . ') VALUES ' . implode(',', $batch) . ";\n");
                    $batch = array();
                }
            }
            if ($batch && $columns !== null) {
                fwrite($fh, 'INSERT INTO `' . $safe . '` (' . implode(',', $columns) . ') VALUES ' . implode(',', $batch) . ";\n");
            }
            $stmt->closeCursor();
            fwrite($fh, "\n");
        }
        fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
        fclose($fh);
    } catch (Exception $e) {
        if (is_resource($fh)) fclose($fh);
        @unlink($tmp);
        throw $e;
    }
    if (!@rename($tmp, $path)) { @unlink($tmp); throw new Exception('Cannot finalize the SQL backup file.'); }
    @chmod($path, 0600);
    return (int) @filesize($path);
}

/* ---------- PROMOTIONAL REPORT: Program + School Year + Term ----------
   Ang automatic backup ng Department data ay gumagamit na ng PAREHONG layout ng
   manual na "Promotional Report" export (api/promotional_report_export.php):
   isang Program bawat file, kaya isang .xlsx bawat Program + School Year + Term.

   Ibinabalik ang listahan ng "group":
     array('program' => array(id,code,course_name,major,term_type) | null,
           'sy' => '2026-2027', 'term' => '1st Semester',
           'pairs' => array(array(raw_sy, raw_term), ...))
   - program = null -> mga enrollee ng Department na walang katugmang Program
     (para hindi mawala sa backup).
   - Semester-based na Program (hal. MAED): ang "Nth Trimester" na lumang record ay
     tinatawag na "Nth Semester" (parehong patakaran ng manual export), kaya
     nagsasama sila sa iisang file.
   - 'pairs' = ang eksaktong raw na halaga sa database (para tama ang filter kahit may
     sobrang espasyo / magkaibang spelling na iisa lang ang label). */

/* Bumubuo ng FROM/WHERE ng mga enrollee para sa isang Program (o "walang Program"). */
function ascb_backup_enrollee_scope($departmentId, $program) {
    $departmentId = (int) $departmentId;
    $from = " FROM enrollees e
              LEFT JOIN programs p ON UPPER(TRIM(p.code))=UPPER(TRIM(e.program_code)) AND p.department_id=?";
    $params = array($departmentId);
    $where = " WHERE e.archived_at IS NULL AND e.status <> 'rejected'";
    if ($program) {
        $where .= ' AND p.id=? AND (e.department_id=? OR e.department_id IS NULL)';
        $params[] = (int) $program['id'];
        $params[] = $departmentId;
    } else {
        $where .= ' AND p.id IS NULL AND e.department_id=?';
        $params[] = $departmentId;
    }
    return array($from, $where, $params);
}

function ascb_backup_department_groups($pdo, $departmentId) {
    $departmentId = (int) $departmentId;
    $progs = array();
    $ps = $pdo->prepare('SELECT id, code, course_name, major, term_type FROM programs WHERE department_id=? ORDER BY course_name, major, code');
    $ps->execute(array($departmentId));
    while ($r = $ps->fetch(PDO::FETCH_ASSOC)) $progs[] = $r;
    $ps->closeCursor();
    $progs[] = null; // huli: mga enrollee na walang katugmang Program

    $groups = array();
    foreach ($progs as $prog) {
        list($from, $where, $params) = ascb_backup_enrollee_scope($departmentId, $prog);
        $st = $pdo->prepare('SELECT e.school_year AS sy, e.trimester AS term' . $from . $where . ' GROUP BY e.school_year, e.trimester');
        $st->execute($params);
        $isSem = ($prog && isset($prog['term_type']) && $prog['term_type'] === 'Semester');
        $local = array();
        while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
            $syLabel = trim((string) $r['sy']);
            if ($syLabel === '') $syLabel = 'No-School-Year';
            $termLabel = trim((string) $r['term']);
            if ($termLabel === '') $termLabel = 'No-Term';
            elseif ($isSem) $termLabel = preg_replace('/\bTrimester\b/i', 'Semester', $termLabel);
            $key = strtolower($syLabel) . '|' . strtolower($termLabel);
            if (!isset($local[$key])) $local[$key] = array('program' => $prog, 'sy' => $syLabel, 'term' => $termLabel, 'pairs' => array());
            $local[$key]['pairs'][] = array($r['sy'], $r['term']);
        }
        $st->closeCursor();
        $local = array_values($local);
        usort($local, function ($a, $b) {
            $c = strcmp($a['sy'], $b['sy']);
            return $c !== 0 ? $c : strcmp($a['term'], $b['term']);
        });
        foreach ($local as $g) $groups[] = $g;
    }
    return $groups;
}

/* Export-only grade: numeric = number (Excel-calculable); CHED text grade = text. */
function ascb_backup_pr_grade($rawGrade) {
    if ($rawGrade === null) return '';
    $grade = trim((string) $rawGrade);
    if ($grade === '' || !is_numeric($grade)) return $grade;
    return (float) $grade;
}

/* ---------- DEPARTMENT DATA EXCEL (.xlsx) — PROMOTIONAL REPORT FORMAT ----------
   Eksaktong layout ng manual na Promotional Report:
     Row 1 : Promotional Report
     Row 2 : SCHOOL:         Andres Soriano Colleges of Bislig
     Row 3 : Program:        <course (+ major)>
     Row 4 : Academic Year:  AY <school year>
     Row 5 : Semester: / Trimester:  <term>
     Row 6 : (blangko)
     Row 7 : No | Student ID | Last Name | First Name | Middle Name | Date of Birth |
             Gender | Home Address | Year | Course Code | Course Description | Grades | Units
     Row 8+: isang estudyante = isa o higit pang row; ang column A-I ay MERGED patayo.
   $group (mula sa ascb_backup_department_groups) = isang Program + School Year + Term;
   null = walang record pa (blangkong template).
   Streamed ang pagsulat (batch ng 500 enrollment) kaya bounded ang memory. */
function ascb_backup_write_department_xlsx($pdo, $dept, $path, $group = null) {
    $departmentId = (int) $dept['id'];
    $tmpOut = $path . '.part';
    $tmpSheet = $path . '.sheet.part';
    $w = null;
    try {
        $widths = array('A' => 6, 'B' => 16, 'C' => 16, 'D' => 16, 'E' => 16, 'F' => 16, 'G' => 10, 'H' => 30, 'I' => 10, 'J' => 18, 'K' => 45, 'L' => 9, 'M' => 8);
        // I-freeze ang unang 7 row (title/meta + header) para laging kita ang header.
        $w = ascb_xlsx_stream_open($tmpSheet, $widths, 7);

        $prog = $group ? $group['program'] : null;
        if ($prog) {
            $programLabel = trim($prog['course_name'] . ($prog['major'] ? ' major in ' . $prog['major'] : ''));
            $termWord = (isset($prog['term_type']) && $prog['term_type'] === 'Semester') ? 'Semester' : 'Trimester';
        } else {
            $programLabel = $group ? 'Unassigned Program (' . $dept['code'] . ')' : 'No Program';
            $termWord = ($group && preg_match('/semester/i', $group['term'])) ? 'Semester' : 'Trimester';
        }
        $syLabel = $group ? ($group['sy'] === 'No-School-Year' ? 'No School Year' : 'AY ' . $group['sy']) : 'All School Years';
        $termLabel = $group ? ($group['term'] === 'No-Term' ? 'No Term' : $group['term']) : 'All Terms';

        $T = function ($v, $style) { return array('v' => (string) $v, 'style' => $style, 'type' => 's'); };
        ascb_xlsx_stream_row($w, array(array('v' => 'Promotional Report')));
        ascb_xlsx_stream_row($w, array(array('v' => 'SCHOOL:'), array('v' => 'Andres Soriano Colleges of Bislig')));
        ascb_xlsx_stream_row($w, array(array('v' => 'Program:'), array('v' => $programLabel)));
        ascb_xlsx_stream_row($w, array(array('v' => 'Academic Year:'), array('v' => $syLabel)));
        ascb_xlsx_stream_row($w, array(array('v' => $termWord . ':'), array('v' => $termLabel)));
        ascb_xlsx_stream_row($w, array());
        $heads = array('No', 'Student ID', 'Last Name', 'First Name', 'Middle Name', 'Date of Birth', 'Gender', 'Home Address', 'Year', 'Course Code', 'Course Description', 'Grades', 'Units');
        $hr = array();
        foreach ($heads as $h) $hr[] = array('v' => $h, 'style' => 1);
        ascb_xlsx_stream_row($w, $hr);

        $merges = array();
        $no = 0;
        $totalRows = 0;

        if ($group) {
            list($from, $where, $scopeParams) = ascb_backup_enrollee_scope($departmentId, $prog);
            // Filter ng School Year + Term. <=> = NULL-safe na paghahambing.
            $conds = array();
            $groupParams = array();
            foreach ($group['pairs'] as $pr) {
                $conds[] = '(e.school_year <=> ? AND e.trimester <=> ?)';
                $groupParams[] = $pr[0];
                $groupParams[] = $pr[1];
            }
            $groupSql = $conds ? ' AND (' . implode(' OR ', $conds) . ')' : '';

            $batchSize = 500;
            $offset = 0;
            while (true) {
                $sql = 'SELECT e.id AS enrollment_id, e.student_id, e.surname, e.first_name, e.middle_name' . ascb_suffix_sql_cols($pdo) . ',
                               e.birth_date, e.sex, e.address, e.year_level, e.subjects_json'
                    . $from . $where . $groupSql . "
                        ORDER BY e.surname ASC, e.first_name ASC, e.id ASC
                        LIMIT $batchSize OFFSET $offset";
                $stmt = $pdo->prepare($sql);
                $stmt->execute(array_merge($scopeParams, $groupParams));
                $enrollees = array_map('ascb_row_print_split', $stmt->fetchAll(PDO::FETCH_ASSOC));
                $stmt->closeCursor();
                if (!$enrollees) break;
                $offset += $batchSize;

                $ids = array_column($enrollees, 'enrollment_id');
                $byEnrollment = array();
                $in = implode(',', array_fill(0, count($ids), '?'));
                $es = $pdo->prepare("SELECT es.enrollment_id, es.course_code, es.description, es.units, g.grade
                                     FROM enrollment_subjects es
                                     LEFT JOIN grades g ON g.enrollment_subject_id=es.id
                                     WHERE es.enrollment_id IN ($in)
                                     ORDER BY es.enrollment_id, es.id");
                $es->execute($ids);
                while ($r = $es->fetch(PDO::FETCH_ASSOC)) { $byEnrollment[$r['enrollment_id']][] = $r; }
                $es->closeCursor();

                foreach ($enrollees as $e) {
                    $subjects = isset($byEnrollment[$e['enrollment_id']]) ? $byEnrollment[$e['enrollment_id']] : array();
                    if (!$subjects && !empty($e['subjects_json'])) {
                        $legacy = json_decode($e['subjects_json'], true);
                        if (is_array($legacy)) {
                            foreach ($legacy as $ls) {
                                $subjects[] = array(
                                    'course_code' => ascb_get($ls, 'code', ''),
                                    'description' => ascb_get($ls, 'description', ''),
                                    'grade' => ascb_clean_numeric_string(ascb_get($ls, 'grade', '')),
                                    'units' => ascb_clean_numeric_string(ascb_get($ls, 'units', '')),
                                );
                            }
                        }
                    }
                    // Huwag isama ang Comprehensive Exam subject (parehong patakaran ng Promotional Report).
                    $subjects = array_values(array_filter($subjects, function ($sub) {
                        $text = trim((string) (isset($sub['course_code']) ? $sub['course_code'] : '') . ' ' . (string) (isset($sub['description']) ? $sub['description'] : ''));
                        return !preg_match('/\bcomprehensive\s*exam\b/i', $text);
                    }));
                    if (!$subjects) $subjects = array(array('course_code' => '', 'description' => '', 'grade' => '', 'units' => ''));

                    $bd = $e['birth_date'];
                    if ($bd) {
                        $dt = DateTime::createFromFormat('Y-m-d', $bd);
                        if ($dt && $dt->format('Y-m-d') === $bd) $bd = $dt->format('F j, Y'); // hal. "July 5, 2007"
                    }

                    $no++;
                    $startRow = $w['row'] + 1; // 1-indexed na row ng unang subject ng estudyante
                    foreach ($subjects as $i => $sub) {
                        $g = ascb_backup_pr_grade(isset($sub['grade']) ? $sub['grade'] : '');
                        $gCell = array('v' => $g, 'style' => 4, 'type' => (is_numeric(trim((string) (isset($sub['grade']) ? $sub['grade'] : ''))) ? 'n' : 's'));
                        $uCell = array('v' => ascb_clean_numeric_string(isset($sub['units']) ? $sub['units'] : ''), 'style' => 3);
                        if ($i === 0) {
                            $cells = array(
                                array('v' => $no, 'style' => 2),
                                array('v' => (string) $e['student_id'], 'style' => 5, 'type' => 's'),
                                array('v' => $e['surname'], 'style' => 2),
                                array('v' => $e['first_name'], 'style' => 2),
                                array('v' => $e['middle_name'], 'style' => 2),
                                array('v' => $bd, 'style' => 2),
                                array('v' => $e['sex'], 'style' => 2),
                                array('v' => $e['address'], 'style' => 2),
                                array('v' => $e['year_level'], 'style' => 2),
                            );
                        } else {
                            $cells = array();
                            for ($c = 0; $c < 9; $c++) $cells[] = array('v' => '', 'style' => 2);
                        }
                        $cells[] = array('v' => isset($sub['course_code']) ? $sub['course_code'] : '', 'style' => 2);
                        $cells[] = array('v' => isset($sub['description']) ? $sub['description'] : '', 'style' => 2);
                        $cells[] = $gCell;
                        $cells[] = $uCell;
                        ascb_xlsx_stream_row($w, $cells);
                        $totalRows++;
                    }
                    $endRow = $w['row'];
                    if ($endRow > $startRow) {
                        // I-merge patayo ang A-I (info ng estudyante) sa lahat ng subject row niya.
                        for ($c = 0; $c <= 8; $c++) {
                            $letter = ascb_xlsx_col_letter($c);
                            $merges[] = $letter . $startRow . ':' . $letter . $endRow;
                        }
                    }
                }
                unset($enrollees, $ids, $byEnrollment);
            }
        }

        if ($totalRows === 0) {
            ascb_xlsx_stream_row($w, array($T('Walang nahanap na student record para sa napiling Program/filters.', 0)));
        }
        ascb_xlsx_stream_close($w, 'Student Grades', $tmpOut, $merges);
    } catch (Exception $e) {
        if (is_array($w) && !empty($w['fh']) && is_resource($w['fh'])) fclose($w['fh']);
        @unlink($tmpSheet);
        @unlink($tmpOut);
        throw $e;
    }
    if (!@rename($tmpOut, $path)) { @unlink($tmpOut); throw new Exception('Cannot finalize the Department Excel backup file.'); }
    @chmod($path, 0600);
    return (int) @filesize($path);
}

/* Itinatago lang ang pinakabagong N na "takbo" (stamp). Ang mas luma ay binubura (file + history row). */
function ascb_backup_apply_retention($pdo, $dir, $keep) {
    $keep = (int) $keep;
    if ($keep < 1) $keep = 1;
    $files = glob($dir . '/AUTO_*');
    if (!$files) return 0;
    $stamps = array();
    foreach ($files as $f) {
        $b = basename($f);
        $m = array();
        if (preg_match('/^AUTO_(\d{8}_\d{6})_/', $b, $m) && substr($b, -5) !== '.part') $stamps[$m[1]] = true;
    }
    $stamps = array_keys($stamps);
    rsort($stamps);
    $drop = array_slice($stamps, $keep);
    if (!$drop) return 0;
    $removed = 0;
    $del = null;
    try {
        $del = $pdo->prepare("DELETE FROM backup_history WHERE filename=? AND backup_type IN (" . ascb_backup_auto_types_sql() . ")");
    } catch (Exception $e) { $del = null; }
    foreach ($files as $f) {
        $b = basename($f);
        $m = array();
        if (preg_match('/^AUTO_(\d{8}_\d{6})_/', $b, $m) && in_array($m[1], $drop, true)) {
            if (@unlink($f)) $removed++;
            if ($del) { try { $del->execute(array($b)); } catch (Exception $e) { /* ignore */ } }
        }
    }
    return $removed;
}

/* ---------- RUN ---------- */
/* $trigger: 'schedule' (inaayos ang next_run_at) | 'manual' (hindi ginagalaw ang schedule) */
function ascb_backup_run($pdo, $actor, $trigger) {
    @ignore_user_abort(true);
    @set_time_limit(0);
    ascb_backup_ensure_schema($pdo);
    $s = ascb_backup_get_settings($pdo);
    if (!$s) return array('ok' => false, 'message' => 'Backup schedule settings not found.');

    // Lock: isang backup lang sa isang pagkakataon (auto-expire sa 30 min kung nag-crash).
    $now = date('Y-m-d H:i:s');
    $until = date('Y-m-d H:i:s', time() + 1800);
    $lock = $pdo->prepare("UPDATE backup_schedule SET running_until=? WHERE id=1 AND (running_until IS NULL OR running_until < ?)");
    $lock->execute(array($until, $now));
    if ($lock->rowCount() !== 1) {
        return array('ok' => false, 'busy' => true, 'message' => 'May tumatakbo nang backup. Subukan ulit mamaya.');
    }

    $actorUser = is_array($actor) ? $actor : array('id' => null, 'displayName' => 'SCHEDULER', 'role' => 'SYSTEM');
    $actorId = is_array($actor) ? (int) ascb_get($actor, 'id', 0) : 0;
    $created = array();
    $errors = array();
    $dir = ascb_backup_dir();
    $stamp = date('Ymd_His');
    $hist = null;
    try {
        $hist = $pdo->prepare("INSERT INTO backup_history(backup_type,department_id,filename,created_by_user_id) VALUES(?,?,?,?)");
    } catch (Exception $e) { $hist = null; }

    try {
        if (!is_dir($dir) || !is_writable($dir)) {
            throw new Exception('Ang folder na storage/backups/auto ay hindi writable.');
        }
        if ((int) $s['include_sql']) {
            $fn = 'AUTO_' . $stamp . '_FULL.sql';
            try {
                $size = ascb_backup_write_sql($dir . '/' . $fn);
                $created[] = array('file' => $fn, 'size' => $size);
                if ($hist) { try { $hist->execute(array('AUTO_FULL_SQL', null, $fn, $actorId ? $actorId : null)); } catch (Exception $e) { /* ignore */ } }
            } catch (Exception $e) { $errors[] = 'Full SQL: ' . $e->getMessage(); }
        }
        if ((int) $s['include_departments']) {
            $deps = $pdo->query("SELECT id,code,name FROM departments WHERE is_active=1 ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
            $usedNames = array();
            $histDept = null;
            try {
                $histDept = $pdo->prepare("INSERT INTO backup_history(backup_type,department_id,school_year,term_label,filename,created_by_user_id) VALUES(?,?,?,?,?,?)");
            } catch (Exception $e) { $histDept = null; }
            foreach ($deps as $d) {
                $code = preg_replace('/[^A-Za-z0-9_-]+/', '_', (string) $d['code']);
                // Promotional Report format: isang .xlsx bawat Program + School Year + Term.
                // Kung walang record ang Department: isang blangkong template file pa rin.
                try {
                    $groups = ascb_backup_department_groups($pdo, (int) $d['id']);
                } catch (Exception $e) {
                    $errors[] = 'Department ' . $d['code'] . ': ' . $e->getMessage();
                    continue;
                }
                if (!$groups) $groups = array(null);
                foreach ($groups as $g) {
                    $suffix = '';
                    $label = 'Department ' . $d['code'];
                    $progCode = '';
                    if ($g) {
                        $progCode = $g['program'] ? (string) $g['program']['code'] : 'NO-PROGRAM';
                        $suffix = '_' . trim(preg_replace('/[^A-Za-z0-9_-]+/', '_', $progCode . '_' . $g['sy'] . '_' . $g['term']), '_');
                        $label .= ' ' . $progCode . ' ' . $g['sy'] . ' ' . $g['term'];
                    }
                    $fn = 'AUTO_' . $stamp . '_DEPT_' . $code . $suffix . '.xlsx';
                    // Proteksyon: kung may magkaparehong pangalan (halos imposible), huwag i-overwrite.
                    for ($n = 2; isset($usedNames[$fn]); $n++) {
                        $fn = 'AUTO_' . $stamp . '_DEPT_' . $code . $suffix . '_' . $n . '.xlsx';
                    }
                    $usedNames[$fn] = true;
                    try {
                        $size = ascb_backup_write_department_xlsx($pdo, $d, $dir . '/' . $fn, $g);
                        $created[] = array('file' => $fn, 'size' => $size);
                        if ($histDept) {
                            try {
                                $histDept->execute(array('AUTO_DEPT_XLSX', (int) $d['id'],
                                    $g ? substr($g['sy'], 0, 20) : null, $g ? substr(($progCode !== '' ? $progCode . ' • ' : '') . $g['term'], 0, 30) : null,
                                    $fn, $actorId ? $actorId : null));
                            } catch (Exception $e) { /* ignore */ }
                        }
                    } catch (Exception $e) { $errors[] = $label . ': ' . $e->getMessage(); }
                }
            }
        }
    } catch (Exception $e) {
        $errors[] = $e->getMessage();
    }

    $removed = 0;
    if ($created) {
        try { $removed = ascb_backup_apply_retention($pdo, $dir, (int) $s['keep_count']); } catch (Exception $e) { /* ignore */ }
    }

    $ok = (count($created) > 0 && count($errors) === 0);
    if (count($created) > 0 && count($errors) > 0) $status = 'PARTIAL';
    else $status = $ok ? 'OK' : 'FAILED';
    $msg = count($created) . ' file(s) created';
    if ($removed) $msg .= ', ' . $removed . ' lumang file inalis (retention)';
    if ($errors) $msg .= '. Errors: ' . implode(' | ', $errors);
    if (!$created && !$errors) $msg = 'Walang napiling i-backup (i-check ang Full SQL / Department options).';
    if (strlen($msg) > 480) $msg = substr($msg, 0, 477) . '...';

    $finishedAt = date('Y-m-d H:i:s');
    if ($trigger === 'schedule' && (int) $s['is_enabled']) {
        $next = ascb_backup_compute_next($s['frequency'], $s['run_time'], $s['run_weekday']);
        $up = $pdo->prepare("UPDATE backup_schedule SET last_run_at=?, last_status=?, last_message=?, running_until=NULL, next_run_at=? WHERE id=1");
        $up->execute(array($finishedAt, $status, $msg, $next));
    } else {
        $up = $pdo->prepare("UPDATE backup_schedule SET last_run_at=?, last_status=?, last_message=?, running_until=NULL WHERE id=1");
        $up->execute(array($finishedAt, $status, $msg));
    }
    ascb_log_activity($pdo, $actorUser, 'AUTO_BACKUP', 'database', 'ascb_registrar', ($trigger === 'schedule' ? 'Scheduled: ' : 'Manual: ') . $status . ' — ' . $msg);

    return array('ok' => $ok, 'status' => $status, 'message' => $msg, 'files' => $created);
}

function ascb_backup_run_if_due($pdo) {
    ascb_backup_ensure_schema($pdo);
    $s = ascb_backup_get_settings($pdo);
    if (!$s || !(int) $s['is_enabled']) return array('ran' => false, 'reason' => 'disabled');
    if (empty($s['next_run_at']) || $s['next_run_at'] > date('Y-m-d H:i:s')) return array('ran' => false, 'reason' => 'not_due');
    $r = ascb_backup_run($pdo, null, 'schedule');
    $r['ran'] = empty($r['busy']);
    return $r;
}
