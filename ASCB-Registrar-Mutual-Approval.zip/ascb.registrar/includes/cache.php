<?php
/* =========================================================
   HELPER: LIGHTWEIGHT FILE-BASED CACHE
   ---------------------------------------------------------
   Ginagamit para sa mabibigat na aggregation query (hal. Dashboard
   stats, na naga-GROUP BY sa buong `enrollees` table) na paulit-ulit
   hinihiling sa loob ng maikling panahon — page load, auto-refresh,
   maraming user na magkasabay na nakatingin sa Dashboard.

   Walang kailangang external service (Redis/Memcached) — nagsusulat
   lang ng maliit na JSON file sa storage/cache/ (naka-deny na sa
   .htaccess, kaya hindi ito direktang ma-access sa browser). Ligtas
   i-delete ang buong folder anumang oras — awtomatiko itong muling
   gagawin sa susunod na request.

   Bawat entry ay may sariling TTL (expiration) — huwag umasa dito
   para sa datos na kailangang ganap na real-time; gamitin lang sa
   mabibigat na "summary"/"stats" na query kung saan katanggap-tanggap
   ang ilang segundong pagkaluma.
   ========================================================= */

if (!function_exists('ascb_cache_dir')) {
    function ascb_cache_dir() {
        $dir = __DIR__ . '/../storage/cache';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        return $dir;
    }
}

if (!function_exists('ascb_cache_path')) {
    function ascb_cache_path($key) {
        // ligtas na filename lang — walang path traversal kahit ano
        // pa ang ipasang $key.
        $safe = preg_replace('/[^a-zA-Z0-9_.-]/', '_', (string) $key);
        return ascb_cache_dir() . '/' . $safe . '.json';
    }
}

/* Kumuha ng cached value kung meron pa AT hindi pa expired.
   Ibinabalik ang decoded value, o null kung wala/expired/sira/gulo
   ang laman (nangangahulugang dapat i-recompute ng caller). */
if (!function_exists('ascb_cache_get')) {
    function ascb_cache_get($key) {
        $path = ascb_cache_path($key);
        if (!is_file($path)) return null;
        $raw = @file_get_contents($path);
        if ($raw === false || $raw === '') return null;
        $wrapped = json_decode($raw, true);
        if (!is_array($wrapped) || !isset($wrapped['expires']) || !array_key_exists('data', $wrapped)) return null;
        if (time() > (int) $wrapped['expires']) return null; // expired na
        return $wrapped['data'];
    }
}

/* I-save ang $data nang $ttlSeconds. Atomic write (sumulat muna sa
   isang pansamantalang file, saka i-rename) para kahit magkasabay
   ang ilang request na nagsusulat ng parehong key, walang makakabasa
   ng kalahating-nasulat/sirang JSON. */
if (!function_exists('ascb_cache_set')) {
    function ascb_cache_set($key, $data, $ttlSeconds) {
        $dir = ascb_cache_dir();
        $safe = preg_replace('/[^a-zA-Z0-9_.-]/', '_', (string) $key);
        $path = $dir . '/' . $safe . '.json';
        $tmp  = $dir . '/.tmp_' . $safe . '_' . getmypid() . '_' . mt_rand(1000, 9999);
        $wrapped = array('expires' => time() + max(1, (int) $ttlSeconds), 'data' => $data);
        $json = json_encode($wrapped);
        if ($json === false) return;
        if (@file_put_contents($tmp, $json) !== false) {
            @rename($tmp, $path);
        } else {
            @unlink($tmp);
        }
    }
}

/* Burahin lahat ng naka-cache na entry na nagsisimula sa $prefix —
   tinatawag pagkatapos ng isang write na nakakaapekto sa mga
   pre-computed na numero (hal. bagong Enrollment, pag-approve/
   archive, Bulk Import) para hindi na kailangang hintayin pang
   mag-expire ang TTL bago makita ang updated na Dashboard. */
if (!function_exists('ascb_cache_clear_prefix')) {
    function ascb_cache_clear_prefix($prefix) {
        $dir = ascb_cache_dir();
        $safePrefix = preg_replace('/[^a-zA-Z0-9_.-]/', '_', (string) $prefix);
        $matches = @glob($dir . '/' . $safePrefix . '*.json');
        if (!$matches) return;
        foreach ($matches as $file) {
            @unlink($file);
        }
    }
}
