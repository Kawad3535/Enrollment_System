<?php
/* =========================================================
   CERTIFICATE STUDENT SOURCE
   ---------------------------------------------------------
   Searches approved enrollment records and returns the
   official student/enrollment values used by certificates.
   Historical enrollment rows remain separate so the
   Registrar can select the correct program and term.
   ========================================================= */

require_once __DIR__ . '/departments.php';
require_once __DIR__ . '/master_record_helper.php';
require_once __DIR__ . '/student_search.php';

if (!function_exists('ascb_certificate_source_definition')) {
    function ascb_certificate_source_definition($pdo) {
        $hasMaster = function_exists('ascb_master_available') && ascb_master_available($pdo);
        $hasEnrolleeSuffix = ascb_column_exists($pdo, 'enrollees', 'suffix');
        $hasEnrolleeSuffixPosition = ascb_column_exists($pdo, 'enrollees', 'suffix_position');
        $hasMasterSuffix = $hasMaster && ascb_column_exists($pdo, 'student_master', 'suffix');
        $hasMasterSuffixPosition = $hasMaster && ascb_column_exists($pdo, 'student_master', 'suffix_position');

        $select = array(
            'e.id AS enrollment_id',
            'e.student_id',
            'e.surname',
            'e.first_name',
            'e.middle_name',
            $hasEnrolleeSuffix ? 'e.suffix AS enrolled_suffix' : 'NULL AS enrolled_suffix',
            $hasEnrolleeSuffixPosition ? "e.suffix_position AS enrolled_suffix_position" : "'separate' AS enrolled_suffix_position",
            'e.program_code',
            'e.course',
            'e.major AS enrollment_major',
            'e.year_level',
            'e.trimester',
            'e.school_year',
            'e.status',
            'e.created_at',
            'e.department_id',
            'p.course_name AS program_course_name',
            'p.major AS program_catalog_major',
        );

        $joins = ' LEFT JOIN programs p ON p.code = e.program_code';
        if ($hasMaster) {
            $select[] = 'm.surname AS current_surname';
            $select[] = 'm.first_name AS current_first_name';
            $select[] = 'm.middle_name AS current_middle_name';
            $select[] = $hasMasterSuffix ? 'm.suffix AS current_suffix' : 'NULL AS current_suffix';
            $select[] = $hasMasterSuffixPosition
                ? "m.suffix_position AS current_suffix_position"
                : "'separate' AS current_suffix_position";
            $joins .= ' LEFT JOIN student_master m ON m.student_id = e.student_id';
        } else {
            $select[] = 'NULL AS current_surname';
            $select[] = 'NULL AS current_first_name';
            $select[] = 'NULL AS current_middle_name';
            $select[] = 'NULL AS current_suffix';
            $select[] = "'separate' AS current_suffix_position";
        }

        return array(
            'select' => implode(', ', $select),
            'joins' => $joins,
            'has_master' => $hasMaster,
        );
    }
}

if (!function_exists('ascb_certificate_source_scope')) {
    function ascb_certificate_source_scope($pdo, $user) {
        $where = array(
            "e.status = 'approved'",
            'e.archived_at IS NULL',
            "e.student_id IS NOT NULL",
            "TRIM(e.student_id) <> ''",
        );
        $params = array();

        if (ascb_get($user, 'role', '') === 'DEAN') {
            $departmentId = ascb_require_dean_department($pdo, $user);
            $where[] = 'e.department_id = ?';
            $params[] = (int) $departmentId;
        }

        return array('where' => $where, 'params' => $params);
    }
}

if (!function_exists('ascb_certificate_source_search_clause')) {
    function ascb_certificate_source_search_clause($query, $hasMaster) {
        $tokens = ascb_search_tokens($query);
        if (!$tokens) {
            return array('sql' => '', 'params' => array());
        }

        if (count($tokens) === 1) {
            if (preg_match('/^\d{4}-\d{5}$/', $tokens[0])) {
                return array('sql' => '(e.student_id = ?)', 'params' => array($tokens[0]));
            }
            if (preg_match('/^\d{9}$/', $tokens[0])) {
                $studentId = substr($tokens[0], 0, 4) . '-' . substr($tokens[0], 4);
                return array('sql' => '(e.student_id = ?)', 'params' => array($studentId));
            }
        }

        $columns = array(
            'e.surname',
            'e.first_name',
            'e.middle_name',
            'e.student_id',
            'e.course',
            'e.major',
            'e.program_code',
            'p.course_name',
            'p.major',
        );
        if ($hasMaster) {
            $columns[] = 'm.surname';
            $columns[] = 'm.first_name';
            $columns[] = 'm.middle_name';
        }

        $parts = array();
        $params = array();
        foreach ($tokens as $token) {
            $like = ascb_search_like($token);
            $ors = array();
            foreach ($columns as $column) {
                $ors[] = $column . ' LIKE ?';
                $params[] = $like;
            }
            $parts[] = '(' . implode(' OR ', $ors) . ')';
        }

        return array('sql' => '(' . implode(' AND ', $parts) . ')', 'params' => $params);
    }
}

if (!function_exists('ascb_certificate_source_public_record')) {
    function ascb_certificate_source_public_record($row) {
        $useMasterName = trim((string) ascb_get($row, 'current_surname', '')) !== ''
            && trim((string) ascb_get($row, 'current_first_name', '')) !== '';

        $surname = $useMasterName ? $row['current_surname'] : $row['surname'];
        $firstName = $useMasterName ? $row['current_first_name'] : $row['first_name'];
        $middleName = $useMasterName ? $row['current_middle_name'] : $row['middle_name'];
        $suffix = $useMasterName && trim((string) ascb_get($row, 'current_suffix', '')) !== ''
            ? $row['current_suffix']
            : ascb_get($row, 'enrolled_suffix', '');
        $suffixPosition = $useMasterName
            ? ascb_get($row, 'current_suffix_position', 'separate')
            : ascb_get($row, 'enrolled_suffix_position', 'separate');

        $programCode = trim((string) ascb_get($row, 'program_code', ''));
        if ($programCode === '') {
            $programCode = trim((string) ascb_get($row, 'course', ''));
        }

        $programName = trim((string) ascb_get($row, 'program_course_name', ''));
        if ($programName === '') {
            $programName = trim((string) ascb_get($row, 'course', ''));
        }
        if ($programName === '') {
            $programName = $programCode;
        }
        $programMajor = trim((string) ascb_get($row, 'program_catalog_major', ''));
        if ($programMajor === '') {
            $programMajor = trim((string) ascb_get($row, 'enrollment_major', ''));
        }
        $programLabel = $programName;
        if ($programMajor !== '' && stripos($programName, $programMajor) === false) {
            $programLabel .= ' - ' . $programMajor;
        }

        return array(
            'enrollmentId' => (int) $row['enrollment_id'],
            'studentId' => (string) $row['student_id'],
            'studentName' => ascb_master_format_name($surname, $firstName, $middleName, $suffix, $suffixPosition),
            'programCode' => $programCode,
            'programLabel' => $programLabel,
            'yearLevel' => (string) ascb_get($row, 'year_level', ''),
            'trimester' => (string) ascb_get($row, 'trimester', ''),
            'academicYear' => (string) ascb_get($row, 'school_year', ''),
            'enrollmentDate' => !empty($row['created_at']) ? substr((string) $row['created_at'], 0, 10) : '',
            'status' => 'OFFICIALLY ENROLLED',
        );
    }
}

if (!function_exists('ascb_certificate_search_enrollments')) {
    function ascb_certificate_search_enrollments($pdo, $query, $user) {
        $definition = ascb_certificate_source_definition($pdo);
        $scope = ascb_certificate_source_scope($pdo, $user);
        $where = $scope['where'];
        $params = $scope['params'];

        $search = ascb_certificate_source_search_clause($query, $definition['has_master']);
        if ($search['sql'] === '') {
            return array();
        }
        $where[] = $search['sql'];
        $params = array_merge($params, $search['params']);

        $termRank = "IF(LEFT(TRIM(COALESCE(e.trimester,'')),1) BETWEEN '1' AND '9', CAST(LEFT(TRIM(e.trimester),1) AS UNSIGNED), 0)";
        $sql = 'SELECT ' . $definition['select']
            . ' FROM enrollees e' . $definition['joins']
            . ' WHERE ' . implode(' AND ', $where)
            . ' ORDER BY e.school_year DESC, ' . $termRank . ' DESC, e.created_at DESC, e.id DESC'
            . ' LIMIT 25';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        $records = array();
        foreach ($stmt->fetchAll() as $row) {
            $records[] = ascb_certificate_source_public_record($row);
        }
        return $records;
    }
}

if (!function_exists('ascb_certificate_load_enrollment')) {
    function ascb_certificate_load_enrollment($pdo, $enrollmentId, $user) {
        $definition = ascb_certificate_source_definition($pdo);
        $scope = ascb_certificate_source_scope($pdo, $user);
        $where = $scope['where'];
        $params = $scope['params'];
        $where[] = 'e.id = ?';
        $params[] = (int) $enrollmentId;

        $sql = 'SELECT ' . $definition['select']
            . ' FROM enrollees e' . $definition['joins']
            . ' WHERE ' . implode(' AND ', $where)
            . ' LIMIT 1';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch();
        if (!$row) {
            return null;
        }

        $record = ascb_certificate_source_public_record($row);
        $hiddenFilter = ascb_column_exists($pdo, 'enrollment_subjects', 'hidden_on_print')
            ? ' AND es.hidden_on_print = 0'
            : '';
        $subjectsStmt = $pdo->prepare(
            'SELECT es.course_code, es.description, es.units, g.grade
             FROM enrollment_subjects es
             LEFT JOIN grades g ON g.enrollment_subject_id = es.id
             WHERE es.enrollment_id = ?' . $hiddenFilter . '
             ORDER BY es.id ASC'
        );
        $subjectsStmt->execute(array((int) $enrollmentId));
        $record['subjects'] = array();
        foreach ($subjectsStmt->fetchAll() as $subject) {
            $record['subjects'][] = array(
                'code' => (string) ascb_get($subject, 'course_code', ''),
                'description' => (string) ascb_get($subject, 'description', ''),
                'grade' => $subject['grade'] === null ? '' : (string) $subject['grade'],
                'units' => (float) ascb_get($subject, 'units', 0),
            );
        }

        return $record;
    }
}