<?php
/* =========================================================
   CERTIFICATE VERIFICATION (QR CODE)
   ---------------------------------------------------------
   Para sa CERTIFICATE OF ENROLLMENT at CERTIFICATE OF
   REGISTRATION. Bawat naka-log na certificate (certificates
   table) ay may sariling random na verify_token. Ang token
   na iyon ay nasa QR code ng papel.

   Dalawang paraan ng pag-verify:
   1) ONLINE  — i-scan ang QR -> bubukas ang verify.php?c=TOKEN
                na kumukuha ng LIVE record sa database.
   2) OFFLINE — ang QR mismo ay may nakasulat na plain text
                (Name, Student ID, Program, Enrollment Date)
                kaya mababasa ito ng kahit anong QR scanner
                kahit walang internet, at maikukumpara sa papel.

   Walang grades na inilalagay sa QR o sa verify page.
   ========================================================= */

if (!function_exists('ascb_cert_verify_types')) {

    /* Mga certificate type na may QR. */
    function ascb_cert_verify_types() {
        return array('ENROLLMENT', 'REGISTRATION');
    }

    function ascb_cert_verify_type_label($type) {
        $type = strtoupper(trim((string) $type));
        if ($type === 'ENROLLMENT')   return 'Certificate of Enrollment';
        if ($type === 'REGISTRATION') return 'Certificate of Registration';
        return '';
    }

    /* Idempotent: dagdagan ang certificates table ng verify_token column
       (para gumana agad sa existing database nang hindi pa tumatakbo ang
       database/migrate_master.php). Ang mga bagong install ay may column
       na sa migrate_master.php. */
    function ascb_cert_verify_ensure_schema($pdo) {
        static $done = false;
        if ($done) return true;
        try {
            $col = $pdo->query("SHOW COLUMNS FROM certificates LIKE 'verify_token'")->fetch();
            if (!$col) {
                $pdo->exec("ALTER TABLE certificates ADD COLUMN verify_token VARCHAR(40) DEFAULT NULL");
            }
            $idx = $pdo->query("SHOW INDEX FROM certificates WHERE Key_name = 'uq_cert_verify_token'")->fetch();
            if (!$idx) {
                $pdo->exec("ALTER TABLE certificates ADD UNIQUE KEY uq_cert_verify_token (verify_token)");
            }
            $done = true;
            return true;
        } catch (Throwable $e) {
            error_log('ASCB certificate verify schema upgrade failed: ' . $e->getMessage());
            return false;
        }
    }

    /* 20 hex characters = 80 bits of randomness (hindi mahuhulaan). */
    function ascb_cert_verify_generate_token() {
        if (function_exists('random_bytes')) {
            return strtoupper(bin2hex(random_bytes(10)));
        }
        return strtoupper(substr(bin2hex(openssl_random_pseudo_bytes(10)), 0, 20));
    }

    function ascb_cert_verify_valid_token($token) {
        return is_string($token) && preg_match('/^[A-F0-9]{20}$/', $token) === 1;
    }

    /* "7F3A9C21B4E88D05A6C1" -> "7F3A9-C21B4-E88D0-5A6C1" */
    function ascb_cert_verify_display_code($token) {
        return implode('-', str_split((string) $token, 5));
    }

    /* Siguraduhin na may token ang certificate record. Ibinabalik ang token,
       o null kung hindi eligible ang type / may error. */
    function ascb_cert_verify_ensure_token($pdo, $certificateId) {
        $certificateId = (int) $certificateId;
        if ($certificateId <= 0 || !ascb_cert_verify_ensure_schema($pdo)) return null;

        $st = $pdo->prepare("SELECT certificate_type, verify_token FROM certificates WHERE id = ?");
        $st->execute(array($certificateId));
        $row = $st->fetch();
        if (!$row || !in_array($row['certificate_type'], ascb_cert_verify_types(), true)) return null;
        if (ascb_cert_verify_valid_token((string) $row['verify_token'])) return $row['verify_token'];

        for ($i = 0; $i < 5; $i++) {
            $token = ascb_cert_verify_generate_token();
            try {
                $up = $pdo->prepare("UPDATE certificates SET verify_token = ? WHERE id = ? AND (verify_token IS NULL OR verify_token = '')");
                $up->execute(array($token, $certificateId));
            } catch (Throwable $e) {
                continue; // bihirang duplicate token: subukan ulit
            }
            $st->execute(array($certificateId));
            $again = $st->fetch();
            if ($again && ascb_cert_verify_valid_token((string) $again['verify_token'])) return $again['verify_token'];
        }
        return null;
    }

    /* Base URL ng system na nasa QR. Para sa production, itakda ang
       ASCB_PUBLIC_BASE_URL (hal. https://registrar.ascb.edu.ph) sa config/app.php
       o bilang environment variable. Kung hindi naka-set, kukunin ito sa
       address na ginamit ng staff sa pag-generate. */
    function ascb_cert_verify_base_url() {
        $configured = defined('ASCB_PUBLIC_BASE_URL') ? (string) ASCB_PUBLIC_BASE_URL : (string) getenv('ASCB_PUBLIC_BASE_URL');
        $configured = trim($configured);
        if ($configured !== '' && preg_match('#^https?://#i', $configured)) {
            return rtrim($configured, '/');
        }
        $https  = function_exists('ascb_is_https') ? ascb_is_https() : (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off');
        $host   = isset($_SERVER['HTTP_HOST']) ? (string) $_SERVER['HTTP_HOST'] : (isset($_SERVER['SERVER_NAME']) ? (string) $_SERVER['SERVER_NAME'] : 'localhost');
        if (!preg_match('/^[A-Za-z0-9.\-:\[\]]+$/', $host)) $host = 'localhost';
        $script = isset($_SERVER['SCRIPT_NAME']) ? (string) $_SERVER['SCRIPT_NAME'] : '/';
        $dir    = preg_replace('#/api/[^/]*$#', '', $script);   // /app/api/certificates.php -> /app
        $dir    = preg_replace('#/[^/]*\.php$#', '', $dir);      // /app/dashboard.php -> /app
        $dir    = rtrim($dir, '/');
        return ($https ? 'https://' : 'http://') . $host . $dir;
    }

    function ascb_cert_verify_url($token) {
        return ascb_cert_verify_base_url() . '/verify.php?c=' . rawurlencode((string) $token);
    }

    function ascb_cert_verify_format_date($date) {
        $date = trim((string) $date);
        if ($date === '') return '-';
        $ts = strtotime(substr($date, 0, 10));
        return $ts ? date('F j, Y', $ts) : $date;
    }

    /* Ang plain text na nakasulat mismo sa QR (nababasa offline).
       Sinadyang maikli para hindi sobrang siksik ang QR kapag naka-print. */
    function ascb_cert_verify_qr_text($row, $url) {
        $type = ascb_cert_verify_type_label(isset($row['certificate_type']) ? $row['certificate_type'] : '');
        $oneLine = function ($v) {
            return trim(preg_replace('/\s+/u', ' ', (string) $v));
        };
        $lines = array(
            'ASCB ' . strtoupper($type !== '' ? $type : 'CERTIFICATE'),
            'Name: ' . $oneLine(isset($row['student_name']) ? $row['student_name'] : ''),
            'Student ID: ' . $oneLine(isset($row['student_id']) ? $row['student_id'] : ''),
            'Program: ' . $oneLine(isset($row['program']) ? $row['program'] : ''),
            'Enrolled: ' . ascb_cert_verify_format_date(isset($row['enrollment_date']) ? $row['enrollment_date'] : ''),
            'Verify online: ' . $url,
        );
        return implode("\n", $lines);
    }

    /* Parehong info pero galing sa row na hawak na (walang dagdag na query).
       Ginagamit sa Records list para sa reprint. */
    function ascb_cert_verify_info_from_row($row) {
        if (!is_array($row) || !in_array(isset($row['certificate_type']) ? $row['certificate_type'] : '', ascb_cert_verify_types(), true)) return null;
        $token = isset($row['verify_token']) ? (string) $row['verify_token'] : '';
        if (!ascb_cert_verify_valid_token($token)) return null;
        $url = ascb_cert_verify_url($token);
        return array(
            'token'  => $token,
            'code'   => ascb_cert_verify_display_code($token),
            'url'    => $url,
            'qrText' => ascb_cert_verify_qr_text($row, $url),
        );
    }

    /* Ang buong info na ibinabalik sa script.js para i-render ang QR.
       Null kung ang certificate type ay walang QR. */
    function ascb_cert_verify_info($pdo, $certificateId) {
        $token = ascb_cert_verify_ensure_token($pdo, $certificateId);
        if ($token === null) return null;

        $st = $pdo->prepare("SELECT certificate_type, student_name, student_id, program, enrollment_date FROM certificates WHERE id = ?");
        $st->execute(array((int) $certificateId));
        $row = $st->fetch();
        if (!$row) return null;

        $url = ascb_cert_verify_url($token);
        return array(
            'token'  => $token,
            'code'   => ascb_cert_verify_display_code($token),
            'url'    => $url,
            'qrText' => ascb_cert_verify_qr_text($row, $url),
        );
    }
}
