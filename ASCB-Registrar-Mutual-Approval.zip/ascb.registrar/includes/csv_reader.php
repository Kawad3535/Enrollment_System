<?php
/* =========================================================
   MINIMAL .CSV READER (walang external library/composer)
   ---------------------------------------------------------
   Binabasa ang isang .csv file papunta sa parehong "shape"
   ng ibinabalik ng ascb_xlsx_read_first_sheet() sa
   xlsx_reader.php — 0-indexed array of rows, bawat row ay
   0-indexed array of trimmed string cell values — para magamit
   ito ng grade_import.php nang walang binabagong logic doon.

   Sinusuportahan:
     - UTF-8 BOM (auto-stripped kung meron)
     - Comma (,) o semicolon (;) delimiter — auto-detected mula
       sa unang linya (maraming Excel install sa PH/EU na naka-
       locale ay gumagamit ng semicolon kapag "Save as CSV")
     - Naka-quote na fields na may comma/quote/newline sa loob
     - CRLF at LF line endings (parehong okay ang fgetcsv dito) */

if (!function_exists('ascb_csv_read')) {

    function ascb_csv_detect_delimiter($firstLine) {
        $commaCount = substr_count($firstLine, ',');
        $semiCount = substr_count($firstLine, ';');
        return ($semiCount > $commaCount) ? ';' : ',';
    }

    function ascb_csv_read($filePath, $maxRows = 20000) {
        if (!is_readable($filePath)) {
            throw new Exception('Hindi mabuksan ang .csv file (baka sira o walang laman).');
        }

        $raw = file_get_contents($filePath);
        if ($raw === false) {
            throw new Exception('Hindi mabasa ang .csv file.');
        }
        // Alisin ang UTF-8 BOM kung meron, para hindi ito sumali sa
        // unang column name/value.
        if (substr($raw, 0, 3) === "\xEF\xBB\xBF") {
            $raw = substr($raw, 3);
        }
        if ($raw === '') {
            return array();
        }

        $firstLineEnd = strpos($raw, "\n");
        $firstLine = $firstLineEnd !== false ? substr($raw, 0, $firstLineEnd) : $raw;
        $delimiter = ascb_csv_detect_delimiter($firstLine);

        $handle = fopen('php://temp', 'r+');
        fwrite($handle, $raw);
        rewind($handle);

        $rows = array();
        $rowCount = 0;
        while (($data = fgetcsv($handle, 0, $delimiter, '"', '\\')) !== false) {
            if (++$rowCount > $maxRows) break;
            if ($data === array(null)) {
                // Blangkong linya — panatilihin bilang blangkong row para
                // tumugma ang line numbers sa aktwal na file.
                $rows[] = array();
                continue;
            }
            $normalized = array();
            foreach ($data as $i => $v) {
                $normalized[$i] = trim((string) $v);
            }
            $rows[] = $normalized;
        }
        fclose($handle);

        return $rows;
    }
}
