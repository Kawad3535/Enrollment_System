<?php
/* =========================================================
   HELPER: DASHBOARD STATS (Enrollment Overview)
   ---------------------------------------------------------
   Iisang function na ginagamit ng api/dashboard_stats.php
   (JSON, para sa cards/breakdown sa Dashboard) AT ng
   api/dashboard_stats_export.php (Excel report) — para hindi
   dalawang beses isulat ang parehong counting logic at laging
   magkatugma ang nakikita sa screen at ang na-e-export.

   ascb_dashboard_stats($pdo, $trimester, $departmentId, $schoolYear):
       $trimester  — opsyonal, hal. "1st Trimester". Blangko
                     ("") = lahat ng trimester.
       $schoolYear — opsyonal, hal. "2025-2026". Blangko ("")
                     = lahat ng school year. Parehong column
                     (enrollees.school_year) na ginagamit na sa
                     Honors at Department Export filters.

   Ibinabalik: array na may totalEnrolled, male, female,
   byCourse (parehong laman/behavior gaya ng dati sa
   dashboard_stats.php — isang beses lang bawat estudyante,
   short program_code ang "course" kung meron).
   ========================================================= */

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/programs_helper.php';

if (!function_exists('ascb_dashboard_stats')) {
    function ascb_dashboard_stats($pdo, $trimester = '', $departmentId = null, $schoolYear = '') {

        $trimester  = trim((string) $trimester);
        $schoolYear = trim((string) $schoolYear);
        /* Build each filter with explicit table aliases. This matters on MySQL
           shared hosting: the department fallback joins `programs`, which also
           has a department_id column. Unqualified columns can resolve to the
           wrong table and produce incorrect counts (or ambiguous-column errors). */
        $buildFilter = function ($alias) use ($trimester, $schoolYear, $departmentId) {
            $sql = " WHERE {$alias}.archived_at IS NULL AND {$alias}.status = 'approved'";
            $params = array();
            if ($trimester !== '') {
                $sql .= " AND {$alias}.trimester = ?";
                $params[] = $trimester;
            }
            if ($schoolYear !== '') {
                $sql .= " AND {$alias}.school_year = ?";
                $params[] = $schoolYear;
            }
            if ($departmentId) {
                $sql .= " AND (
                    {$alias}.department_id = ?
                    OR (
                        {$alias}.department_id IS NULL
                        AND EXISTS (
                            SELECT 1 FROM programs dp
                            WHERE UPPER(TRIM(dp.code)) COLLATE utf8mb4_unicode_ci = UPPER(TRIM({$alias}.program_code)) COLLATE utf8mb4_unicode_ci
                              AND dp.department_id = ?
                        )
                    )
                )";
                $params[] = (int)$departmentId;
                $params[] = (int)$departmentId;
            }
            return array($sql, $params);
        };

        list($filter1, $params1) = $buildFilter('e1');
        list($filter2, $params2) = $buildFilter('e2');
        list($filter3, $params3) = $buildFilter('e3');

        /* Pinipili ang latest active record per student ID sa selected filters.
           Legacy rows na walang student_id ay binibilang nang paisa-isa. */
        $latestSql = "
            SELECT e1.id AS max_id
            FROM enrollees e1
            {$filter1}
              AND e1.student_id IS NOT NULL AND TRIM(e1.student_id) <> ''
              AND e1.id IN (
                  SELECT MAX(e2.id)
                  FROM enrollees e2
                  {$filter2}
                    AND e2.student_id IS NOT NULL AND TRIM(e2.student_id) <> ''
                  GROUP BY e2.student_id
              )
            UNION ALL
            SELECT e3.id AS max_id
            FROM enrollees e3
            {$filter3}
              AND (e3.student_id IS NULL OR TRIM(e3.student_id) = '')
        ";

        $sql = "
            SELECT e.program_code, e.course, e.sex, COUNT(*) AS cnt
            FROM enrollees e
            INNER JOIN ({$latestSql}) latest ON latest.max_id = e.id
            GROUP BY e.program_code, e.course, e.sex
        ";

        $params = array_merge($params1, $params2, $params3);
        // Separate metric: enrollment rows are not unique students. Keep the
        // same approved/non-archived and filter scope as the unique-student card.
        list($enrollmentFilter, $enrollmentParams) = $buildFilter('ec');
        $enrollmentCountStmt = $pdo->prepare("SELECT COUNT(*) FROM enrollees ec {$enrollmentFilter}");
        $enrollmentCountStmt->execute($enrollmentParams);
        $totalEnrollments = (int)$enrollmentCountStmt->fetchColumn();
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        $total       = 0;
        $maleTotal   = 0;
        $femaleTotal = 0;
        $courses     = array(); // course label => ['course'=>, 'male'=>, 'female'=>, 'total'=>]

        foreach ($rows as $row) {
            $programCode = trim((string) ascb_get($row, 'program_code', ''));
            $course      = trim((string) ascb_get($row, 'course', ''));
            /* (fix BSIS) Enrollment na walang program_code pero may course text
               (hal. galing sa Excel import: "Bachelor of Science in Information
               System") ay ini-resolve sa tamang Program para hindi maging hiwalay
               na "course" sa breakdown. */
            if ($programCode === '' && $course !== '') {
                $hit = ascb_resolve_program($pdo, '', $course);
                if ($hit) $programCode = trim((string) $hit['code']);
            }
            if ($programCode !== '') {
                $courseLabel = $programCode;
            } elseif ($course !== '') {
                $courseLabel = $course;
            } else {
                $courseLabel = 'Unspecified';
            }
            $sex = ascb_get($row, 'sex', '');
            $cnt = (int) ascb_get($row, 'cnt', 0);

            $total += $cnt;

            if ($sex === 'Male') {
                $maleTotal += $cnt;
            } elseif ($sex === 'Female') {
                $femaleTotal += $cnt;
            }

            if (!isset($courses[$courseLabel])) {
                $courses[$courseLabel] = array('course' => $courseLabel, 'male' => 0, 'female' => 0, 'total' => 0);
            }
            if ($sex === 'Male') {
                $courses[$courseLabel]['male'] += $cnt;
            } elseif ($sex === 'Female') {
                $courses[$courseLabel]['female'] += $cnt;
            }
            $courses[$courseLabel]['total'] += $cnt;
        }

        $courseList = array_values($courses);
        usort($courseList, function ($a, $b) {
            if ($a['total'] === $b['total']) {
                return strcasecmp($a['course'], $b['course']);
            }
            return ($a['total'] > $b['total']) ? -1 : 1;
        });

        return array(
            'totalEnrolled' => $total, // backwards-compatible: unique students within selected scope
            'totalUniqueStudents' => $total,
            'totalEnrollments' => $totalEnrollments,
            'male'          => $maleTotal,
            'female'        => $femaleTotal,
            'byCourse'      => $courseList,
        );
    }
}
