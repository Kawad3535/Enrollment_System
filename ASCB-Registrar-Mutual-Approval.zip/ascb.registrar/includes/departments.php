<?php
/* Department / Dean scope helpers. Backward-compatible until migration is run. */
if (!function_exists('ascb_has_column')) {
    function ascb_has_column($pdo, $table, $column) {
        /* (2024 audit fix) Defense in depth: ang $table dati ay direktang
           isinasama sa SQL string (SHOW COLUMNS FROM `$table`), na hindi
           pwedeng gawing bound parameter sa MySQL. Ligtas ito SA NGAYON
           dahil hardcoded literal lang ('users', 'enrollees', ...) ang
           ipinapasa ng lahat ng tumatawag dito — pero para hindi ito
           maging SQL-injection point balang araw kung sakaling may bagong
           code na tumawag dito gamit ang isang variable na galing sa
           request, idinagdag ang whitelist check sa ibaba bilang
           karagdagang proteksyon (hindi lang umaasa sa mga tumatawag na
           gumamit lang ng literal). */
        $allowedTables = array('users', 'enrollees', 'programs', 'departments');
        if (!in_array($table, $allowedTables, true)) {
            $GLOBALS['ascb_department_schema_error'] = 'ascb_has_column: hindi kilalang table (' . $table . ').';
            return false;
        }
        try {
            $t = str_replace('`','',$table);
            $col = $pdo->quote($column);
            $stmt = $pdo->query("SHOW COLUMNS FROM `" . $t . "` LIKE " . $col);
            return (bool)$stmt->fetch();
        } catch (Exception $e) {
            $GLOBALS['ascb_department_schema_error'] = 'ascb_has_column(' . $table . '.' . $column . '): ' . $e->getMessage();
            return false;
        }
    }
}
if (!function_exists('ascb_current_department_id')) {
    function ascb_current_department_id($pdo, $user) {
        if (!in_array(ascb_get($user, 'role', ''), array('DEAN','ADMIN STAFF'), true)) return null;
        $uid = (int)ascb_get($user, 'id', 0);
        if (!$uid || !ascb_has_column($pdo, 'users', 'department_id')) return null;
        $st=$pdo->prepare("SELECT department_id FROM users WHERE id=?"); $st->execute(array($uid));
        $v=$st->fetchColumn(); return $v !== false && $v !== null ? (int)$v : null;
    }
}
if (!function_exists('ascb_require_dean_department')) {
    function ascb_require_dean_department($pdo, $user) {
        $id=ascb_current_department_id($pdo,$user);
        if (in_array(ascb_get($user,'role',''), array('DEAN','ADMIN STAFF'), true) && !$id) {
            http_response_code(403); echo json_encode(array('ok'=>false,'error'=>'No Department is assigned to this Dean account.')); exit;
        }
        return $id;
    }
}

if (!function_exists('ascb_staff_assignment_scope_sql')) {
    /**
     * SQL predicate restricting an enrollment alias to an ADMIN STAFF user's
     * active department/program assignments. Returns SQL only; caller appends
     * the returned parameter list to its own prepared-statement parameters.
     *
     * $alias must be a trusted SQL alias such as "e".
     */
    function ascb_staff_assignment_scope_sql($pdo, $user, $alias = 'e') {
        $allowedAliases = array('e', 'ex', 'ey', 'en');
        if (!in_array($alias, $allowedAliases, true)) {
            throw new InvalidArgumentException('Invalid enrollment alias for staff assignment scope.');
        }
        $uid = (int)ascb_get($user, 'id', 0);
        if ($uid < 1) {
            return array('sql' => ' AND 1=0 ', 'params' => array());
        }
        /* Fallback: kung hindi pa na-run ang migrate_master.php
           (wala pa ang assignment tables), huwag mag-500 — gamitin muna ang
           dating users.department_id scope para gumana pa rin ang Grade Management. */
        try {
            $tblChk = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name IN ('user_department_assignments','user_program_assignments')");
            $tblChk->execute();
            $hasAssignTables = ((int)$tblChk->fetchColumn() === 2);
        } catch (Exception $e) {
            $hasAssignTables = false;
        }
        if (!$hasAssignTables) {
            $legacyDept = ascb_current_department_id($pdo, $user);
            if (!$legacyDept) {
                return array('sql' => ' AND 1=0 ', 'params' => array());
            }
            return array(
                'sql' => " AND (COALESCE({$alias}.department_id,0) = ? OR (COALESCE({$alias}.department_id,0) = 0 AND EXISTS (
                    SELECT 1 FROM programs plg WHERE plg.department_id = ?
                      AND UPPER(TRIM(plg.code)) COLLATE utf8mb4_unicode_ci = UPPER(TRIM(COALESCE(NULLIF({$alias}.program_code,''), {$alias}.course, ''))) COLLATE utf8mb4_unicode_ci)) ) ",
                'params' => array($legacyDept, $legacyDept)
            );
        }
        /* Explicit collation sa bawat paghahambing ng text — iwas "Illegal mix of
           collations" (500 error) kapag magkaiba ang collation ng enrollees at
           programs tables (hal. utf8mb4_general_ci vs utf8mb4_unicode_ci). */
        $C = ' COLLATE utf8mb4_unicode_ci';
        $programMatch = function ($programAlias) use ($alias, $C) {
            return "(UPPER(TRIM(COALESCE(NULLIF({$alias}.program_code,''),''))){$C} = UPPER(TRIM(COALESCE({$programAlias}.code,''))){$C}
                OR UPPER(TRIM(COALESCE({$alias}.course,''))){$C} = UPPER(TRIM(COALESCE({$programAlias}.code,''))){$C}
                OR (UPPER(TRIM(COALESCE({$alias}.course,''))){$C} = UPPER(TRIM(COALESCE({$programAlias}.course_name,''))){$C}
                    AND (TRIM(COALESCE({$alias}.major,'')) = '' OR UPPER(TRIM(COALESCE({$alias}.major,''))){$C} = UPPER(TRIM(COALESCE({$programAlias}.major,''))){$C})))";
        };
        $allMatch = $programMatch('pscope');
        $assignedMatch = $programMatch('pa');
        $sql = " AND EXISTS (
            SELECT 1 FROM user_department_assignments uda
            WHERE uda.user_id = ? AND uda.is_active = 1
              AND (
                (uda.all_programs = 1 AND (
                    COALESCE({$alias}.department_id,0) = uda.department_id
                    OR EXISTS (SELECT 1 FROM programs pscope WHERE pscope.department_id = uda.department_id AND {$allMatch})
                ))
                OR EXISTS (
                    SELECT 1 FROM user_program_assignments upa
                    INNER JOIN programs pa ON pa.id = upa.program_id
                    WHERE upa.user_department_assignment_id = uda.id
                      AND pa.department_id = uda.department_id
                      AND {$assignedMatch}
                )
              )
        ) ";
        return array('sql' => $sql, 'params' => array($uid));
    }
}

if (!function_exists('ascb_staff_has_active_assignments')) {
    /* TRUE kung may kahit isang active Department assignment ang user (Assign button
       sa Staff Accounts). FALSE rin kapag wala pa ang assignment tables. */
    function ascb_staff_has_active_assignments($pdo, $userId) {
        try {
            $chk = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'user_department_assignments'");
            $chk->execute();
            if (!(int)$chk->fetchColumn()) return false;
            $q = $pdo->prepare("SELECT COUNT(*) FROM user_department_assignments WHERE user_id = ? AND is_active = 1");
            $q->execute(array((int)$userId));
            return (int)$q->fetchColumn() > 0;
        } catch (Exception $e) {
            return false;
        }
    }
}

if (!function_exists('ascb_dean_assignment_scope_sql')) {
    /**
     * DEAN scope para sa Grade Management / Grade Evaluation.
     * - May Assign (department/program) ang Dean  -> ang mga naka-assign lang ang makikita.
     * - Wala pang Assign                           -> dating iisang users.department_id
     *   (para hindi mawalan ng access ang mga lumang Dean account).
     * Parehong shape ng ascb_staff_assignment_scope_sql(): array('sql'=>..., 'params'=>...).
     */
    function ascb_dean_assignment_scope_sql($pdo, $user, $alias = 'e') {
        $uid = (int)ascb_get($user, 'id', 0);
        if ($uid > 0 && ascb_staff_has_active_assignments($pdo, $uid)) {
            return ascb_staff_assignment_scope_sql($pdo, $user, $alias);
        }
        $deptId = (int)ascb_require_dean_department($pdo, $user);
        return array(
            'sql' => " AND (COALESCE({$alias}.department_id,0) = ? OR (COALESCE({$alias}.department_id,0) = 0 AND EXISTS (
                SELECT 1 FROM programs plg WHERE plg.department_id = ?
                  AND UPPER(TRIM(plg.code)) COLLATE utf8mb4_unicode_ci = UPPER(TRIM(COALESCE(NULLIF({$alias}.program_code,''), {$alias}.course, ''))) COLLATE utf8mb4_unicode_ci)) ) ",
            'params' => array($deptId, $deptId)
        );
    }
}

if (!function_exists('ascb_role_assignment_scope_sql')) {
    /* ADMIN STAFF at DEAN: sundin ang Assign; ibang role: walang dagdag na restriction. */
    function ascb_role_assignment_scope_sql($pdo, $user, $alias = 'e') {
        $role = strtoupper(trim((string)ascb_get($user, 'role', '')));
        if ($role === 'DEAN') return ascb_dean_assignment_scope_sql($pdo, $user, $alias);
        if ($role === 'ADMIN STAFF') return ascb_staff_assignment_scope_sql($pdo, $user, $alias);
        return array('sql' => '', 'params' => array());
    }
}

?>
