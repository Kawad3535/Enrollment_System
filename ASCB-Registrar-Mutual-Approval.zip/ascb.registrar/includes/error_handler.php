<?php
/* =========================================================
   HELPER: CENTRALIZED PHP ERROR HANDLING
   ---------------------------------------------------------
   Bago ito, kung may hindi na-catch na Exception/Error (hal. isang
   hindi inaasahang PDOException, isang null-pointer sa isang di
   pa nasusubukang code path) sa loob ng isang api/*.php file na
   walang sariling try/catch, ang mangyayari:

     - Sa production (display_errors=0): BLANGKONG response — ang
       JavaScript sa script.js ay umaasa ng valid JSON, kaya ang
       resulta ay isang generic/nakakalitong "Unable to reach the
       server" sa user, walang detalye sa log maliban sa default
       PHP error log format.
     - Sa debug mode: puwedeng ma-leak ang buong stack trace
       (kasama ang file path, query, atbp.) diretso sa response —
       hindi valid na JSON, at posibleng nakakasira ng seguridad.

   Ang ascb_install_error_handler() ay nagre-rehistro ng ISANG
   pangkalahatang "huling linya ng depensa": kahit anong klaseng
   hindi na-catch na error/exception, laging:
     1) Naka-log nang buo (mensahe + file + line + stack trace) sa
        PHP error log — para may malinaw na masusundan kapag
        nag-imbestiga.
     2) Nagbibigay sa user ng malinaw, WALANG detalyeng-panloob na
        mensahe (JSON para sa API, maikling text para sa page) —
        maliban kung ASCB_DEBUG=1, doon lang lumalabas ang totoong
        mensahe para sa developer.

   Tawagin ito PAGKATAPOS ma-require ang config/app.php (para
   defined na ang ASCB_DEBUG) — ginagawa na ito ng api_guard.php
   at auth_check.php. ========================================================= */

if (!function_exists('ascb_error_handler_respond')) {
    function ascb_error_handler_respond($mode, $debugMessage) {
        if (!headers_sent()) {
            http_response_code(500);
        }
        $friendly = 'The server hit an unexpected error and could not complete your request. Please try again in a moment. If it keeps happening, contact IT/Admin and mention the time it occurred.';
        $message = (defined('ASCB_DEBUG') && ASCB_DEBUG) ? $debugMessage : $friendly;

        if ($mode === 'json') {
            if (!headers_sent()) {
                header('Content-Type: application/json; charset=utf-8');
            }
            echo json_encode(array('ok' => false, 'error' => $message));
        } else {
            echo '<div style="font-family:sans-serif;color:#7a1f1f;background:#fdecea;'
                . 'border:1px solid #f5c2c0;padding:12px 16px;margin:16px;border-radius:6px;">'
                . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</div>';
        }
    }
}

if (!function_exists('ascb_install_error_handler')) {
    /**
     * @param string $mode 'json' para sa api/*.php (JSON response contract),
     *                     'html' para sa mga pahina/export na text/CSV/Excel
     *                     ang tinatawid (best-effort na fallback lang doon —
     *                     hindi maiiwasan ang naipadalang laman kung
     *                     nagsimula na ang streaming bago mag-fatal).
     */
    function ascb_install_error_handler($mode = 'json') {
        static $installed = false;
        if ($installed) return; // huwag paulit-ulit i-rehistro sa parehong request
        $installed = true;

        set_exception_handler(function ($e) use ($mode) {
            error_log('ASCB uncaught exception: ' . $e->getMessage()
                . ' in ' . $e->getFile() . ':' . $e->getLine() . "\n" . $e->getTraceAsString());
            ascb_error_handler_respond($mode, $e->getMessage());
        });

        register_shutdown_function(function () use ($mode) {
            $err = error_get_last();
            $fatalTypes = array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR);
            if ($err && in_array($err['type'], $fatalTypes, true)) {
                error_log('ASCB fatal error: ' . $err['message'] . ' in ' . $err['file'] . ':' . $err['line']);
                // Kung nagsimula na ang output (hal. kalahating-naipadalang
                // CSV/Excel stream), huwag nang subukang magdagdag pa ng
                // JSON/HTML — sisirain lang nito ang naipadala na. Naka-log
                // na ito sa itaas, sapat na iyon para sa pag-iimbestiga.
                if (!headers_sent() && ob_get_length() === false) {
                    ascb_error_handler_respond($mode, $err['message']);
                }
            }
        });
    }
}
