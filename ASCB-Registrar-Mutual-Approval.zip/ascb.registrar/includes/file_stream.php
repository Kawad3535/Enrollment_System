<?php
/* =========================================================
   HELPER: FILE/IMAGE OPTIMIZATION — HTTP FILE STREAMING
   ---------------------------------------------------------
   Iisang function na ginagamit ng lahat ng "serve an uploaded
   file" na endpoint (api/document_file.php, api/approved_so_file.php,
   the removed course-file endpoint) — dati ay tatlong beses paulit-ulit
   isinusulat (at tatlong beses puwedeng malimutan i-optimize) ang
   parehong "readfile()" na code.

   Nagdadagdag ito ng dalawang bagay na wala sa lumang code:

   1) CONDITIONAL CACHING (ETag + Last-Modified) — kapag binuksan
      muli ng browser ang parehong file (hal. pabalik-balik na
      pagtingin sa parehong PDF sa Records/Documents), maibabalik
      na lang ng server ang "304 Not Modified" (walang laman) sa
      halip na muling ipadala ang buong file. Malaki ang epekto
      nito sa malalaking PDF/Excel file na paulit-ulit binubuksan.

   2) HTTP RANGE SUPPORT (206 Partial Content) — kailangan ito ng
      mga browser PDF viewer para mabilis na ma-"scrub"/lumundag sa
      isang partikular na pahina ng malaking PDF sa halip na hintayin
      munang mai-download ang BUONG file bago ito mapakita.

   "private" ang Cache-Control (hindi "public") dahil authenticated,
   per-user-permission ang mga file na ito — hindi dapat i-cache ng
   mga shared/intermediate na proxy, browser cache lang ng user mismo.
   ========================================================= */

if (!function_exists('ascb_stream_file')) {
    /**
     * @param string $path          Ganap na path ng file sa disk.
     * @param string $contentType   Hal. 'application/pdf'.
     * @param string $downloadName  Pangalang makikita ng user (Content-Disposition).
     * @param bool   $inline        true = "inline" (buksan sa browser), false = "attachment" (i-download).
     */
    function ascb_stream_file($path, $contentType, $downloadName, $inline = true) {
        $size  = filesize($path);
        $mtime = filemtime($path);
        if ($size === false || $mtime === false) {
            http_response_code(404);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('ok' => false, 'error' => 'File missing on server.'));
            return;
        }

        // ETag mula sa mtime+size+path — nagbabago lang kapag talagang
        // nagbago ang laman/panahon ng file, kaya ligtas itong i-cache.
        $etag = '"' . md5($path . '|' . $mtime . '|' . $size) . '"';
        $lastModifiedHttp = gmdate('D, d M Y H:i:s', $mtime) . ' GMT';

        header_remove('Content-Type'); // i-override ang JSON default ng api_guard.php
        header('Content-Type: ' . $contentType);
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, max-age=86400, must-revalidate');
        header('ETag: ' . $etag);
        header('Last-Modified: ' . $lastModifiedHttp);
        header('Accept-Ranges: bytes');

        $safeName = str_replace(array("\r", "\n", '"'), '', basename($downloadName));
        header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . $safeName . '"');

        // ----- Conditional GET: 304 Not Modified kung hindi pa nagbago -----
        $ifNoneMatch = isset($_SERVER['HTTP_IF_NONE_MATCH']) ? trim($_SERVER['HTTP_IF_NONE_MATCH']) : '';
        $ifModifiedSince = isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ? $_SERVER['HTTP_IF_MODIFIED_SINCE'] : '';
        if (($ifNoneMatch !== '' && $ifNoneMatch === $etag)
            || ($ifModifiedSince !== '' && @strtotime($ifModifiedSince) >= $mtime)) {
            http_response_code(304);
            return;
        }

        // ----- HTTP Range support: 206 Partial Content -----
        // Kailangan ito ng mga in-browser PDF viewer para mabilis na
        // makapag-jump sa gitna/dulo ng malaking file sa halip na
        // hintaying ma-download muna ang lahat.
        $start = 0;
        $end = $size - 1;
        $isRange = false;
        if (!empty($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', $_SERVER['HTTP_RANGE'], $m)) {
            $rangeStart = $m[1];
            $rangeEnd = $m[2];
            if ($rangeStart === '' && $rangeEnd !== '') {
                // "suffix range" — huling N bytes
                $start = max(0, $size - (int) $rangeEnd);
                $end = $size - 1;
            } else {
                $start = (int) $rangeStart;
                $end = ($rangeEnd !== '') ? min($size - 1, (int) $rangeEnd) : $size - 1;
            }
            if ($start <= $end && $start < $size) {
                $isRange = true;
            }
        }

        $fh = @fopen($path, 'rb');
        if ($fh === false) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('ok' => false, 'error' => 'Unable to read file.'));
            return;
        }

        if ($isRange) {
            http_response_code(206);
            header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
            header('Content-Length: ' . ($end - $start + 1));
            fseek($fh, $start);
            $remaining = $end - $start + 1;
            while ($remaining > 0 && !feof($fh)) {
                $chunk = fread($fh, min(1024 * 256, $remaining));
                if ($chunk === false) break;
                echo $chunk;
                $remaining -= strlen($chunk);
            }
        } else {
            header('Content-Length: ' . $size);
            fpassthru($fh);
        }
        fclose($fh);
    }
}
