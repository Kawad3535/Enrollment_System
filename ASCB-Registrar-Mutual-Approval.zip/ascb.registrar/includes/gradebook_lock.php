<?php
/* Subject Gradebook locking helpers.
 *
 * 2026-09-22 — LOCKING FEATURE DISABLED.
 * Reason: subjects that were locked could no longer be unlocked in practice
 * (only the UNIT HEAD role was allowed, and the lock key was matched on a
 * normalized School Year + Term + Code + Description tuple, so any stored row
 * whose description differed slightly became a permanent, unclearable block on
 * grade encoding and grade-sheet imports).
 *
 * The helpers are kept so every existing call site continues to work, but they
 * now always report "no active lock". The subject_grade_locks table is left in
 * place as historical audit data; run
 * database/clear_subject_grade_locks_once.php to purge the stale rows.
 */
require_once __DIR__ . '/helpers.php';

if (!function_exists('ascb_gradebook_norm_text')) {
    function ascb_gradebook_norm_text($value) {
        $value = trim((string)$value);
        $value = preg_replace('/\s+/u', ' ', $value);
        return function_exists('mb_strtoupper') ? mb_strtoupper($value, 'UTF-8') : strtoupper($value);
    }
}

if (!function_exists('ascb_gradebook_locks_enabled')) {
    function ascb_gradebook_locks_enabled() {
        return false;
    }
}

if (!function_exists('ascb_gradebook_lock_find')) {
    /* Always null: locking is disabled, so no subject is ever blocked. */
    function ascb_gradebook_lock_find($pdo, $schoolYear, $term, $courseCode, $description) {
        return null;
    }
}

if (!function_exists('ascb_gradebook_lock_assert_editable')) {
    /* No-op: every subject is editable. */
    function ascb_gradebook_lock_assert_editable($pdo, $schoolYear, $term, $courseCode, $description, $role) {
        return null;
    }
}

if (!function_exists('ascb_gradebook_locks_clear')) {
    /* Removes any stored lock rows for a subject (best effort, never fatal). */
    function ascb_gradebook_locks_clear($pdo, $schoolYear, $term, $courseCode, $description) {
        try {
            $q = $pdo->prepare("DELETE FROM subject_grade_locks WHERE school_year = ? AND trimester = ? AND course_code = ?");
            $q->execute([
                trim((string)$schoolYear),
                trim((string)$term),
                ascb_gradebook_norm_text($courseCode)
            ]);
            return $q->rowCount();
        } catch (Throwable $e) {
            return 0;
        }
    }
}
