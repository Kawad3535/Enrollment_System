<?php
/* =========================================================
   HELPER: HONORS (President's Lister / Dean's Lister)
   ---------------------------------------------------------
   Iisang function na ginagamit ng api/honors.php (JSON, para
   sa on-screen table) AT ng api/honors_export.php (Excel
   report) — para hindi dalawang beses isulat ang parehong
   GWA-computation logic at laging magkatugma ang nakikita sa
   screen at ang na-e-export (parehong prinsipyo gaya ng
   includes/dashboard_stats_helper.php).

   ascb_honors_rows($pdo, $ascbUser, $trimester, $schoolYear):
       $trimester, $schoolYear — opsyonal, blangko ("") = lahat.

   Per TERM (isang enrollment record) kinakalkula ang GWA —
   weighted average ng grade x units, parehong formula gaya ng
   Grade Evaluation (ascbGradeEvalTermGWA sa script.js) — at
   ini-classify:

     - PRESIDENT'S LISTER : GWA 1.00 - 1.45
     - DEAN'S LISTER       : GWA 1.46 - 1.75

   Bago maisama sa alinman sa dalawa, kailangan munang:
     - LAHAT ng subjects ng term na iyon ay may NUMERIC na
       grade (walang blangko, INC, o DRP).
     - WALANG grade na mas mataas sa 2.00 sa alinmang subject.

   Gusto pang baguhin ang cutoff/requirement? Dito lang sa
   mga constant sa ibaba — sentralisado tulad ng
   includes/permissions.php.

   DEAN accounts: sariling Department lang, parehong pattern
   gaya ng Dashboard Stats / Grade Evaluation.
   ========================================================= */

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/departments.php';

if (!defined('ASCB_HONORS_PRESIDENT_MIN')) define('ASCB_HONORS_PRESIDENT_MIN', 1.00);
if (!defined('ASCB_HONORS_PRESIDENT_MAX')) define('ASCB_HONORS_PRESIDENT_MAX', 1.45);
if (!defined('ASCB_HONORS_DEAN_MIN')) define('ASCB_HONORS_DEAN_MIN', 1.46);
if (!defined('ASCB_HONORS_DEAN_MAX')) define('ASCB_HONORS_DEAN_MAX', 1.75);
if (!defined('ASCB_HONORS_MAX_SUBJECT_GRADE')) define('ASCB_HONORS_MAX_SUBJECT_GRADE', 2.00);

if (!function_exists('ascb_honors_is_numeric_grade')) {
    function ascb_honors_is_numeric_grade($grade) {
        $g = trim((string) $grade);
        if ($g === '') return false;
        return is_numeric($g); // excludes blank/INC/DRP
    }
}

if (!function_exists('ascb_honors_rows')) {
    function ascb_honors_rows($pdo, $ascbUser, $trimester = '', $schoolYear = '') {
        $trimester  = trim((string) $trimester);
        $schoolYear = trim((string) $schoolYear);
        $role = ascb_get($ascbUser, 'role', '');

        $where = array("e.archived_at IS NULL", "LOWER(TRIM(e.status)) = 'approved'");
        $params = array();

        if ($role === 'DEAN') {
            $deptId = ascb_require_dean_department($pdo, $ascbUser);
            $where[] = "e.department_id = ?";
            $params[] = $deptId;
        }
        if ($trimester !== '') {
            // Normalize legacy labels found in imported data. Semester-based
            // programs use Summer for their third semester; do not treat Summer
            // as a third trimester because those are different academic systems.
            $term = strtolower(preg_replace('/\s+/', ' ', trim($trimester)));
            $termAliases = array(
                '1st trimester' => array('1st trimester', 'first trimester', '1st'),
                '2nd trimester' => array('2nd trimester', 'second trimester', '2nd'),
                '3rd trimester' => array('3rd trimester', 'third trimester', '3rd'),
                '1st semester'  => array('1st semester', 'first semester'),
                '2nd semester'  => array('2nd semester', 'second semester'),
                'summer'        => array('summer', '3rd semester'),
                '3rd semester'  => array('summer', '3rd semester')   /* backward compatible sa lumang value */
            );
            if (isset($termAliases[$term])) {
                $aliases = $termAliases[$term];
                $where[] = 'LOWER(TRIM(e.trimester)) IN (' . implode(',', array_fill(0, count($aliases), '?')) . ')';
                foreach ($aliases as $alias) $params[] = $alias;
            } else {
                $where[] = "LOWER(TRIM(e.trimester)) = ?";
                $params[] = $term;
            }
        }
        if ($schoolYear !== '') { $where[] = "e.school_year = ?"; $params[] = $schoolYear; }

        /*
         * Large-data implementation: aggregate one row per enrollment in SQL.
         * The previous version loaded every subject into PHP with fetchAll(),
         * then grouped/calculated GWA in memory. That does not scale.
         */
        $sql = "SELECT
                    e.id AS enrollment_id,
                    e.student_id,
                    e.surname,
                    e.first_name,
                    e.middle_name" . ascb_suffix_sql_cols($pdo) . ",
                    e.course,
                    e.major,
                    e.program_code,
                    e.year_level,
                    e.trimester,
                    e.school_year,
                    e.student_type,
                    COALESCE(d.name, pd.name) AS department_name,
                    ROUND(
                        SUM(CASE
                            WHEN g.grade REGEXP '^[0-9]+(\\.[0-9]+)?$'
                            THEN CAST(g.grade AS DECIMAL(10,4)) * es.units
                            ELSE 0
                        END) / NULLIF(SUM(es.units),0), 2
                    ) AS gwa
                FROM enrollees e
                INNER JOIN enrollment_subjects es ON es.enrollment_id = e.id
                LEFT JOIN grades g ON g.enrollment_subject_id = es.id
                LEFT JOIN departments d ON d.id = e.department_id
                LEFT JOIN programs p ON UPPER(TRIM(p.code)) = UPPER(TRIM(e.program_code))
                LEFT JOIN departments pd ON pd.id = p.department_id
                WHERE " . implode(' AND ', $where) . "
                GROUP BY e.id, e.student_id, e.surname, e.first_name, e.middle_name" . ascb_suffix_sql_cols($pdo) . ",
                         e.course, e.major, e.program_code, e.year_level, e.trimester,
                         e.school_year, e.student_type, d.name, pd.name
                HAVING COUNT(es.id) > 0
                   AND SUM(CASE
                       WHEN g.grade REGEXP '^[0-9]+(\\.[0-9]+)?$' THEN 1 ELSE 0
                   END) = COUNT(es.id)
                   AND MAX(CASE
                       WHEN g.grade REGEXP '^[0-9]+(\\.[0-9]+)?$'
                       THEN CAST(g.grade AS DECIMAL(10,4))
                       ELSE 999
                   END) <= " . (float) ASCB_HONORS_MAX_SUBJECT_GRADE . "
                   AND ROUND(
                       SUM(CAST(g.grade AS DECIMAL(10,4)) * es.units) / NULLIF(SUM(es.units),0), 2
                   ) BETWEEN " . (float) ASCB_HONORS_PRESIDENT_MIN . " AND " . (float) ASCB_HONORS_DEAN_MAX . "
                ORDER BY e.surname, e.first_name";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = array();

        while ($r = $stmt->fetch()) {
            $gwa = (float) $r['gwa'];
            $listType = null;
            if ($gwa >= ASCB_HONORS_PRESIDENT_MIN && $gwa <= ASCB_HONORS_PRESIDENT_MAX) {
                $listType = 'PRESIDENT';
            } elseif ($gwa >= ASCB_HONORS_DEAN_MIN && $gwa <= ASCB_HONORS_DEAN_MAX) {
                $listType = 'DEAN';
            }
            if (!$listType) continue;

            $r = ascb_row_master_suffix($r); /* (fix) CURRENT suffix mula sa Master Record */
            $rows[] = array(
                'enrollment_id'   => (int) $r['enrollment_id'],
                'student_id'      => $r['student_id'],
                'student_name'    => ascb_name_print($r['surname'], $r['first_name'], $r['middle_name'], isset($r['suffix']) ? $r['suffix'] : '', isset($r['suffix_position']) ? $r['suffix_position'] : 'separate'),
                'course'          => $r['course'],
                'major'           => $r['major'],
                'program_code'    => $r['program_code'],
                'year_level'      => $r['year_level'],
                'trimester'       => $r['trimester'],
                'school_year'     => $r['school_year'],
                'student_type'    => $r['student_type'],
                'department_name' => $r['department_name'],
                'gwa'             => $gwa,
                'list_type'       => $listType,
            );
        }

        usort($rows, function ($a, $b) {
            if ($a['list_type'] !== $b['list_type']) return $a['list_type'] === 'PRESIDENT' ? -1 : 1;
            if ($a['gwa'] !== $b['gwa']) return $a['gwa'] <=> $b['gwa'];
            return strcmp($a['student_name'], $b['student_name']);
        });

        return $rows;
    }
}
