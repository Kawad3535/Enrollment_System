<?php
/* =========================================================
   LOGIN THROTTLE / ACCOUNT LOCKOUT
   ---------------------------------------------------------
   (2024 audit fix) Dati, isang flat 350ms na `usleep()` lang
   ang tanging depensa laban sa paulit-ulit na pag-guess ng
   password — sapat laban sa isang thread/connection, pero
   hindi laban sa parallel na mga request. Dinagdagan ito ng
   simpleng per-username na counter (`login_attempts` table,
   tingnan ang includes/schema_upgrade.php): pagkatapos ng
   ASCB_LOGIN_MAX_ATTEMPTS na magkakasunod na maling password
   sa loob ng ASCB_LOGIN_WINDOW_SECONDS, ni-lo-lock ang
   username na iyon sa loob din ng parehong haba ng oras.

   Sinasadyang naka-try/catch ang lahat dito (tulad ng
   activity_log.php): kung sakaling mabigo ito (hal. hindi pa
   na-migrate ang bagong table sa isang lumang deployment),
   hindi dapat ito ang dahilan para hindi na makapag-login ang
   lahat ng tao — mas mabuti pang mawalan muna ng lockout
   protection kaysa ma-lock out lahat sa sarili nilang system.
   ========================================================= */

if (!function_exists('ascb_login_throttle_window_seconds')) {
    function ascb_login_throttle_window_seconds() {
        return 15 * 60; // 15 minutes
    }
}

if (!function_exists('ascb_login_throttle_max_attempts')) {
    function ascb_login_throttle_max_attempts() {
        return 5;
    }
}

/* Ibinabalik ang bilang ng segundong natitira bago ma-unlock ang
   username na ito, o 0 kung hindi (o hindi na) naka-lock. */
if (!function_exists('ascb_login_locked_seconds_remaining')) {
    function ascb_login_locked_seconds_remaining($pdo, $username) {
        try {
            $stmt = $pdo->prepare("SELECT locked_until FROM login_attempts WHERE username = ?");
            $stmt->execute(array($username));
            $lockedUntil = $stmt->fetchColumn();
            if (!$lockedUntil) {
                return 0;
            }
            $remaining = strtotime($lockedUntil) - time();
            return $remaining > 0 ? $remaining : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
}

/* Tinatawag pagkatapos ng isang HINDI matagumpay na password check. */
if (!function_exists('ascb_login_record_failure')) {
    function ascb_login_record_failure($pdo, $username) {
        try {
            $window      = ascb_login_throttle_window_seconds();
            $maxAttempts = ascb_login_throttle_max_attempts();
            $now         = time();

            $stmt = $pdo->prepare("SELECT failed_count, first_failed_at FROM login_attempts WHERE username = ?");
            $stmt->execute(array($username));
            $row = $stmt->fetch();

            $windowExpired = (!$row) || empty($row['first_failed_at']) ||
                ((strtotime($row['first_failed_at']) + $window) < $now);

            if ($windowExpired) {
                // Walang existing row, o luma na ang window (matagal
                // nang huling maling attempt) — magsimula ulit sa 1.
                $ins = $pdo->prepare(
                    "INSERT INTO login_attempts (username, failed_count, first_failed_at, locked_until)
                         VALUES (?, 1, ?, NULL)
                     ON DUPLICATE KEY UPDATE
                         failed_count = 1, first_failed_at = VALUES(first_failed_at), locked_until = NULL"
                );
                $ins->execute(array($username, date('Y-m-d H:i:s', $now)));
                return;
            }

            $newCount    = (int) $row['failed_count'] + 1;
            $lockedUntil = ($newCount >= $maxAttempts) ? date('Y-m-d H:i:s', $now + $window) : null;

            $upd = $pdo->prepare("UPDATE login_attempts SET failed_count = ?, locked_until = ? WHERE username = ?");
            $upd->execute(array($newCount, $lockedUntil, $username));
        } catch (Exception $e) {
            // Hindi dapat mabigo ang buong login flow dahil lang mabigo
            // ang pag-log ng throttle counter.
        }
    }
}

/* Tinatawag pagkatapos ng isang MATAGUMPAY na login — nililinis ang
   counter para hindi na apektuhan ng lumang failed attempts. */
if (!function_exists('ascb_login_reset_throttle')) {
    function ascb_login_reset_throttle($pdo, $username) {
        try {
            $del = $pdo->prepare("DELETE FROM login_attempts WHERE username = ?");
            $del->execute(array($username));
        } catch (Exception $e) {
        }
    }
}
