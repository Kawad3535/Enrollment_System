<?php
function ascb_mail_config() { static $c; if ($c === null) $c = require __DIR__.'/../config/mail.php'; return $c; }
function ascb_smtp_read($fp) {
    $out=''; while (!feof($fp)) { $line=fgets($fp,515); if($line===false) break; $out.=$line; if(strlen($line)>=4 && $line[3]===' ') break; } return $out;
}
function ascb_smtp_expect($fp,$codes) {
    $r=ascb_smtp_read($fp); $code=(int)substr($r,0,3);
    if(!in_array($code,(array)$codes,true)) throw new Exception('SMTP '.$code.': '.trim($r)); return $r;
}
function ascb_smtp_cmd($fp,$cmd,$codes) { fwrite($fp,$cmd."\r\n"); return ascb_smtp_expect($fp,$codes); }
function ascb_mail_header_encode($s) { return '=?UTF-8?B?'.base64_encode($s).'?='; }

function ascb_mail_send_official_enrollment($to,$studentName,$studentId,$course,$yearLevel,$term,$schoolYear) {
    $c=ascb_mail_config();
    if(empty($c['enabled'])) return ['ok'=>false,'error'=>'Gmail SMTP is disabled in config/mail.php.'];
    $to=trim((string)$to);
    if(!filter_var($to,FILTER_VALIDATE_EMAIL)) return ['ok'=>false,'error'=>'Invalid student Gmail/email address.'];
    foreach(['username','password','from_email'] as $k) if(empty($c[$k]) || strpos((string)$c[$k],'YOUR_')===0) return ['ok'=>false,'error'=>'Gmail SMTP credentials are not configured.'];
    $fp=@stream_socket_client('ssl://'.$c['host'].':'.(int)$c['port'],$errno,$errstr,15,STREAM_CLIENT_CONNECT,
        stream_context_create(['ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'allow_self_signed'=>false]]));
    if(!$fp) return ['ok'=>false,'error'=>'Could not connect to Gmail SMTP: '.$errstr.' ('.$errno.')'];
    stream_set_timeout($fp,15);
    try {
        ascb_smtp_expect($fp,220); ascb_smtp_cmd($fp,'EHLO localhost',[250]);
        ascb_smtp_cmd($fp,'AUTH LOGIN',[334]); ascb_smtp_cmd($fp,base64_encode($c['username']),[334]); ascb_smtp_cmd($fp,base64_encode($c['password']),[235]);
        ascb_smtp_cmd($fp,'MAIL FROM:<'.$c['from_email'].'>',[250]); ascb_smtp_cmd($fp,'RCPT TO:<'.$to.'>',[250,251]); ascb_smtp_cmd($fp,'DATA',[354]);
        $h=htmlspecialchars($studentName,ENT_QUOTES,'UTF-8'); $id=htmlspecialchars($studentId,ENT_QUOTES,'UTF-8');
        $co=htmlspecialchars($course ?: '—',ENT_QUOTES,'UTF-8'); $yl=htmlspecialchars($yearLevel ?: '—',ENT_QUOTES,'UTF-8');
        $tm=htmlspecialchars($term ?: '—',ENT_QUOTES,'UTF-8'); $sy=htmlspecialchars($schoolYear ?: '—',ENT_QUOTES,'UTF-8');
        $subject='Official Enrollment Confirmation - ASCB';
        $html='<html><body style="font-family:Arial,sans-serif;line-height:1.6;color:#222"><h2>Official Enrollment Confirmation</h2><p>Dear <strong>'.$h.'</strong>,</p><p>You are <strong>officially enrolled at Andres Soriano Colleges of Bislig, Inc. (ASCB)</strong>.</p><p><strong>Student ID:</strong> '.$id.'<br><strong>Course / Program:</strong> '.$co.'<br><strong>Year Level:</strong> '.$yl.'<br><strong>Term:</strong> '.$tm.'<br><strong>Academic Year:</strong> '.$sy.'</p><p>Please keep this email for your records.</p><p>Regards,<br><strong>ASCB Registrar</strong><br>Andres Soriano Colleges of Bislig, Inc.</p></body></html>';
        $msg='Date: '.date(DATE_RFC2822)."\r\n".'From: '.ascb_mail_header_encode($c['from_name']).' <'.$c['from_email'].">\r\n".'To: <'.$to.">\r\n".'Subject: '.ascb_mail_header_encode($subject)."\r\n".'MIME-Version: 1.0'."\r\n".'Content-Type: text/html; charset=UTF-8'."\r\n".'Content-Transfer-Encoding: 8bit'."\r\n\r\n".$html;
        $msg=preg_replace('/^\./m','..',$msg); fwrite($fp,$msg."\r\n.\r\n"); ascb_smtp_expect($fp,250); @fwrite($fp,"QUIT\r\n"); @fclose($fp); return ['ok'=>true];
    } catch(Throwable $e) { @fwrite($fp,"QUIT\r\n"); @fclose($fp); return ['ok'=>false,'error'=>$e->getMessage()]; }
}
?>