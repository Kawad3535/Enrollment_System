<?php
/* =========================================================
   MASTER RECORD - SHARED HELPERS
   ---------------------------------------------------------
   Used by api/master_record.php and, defensively, by the
   Enrollment / Grade Import / Student 360 APIs.

   Every function here is safe to call BEFORE the migration
   (database/migrate_master.php) has been run: if the
   student_master table does not exist yet, they return
   false / empty arrays and never throw, so the existing
   modules keep working exactly as before.
   ========================================================= */

require_once __DIR__ . '/helpers.php';

if (!function_exists('ascb_master_available')) {
    /* true if the student_master + student_name_history tables exist. */
    function ascb_master_available($pdo) {
        static $ok = null;
        if ($ok !== null) return $ok;
        try {
            $pdo->query("SELECT 1 FROM student_master LIMIT 1");
            $pdo->query("SELECT 1 FROM student_name_history LIMIT 1");
            $ok = true;
        } catch (Exception $e) {
            $ok = false;
        }
        return $ok;
    }
}

if (!function_exists('ascb_master_format_name')) {
    /* Same shape the rest of the system already uses:
       "Surname, First Middle" (+ suffix when there is one).
       $position (optional) = PSA placement of the suffix:
       'separate' (default, at the end) | 'first_name' | 'surname'.
       Old callers that pass 4 arguments behave exactly as before. */
    function ascb_master_format_name($surname, $first, $middle, $suffix = '', $position = 'separate') {
        return ascb_name_print($surname, $first, $middle, $suffix, $position);
    }
}

if (!function_exists('ascb_master_natural_name')) {
    /* "First Middle Surname Suffix" - used in the marriage preview.
       Honors the PSA placement of the suffix. */
    function ascb_master_natural_name($surname, $first, $middle, $suffix = '', $position = 'separate') {
        $p = ascb_name_print_parts($surname, $first, $middle, $suffix, $position);
        $parts = array($p['first_name'], $p['middle_name'], $p['surname'], $p['suffix_tail']);
        $out = array();
        foreach ($parts as $x) { if ($x !== '') $out[] = $x; }
        return implode(' ', $out);
    }
}

if (!function_exists('ascb_master_ensure')) {
    /* Make sure a student_master row exists for $studentId. Never
       overwrites an existing row (INSERT IGNORE on the unique
       student_id). $f uses the enrollees column names. Returns true
       when a row exists afterwards, false on any problem. */
    function ascb_master_ensure($pdo, $studentId, $f, $userId = null) {
        $studentId = trim((string) $studentId);
        if ($studentId === '' || !ascb_master_available($pdo)) return false;
        $surname = trim((string) ascb_get($f, 'surname', ''));
        $first   = trim((string) ascb_get($f, 'first_name', ''));
        if ($surname === '' || $first === '') return false;

        $nn = function ($v) { $v = trim((string) $v); return $v !== '' ? $v : null; };
        $civil = trim((string) ascb_get($f, 'civil_status', ''));
        if (!in_array($civil, array('Single', 'Married', 'Widowed', 'Separated'), true)) $civil = null;
        $sex = trim((string) ascb_get($f, 'sex', ''));
        if (!in_array($sex, array('Male', 'Female'), true)) $sex = null;

        try {
            $stmt = $pdo->prepare(
                "INSERT IGNORE INTO student_master
                    (student_id, surname, first_name, middle_name, sex, civil_status, birth_date,
                     birthplace, address, mobile_number, email, guardian_name, nationality, updated_by)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            );
            $stmt->execute(array(
                $studentId, $surname, $first, $nn(ascb_get($f, 'middle_name', '')), $sex, $civil,
                $nn(ascb_get($f, 'birth_date', '')), $nn(ascb_get($f, 'birth_place', '')),
                $nn(ascb_get($f, 'address', '')), $nn(ascb_get($f, 'mobile_number', '')),
                $nn(ascb_get($f, 'email', '')), $nn(ascb_get($f, 'guardian_name', '')),
                'Filipino', $userId,
            ));
            /* Suffix + PSA placement: isinusulat lang sa BAGONG master row
               (rowCount = 1). Hindi ginagalaw ang existing na master row --
               dumadaan sa Master Record module ang pagbabago ng pangalan. */
            if ($stmt->rowCount() === 1) {
                $sfx = trim((string) ascb_get($f, 'suffix', ''));
                if ($sfx !== '') {
                    $pos = ascb_normalize_suffix_position(ascb_get($f, 'suffix_position', 'separate'));
                    if (ascb_column_exists($pdo, 'student_master', 'suffix_position')) {
                        $u = $pdo->prepare("UPDATE student_master SET suffix = ?, suffix_position = ? WHERE student_id = ?");
                        $u->execute(array($sfx, $pos, $studentId));
                    } else {
                        $u = $pdo->prepare("UPDATE student_master SET suffix = ? WHERE student_id = ?");
                        $u->execute(array($sfx, $studentId));
                    }
                }
            }
            return true;
        } catch (Exception $e) {
            error_log('ASCB master ensure failed: ' . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('ascb_master_sync_details')) {
    /* (2026-09-27 fix) Push the NON-NAME personal details of an
       enrollment save (New Term / Edit) into the student's Master Record.
       ascb_master_ensure() is INSERT IGNORE, so before this fix a changed
       Birthplace/Address/etc. on New Term never reached student_master.
       Rules: only non-empty values are written (a blank field never erases
       master data); name fields are NOT touched here because name changes
       go through the Master Record module with its name history. */
    function ascb_master_sync_details($pdo, $studentId, $f, $userId = null) {
        $studentId = trim((string) $studentId);
        if ($studentId === '' || !ascb_master_available($pdo)) return false;
        $map = array(
            'sex' => 'sex', 'civil_status' => 'civil_status', 'birth_date' => 'birth_date',
            'birth_place' => 'birthplace', 'address' => 'address', 'mobile_number' => 'mobile_number',
            'email' => 'email', 'guardian_name' => 'guardian_name',
        );
        $sets = array(); $vals = array();
        foreach ($map as $in => $col) {
            $v = trim((string) ascb_get($f, $in, ''));
            if ($v === '') continue;
            if ($in === 'sex' && !in_array($v, array('Male', 'Female'), true)) continue;
            if ($in === 'civil_status' && !in_array($v, array('Single', 'Married', 'Widowed', 'Separated'), true)) continue;
            $sets[] = "$col = ?"; $vals[] = $v;
        }
        if (!$sets) return true;
        $sets[] = 'updated_by = ?'; $vals[] = $userId;
        $vals[] = $studentId;
        try {
            $stmt = $pdo->prepare("UPDATE student_master SET " . implode(', ', $sets) . " WHERE student_id = ?");
            $stmt->execute($vals);
            return true;
        } catch (Exception $e) {
            error_log('ASCB master sync failed: ' . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('ascb_master_propagate_suffix')) {
    /* (fix) Ang Suffix + PSA placement ay ISANG katotohanan lang bawat estudyante
       (ayon sa PSA), kaya kapag binago ito, ipinapasa sa LAHAT ng enrollment
       (term) rows ng Student ID na iyon. Ang exports (Department, Honors,
       Promotional, Gradebook, atbp.) ay nagbabasa ng enrollees.suffix /
       enrollees.suffix_position, kaya kapag hindi ito na-update ay luma pa rin
       ang lalabas. Surname / First / Middle ng lumang rows ay HINDI ginagalaw
       (history iyon). Walang suffix = position 'separate'. */
    function ascb_master_propagate_suffix($pdo, $studentId, $suffix, $position) {
        $studentId = trim((string) $studentId);
        if ($studentId === '') return false;
        if (!ascb_column_exists($pdo, 'enrollees', 'suffix') || !ascb_column_exists($pdo, 'enrollees', 'suffix_position')) return false;
        $suffix = trim((string) $suffix);
        $position = $suffix !== '' ? ascb_normalize_suffix_position($position) : 'separate';
        try {
            $stmt = $pdo->prepare("UPDATE enrollees SET suffix = ?, suffix_position = ? WHERE student_id = ?");
            $stmt->execute(array($suffix !== '' ? $suffix : null, $position, $studentId));
            return true;
        } catch (Exception $e) {
            error_log('ASCB suffix propagate failed: ' . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('ascb_master_sync_suffix')) {
    /* Isulat ang Suffix + PSA placement sa Master Record (kung iba sa kasalukuyan)
       at ipasa sa lahat ng enrollment rows ng estudyante. Ginagamit ng Enrollment
       Edit kapag talagang binago ang suffix. */
    function ascb_master_sync_suffix($pdo, $studentId, $suffix, $position, $userId = null) {
        $studentId = trim((string) $studentId);
        if ($studentId === '' || !ascb_master_available($pdo)) return false;
        $suffix = trim((string) $suffix);
        $position = $suffix !== '' ? ascb_normalize_suffix_position($position) : 'separate';
        try {
            $hasPos = ascb_column_exists($pdo, 'student_master', 'suffix_position');
            $sql = "UPDATE student_master SET suffix = ?" . ($hasPos ? ", suffix_position = ?" : "") . ", updated_by = ? WHERE student_id = ?";
            $params = array($suffix !== '' ? $suffix : null);
            if ($hasPos) $params[] = $position;
            $params[] = $userId;
            $params[] = $studentId;
            $pdo->prepare($sql)->execute($params);
        } catch (Exception $e) {
            error_log('ASCB master suffix sync failed: ' . $e->getMessage());
            return false;
        }
        return ascb_master_propagate_suffix($pdo, $studentId, $suffix, $position);
    }
}

if (!function_exists('ascb_master_current')) {
    /* The current master row for a Student ID (or null). */
    function ascb_master_current($pdo, $studentId) {
        $studentId = trim((string) $studentId);
        if ($studentId === '' || !ascb_master_available($pdo)) return null;
        try {
            $stmt = $pdo->prepare("SELECT * FROM student_master WHERE student_id = ? LIMIT 1");
            $stmt->execute(array($studentId));
            $row = $stmt->fetch();
            return $row ? $row : null;
        } catch (Exception $e) {
            return null;
        }
    }
}

if (!function_exists('ascb_master_renamed_map')) {
    /* Students whose name has EVER been changed through the Master
       Record, keyed by student_id. Other modules use this to show the
       current name for new output (Grade Evaluation prints, New Term)
       without touching any historical row. The set is small (only
       students with a name-history entry), so it is cheap to load.

       $deptId (int|null): when set, only students who have at least one
       enrollment in that Department (Dean scope). */
    function ascb_master_renamed_map($pdo, $deptId = null) {
        $out = array();
        if (!ascb_master_available($pdo)) return $out;
        try {
            $sql = "SELECT m.*
                    FROM student_master m
                    WHERE EXISTS (SELECT 1 FROM student_name_history h WHERE h.student_id = m.student_id)";
            $params = array();
            if ($deptId !== null) {
                $sql .= " AND EXISTS (SELECT 1 FROM enrollees e WHERE e.student_id = m.student_id AND e.department_id = ?)";
                $params[] = (int) $deptId;
            }
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            foreach ($stmt->fetchAll() as $r) {
                $out[$r['student_id']] = array(
                    'surname'    => $r['surname'],
                    'firstName'  => $r['first_name'],
                    'middleName' => $r['middle_name'],
                    'suffix'     => $r['suffix'],
                    'suffixPosition' => ascb_normalize_suffix_position(isset($r['suffix_position']) ? $r['suffix_position'] : ''),
                    'fullName'   => ascb_master_format_name($r['surname'], $r['first_name'], $r['middle_name'], $r['suffix'], isset($r['suffix_position']) ? $r['suffix_position'] : 'separate'),
                );
            }
        } catch (Exception $e) {
            error_log('ASCB master renamed map failed: ' . $e->getMessage());
        }
        return $out;
    }
}
