<?php
/* =========================================================
   ROLE PERMISSIONS — ADMIN MODULE
   ---------------------------------------------------------
   Lahat ng naka-login (kahit anong role) ay may access sa
   Admin panel — pero magkaiba ang kayang gawin ng bawat isa
   dito. Dito lang nakadepende ang lahat ng permission checks
   (parehong ginagamit sa PHP/API side at pinapadala sa
   frontend para sa pag-hide/disable ng mga button).

   PERMISSIONS:
     manage_users      - add / edit / deactivate / delete
                          user accounts (sensitive — UNIT HEAD
                          lang, ito ang pinakamataas na role).
     delete_lookups    - pwedeng mag-DELETE ng schools/courses
                          (ang pag-ADD ay bukas pa rin sa lahat,
                          tulad ng dati, dahil ginagamit ito
                          habang pumupuno ng Form 137-A).
     view_activity_log - makikita ang History/Activity Log ng
                          buong system.
     approve_enrollment - pwedeng mag-Approve/Reject ng mga
                          enrollment record na "pending" (mga
                          na-input ng ADMIN STAFF) — UNIT HEAD
                          o SCHOOL REGISTRAR (2026 fix: kahit
                          sino sa dalawa, sapat na — hindi na
                          kailangan pareho).
     update_enrollment  - pwedeng mag-Update/edit ng existing
                          enrollment record (student/term/subject assignment only — grades are managed
                          separately in Grade Management) —
                          UNIT HEAD at ADMIN STAFF (2026 fix:
                          binuksan na rin ito sa ADMIN STAFF,
                          kasama ang New Term — pero kapag ADMIN
                          STAFF ang nag-update, babalik itong
                          "pending" at kailangan pa ring aprubahan
                          ng UNIT HEAD o SCHOOL REGISTRAR, gaya
                          rin ng ginagawa na sa create/New Term).
     delete_enrollment  - pwedeng mag-DELETE/Archive ng existing
                          enrollment record. Dating ginagamit ang
                          'delete_lookups' key para dito rin — hiniwalay
                          ito (2024 audit fix) para hindi na magkasabay
                          magbago ang access sa Enrollment deletion at
                          sa Schools/Courses deletion kapag may
                          nag-edit sa isa lang sa dalawa balang araw.
                          Parehong role pa rin sa ngayon.
     hide_grades       - pwedeng mag-toggle ng subject visibility sa
                          Grade Evaluation / Student Portal
                          (display-only flag sa
                          enrollment_subjects.hidden_on_print). HINDI
                          nito kasama ang pag-encode/edit ng aktwal na
                          grade — iyon ay 'manage_grades' pa rin
                          (UNIT HEAD / SCHOOL REGISTRAR ang official grade approvers; ADMIN STAFF submissions require approval). Sadyang
                          hiniwalay ito para makapag-hide ang DEAN
                          (sariling Department lang) at ADMIN STAFF
                          nang hindi binibigyan ng access sa
                          Grade Management (grade encoding).
     approve_record_correction - pwedeng mag-approve/reject ng Previous
                          Term Correction requests — UNIT HEAD lang
                          (2026 fix). Kahit sinong UNIT HEAD account
                          ang gumawa (request) ng correction, kaya
                          pa rin itong i-approve ng kahit sinong
                          UNIT HEAD (pati na rin ang gumawa nito) —
                          wala nang "requester ≠ approver" restriction.
                          Ang ADMIN STAFF pa rin ang pangunahing
                          gumagawa ng request (request_record_correction).
     manage_office_records - pwedeng mag-add/delete ng entries sa
                          Approved SO, at makakuha (download) ng mga naka-attach na
                          file doon. (2024 audit
                          fix) Dating BUKAS ito sa LAHAT ng naka-login
                          kahit DEAN — pero walang Department-level na
                          paghihiwalay ang mga table na ito (general
                          registrar-office logs, hindi enrollment record
                          ng isang particular na Department), kaya
                          in-eexclude na ang DEAN dito para tugma sa
                          "read-only / sariling Department lang" na
                          prinsipyo na sinusunod na ng ibang modules.
                          Kung talagang kailangan ng DEAN ang access na
                          ito, idagdag lang siya sa listahan sa ibaba.

   Baguhin lang dito kung sino ang dapat may access — sentralisado
   ito para hindi na kailangang hanapin sa maraming files.
   ========================================================= */

if (!function_exists('ascb_can')) {
    function ascb_can($role, $permission) {
        $matrix = array(
            'manage_users'         => array('UNIT HEAD'),
            'manage_lookups'       => array('UNIT HEAD', 'ADMIN STAFF'),
            'delete_lookups'       => array('UNIT HEAD', 'SCHOOL REGISTRAR'),
            'view_activity_log'    => array('UNIT HEAD', 'SCHOOL REGISTRAR'),
            'approve_enrollment'   => array('UNIT HEAD', 'SCHOOL REGISTRAR'),
            'update_enrollment'    => array('UNIT HEAD', 'ADMIN STAFF'),
            'delete_enrollment'    => array('UNIT HEAD', 'SCHOOL REGISTRAR'),
            'manage_grades'        => array('UNIT HEAD', 'SCHOOL REGISTRAR', 'ADMIN STAFF'),
            'request_record_correction' => array('UNIT HEAD', 'SCHOOL REGISTRAR', 'ADMIN STAFF'),
            'approve_record_correction' => array('UNIT HEAD'),
            'hide_grades'          => array('UNIT HEAD', 'SCHOOL REGISTRAR', 'DEAN', 'ADMIN STAFF'),
            'manage_departments'   => array('UNIT HEAD', 'SCHOOL REGISTRAR'),
            'export_department'    => array('UNIT HEAD', 'SCHOOL REGISTRAR', 'DEAN'),
            // Dashboard reports (Summary of Enrollment PDF / stats Excel).
            // WALA ang ADMIN STAFF dito.
            'generate_reports'     => array('UNIT HEAD', 'SCHOOL REGISTRAR', 'DEAN'),
            // Archive menu, President's & Dean's Lister, at Departments & Backup tab.
            // WALA ang ADMIN STAFF sa tatlong ito.
            'view_archive'         => array('UNIT HEAD', 'SCHOOL REGISTRAR', 'DEAN'),
            'view_honors'          => array('UNIT HEAD', 'SCHOOL REGISTRAR', 'DEAN'),
            'view_departments_tab' => array('UNIT HEAD', 'SCHOOL REGISTRAR', 'DEAN'),
            'full_backup'          => array('UNIT HEAD', 'SCHOOL REGISTRAR'),
            'manage_office_records'=> array('UNIT HEAD', 'SCHOOL REGISTRAR', 'ADMIN STAFF'),
            'view_records_log'     => array('UNIT HEAD', 'SCHOOL REGISTRAR', 'ADMIN STAFF'),
            'import_grades'        => array('UNIT HEAD'),
            'manage_professor_gradebook' => array('UNIT HEAD', 'SCHOOL REGISTRAR', 'ADMIN STAFF'),
            // Master Record (student_master): permanent student profile,
            // name changes (marriage), photo. Registrar-level only.
            'manage_master_record' => array('UNIT HEAD', 'SCHOOL REGISTRAR'),
            // Auto STUDENT account: mag-issue / mag-reset ng temporary password
            // (hal. nakalimutan ng estudyante o nawala ang slip).
            'issue_student_account' => array('UNIT HEAD', 'SCHOOL REGISTRAR'),
            // Bulk Excel import (Department Export .xlsx format) na direktang
            // gumagawa/nagbabago ng Enrollment + Grade records nang walang
            // hiwalay na approval step — UNIT HEAD lang, ito ang pinakamataas
            // na role, dahil malaking epekto ito sa maraming record nang sabay.
        );

        if (!isset($matrix[$permission])) {
            return false;
        }

        return in_array($role, $matrix[$permission], true);
    }
}

/* Kailangan ang lahat ng permission keys na ito (bilang booleans)
   para ma-expose sa JS bilang ASCB_PERMISSIONS — ginagamit ng
   frontend para i-hide/disable ang mga bagay na hindi pwede sa
   kasalukuyang naka-login na user. HINDI ito ang tunay na
   security boundary (ang mga api/*.php files pa rin ang
   nagpapatupad ng tunay na check) — UI convenience lang ito. */
if (!function_exists('ascb_permissions_for')) {
    function ascb_permissions_for($role) {
        return array(
            'manageUsers'         => ascb_can($role, 'manage_users'),
            'issueStudentAccount' => ascb_can($role, 'issue_student_account'),
            'manageLookups'       => ascb_can($role, 'manage_lookups'),
            'deleteLookups'       => ascb_can($role, 'delete_lookups'),
            'viewActivityLog'     => ascb_can($role, 'view_activity_log'),
            'approveEnrollment'   => ascb_can($role, 'approve_enrollment'),
            'updateEnrollment'    => ascb_can($role, 'update_enrollment'),
            'deleteEnrollment'    => ascb_can($role, 'delete_enrollment'),
            'manageGrades'        => ascb_can($role, 'manage_grades'),
            'requestRecordCorrection' => ascb_can($role, 'request_record_correction'),
            'approveRecordCorrection' => ascb_can($role, 'approve_record_correction'),
            'hideGrades'          => ascb_can($role, 'hide_grades'),
            'manageDepartments'   => ascb_can($role, 'manage_departments'),
            'exportDepartment'    => ascb_can($role, 'export_department'),
            'generateReports'     => ascb_can($role, 'generate_reports'),
            'viewArchive'         => ascb_can($role, 'view_archive'),
            'viewHonors'          => ascb_can($role, 'view_honors'),
            'viewDepartmentsTab'  => ascb_can($role, 'view_departments_tab'),
            'fullBackup'          => ascb_can($role, 'full_backup'),
            'manageOfficeRecords' => ascb_can($role, 'manage_office_records'),
            'viewRecordsLog'      => ascb_can($role, 'view_records_log'),
            'importGrades'        => ascb_can($role, 'import_grades'),
            'manageProfessorGradebook' => ascb_can($role, 'manage_professor_gradebook'),
            'manageMasterRecord'  => ascb_can($role, 'manage_master_record'),
        );
    }
}


/* =========================================================
   STUDENT ROLE (2026)
   ---------------------------------------------------------
   Ang STUDENT ay HINDI nasa kahit anong listahan sa
   ascb_can() sa itaas, kaya DENIED siya sa lahat ng
   permission. Dagdag pa riyan, may DENY-BY-DEFAULT na guard
   sa includes/api_guard.php at includes/auth_check.php: ang
   STUDENT ay hindi makakapasok sa KAHIT ANONG api/*.php o
   page maliban kung ang file mismo ay nag-define ng
   ASCB_ALLOW_STUDENT bago i-require ang guard. Sa ngayon,
   dalawa lang ang may ganito:
     - student.php            (ang Student Portal page)
     - api/student_portal.php (read-only, sariling record lang)
     - api/users.php          (change_password lang; lahat ng
                               ibang action ay nangangailangan
                               ng manage_users na wala sa STUDENT)
   ========================================================= */
if (!function_exists('ascb_is_student')) {
    function ascb_is_student($role) {
        return $role === 'STUDENT';
    }
}
