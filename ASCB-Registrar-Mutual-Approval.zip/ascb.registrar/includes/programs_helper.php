<?php
/* =========================================================
   PROGRAMS & SUBJECTS — SHARED HELPERS
   ---------------------------------------------------------
   Ginagamit ng api/programs.php (CRUD) AT ng dashboard.php
   (para i-embed ang data bilang JS globals sa page load, para
   ang mga bagong idinagdag na Course/Major/Subject/Trimester
   o Semester ay awtomatikong "callable" (magagamit) agad sa
   Enrollment module — walang kailangang i-edit na code).
   ========================================================= */

require_once __DIR__ . '/helpers.php';

/* Program codes are database data. Only ordering metadata remains in code. */
$GLOBALS['ASCB_YEAR_LEVEL_RANK'] = array('1st Year' => 1, '2nd Year' => 2, '3rd Year' => 3, '4th Year' => 4);
$GLOBALS['ASCB_TERM_RANK'] = array('1st Trimester' => 1, '2nd Trimester' => 2, '3rd Trimester' => 3, '1st Semester' => 1, '2nd Semester' => 2, 'Summer' => 3);

if (!function_exists('ascb_reserved_program_codes')) {
    function ascb_reserved_program_codes($pdo) {
        try {
            return array_map('strtoupper', $pdo->query("SELECT code FROM programs WHERE is_protected = 1")->fetchAll(PDO::FETCH_COLUMN));
        } catch (PDOException $e) {
            return array();
        }
    }
}

if (!function_exists('ascb_program_label')) {
    function ascb_program_label($courseName, $major) {
        $courseName = trim((string) $courseName);
        $major = trim((string) $major);
        return $major !== '' ? ($courseName . ' Major in ' . $major) : $courseName;
    }
}

if (!function_exists('ascb_subject_sort')) {
    function ascb_subject_sort($a, $b, $yearRank, $termRank) {
        $ya = isset($yearRank[$a['year_level']]) ? $yearRank[$a['year_level']] : 99;
        $yb = isset($yearRank[$b['year_level']]) ? $yearRank[$b['year_level']] : 99;
        if ($ya !== $yb) return $ya - $yb;
        $ta = isset($termRank[$a['term_label']]) ? $termRank[$a['term_label']] : 99;
        $tb = isset($termRank[$b['term_label']]) ? $termRank[$b['term_label']] : 99;
        if ($ta !== $tb) return $ta - $tb;
        if ((int) $a['sort_order'] !== (int) $b['sort_order']) return (int) $a['sort_order'] - (int) $b['sort_order'];
        return (int) $a['id'] - (int) $b['id'];
    }
}

/* Bumubuo ng { names, termTypes, structured } — direktang
   maii-merge sa `programNames` / `programTermTypes` /
   `structuredPrograms` sa JS side (Object.assign). Kung hindi
   pa na-run ang migration (wala pang `programs` table), balik
   nang tahimik ang mga blangkong array sa halip na mag-error,
   para hindi masira ang dashboard ng mga lumang install. */
if (!function_exists('ascb_build_structured_programs')) {
    function ascb_build_structured_programs($pdo) {
        $empty = array('names' => new stdClass(), 'termTypes' => new stdClass(), 'structured' => new stdClass());

        try {
            $programs = $pdo->query("SELECT id, code, course_name, major, term_type FROM programs WHERE is_active = 1")->fetchAll();
        } catch (PDOException $e) {
            return $empty;
        }

        if (!$programs) {
            return $empty;
        }

        $yearRank = $GLOBALS['ASCB_YEAR_LEVEL_RANK'];
        $termRank = $GLOBALS['ASCB_TERM_RANK'];

        $names = array();
        $termTypes = array();
        $structured = array();

        $subjStmt = $pdo->prepare("SELECT year_level, term_label, subject_code, description, units, sort_order, id FROM program_subjects WHERE program_id = ?");

        foreach ($programs as $p) {
            $names[$p['code']] = ascb_program_label($p['course_name'], $p['major']);
            $termTypes[$p['code']] = $p['term_type'];

            $subjStmt->execute(array($p['id']));
            $rows = $subjStmt->fetchAll();
            usort($rows, function ($a, $b) use ($yearRank, $termRank) {
                return ascb_subject_sort($a, $b, $yearRank, $termRank);
            });

            $groups = array();
            $groupIndex = array();
            foreach ($rows as $r) {
                $key = $r['year_level'] . '|' . $r['term_label'];
                if (!isset($groupIndex[$key])) {
                    $groupIndex[$key] = count($groups);
                    $groups[] = array('year' => $r['year_level'], 'trimester' => $r['term_label'], 'subjects' => array());
                }
                $groups[$groupIndex[$key]]['subjects'][] = array(
                    'code' => $r['subject_code'],
                    'description' => $r['description'],
                    'units' => (float) $r['units'],
                );
            }

            $structured[$p['code']] = $groups;
        }

        return array('names' => $names, 'termTypes' => $termTypes, 'structured' => $structured);
    }
}

/* Program dropdown options (code => label), sourced only from DB. */
if (!function_exists('ascb_program_dropdown_options')) {
    function ascb_program_dropdown_options($pdo) {
        try {
            $programs = $pdo->query("SELECT code, course_name, major FROM programs WHERE is_active = 1 ORDER BY course_name, major")->fetchAll();
        } catch (PDOException $e) {
            return array();
        }
        $options = array();
        $seenLabels = array();
        foreach ($programs as $p) {
            $label = ascb_program_label($p['course_name'], $p['major']);
            // Enrollment should never show the same Course/Major twice even
            // if legacy duplicate program rows exist in the database.
            $labelKey = function_exists('ascb_program_match_key')
                ? ascb_program_match_key($label)
                : strtolower(preg_replace('/\s+/', ' ', trim($label)));
            if ($labelKey !== '' && isset($seenLabels[$labelKey])) continue;
            if ($labelKey !== '') $seenLabels[$labelKey] = true;
            $options[$p['code']] = $label;
        }
        return $options;
    }
}

/* =========================================================
   PROGRAM RESOLVER  (BSIS / lahat ng Course)
   ---------------------------------------------------------
   Problema dati: ang Program ay hinahanap sa `programs` table
   gamit ang EKSAKTONG course_name. Kaya kapag ang Excel na
   ini-import ay may bahagyang ibang spelling — hal.
   "Bachelor of Science in Information System" (walang "s"),
   "...Information Systems (BSIS)", "BS Information Systems",
   o extra spaces — walang natutugmaang Program, kaya BLANGKO
   ang program_code ng enrollment. Bunga: hindi na-"detect" ang
   BSIS sa Summary of Enrollment / Department / Promotional
   report at nagiging hiwalay na "course" ito sa Dashboard.

   ascb_program_match_key()  — "fingerprint" ng pangalan ng
                               course (case, spacing, (CODE),
                               singular/plural, "Bachelor of
                               Science" = "BS" ay hindi na
                               nakakaapekto).
   ascb_resolve_program()    — hanapin ang tamang row ng
                               `programs` mula sa code at/o
                               course/major text. Null kung
                               talagang walang tugma.
   ========================================================= */

if (!function_exists('ascb_program_match_key')) {
    function ascb_program_match_key($text) {
        $s = strtolower(trim((string) $text));
        if ($s === '') return '';
        $s = preg_replace('/\([^)]*\)/', ' ', $s);                  // tanggalin ang "(BSIS)"
        $s = str_replace(array('&', '—', '–'), array(' and ', ' ', ' '), $s);
        $s = preg_replace('/\bbachelor\s+of\s+science\b/', 'bs', $s);
        $s = preg_replace('/\bbachelor\s+of\s+arts\b/', 'ab', $s);
        $s = preg_replace('/[^a-z0-9]+/', ' ', $s);
        $stop = array('in' => 1, 'of' => 1, 'and' => 1, 'the' => 1, 'major' => 1, 'majors' => 1);
        $out = array();
        foreach (explode(' ', $s) as $w) {
            if ($w === '' || isset($stop[$w])) continue;
            if (strlen($w) > 3 && substr($w, -1) === 's' && substr($w, -2) !== 'ss') $w = substr($w, 0, -1); // Systems -> System
            $out[] = $w;
        }
        return implode(' ', $out);
    }
}

if (!function_exists('ascb_program_index')) {
    /* Isang beses lang ikinakarga kada request. */
    function ascb_program_index($pdo, $refresh = false) {
        static $idx = null;
        if ($idx !== null && !$refresh) return $idx;
        $idx = array('byCode' => array(), 'byKey' => array(), 'byCourseOnly' => array());
        try {
            $rows = $pdo->query("SELECT id, code, course_name, major, department_id, term_type, is_active FROM programs ORDER BY is_active DESC, id ASC")->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return $idx;
        }
        foreach ($rows as $r) {
            $codeKey = strtoupper(trim((string) $r['code']));
            if ($codeKey !== '' && !isset($idx['byCode'][$codeKey])) $idx['byCode'][$codeKey] = $r;
            $major = trim((string) $r['major']);
            $k = ascb_program_match_key($r['course_name'] . ' ' . $major);
            if ($k !== '' && !isset($idx['byKey'][$k])) $idx['byKey'][$k] = $r;
            if ($major === '') {
                $ck = ascb_program_match_key($r['course_name']);
                if ($ck !== '' && !isset($idx['byCourseOnly'][$ck])) $idx['byCourseOnly'][$ck] = $r;
            }
        }
        return $idx;
    }
}

if (!function_exists('ascb_resolve_program')) {
    /* $codeText   — laman ng "Program Code" (pwedeng blangko/mali)
       $courseText — "Bachelor of Science in Information System(s)" o kahit "BSIS"
       $majorText  — opsyonal
       Returns: array(id, code, course_name, major, department_id, term_type, is_active) o null. */
    function ascb_resolve_program($pdo, $codeText = '', $courseText = '', $majorText = '') {
        $idx = ascb_program_index($pdo);
        $codeText = trim((string) $codeText);
        $courseText = trim((string) $courseText);
        $majorText = trim((string) $majorText);

        // 1) Eksaktong Program Code
        if ($codeText !== '' && isset($idx['byCode'][strtoupper($codeText)])) return $idx['byCode'][strtoupper($codeText)];

        $candidates = array();
        if ($courseText !== '') $candidates[] = $courseText;
        if ($codeText !== '') $candidates[] = $codeText;   // minsan pangalan ng course ang nasa Program Code column

        foreach ($candidates as $label) {
            // 2) Ang text mismo ay code ("BSIS") o may code sa dulo: "... (BSIS)"
            if (isset($idx['byCode'][strtoupper($label)])) return $idx['byCode'][strtoupper($label)];
            if (preg_match('/\(\s*([A-Za-z0-9\-]+)\s*\)\s*$/', $label, $m) && isset($idx['byCode'][strtoupper($m[1])])) {
                $hit = $idx['byCode'][strtoupper($m[1])];
                if ($majorText === '' || trim((string) $hit['major']) !== '') return $hit;
            }

            // 3) "… major in …" sa loob mismo ng label
            $lblCourse = $label; $lblMajor = $majorText;
            if (preg_match('/^(.*?)\s+major(?:ing)?\s+in\s+(.*)$/i', $label, $m)) {
                $lblCourse = trim($m[1]);
                if ($lblMajor === '') $lblMajor = trim($m[2]);
            }

            // 4) Fingerprint match (course + major)
            $k = ascb_program_match_key($lblCourse . ' ' . $lblMajor);
            if ($k !== '' && isset($idx['byKey'][$k])) return $idx['byKey'][$k];

            // 5) Course lang (walang major sa program table)
            $ck = ascb_program_match_key($lblCourse);
            if ($ck !== '' && isset($idx['byCourseOnly'][$ck])) return $idx['byCourseOnly'][$ck];
        }
        return null;
    }
}
