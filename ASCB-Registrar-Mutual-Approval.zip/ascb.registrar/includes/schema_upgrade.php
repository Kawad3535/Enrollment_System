<?php
/* Lightweight idempotent schema upgrade for Department/Dean/Backup module.
   Keeps upgraded files usable immediately on an existing XAMPP database. */
$GLOBALS['ascb_department_schema_error'] = null;

function ascb_ensure_department_schema($pdo) {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS departments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            code VARCHAR(30) NOT NULL,
            name VARCHAR(200) NOT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_department_code (code),
            UNIQUE KEY uniq_department_name (name(191))
        ) ENGINE=InnoDB");

        $pdo->exec("CREATE TABLE IF NOT EXISTS programs (
            id INT AUTO_INCREMENT PRIMARY KEY, department_id INT DEFAULT NULL, code VARCHAR(30) NOT NULL,
            course_name VARCHAR(200) NOT NULL, major VARCHAR(150) DEFAULT NULL,
            term_type ENUM('Trimester','Semester') NOT NULL DEFAULT 'Trimester', is_active TINYINT(1) NOT NULL DEFAULT 1, is_protected TINYINT(1) NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uniq_program_code(code),
            INDEX idx_programs_department(department_id), CONSTRAINT fk_programs_department FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE SET NULL
        ) ENGINE=InnoDB");
        $pdo->exec("CREATE TABLE IF NOT EXISTS program_subjects (
            id INT AUTO_INCREMENT PRIMARY KEY, program_id INT NOT NULL, year_level VARCHAR(30) NOT NULL, term_label VARCHAR(30) NOT NULL,
            subject_code VARCHAR(50) NOT NULL, description VARCHAR(255) NOT NULL, units DECIMAL(4,1) NOT NULL DEFAULT 3, sort_order INT NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, CONSTRAINT fk_programsubject_program FOREIGN KEY(program_id) REFERENCES programs(id) ON DELETE CASCADE,
            INDEX idx_programsubject_program(program_id), INDEX idx_programsubject_term(program_id,year_level,term_label)
        ) ENGINE=InnoDB");
        $hasPrograms = true;
        if ($hasPrograms) {
            $c=$pdo->query("SHOW COLUMNS FROM programs LIKE 'department_id'")->fetch();
            if(!$c) $pdo->exec("ALTER TABLE programs ADD COLUMN department_id INT DEFAULT NULL AFTER id, ADD INDEX idx_programs_department (department_id), ADD CONSTRAINT fk_programs_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL");
            $c=$pdo->query("SHOW COLUMNS FROM programs LIKE 'is_protected'")->fetch();
            if(!$c) $pdo->exec("ALTER TABLE programs ADD COLUMN is_protected TINYINT(1) NOT NULL DEFAULT 0 AFTER is_active");
        }
        $c=$pdo->query("SHOW COLUMNS FROM users LIKE 'department_id'")->fetch();
        if(!$c) $pdo->exec("ALTER TABLE users ADD COLUMN department_id INT DEFAULT NULL AFTER role, ADD INDEX idx_users_department (department_id), ADD CONSTRAINT fk_users_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL");

        /* (2026 STUDENT role) Each STUDENT account is linked to exactly ONE
           Student ID (single column) and each Student ID can belong to only
           ONE account (UNIQUE key; MySQL allows many NULLs, so staff
           accounts are unaffected). */
        $c=$pdo->query("SHOW COLUMNS FROM users LIKE 'student_id'")->fetch();
        if(!$c) $pdo->exec("ALTER TABLE users ADD COLUMN student_id VARCHAR(50) DEFAULT NULL AFTER department_id");
        $c=$pdo->query("SHOW INDEX FROM users WHERE Key_name = 'uq_users_student_id'")->fetch();
        if(!$c) $pdo->exec("ALTER TABLE users ADD UNIQUE KEY uq_users_student_id (student_id)");

        /* (2026 Auto STUDENT account) First-login temporary password support.
           must_change_password : 1 = the account still uses the one-time
                                  temporary password and must set a new one
                                  before it can reach ANY page or API.
           temp_password_expires_at : optional expiry of that temporary password.
           password_changed_at  : when the owner last chose their own password. */
        $c=$pdo->query("SHOW COLUMNS FROM users LIKE 'must_change_password'")->fetch();
        if(!$c) $pdo->exec("ALTER TABLE users ADD COLUMN must_change_password TINYINT(1) NOT NULL DEFAULT 0");
        $c=$pdo->query("SHOW COLUMNS FROM users LIKE 'temp_password_expires_at'")->fetch();
        if(!$c) $pdo->exec("ALTER TABLE users ADD COLUMN temp_password_expires_at DATETIME DEFAULT NULL");
        $c=$pdo->query("SHOW COLUMNS FROM users LIKE 'password_changed_at'")->fetch();
        if(!$c) $pdo->exec("ALTER TABLE users ADD COLUMN password_changed_at DATETIME DEFAULT NULL");

        // Existing installations may have inherited the old shared 'admin'
        // username design. Do not silently guess how to rename arbitrary
        // duplicates; the dedicated migration script handles known starter
        // accounts safely. Fresh installs get the UNIQUE key from SQL.

        // Keep the Department attached to the enrollment record itself.
        // This prevents Department exports from losing historical students
        // when a Program mapping is edited later.
        $c=$pdo->query("SHOW COLUMNS FROM enrollees LIKE 'department_id'")->fetch();
        if(!$c) {
            $pdo->exec("ALTER TABLE enrollees ADD COLUMN department_id INT DEFAULT NULL AFTER program_code, ADD INDEX idx_enrollee_department (department_id), ADD CONSTRAINT fk_enrollee_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL");
        }
        // Backfill existing enrollments only when NULL department snapshots
        // actually remain. The indexed probe keeps normal requests cheap.
        $nullDept = $pdo->query("SELECT 1 FROM enrollees WHERE department_id IS NULL LIMIT 1")->fetchColumn();
        if ($nullDept) {
            $pdo->exec("UPDATE enrollees e INNER JOIN programs p ON UPPER(TRIM(p.code))=UPPER(TRIM(e.program_code)) SET e.department_id=p.department_id WHERE e.department_id IS NULL AND p.department_id IS NOT NULL");
        }

        $pdo->exec("CREATE TABLE IF NOT EXISTS backup_history (
            id INT AUTO_INCREMENT PRIMARY KEY, backup_type VARCHAR(30) NOT NULL,
            department_id INT DEFAULT NULL, school_year VARCHAR(20) DEFAULT NULL, term_label VARCHAR(30) DEFAULT NULL,
            filename VARCHAR(255) NOT NULL, created_by_user_id INT DEFAULT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_backup_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
            CONSTRAINT fk_backup_user FOREIGN KEY (created_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_backup_created (created_at)
        ) ENGINE=InnoDB");

        /* (2024 audit fix) Atomic per-year counter for Student ID generation.
           Dati, SELECT MAX(...) tapos +1 sa PHP ang ginagamit — kung dalawang
           request ang sumabay (dalawang "New Student" na sinabmit ng magkaibang
           tao sa parehong segundo), pwedeng parehong makakuha ng SUNOD-SUNOD na
           parehong Student ID (walang UNIQUE constraint na sasabat dahil
           SINADYANG paulit-ulit ang student_id sa `enrollees` kapag "New Term"
           ng parehong estudyante — kaya HINDI dapat gawing UNIQUE ang column
           na iyon). Ang tamang ayos ay gawing atomic ang PAGKUHA ng sunod na
           bilang gamit ang row-level lock ng MySQL sa isang dedicated counter
           table (INSERT ... ON DUPLICATE KEY UPDATE ... LAST_INSERT_ID()),
           hindi ang paglagay ng UNIQUE constraint sa enrollees.student_id. */
        $pdo->exec("CREATE TABLE IF NOT EXISTS student_id_sequences (
            year_key VARCHAR(4) PRIMARY KEY,
            next_number INT NOT NULL
        ) ENGINE=InnoDB");

        /* (2024 audit fix) Login attempt tracking, para sa account lockout
           laban sa brute-force password guessing. Isang row bawat username;
           binibilang ang magkakasunod na failed attempts sa loob ng isang
           lockout window, at nire-reset agad sa successful login. */
        $pdo->exec("CREATE TABLE IF NOT EXISTS login_attempts (
            username VARCHAR(50) PRIMARY KEY,
            failed_count INT NOT NULL DEFAULT 0,
            first_failed_at DATETIME DEFAULT NULL,
            locked_until DATETIME DEFAULT NULL
        ) ENGINE=InnoDB");

        /* (2026 Grade Evaluation "Hide on Print") Per-subject flag na
           kinokontrol kung itatago ang grade nitong subject pag ni-print
           ang Grade Evaluation — hindi nito binabago/binubura ang totoong
           grade, display-only ito. Idempotent ADD COLUMN para sa mga
           existing na database na na-set up na bago dumating ang feature
           na ito. */
        $c=$pdo->query("SHOW COLUMNS FROM enrollment_subjects LIKE 'hidden_on_print'")->fetch();
        if(!$c) $pdo->exec("ALTER TABLE enrollment_subjects ADD COLUMN hidden_on_print TINYINT(1) NOT NULL DEFAULT 0 AFTER units");

        /* (2026 Guardian Name) Parent/guardian name ng estudyante, kinukuha
           sa Enrollment form (Add/Update/New Term). Idempotent ADD COLUMN
           para sa mga existing na database na na-set up na bago dumating
           ang field na ito. */
        $c=$pdo->query("SHOW COLUMNS FROM enrollees LIKE 'guardian_name'")->fetch();
        if(!$c) $pdo->exec("ALTER TABLE enrollees ADD COLUMN guardian_name VARCHAR(150) DEFAULT NULL AFTER mobile_number");

        /* (2026 Professor Grade Sheet / Subject Gradebook)
           One lock covers the same subject across all matching enrollment_subject_id
           rows for a School Year + Term. The grade itself remains keyed by
           enrollment_subject_id in the grades table. */
        $pdo->exec("CREATE TABLE IF NOT EXISTS subject_grade_locks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            school_year VARCHAR(20) NOT NULL, trimester VARCHAR(30) NOT NULL,
            course_code VARCHAR(50) NOT NULL DEFAULT '', description VARCHAR(255) NOT NULL,
            locked_by_user_id INT DEFAULT NULL, locked_at DATETIME DEFAULT NULL,
            unlocked_by_user_id INT DEFAULT NULL, unlocked_at DATETIME DEFAULT NULL,
            CONSTRAINT fk_sgl_locked_by FOREIGN KEY (locked_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
            CONSTRAINT fk_sgl_unlocked_by FOREIGN KEY (unlocked_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
            UNIQUE KEY uq_sgl_subject (school_year, trimester, course_code, description),
            INDEX idx_sgl_term (school_year, trimester), INDEX idx_sgl_locked (locked_at)
        ) ENGINE=InnoDB");

        /* (2026 Previous Term Correction) Historical enrollment records are
           read-only in Grade Management. Correction requests are stored first
           and only applied by an authorized reviewer, with before/after data
           retained in record_correction_items for auditability. */
        $pdo->exec("CREATE TABLE IF NOT EXISTS record_corrections (
            id INT AUTO_INCREMENT PRIMARY KEY, enrollment_id INT NOT NULL, student_id VARCHAR(50) DEFAULT NULL,
            correction_type VARCHAR(30) NOT NULL DEFAULT 'SUBJECT_GRADE', reason VARCHAR(500) NOT NULL,
            changes_json MEDIUMTEXT NOT NULL, status ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
            requested_by_user_id INT DEFAULT NULL, requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            reviewed_by_user_id INT DEFAULT NULL, reviewed_at DATETIME DEFAULT NULL, review_remarks VARCHAR(500) DEFAULT NULL,
            CONSTRAINT fk_rc_enrollment FOREIGN KEY (enrollment_id) REFERENCES enrollees(id) ON DELETE RESTRICT,
            CONSTRAINT fk_rc_requested_by FOREIGN KEY (requested_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
            CONSTRAINT fk_rc_reviewed_by FOREIGN KEY (reviewed_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_rc_enrollment (enrollment_id), INDEX idx_rc_student (student_id), INDEX idx_rc_status (status), INDEX idx_rc_requested (requested_at)
        ) ENGINE=InnoDB");
        $pdo->exec("CREATE TABLE IF NOT EXISTS record_correction_items (
            id INT AUTO_INCREMENT PRIMARY KEY, correction_id INT NOT NULL, entity_type VARCHAR(40) NOT NULL,
            entity_id INT DEFAULT NULL, field_name VARCHAR(80) NOT NULL, old_value TEXT DEFAULT NULL, new_value TEXT DEFAULT NULL,
            CONSTRAINT fk_rci_correction FOREIGN KEY (correction_id) REFERENCES record_corrections(id) ON DELETE CASCADE,
            INDEX idx_rci_correction (correction_id), INDEX idx_rci_entity (entity_type, entity_id)
        ) ENGINE=InnoDB");
        /* (2026-09-22 fix) NEW TERM DUPLICATE PROTECTION on upgraded databases.
           Fresh installs get UNIQUE KEY uq_enrollee_student_term from
           database/ascb_registrar.sql, and there is a standalone migration in
           database/migrations/20260919_new_term_protection.sql — but an
           existing XAMPP database that was only upgraded by copying the new
           files never ran either one, so the concurrency-safe database guard
           was simply missing there. The PHP pre-check alone cannot stop two
           simultaneous saves. This idempotent block installs the key.

           If legacy duplicate rows already exist, MySQL refuses to create the
           UNIQUE key (errno 1062). We do NOT delete enrollment records here;
           instead we record the conflict so the registrar can clean it up with
           database/fix_new_term_duplicates.php. */
        $hasKey = $pdo->query("SELECT COUNT(*) FROM information_schema.statistics
             WHERE table_schema = DATABASE() AND table_name = 'enrollees'
               AND index_name = 'uq_enrollee_student_term'")->fetchColumn();
        if (!$hasKey) {
            $dupRow = $pdo->query("SELECT COUNT(*) FROM (
                    SELECT 1 FROM enrollees
                     GROUP BY student_id, school_year, trimester
                    HAVING COUNT(*) > 1
                ) d")->fetchColumn();
            if ((int)$dupRow > 0) {
                $msg = 'New Term duplicate protection could not be installed: '
                     . (int)$dupRow . ' duplicate student/term group(s) already exist in `enrollees`. '
                     . 'Run database/fix_new_term_duplicates.php to review them.';
                $GLOBALS['ascb_new_term_guard_error'] = $msg;
                error_log('ASCB schema upgrade warning: ' . $msg);
            } else {
                try {
                    $pdo->exec("ALTER TABLE enrollees ADD UNIQUE KEY uq_enrollee_student_term (student_id, school_year, trimester)");
                } catch (Throwable $e) {
                    $GLOBALS['ascb_new_term_guard_error'] = $e->getMessage();
                    error_log('ASCB schema upgrade warning (new term guard): ' . $e->getMessage());
                }
            }
        }

        return true;
    } catch (Exception $e) {
        error_log('ASCB department schema upgrade warning: '.$e->getMessage());
        $GLOBALS['ascb_department_schema_error'] = $e->getMessage();
        return false;
    }
}
