<?php
/**
 * Tiny dependency-free PDF writer used for offline/on-premise ASCB reports.
 * Supports A4 pages, Helvetica text, lines/rectangles, JPEG images (any
 * number of distinct images per document, e.g. a letterhead plus a
 * translucent watermark), and true PDF-level transparency (ExtGState)
 * for the watermark effect.
 */
class ASCB_SimplePDF {
    private $pages = array();
    private $current = '';
    /* One entry per distinct image path actually drawn: {path, data, w, h}.
       Re-using the same path (e.g. the letterhead repeated on every page,
       or the watermark repeated on every page) reuses the same entry —
       the image bytes are embedded in the PDF only once either way. */
    private $images = array();
    /* Distinct alpha (opacity) values used by imageJpeg() calls, so each
       gets its own /GSn ExtGState object. Fully opaque (1.0) draws need
       no ExtGState at all. */
    private $alphas = array();
    private $pageW = 612.00; // US Letter / Short Bond width (8.5 x 11 in)
    private $pageH = 792.00; // US Letter / Short Bond height (8.5 x 11 in)

    public function addPage() {
        if ($this->current !== '') $this->pages[] = $this->current;
        $this->current = '';
    }
    public function finishPage() {
        if ($this->current !== '') { $this->pages[] = $this->current; $this->current = ''; }
    }
    private function esc($s) {
        $s = (string)$s;
        if (function_exists('iconv')) $s = @iconv('UTF-8', 'Windows-1252//TRANSLIT', $s);
        return str_replace(array('\\','(',')'), array('\\\\','\\(','\\)'), $s);
    }
    /* Standard Helvetica / Helvetica-Bold advance widths (1000 units per em)
       for ASCII 32..126, so centered/right-aligned text is placed exactly
       instead of using a rough average-character guess. */
    private static $wRegular = array(
        278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,
        556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,
        1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,
        667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,
        333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,
        556,556,333,500,278,556,500,722,500,500,500,334,260,334,584);
    private static $wBold = array(
        278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,
        556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,
        975,722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,
        667,778,722,667,611,722,667,944,667,667,611,333,278,333,584,556,
        333,556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,
        611,611,389,556,333,611,556,778,556,556,500,389,280,389,584);

    /* Width in points of $txt at $size (text is measured after the same
       UTF-8 -> Windows-1252 conversion used when it is written). */
    public function textWidth($txt, $size=10, $bold=false) {
        $raw = (string)$txt;
        if (function_exists('iconv')) { $c = @iconv('UTF-8', 'Windows-1252//TRANSLIT', $raw); if ($c !== false) $raw = $c; }
        $tbl = $bold ? self::$wBold : self::$wRegular;
        $w = 0;
        for ($i = 0, $n = strlen($raw); $i < $n; $i++) {
            $o = ord($raw[$i]);
            if ($o >= 32 && $o <= 126) $w += $tbl[$o - 32];
            elseif ($o === 151) $w += 1000;       // em dash
            elseif ($o === 150) $w += 556;        // en dash
            else $w += 556;
        }
        return $w * $size / 1000;
    }
    /* Shrinks the font (down to $minSize) and, if still too wide,
       truncates with an ellipsis so long course names never spill out of
       their cell. Returns array(text, size). */
    public function fitText($txt, $maxW, $size=10, $bold=false, $minSize=7.5) {
        $txt = (string)$txt;
        while ($size > $minSize && $this->textWidth($txt, $size, $bold) > $maxW) $size -= 0.5;
        if ($this->textWidth($txt, $size, $bold) > $maxW) {
            $ell = '...';
            while ($txt !== '' && $this->textWidth($txt . $ell, $size, $bold) > $maxW) {
                $txt = function_exists('mb_substr') ? mb_substr($txt, 0, mb_strlen($txt, 'UTF-8') - 1, 'UTF-8') : substr($txt, 0, -1);
            }
            $txt = rtrim($txt) . $ell;
        }
        return array($txt, $size);
    }
    public function pageWidth()  { return $this->pageW; }
    public function pageHeight() { return $this->pageH; }

    public function text($x, $y, $txt, $size=10, $bold=false, $align='left') {
        $font = $bold ? '/F2' : '/F1';
        $s = $this->esc($txt);
        $approx = $this->textWidth($txt, $size, $bold);
        if ($align === 'center') $x -= $approx / 2;
        elseif ($align === 'right') $x -= $approx;
        $this->current .= "BT {$font} {$size} Tf 1 0 0 1 " . round($x,2) . ' ' . round($this->pageH-$y,2) . " Tm (" . $s . ") Tj ET\n";
    }
    /* Translucent solid fill (RGB 0..1) — translucent so the watermark
       drawn earlier on the page still shows through shaded cells. */
    public function fillRect($x,$y,$w,$h,$r,$g,$b,$alpha=1.0) {
        $this->current .= "q\n";
        if ($alpha < 1.0) $this->current .= '/' . $this->loadAlpha($alpha) . " gs\n";
        $this->current .= round($r,3) . ' ' . round($g,3) . ' ' . round($b,3) . " rg " . round($x,2) . ' ' . round($this->pageH-$y-$h,2) . ' ' . round($w,2) . ' ' . round($h,2) . " re f\nQ\n";
    }
    public function line($x1,$y1,$x2,$y2,$width=0.5) {
        $this->current .= round($width,2) . " w " . round($x1,2) . ' ' . round($this->pageH-$y1,2) . ' m ' . round($x2,2) . ' ' . round($this->pageH-$y2,2) . " l S\n";
    }
    public function rect($x,$y,$w,$h,$fill=false,$width=0.5) {
        $op = $fill ? 'f' : 'S';
        $this->current .= round($width,2) . " w " . round($x,2) . ' ' . round($this->pageH-$y-$h,2) . ' ' . round($w,2) . ' ' . round($h,2) . " re {$op}\n";
    }
    public function setGray($gray) {
        $g = max(0,min(1,(float)$gray));
        $this->current .= $g . ' g ' . $g . " G\n";
    }
    public function setStrokeGray($gray) {
        $g = max(0,min(1,(float)$gray));
        $this->current .= $g . " G\n";
    }
    public function setFillGray($gray) {
        $g = max(0,min(1,(float)$gray));
        $this->current .= $g . " g\n";
    }
    /* Loads (and caches, by path) a JPEG image and returns its resource
       name (e.g. "Im1"). Every distinct path used anywhere in the
       document gets exactly one embedded copy, however many times it's
       drawn across however many pages. */
    private function loadImage($path) {
        if (isset($this->images[$path])) return $this->images[$path]['name'];
        if (!file_exists($path)) return null;
        $info = @getimagesize($path);
        $data = @file_get_contents($path);
        if (!$info || $data === false || !isset($info['mime']) || $info['mime'] !== 'image/jpeg') return null;
        $name = 'Im' . (count($this->images) + 1);
        $this->images[$path] = array('name'=>$name, 'w'=>(int)$info[0], 'h'=>(int)$info[1], 'data'=>$data);
        return $name;
    }
    /* Registers (if new) an alpha value and returns its ExtGState
       resource name (e.g. "GS1"). Alpha 1.0 (fully opaque) needs no
       ExtGState and is handled by the caller. */
    private function loadAlpha($alpha) {
        $a = round(max(0,min(1,(float)$alpha)), 3);
        $key = (string)$a;
        if (isset($this->alphas[$key])) return $this->alphas[$key]['name'];
        $name = 'GS' . (count($this->alphas) + 1);
        $this->alphas[$key] = array('name'=>$name, 'alpha'=>$a);
        return $name;
    }
    /**
     * Draws a JPEG image on the current page.
     * $alpha: 1.0 = fully opaque (default, used for the letterhead);
     *         a lower value (e.g. 0.10) draws it translucently, which is
     *         how the watermark is drawn behind the page's content.
     */
    public function imageJpeg($path,$x,$y,$w,$h,$alpha=1.0) {
        $imName = $this->loadImage($path);
        if ($imName === null) return;
        $img = $this->images[$path];
        $a = max(0,min(1,(float)$alpha));
        $this->current .= "q\n";
        if ($a < 1.0) {
            $gsName = $this->loadAlpha($a);
            $this->current .= "/{$gsName} gs\n";
        }
        $this->current .= round($w,4) . " 0 0 " . round($h,4) . ' ' . round($x,2) . ' ' . round($this->pageH-$y-$h,2) . " cm /{$imName} Do\nQ\n";
    }
    public function output($filename) {
        $this->finishPage();
        $objects = array();
        $obj = function($body) use (&$objects) { $objects[] = $body; return count($objects); };
        $font1 = $obj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
        $font2 = $obj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");

        /* Embed every distinct image used anywhere in the document. */
        $imageObjNums = array(); // name => object number
        foreach ($this->images as $path => $img) {
            $dict = "<< /Type /XObject /Subtype /Image /Width {$img['w']} /Height {$img['h']} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " . strlen($img['data']) . " >>\nstream\n" . $img['data'] . "\nendstream";
            $imageObjNums[$img['name']] = $obj($dict);
        }

        /* Emit one ExtGState object per distinct opacity value used
           (e.g. the watermark's 0.10 alpha), for both fill and stroke. */
        $alphaObjNums = array(); // name => object number
        foreach ($this->alphas as $a) {
            $dict = "<< /Type /ExtGState /ca " . $a['alpha'] . " /CA " . $a['alpha'] . " >>";
            $alphaObjNums[$a['name']] = $obj($dict);
        }

        $resourceDict = function() use ($font1, $font2, $imageObjNums, $alphaObjNums) {
            $resources = "/Font << /F1 {$font1} 0 R /F2 {$font2} 0 R >>";
            if (!empty($imageObjNums)) {
                $xo = array();
                foreach ($imageObjNums as $name => $num) $xo[] = "/{$name} {$num} 0 R";
                $resources .= " /XObject << " . implode(' ', $xo) . " >>";
            }
            if (!empty($alphaObjNums)) {
                $eg = array();
                foreach ($alphaObjNums as $name => $num) $eg[] = "/{$name} {$num} 0 R";
                $resources .= " /ExtGState << " . implode(' ', $eg) . " >>";
            }
            return $resources;
        };

        $pageObjs = array();
        $contentObjs = array();
        foreach ($this->pages as $content) {
            $contentObjs[] = $obj("<< /Length " . strlen($content) . " >>\nstream\n" . $content . "endstream");
            $pageObjs[] = $obj("<< /Type /Page /MediaBox [0 0 {$this->pageW} {$this->pageH}] /Resources << " . $resourceDict() . " >> /Contents " . end($contentObjs) . " 0 R >>");
        }
        $kids = implode(' ', array_map(function($n){return $n.' 0 R';}, $pageObjs));
        $pagesObj = $obj("<< /Type /Pages /Kids [{$kids}] /Count " . count($pageObjs) . " >>");
        // Rebuild page objects with the correct parent reference.
        $pageIndex = 0;
        foreach ($pageObjs as $n) {
            $contentNo = $contentObjs[$pageIndex++];
            $objects[$n-1] = "<< /Type /Page /Parent {$pagesObj} 0 R /MediaBox [0 0 {$this->pageW} {$this->pageH}] /Resources << " . $resourceDict() . " >> /Contents {$contentNo} 0 R >>";
        }
        $catalogObj = $obj("<< /Type /Catalog /Pages {$pagesObj} 0 R >>");
        $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = array(0);
        foreach ($objects as $i=>$body) {
            $offsets[$i+1] = strlen($pdf);
            $pdf .= ($i+1) . " 0 obj\n" . $body . "\nendobj\n";
        }
        $xref = strlen($pdf);
        $pdf .= "xref\n0 " . (count($objects)+1) . "\n0000000000 65535 f \n";
        for ($i=1;$i<=count($objects);$i++) $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        $pdf .= "trailer\n<< /Size " . (count($objects)+1) . " /Root {$catalogObj} 0 R >>\nstartxref\n{$xref}\n%%EOF";
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="'.preg_replace('/[^A-Za-z0-9_.-]+/','_',$filename).'"');
        header('Content-Length: '.strlen($pdf));
        header('X-Content-Type-Options: nosniff');
        echo $pdf;
        exit;
    }
}
