<?php
/* =========================================================
   STUDENT ACCOUNT — AUTOMATIC PROVISIONING (SERVER-SIDE)
   ---------------------------------------------------------
   Every student gets exactly ONE login account, created
   automatically when an enrollment becomes APPROVED:

     username  = the student's Student ID
     password  = random one-time temporary password (shown ONCE to
                 the registrar, stored only as a password_hash())
     role      = STUDENT
     student_id= the Student ID  (UNIQUE key uq_users_student_id =
                 permanent 1 account : 1 Student ID link)
     must_change_password = 1  -> forced change on first login

   No duplicate accounts: if the Student ID already has an account
   (New Term, re-enrollment, another academic year, imports ...), the
   existing account is left completely untouched and NO new password
   is generated. The UNIQUE key is the final guard against race
   conditions.

   Account creation never breaks enrollment: it runs AFTER the
   enrollment is saved and every failure is caught and logged. The
   registrar can always use "Issue / Reset temporary password".
   ========================================================= */

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/master_record_helper.php';

/* Temporary password lifetime in days. 0 = never expires. */
if (!defined('ASCB_TEMP_PASSWORD_DAYS')) {
    define('ASCB_TEMP_PASSWORD_DAYS', 30);
}

if (!function_exists('ascb_sa_available')) {
    /* True once the schema upgrade has added the needed columns. */
    function ascb_sa_available($pdo) {
        return ascb_column_exists($pdo, 'users', 'student_id')
            && ascb_column_exists($pdo, 'users', 'must_change_password');
    }
}

if (!function_exists('ascb_sa_generate_temp_password')) {
    /* Cryptographically secure, easy to read out loud / type:
       10 characters, no look-alikes (0/O, 1/I/l), at least one letter
       and one digit. Example: K7MQ-4XPD-9T  (displayed with dashes;
       the dashes are NOT part of the password). */
    function ascb_sa_generate_temp_password($length = 10) {
        $letters = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
        $digits  = '23456789';
        $all     = $letters . $digits;
        do {
            $pw = '';
            for ($i = 0; $i < $length; $i++) {
                $pw .= $all[random_int(0, strlen($all) - 1)];
            }
        } while (!preg_match('/[A-Z]/', $pw) || !preg_match('/[2-9]/', $pw));
        return $pw;
    }
}

if (!function_exists('ascb_sa_format_temp_password')) {
    function ascb_sa_format_temp_password($pw) {
        return implode('-', str_split((string) $pw, 4));
    }
}

if (!function_exists('ascb_sa_normalize_temp_password')) {
    /* Forgiving typing: the displayed dashes/spaces are ignored and the
       letters are case-insensitive — but ONLY for accounts still on a
       temporary password (see index.php). Real passwords are exact. */
    function ascb_sa_normalize_temp_password($input) {
        return strtoupper(preg_replace('/[\s\-]+/', '', (string) $input));
    }
}

if (!function_exists('ascb_sa_expiry')) {
    function ascb_sa_expiry() {
        if ((int) ASCB_TEMP_PASSWORD_DAYS <= 0) return null;
        return date('Y-m-d H:i:s', time() + (int) ASCB_TEMP_PASSWORD_DAYS * 86400);
    }
}

if (!function_exists('ascb_sa_display_name')) {
    /* users.display_name has a UNIQUE key, so two students with the same
       name must not collide: fall back to "Name (Student ID)". */
    function ascb_sa_display_name($pdo, $studentId, $surname, $firstName, $middleName = '', $suffix = '') {
        $name = trim($surname) . ', ' . trim($firstName);
        $mid  = trim((string) $middleName);
        if ($mid !== '') $name .= ' ' . mb_substr($mid, 0, 1, 'UTF-8') . '.';
        $suffix = trim((string) $suffix);
        if ($suffix !== '') $name .= ' ' . $suffix;
        $name = trim(preg_replace('/\s+/u', ' ', $name));
        if ($name === ',' || $name === '') $name = (string) $studentId;
        if (mb_strlen($name, 'UTF-8') > 100) $name = mb_substr($name, 0, 100, 'UTF-8');

        $q = $pdo->prepare("SELECT 1 FROM users WHERE display_name = ? LIMIT 1");
        $q->execute(array($name));
        if ($q->fetchColumn()) {
            $tag  = ' (' . $studentId . ')';
            $base = mb_substr($name, 0, max(1, 100 - mb_strlen($tag, 'UTF-8')), 'UTF-8');
            $name = $base . $tag;
        }
        return $name;
    }
}

if (!function_exists('ascb_sa_find_by_student')) {
    /* The account (if any) permanently linked to this Student ID. */
    function ascb_sa_find_by_student($pdo, $studentId) {
        $q = $pdo->prepare("SELECT * FROM users WHERE UPPER(TRIM(student_id)) = UPPER(TRIM(?)) LIMIT 1");
        $q->execute(array($studentId));
        $row = $q->fetch();
        return $row ? $row : null;
    }
}

if (!function_exists('ascb_sa_ensure_account')) {
    /* Create the STUDENT account for $studentId if it does not exist yet.

       $name = array(surname, first_name, middle_name, suffix)
       Returns array(
         'status'       => 'created' | 'exists' | 'unavailable' | 'failed',
         'username'     => Student ID (created / exists),
         'tempPassword' => formatted one-time password (ONLY when 'created'),
         'expiresAt'    => string|null,
         'message'      => human readable reason (failed / unavailable)
       ) */
    function ascb_sa_ensure_account($pdo, $studentId, $name, $actor = null) {
        $studentId = trim((string) $studentId);
        if ($studentId === '') {
            return array('status' => 'failed', 'message' => 'Missing Student ID.');
        }
        try {
            if (!ascb_sa_available($pdo)) {
                return array('status' => 'unavailable',
                    'message' => 'Student accounts are not installed yet. Run: php database/migrate_master.php');
            }

            /* 1) Already linked (any earlier trimester / school year,
                  or created by hand)? -> leave it alone. */
            $existing = ascb_sa_find_by_student($pdo, $studentId);
            if ($existing) {
                return array('status' => 'exists', 'username' => $existing['username']);
            }

            /* 2) The username (= Student ID) must not already belong to a
                  different account (e.g. a staff user) — never take it over. */
            $q = $pdo->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
            $q->execute(array($studentId));
            if ($q->fetchColumn()) {
                return array('status' => 'failed',
                    'message' => 'The username "' . $studentId . '" is already used by another (non-student) account.');
            }

            $temp    = ascb_sa_generate_temp_password();
            $hash    = password_hash($temp, PASSWORD_DEFAULT);
            $expires = ascb_sa_expiry();
            $display = ascb_sa_display_name(
                $pdo, $studentId,
                (string) ascb_get($name, 'surname', ''),
                (string) ascb_get($name, 'first_name', ''),
                (string) ascb_get($name, 'middle_name', ''),
                (string) ascb_get($name, 'suffix', '')
            );

            $hasExp = ascb_column_exists($pdo, 'users', 'temp_password_expires_at');
            $sql = "INSERT INTO users (username, password_hash, display_name, role, student_id, is_active, must_change_password"
                 . ($hasExp ? ", temp_password_expires_at" : "") . ")
                    VALUES (?, ?, ?, 'STUDENT', ?, 1, 1" . ($hasExp ? ", ?" : "") . ")";
            $params = array($studentId, $hash, $display, $studentId);
            if ($hasExp) $params[] = $expires;

            try {
                $pdo->prepare($sql)->execute($params);
            } catch (PDOException $e) {
                /* Two requests raced: the UNIQUE key already stopped the
                   duplicate. Treat it as "exists". */
                if ($e->getCode() === '23000') {
                    $again = ascb_sa_find_by_student($pdo, $studentId);
                    if ($again) return array('status' => 'exists', 'username' => $again['username']);
                    return array('status' => 'failed', 'message' => 'Could not create the account (duplicate username or name).');
                }
                throw $e;
            }

            if ($actor !== null && function_exists('ascb_log_activity')) {
                ascb_log_activity($pdo, $actor, 'STUDENT_ACCOUNT_AUTO_CREATE', 'user', $display, 'Student ID: ' . $studentId);
            }
            return array(
                'status'       => 'created',
                'username'     => $studentId,
                'tempPassword' => ascb_sa_format_temp_password($temp),
                'expiresAt'    => $expires,
            );
        } catch (Throwable $e) {
            error_log('ASCB student account auto-create failed for ' . $studentId . ': ' . $e->getMessage());
            return array('status' => 'failed', 'message' => 'The student account could not be created automatically.');
        }
    }
}

if (!function_exists('ascb_sa_reset_temp_password')) {
    /* Issue a NEW one-time temporary password for an existing STUDENT
       account (forgotten password / lost slip). Forces a change at the
       next login and invalidates the previous password immediately.
       Returns the same shape as ascb_sa_ensure_account(). */
    function ascb_sa_reset_temp_password($pdo, $userId, $actor = null) {
        try {
            if (!ascb_sa_available($pdo)) {
                return array('status' => 'unavailable', 'message' => 'Student accounts are not installed yet.');
            }
            $q = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'STUDENT' LIMIT 1");
            $q->execute(array((int) $userId));
            $u = $q->fetch();
            if (!$u) return array('status' => 'failed', 'message' => 'Student account not found.');

            $temp    = ascb_sa_generate_temp_password();
            $expires = ascb_sa_expiry();
            $hasExp  = ascb_column_exists($pdo, 'users', 'temp_password_expires_at');
            $sql = "UPDATE users SET password_hash = ?, must_change_password = 1"
                 . ($hasExp ? ", temp_password_expires_at = ?" : "") . " WHERE id = ?";
            $params = array(password_hash($temp, PASSWORD_DEFAULT));
            if ($hasExp) $params[] = $expires;
            $params[] = (int) $userId;
            $pdo->prepare($sql)->execute($params);

            /* Throttle counters from earlier failed guesses no longer apply. */
            try {
                $pdo->prepare("DELETE FROM login_attempts WHERE username = ?")->execute(array($u['username']));
            } catch (Throwable $e) { /* table optional */ }

            if ($actor !== null && function_exists('ascb_log_activity')) {
                ascb_log_activity($pdo, $actor, 'STUDENT_ACCOUNT_RESET', 'user', $u['display_name'], 'Student ID: ' . $u['student_id']);
            }
            return array(
                'status'       => 'created',
                'username'     => $u['username'],
                'tempPassword' => ascb_sa_format_temp_password($temp),
                'expiresAt'    => $expires,
                'reset'        => true,
            );
        } catch (Throwable $e) {
            error_log('ASCB student temp password reset failed: ' . $e->getMessage());
            return array('status' => 'failed', 'message' => 'Could not reset the temporary password.');
        }
    }
}

if (!function_exists('ascb_sa_name_for_student')) {
    /* Current name of a student for the account's display_name:
       Master Record first (it holds the CURRENT name), else the latest
       enrollment row. Returns array(surname, first_name, middle_name, suffix)
       or null when the Student ID is unknown. */
    function ascb_sa_name_for_student($pdo, $studentId) {
        try {
            if (function_exists('ascb_master_current')) {
                $m = ascb_master_current($pdo, $studentId);
                if ($m && trim((string) ascb_get($m, 'surname', '')) !== '') {
                    return array(
                        'surname' => $m['surname'], 'first_name' => ascb_get($m, 'first_name', ''),
                        'middle_name' => ascb_get($m, 'middle_name', ''), 'suffix' => ascb_get($m, 'suffix', ''),
                    );
                }
            }
            $q = $pdo->prepare("SELECT * FROM enrollees WHERE student_id = ? ORDER BY id DESC LIMIT 1");
            $q->execute(array($studentId));
            $r = $q->fetch();
            if ($r) {
                return array(
                    'surname' => $r['surname'], 'first_name' => $r['first_name'],
                    'middle_name' => ascb_get($r, 'middle_name', ''), 'suffix' => ascb_get($r, 'suffix', ''),
                );
            }
        } catch (Throwable $e) { /* fall through */ }
        return null;
    }
}

if (!function_exists('ascb_sa_public_result')) {
    /* What is safe to send to the browser. Only the Registrar / Unit Head
       who triggered the enrollment ever receives the temp password, and
       only in the response that created it. */
    function ascb_sa_public_result($r) {
        if (!is_array($r)) return null;
        $out = array('status' => $r['status']);
        foreach (array('username', 'tempPassword', 'expiresAt', 'message', 'reset') as $k) {
            if (isset($r[$k])) $out[$k] = $r[$k];
        }
        return $out;
    }
}
