<?php
/* =========================================================
   STUDENT SEARCH HELPER — FULL NAME + STUDENT ID
   PHP 5.6 COMPATIBLE (walang ?? / return types)
   ---------------------------------------------------------
   Dati, ang buong search text ay hinahanap bilang ISANG
   piraso sa loob ng ISANG column lang (surname O first_name
   O middle_name). Kaya ang "Juan Dela Cruz" o "Cruz, Juan"
   ay HINDI nakikita, kahit existing ang estudyante.

   Ngayon:
   1) Kapag Student ID ang tinype (2024-00123, o 202400123
      na walang dash) -> EXACT match sa student_id (indexed).
   2) Kapag pangalan -> hinahati sa mga salita (tokens).
      Bawat salita ay kailangang tumama sa surname O
      first_name O middle_name O student_id, at LAHAT ng
      salita ay kailangang tumama (AND). Kaya gumagana ang:
        "Juan Dela Cruz"      "Dela Cruz, Juan"
        "Cruz Juan A."        "2024-0012"  (partial ID)
      Ang isang letra (hal. middle initial "A") ay
      "starts with" lang ang tinitingnan, hindi "contains".
   3) Kung may Master Record, kasama rin ang CURRENT name
      (para sa nagpalit ng apelyido).
   ========================================================= */

if (!function_exists('ascb_search_tokens')) {
    /* Hatiin ang search text sa mga salita. Max $max tokens. */
    function ascb_search_tokens($q, $max = 6) {
        $q = (string) $q;
        $q = str_replace(array("\xC2\xA0", "\t", "\r", "\n", ',', ';', '.'), ' ', $q);
        $q = preg_replace('/\s+/', ' ', $q);
        $q = trim($q);
        if ($q === '') {
            return array();
        }
        $tokens = explode(' ', $q);
        $out = array();
        foreach ($tokens as $t) {
            if ($t !== '') {
                $out[] = $t;
            }
        }
        return array_slice($out, 0, $max);
    }
}

if (!function_exists('ascb_search_like')) {
    /* LIKE pattern: 1 letter = starts-with, 2+ letters = contains. */
    function ascb_search_like($token) {
        $esc = str_replace(array('\\', '%', '_'), array('\\\\', '\\%', '\\_'), $token);
        $len = function_exists('mb_strlen') ? mb_strlen($token, 'UTF-8') : strlen($token);
        return ($len <= 1) ? ($esc . '%') : ('%' . $esc . '%');
    }
}

if (!function_exists('ascb_student_search_clause')) {
    /* Returns array('sql' => '(...)', 'params' => array(...)).
       sql === '' kapag walang mahahanap na salita.
       $alias      = alias ng enrollees table (default 'e')
       $withMaster = isama ang CURRENT name mula sa student_master
       $extraCols  = dagdag na columns ng $alias na hahanapin din */
    function ascb_student_search_clause($q, $alias = 'e', $withMaster = false, $extraCols = array()) {
        $tokens = ascb_search_tokens($q);
        if (!$tokens) {
            return array('sql' => '', 'params' => array());
        }
        $a = $alias;

        /* Student ID lang ang tinype -> canonical exact match.
           Imported Excel values are normalized to YYYY-NNNNN, but this
           search also tolerates legacy rows that contain a dash/space
           variation or a leading apostrophe. */
        if (count($tokens) === 1) {
            $id = trim($tokens[0], " \\t\\r\\n\\0\\x0B\\'");
            $id = str_replace(array('–','—','−','‑','‐'), '-', $id);
            if (preg_match('/^\\d{9}$/', $id)) {
                $id = substr($id, 0, 4) . '-' . substr($id, 4);
            }
            if (preg_match('/^\\d{4}\\s*-\\s*\\d{1,}$/', $id)) {
                $id = preg_replace('/\\s+/', '', $id);
            }
            if (preg_match('/^\\d{4}-\\d{1,}$/', $id)) {
                /* Compare both the canonical ID and a digits-only form.
                   This fixes old imported rows without requiring a destructive
                   database migration. */
                $digits = preg_replace('/\\D+/', '', $id);
                return array(
                    'sql' => "(REPLACE(REPLACE(REPLACE(TRIM($a.student_id), '-', ''), '–', ''), '''', '') = ? OR $a.student_id = ?)",
                    'params' => array($digits, $id)
                );
            }
        }

        $parts = array();
        $params = array();
        foreach ($tokens as $t) {
            $like = ascb_search_like($t);
            $p = "($a.surname LIKE ? OR $a.first_name LIKE ? OR $a.middle_name LIKE ? OR $a.student_id LIKE ?";
            $params[] = $like; $params[] = $like; $params[] = $like; $params[] = $like;
            /* Dagdag na columns (course, major, mobile, school...) — optional */
            foreach ($extraCols as $col) {
                $p .= " OR $a.$col LIKE ?";
                $params[] = $like;
            }
            if ($withMaster) {
                $p .= " OR $a.student_id IN (SELECT m.student_id FROM student_master m"
                    . " WHERE m.surname LIKE ? OR m.first_name LIKE ? OR m.middle_name LIKE ?)";
                $params[] = $like; $params[] = $like; $params[] = $like;
            }
            $p .= ")";
            $parts[] = $p;
        }
        return array('sql' => '(' . implode(' AND ', $parts) . ')', 'params' => $params);
    }
}

if (!function_exists('ascb_text_search_clause')) {
    /* Para sa mga table na may isang buong "student_name" column
       (hal. certificates): bawat salita ay kailangang tumama sa
       alinman sa $columns, at LAHAT ng salita ay kailangang tumama. */
    function ascb_text_search_clause($q, $columns) {
        $tokens = ascb_search_tokens($q);
        if (!$tokens || !$columns) {
            return array('sql' => '', 'params' => array());
        }
        $parts = array();
        $params = array();
        foreach ($tokens as $t) {
            $like = '%' . str_replace(array('\\', '%', '_'), array('\\\\', '\\%', '\\_'), $t) . '%';
            $ors = array();
            foreach ($columns as $c) {
                $ors[] = $c . ' LIKE ?';
                $params[] = $like;
            }
            $parts[] = '(' . implode(' OR ', $ors) . ')';
        }
        return array('sql' => '(' . implode(' AND ', $parts) . ')', 'params' => $params);
    }
}
