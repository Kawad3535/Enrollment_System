<?php
/* =========================================================
   MINIMAL .XLSX READER (walang external library/composer)
   ---------------------------------------------------------
   Isang .xlsx file ay isang ZIP container na may mga XML file
   sa loob. Binabasa lang dito ang UNANG worksheet:
     - xl/sharedStrings.xml : listahan ng lahat ng text/string
       na ginamit sa buong workbook (para hindi paulit-ulit
       na naka-store ang parehong text sa bawat cell)
     - xl/worksheets/sheet1.xml : ang aktwal na mga cell
       (row/column reference, at index papunta sa shared
       string kung text ang laman, o direktang numero)

   Ibinabalik ang isang 0-indexed array of rows, bawat row ay
   0-indexed array of trimmed string cell values (walang
   pag-preserve ng cell type/formatting — text lang).

   Requires: ZipArchive at SimpleXML/DOM (parehong built-in na
   sa halos lahat ng PHP install, walang kailangang i-install). */

require_once __DIR__ . '/helpers.php'; // para sa ascb_clean_numeric_string()

if (!function_exists('ascb_xlsx_read_first_sheet')) {

    function ascb_xlsx_col_to_index($ref) {
        // "C7" -> column letters "C" -> 0-indexed column number (2)
        preg_match('/^([A-Z]+)/', $ref, $m);
        $letters = isset($m[1]) ? $m[1] : 'A';
        $col = 0;
        for ($i = 0; $i < strlen($letters); $i++) {
            $col = $col * 26 + (ord($letters[$i]) - ord('A') + 1);
        }
        return $col - 1;
    }

    /* Pure-PHP ZIP reader (walang ext-zip/ZipArchive na kailangan) —
       ginagamit lang ang gzinflate() (zlib) at ang End-of-Central-Directory
       / Central Directory record ng ZIP format, na parehong halos laging
       available kahit walang ZipArchive extension. Ibinabalik ang assoc
       array ng "path/loob/ng/zip" => raw (decompressed) content string. */
    function ascb_zip_read_nozip($filePath) {
        $data = file_get_contents($filePath);
        if ($data === false || $data === '') {
            throw new Exception('Hindi mabuksan ang file bilang .xlsx (baka sira o hindi talaga Excel file).');
        }
        $eocdPos = strrpos($data, "\x50\x4b\x05\x06");
        if ($eocdPos === false) {
            throw new Exception('Hindi kilalang .xlsx/.zip format ng file.');
        }
        $eocd = unpack('Vsig/vdisk/vdiskcd/ventriesdisk/ventriestotal/Vcdsize/Vcdoffset/vcommentlen', substr($data, $eocdPos, 22));

        $files = array();
        $pos = (int) $eocd['cdoffset'];
        for ($i = 0; $i < (int) $eocd['entriestotal']; $i++) {
            if (substr($data, $pos, 4) !== "\x50\x4b\x01\x02") break;
            $cf = unpack('Vsig/vvmade/vvneed/vflags/vmethod/vmtime/vmdate/Vcrc/Vcompsize/Vuncompsize/vnamelen/vextralen/vcommentlen/vdisknum/vintattr/Vextattr/Vlocaloffset', substr($data, $pos, 46));
            $name = substr($data, $pos + 46, $cf['namelen']);
            $pos += 46 + $cf['namelen'] + $cf['extralen'] + $cf['commentlen'];

            $lh = (int) $cf['localoffset'];
            $lf = unpack('Vsig/vvneed/vflags/vmethod/vmtime/vmdate/Vcrc/Vcompsize/Vuncompsize/vnamelen/vextralen', substr($data, $lh, 30));
            $dataStart = $lh + 30 + $lf['namelen'] + $lf['extralen'];
            $compressed = substr($data, $dataStart, (int) $cf['compsize']);

            if ((int) $cf['method'] === 0) {
                $files[$name] = $compressed;
            } elseif ((int) $cf['method'] === 8 && function_exists('gzinflate')) {
                $inflated = @gzinflate($compressed);
                $files[$name] = $inflated !== false ? $inflated : '';
            }
            // ibang compression method (hal. bzip2) — hindi suportado, laktawan.
        }
        return $files;
    }

    function ascb_xlsx_read_first_sheet($filePath, $maxRows = 20000) {
        $useZipArchive = class_exists('ZipArchive');
        $zip = null;
        $entries = null;
        if ($useZipArchive) {
            $zip = new ZipArchive();
            if ($zip->open($filePath) !== true) {
                throw new Exception('Hindi mabuksan ang file bilang .xlsx (baka sira o hindi talaga Excel file).');
            }
        } else {
            // FALLBACK: walang ZipArchive extension sa server — gumamit na
            // lang ng built-in pure-PHP ZIP reader para mabasa pa rin ang
            // na-upload na .xlsx.
            $entries = ascb_zip_read_nozip($filePath);
        }
        $getFromName = function ($name) use ($useZipArchive, $zip, $entries) {
            if ($useZipArchive) return $zip->getFromName($name);
            return isset($entries[$name]) ? $entries[$name] : false;
        };

        // Kunin muna ang aktwal na relative path ng unang sheet mula sa
        // workbook.xml + workbook.xml.rels (sa ibang exporter, hindi
        // laging "sheet1.xml" ang unang sheet).
        $sheetPath = 'xl/worksheets/sheet1.xml';
        $wbXml = $getFromName('xl/workbook.xml');
        $relsXml = $getFromName('xl/_rels/workbook.xml.rels');
        if ($wbXml !== false && $relsXml !== false) {
            $wb = @simplexml_load_string($wbXml);
            $rels = @simplexml_load_string($relsXml);
            if ($wb && $rels && isset($wb->sheets->sheet[0])) {
                $rId = (string) $wb->sheets->sheet[0]->attributes('r', true)->id;
                foreach ($rels->Relationship as $rel) {
                    if ((string) $rel['Id'] === $rId) {
                        $target = str_replace('..', '', (string) $rel['Target']);
                        // Target ay pwedeng absolute mula sa package root ("/xl/worksheets/sheet1.xml")
                        // o relative sa loob ng xl/ folder ("worksheets/sheet1.xml") — dalawang paraan
                        // ito ng pagsulat na parehong valid sa OOXML spec.
                        $sheetPath = (strpos($target, '/') === 0) ? ltrim($target, '/') : 'xl/' . $target;
                        break;
                    }
                }
            }
        }

        // Shared strings table (opsyonal — wala nito kung puro numero/blangko).
        $sharedStrings = array();
        $ssXml = $getFromName('xl/sharedStrings.xml');
        if ($ssXml !== false) {
            $ss = @simplexml_load_string($ssXml);
            if ($ss) {
                foreach ($ss->si as $si) {
                    if (isset($si->t)) {
                        $sharedStrings[] = (string) $si->t;
                    } else {
                        // Rich text (maraming <r><t> runs) — pagsamahin.
                        $text = '';
                        foreach ($si->r as $run) { $text .= (string) $run->t; }
                        $sharedStrings[] = $text;
                    }
                }
            }
        }

        $sheetXmlRaw = $getFromName($sheetPath);
        if ($useZipArchive) $zip->close();
        if ($sheetXmlRaw === false) {
            throw new Exception('Hindi nakita ang worksheet data sa loob ng .xlsx file.');
        }

        $sheet = @simplexml_load_string($sheetXmlRaw);
        if (!$sheet) {
            throw new Exception('Hindi nabasa ang worksheet XML (baka sira o hindi standard na .xlsx).');
        }

        $rows = array();
        $rowCount = 0;
        foreach ($sheet->sheetData->row as $rowXml) {
            if (++$rowCount > $maxRows) break;
            $rowData = array();
            foreach ($rowXml->c as $c) {
                $ref = (string) $c['r'];
                $colIdx = $ref !== '' ? ascb_xlsx_col_to_index($ref) : count($rowData);
                $type = (string) $c['t'];
                $raw = isset($c->v) ? (string) $c->v : '';
                if ($type === 's') {
                    $value = isset($sharedStrings[(int) $raw]) ? $sharedStrings[(int) $raw] : '';
                } elseif ($type === 'inlineStr') {
                    $value = isset($c->is->t) ? (string) $c->is->t : '';
                } elseif ($raw !== '' && is_numeric($raw)) {
                    /* Numeric cell (hal. grade/units): i-clean ang
                       floating-point imprecision na paminsan-minsan
                       na-eencode sa raw XML (hal. "1.1000000000000001")
                       bago pa ito ma-store sa database. */
                    $value = ascb_clean_numeric_string($raw);
                } else {
                    $value = $raw;
                }
                $rowData[$colIdx] = trim($value);
            }
            if ($rowData) {
                $maxIdx = max(array_keys($rowData));
                $normalized = array();
                for ($i = 0; $i <= $maxIdx; $i++) {
                    $normalized[$i] = isset($rowData[$i]) ? $rowData[$i] : '';
                }
                $rows[] = $normalized;
            } else {
                $rows[] = array();
            }
        }
        return $rows;
    }
}


/* =========================================================
   INTELLIGENT IMPORT SUPPORT — ALL WORKSHEETS
   ---------------------------------------------------------
   Returns:
     array(
       array('name' => 'Sheet1', 'rows' => [...]),
       ...
     )
   The original ascb_xlsx_read_first_sheet() remains untouched
   for legacy callers.
   ========================================================= */
if (!function_exists('ascb_xlsx_read_all_sheets')) {
    function ascb_xlsx_read_all_sheets($filePath, $maxRows = 20000) {
        $useZipArchive = class_exists('ZipArchive');
        $zip = null;
        $entries = null;
        if ($useZipArchive) {
            $zip = new ZipArchive();
            if ($zip->open($filePath) !== true) {
                throw new Exception('Hindi mabuksan ang file bilang .xlsx.');
            }
        } else {
            $entries = ascb_zip_read_nozip($filePath);
        }
        $get = function ($name) use ($useZipArchive, $zip, $entries) {
            if ($useZipArchive) return $zip->getFromName($name);
            return isset($entries[$name]) ? $entries[$name] : false;
        };

        $sharedStrings = array();
        $ssXml = $get('xl/sharedStrings.xml');
        if ($ssXml !== false) {
            $ss = @simplexml_load_string($ssXml);
            if ($ss) foreach ($ss->si as $si) {
                if (isset($si->t)) $sharedStrings[] = (string)$si->t;
                else {
                    $text = '';
                    foreach ($si->r as $run) $text .= (string)$run->t;
                    $sharedStrings[] = $text;
                }
            }
        }

        $wbXml = $get('xl/workbook.xml');
        $relsXml = $get('xl/_rels/workbook.xml.rels');
        if ($wbXml === false || $relsXml === false) {
            if ($useZipArchive) $zip->close();
            throw new Exception('Hindi mabasa ang workbook metadata.');
        }
        $wb = @simplexml_load_string($wbXml);
        $rels = @simplexml_load_string($relsXml);
        if (!$wb || !$rels || !isset($wb->sheets->sheet)) {
            if ($useZipArchive) $zip->close();
            throw new Exception('Hindi mabasa ang worksheet list.');
        }

        $relMap = array();
        foreach ($rels->Relationship as $rel) {
            $relMap[(string)$rel['Id']] = (string)$rel['Target'];
        }

        $result = array();
        foreach ($wb->sheets->sheet as $sheetNode) {
            $name = (string)$sheetNode['name'];
            $rId = (string)$sheetNode->attributes('r', true)->id;
            if (!isset($relMap[$rId])) continue;
            $target = str_replace('..', '', $relMap[$rId]);
            $sheetPath = (strpos($target, '/') === 0) ? ltrim($target, '/') : 'xl/' . ltrim($target, '/');
            $raw = $get($sheetPath);
            if ($raw === false) continue;
            $sheet = @simplexml_load_string($raw);
            if (!$sheet) continue;

            $rows = array();
            $rowCount = 0;
            foreach ($sheet->sheetData->row as $rowXml) {
                if (++$rowCount > $maxRows) break;
                $rowData = array();
                foreach ($rowXml->c as $c) {
                    $ref = (string)$c['r'];
                    $colIdx = $ref !== '' ? ascb_xlsx_col_to_index($ref) : count($rowData);
                    $type = (string)$c['t'];
                    $rawValue = isset($c->v) ? (string)$c->v : '';
                    if ($type === 's') {
                        $value = isset($sharedStrings[(int)$rawValue]) ? $sharedStrings[(int)$rawValue] : '';
                    } elseif ($type === 'inlineStr') {
                        $value = isset($c->is->t) ? (string)$c->is->t : '';
                    } elseif ($rawValue !== '' && is_numeric($rawValue)) {
                        $value = ascb_clean_numeric_string($rawValue);
                    } else {
                        $value = $rawValue;
                    }
                    $rowData[$colIdx] = trim($value);
                }
                if ($rowData) {
                    $maxIdx = max(array_keys($rowData));
                    $normalized = array();
                    for ($i=0; $i<=$maxIdx; $i++) $normalized[$i] = isset($rowData[$i]) ? $rowData[$i] : '';
                    $rows[] = $normalized;
                } else $rows[] = array();
            }
            $result[] = array('name'=>$name, 'rows'=>$rows);
        }
        if ($useZipArchive) $zip->close();
        return $result;
    }
}
