<?php
/* =========================================================
   MINIMAL .XLSX WRITER (walang external library/composer)
   ---------------------------------------------------------
   Kabaligtaran ng includes/xlsx_reader.php: dito, gumagawa
   tayo ng tunay na .xlsx file (isang ZIP container na may
   OOXML XML parts sa loob) gamit lang ang ZipArchive — parehong
   built-in extension na ginagamit na ng xlsx_reader.php, kaya
   walang bagong dependency.

   Sinasadyang "inline string" (t="inlineStr") ang ginagamit
   para sa text cells sa halip na sharedStrings.xml — mas simple
   ito at hindi na kailangan pa ng hiwalay na string table, at
   nababasa pa rin ito nang tama ng ascb_xlsx_read_first_sheet()
   sa xlsx_reader.php (may suporta na ito sa inlineStr).

   Apat lang na style ang suportado (sapat na para sa mga export
   report ng ASCB Registrar):
     0 = normal      — walang border, walang bold (title/meta/blangkong row)
     1 = header      — bold, naka-center (h+v), may thin border sa apat na gilid
     2 = body        — naka-center lang nang patayo (vertical), may thin border
     3 = body_center — naka-center pareho (h+v), may thin border (para sa Grades/Units)

   Paggamit:
     $rows = array(
         array(array('v' => 'Promotional Report')),                 // style 0 (default)
         array(array('v' => 'No', 'style' => 1), array('v' => 'Student Number', 'style' => 1)),
         array(array('v' => 1, 'style' => 2), array('v' => '2024111510', 'style' => 2, 'type' => 's')),
     );
     $merges = array('A1:M1', 'A8:A14');
     $bytes = ascb_xlsx_build('Student Grades', $rows, $merges, array('A' => 24, 'B' => 27));
     // pagkatapos, i-stream sa browser gamit ang tamang headers (tingnan ang
     // api/promotional_report_export.php) o isulat sa disk gamit file_put_contents(). */

if (!function_exists('ascb_xlsx_col_letter')) {

    // Sadyang HIWALAY na function ito sa ascb_xlsx_col_to_index() ng
    // xlsx_reader.php (na nag-e-expect ng buong cell ref tulad ng "C7") —
    // dito, letra lang ang input (hal. "C"), para hindi kailangang
    // i-require pa ang xlsx_reader.php sa mga script na gumagamit lang
    // ng writer.
    function ascb_xlsx_letter_to_index($letters) {
        $letters = strtoupper($letters);
        $col = 0;
        for ($i = 0; $i < strlen($letters); $i++) {
            $col = $col * 26 + (ord($letters[$i]) - ord('A') + 1);
        }
        return $col - 1;
    }

    function ascb_xlsx_col_letter($idx) {
        // 0-indexed column number -> letra (0 => "A", 26 => "AA")
        $idx++; // gawing 1-indexed muna
        $letters = '';
        while ($idx > 0) {
            $rem = ($idx - 1) % 26;
            $letters = chr(65 + $rem) . $letters;
            $idx = intdiv($idx - 1, 26);
        }
        return $letters;
    }

    function ascb_xlsx_escape($value) {
        // Valid lang sa XML ang mga karakter na ito; tinatanggal ang mga
        // "control character" na maaaring makasira sa XML (hal. mula sa
        // basura/invisible na naka-paste galing sa ibang system).
        $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', (string) $value);
        return htmlspecialchars($value, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }

    function ascb_xlsx_styles_xml() {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' .
            /* OOXML schema order is important: numFmts must come before fonts/fills/borders. */
            '<numFmts count="1"><numFmt numFmtId="164" formatCode="0.0#"/></numFmts>' .
            '<fonts count="4">' .
                '<font><sz val="11"/><name val="Calibri"/></font>' .
                '<font><b/><sz val="11"/><name val="Calibri"/></font>' .
                '<font><b/><sz val="16"/><name val="Times New Roman"/></font>' .
                '<font><b/><sz val="11"/><color rgb="FFC00000"/><name val="Calibri"/></font>' .
            '</fonts>' .
            '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>' .
            '<borders count="2">' .
                '<border><left/><right/><top/><bottom/><diagonal/></border>' .
                '<border><left style="thin"><color indexed="64"/></left><right style="thin"><color indexed="64"/></right>' .
                    '<top style="thin"><color indexed="64"/></top><bottom style="thin"><color indexed="64"/></bottom><diagonal/></border>' .
            '</borders>' .
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellStyleXfs>' .
            '<cellXfs count="15">' .
                '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' . // 0 normal
                '<xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>' . // 1 header
                '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>' . // 2 body
                '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' . // 3 body_center
                '<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' . // 4 grade
                '<xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>' . // 5 student number
                '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' . // 6 title (big, centered, no border)
                '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' . // 7 centered plain, no border
                '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>' . // 8 bold left, no border
                '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>' . // 9 plain left, no border
                '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' . // 10 bold centered, no border
                '<xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>' . // 11 bold right, border (total label)
                '<xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' . // 12 bold center, border (total value)
                '<xf numFmtId="0" fontId="3" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' . // 13 red bold center, border (INC / DRP flag)
                '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>' . // 14 bold left wrap, no border (term label)
            '</cellXfs>' .
            '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>' .
            '</styleSheet>';
    }

    function ascb_xlsx_content_types_xml($hasImage = false) {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' .
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' .
            '<Default Extension="xml" ContentType="application/xml"/>' .
            ($hasImage ? '<Default Extension="png" ContentType="image/png"/><Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>' : '') .
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' .
            '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' .
            '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' .
            '</Types>';
    }

    function ascb_xlsx_root_rels_xml() {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' .
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' .
            '</Relationships>';
    }

    function ascb_xlsx_workbook_rels_xml() {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' .
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>' .
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' .
            '</Relationships>';
    }

    function ascb_xlsx_workbook_xml($sheetName) {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" ' .
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' .
            '<sheets><sheet name="' . ascb_xlsx_escape($sheetName) . '" sheetId="1" r:id="rId1"/></sheets>' .
            '</workbook>';
    }

    /* Binubuo ang xl/worksheets/sheet1.xml.
       $rows: listahan ng row, bawat row ay listahan ng cell (array 'v'=>value, opsyonal 'style'=>0-3, opsyonal 'type'=>'s'|'n').
              Numeric ang default type kapag numero ang laman, kundi 's' (string/inline text).
       $merges: listahan ng range string, hal. array('A1:M1', 'A8:A14').
       $colWidths: assoc array ng column letter => width, hal. array('A'=>24,'K'=>72). */
    function ascb_xlsx_sheet_xml($rows, $merges = array(), $colWidths = array(), $opts = array()) {
        $rowHeights = isset($opts['rowHeights']) && is_array($opts['rowHeights']) ? $opts['rowHeights'] : array();
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" ' .
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">';
        if (!empty($opts['pageSetup'])) {
            $xml .= '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>';
        }
        if (!empty($opts['hideGridlines'])) {
            $xml .= '<sheetViews><sheetView showGridLines="0" workbookViewId="0"/></sheetViews>';
        }

        if ($colWidths) {
            $xml .= '<cols>';
            foreach ($colWidths as $letter => $width) {
                $idx = ascb_xlsx_letter_to_index($letter) + 1; // 1-indexed
                $xml .= '<col min="' . $idx . '" max="' . $idx . '" width="' . (float) $width . '" customWidth="1"/>';
            }
            $xml .= '</cols>';
        }

        $xml .= '<sheetData>';
        foreach ($rows as $r => $cells) {
            $rowNum = $r + 1;
            $htAttr = isset($rowHeights[$r]) ? ' ht="' . (float) $rowHeights[$r] . '" customHeight="1"' : '';
            $xml .= '<row r="' . $rowNum . '"' . $htAttr . '>';
            foreach ($cells as $c => $cell) {
                if ($cell === null) continue;
                $ref = ascb_xlsx_col_letter($c) . $rowNum;
                $value = is_array($cell) ? (isset($cell['v']) ? $cell['v'] : '') : $cell;
                $style = is_array($cell) && isset($cell['style']) ? (int) $cell['style'] : 0;
                $type = is_array($cell) && isset($cell['type']) ? $cell['type'] : (is_numeric($value) && $value !== '' ? 'n' : 's');
                $styleAttr = $style ? ' s="' . $style . '"' : '';

                if ($value === '' || $value === null) {
                    // Blangkong cell — isulat pa rin kung may style (para sa border ng merged/grid cells).
                    if ($styleAttr !== '') {
                        $xml .= '<c r="' . $ref . '"' . $styleAttr . '/>';
                    }
                    continue;
                }

                if ($type === 'n') {
                    $xml .= '<c r="' . $ref . '"' . $styleAttr . '><v>' . ascb_xlsx_escape((0 + $value)) . '</v></c>';
                } else {
                    $xml .= '<c r="' . $ref . '"' . $styleAttr . ' t="inlineStr"><is><t xml:space="preserve">' . ascb_xlsx_escape($value) . '</t></is></c>';
                }
            }
            $xml .= '</row>';
        }
        $xml .= '</sheetData>';

        if ($merges) {
            $xml .= '<mergeCells count="' . count($merges) . '">';
            foreach ($merges as $m) {
                $xml .= '<mergeCell ref="' . ascb_xlsx_escape($m) . '"/>';
            }
            $xml .= '</mergeCells>';
        }

        if (!empty($opts['pageSetup'])) {
            /* paperSize 14 = Folio 8.5 x 13 in (LONG BOND). fitToHeight=0 -> kasya sa lapad, kahit ilang pahina ang haba. */
            $paper = isset($opts['paperSize']) ? (int) $opts['paperSize'] : 14;
            $xml .= '<printOptions horizontalCentered="1"/>' .
                '<pageMargins left="0.5" right="0.5" top="0.5" bottom="0.5" header="0.3" footer="0.3"/>' .
                '<pageSetup paperSize="' . $paper . '" orientation="portrait" fitToWidth="1" fitToHeight="0"/>';
        }
        if (!empty($opts['drawing'])) {
            $xml .= '<drawing r:id="rId1"/>';
        }

        $xml .= '</worksheet>';
        return $xml;
    }

    function ascb_zip_u16($n) { return pack('v', $n); }
    function ascb_zip_u32($n) { return pack('V', $n); }

    /* Pure-PHP ZIP builder (walang ext-zip/ZipArchive na kailangan) —
       ginagamit lang ang zlib (gzdeflate) at crc32(), na parehong
       built-in/halos laging naka-enable kahit walang ZipArchive.
       $files: assoc array ng "path/loob/ng/zip.xml" => raw content string.
       Ibinabalik ang raw bytes ng buong .zip (=.xlsx) container. */
    function ascb_zip_build_nozip($files) {
        $localParts = '';
        $centralParts = '';
        $offset = 0;
        $count = 0;
        foreach ($files as $name => $data) {
            $count++;
            $uncompLen = strlen($data);
            $crc = crc32($data);
            $compressed = function_exists('gzdeflate') ? gzdeflate($data, 6) : false;
            if ($compressed === false) { $compressed = $data; $method = 0; } else { $method = 8; }
            $compLen = strlen($compressed);
            $nameLen = strlen($name);

            $localHeader = ascb_zip_u32(0x04034b50) . ascb_zip_u16(20) . ascb_zip_u16(0) .
                ascb_zip_u16($method) . ascb_zip_u16(0) . ascb_zip_u16(0x21) .
                ascb_zip_u32($crc) . ascb_zip_u32($compLen) . ascb_zip_u32($uncompLen) .
                ascb_zip_u16($nameLen) . ascb_zip_u16(0) . $name;

            $centralParts .= ascb_zip_u32(0x02014b50) . ascb_zip_u16(20) . ascb_zip_u16(20) .
                ascb_zip_u16(0) . ascb_zip_u16($method) . ascb_zip_u16(0) . ascb_zip_u16(0x21) .
                ascb_zip_u32($crc) . ascb_zip_u32($compLen) . ascb_zip_u32($uncompLen) .
                ascb_zip_u16($nameLen) . ascb_zip_u16(0) . ascb_zip_u16(0) . ascb_zip_u16(0) .
                ascb_zip_u16(0) . ascb_zip_u32(0) . ascb_zip_u32($offset) . $name;

            $localParts .= $localHeader . $compressed;
            $offset += strlen($localHeader) + $compLen;
        }

        $eocd = ascb_zip_u32(0x06054b50) . ascb_zip_u16(0) . ascb_zip_u16(0) .
            ascb_zip_u16($count) . ascb_zip_u16($count) .
            ascb_zip_u32(strlen($centralParts)) . ascb_zip_u32($offset) . ascb_zip_u16(0);

        return $localParts . $centralParts . $eocd;
    }

    /* Ibinabalik ang raw bytes ng isang kumpletong .xlsx file (isang string)
       na pwedeng i-echo diretso o i-save gamit file_put_contents(). */
    function ascb_xlsx_build($sheetName, $rows, $merges = array(), $colWidths = array(), $opts = array()) {
        /* $opts (opsyonal, backward-compatible): rowHeights (0-based row => points), pageSetup (bool),
           paperSize (default 14 = Folio 8.5x13), hideGridlines (bool),
           image => array('path'=>png file, 'cx'=>EMU, 'cy'=>EMU, 'col'=>0, 'row'=>0) */
        $img = (isset($opts['image']) && is_array($opts['image']) && !empty($opts['image']['path']) && is_readable($opts['image']['path'])) ? $opts['image'] : null;
        $opts['drawing'] = $img ? true : false;
        $files = array(
            '[Content_Types].xml' => ascb_xlsx_content_types_xml($img ? true : false),
            '_rels/.rels' => ascb_xlsx_root_rels_xml(),
            'xl/workbook.xml' => ascb_xlsx_workbook_xml($sheetName),
            'xl/_rels/workbook.xml.rels' => ascb_xlsx_workbook_rels_xml(),
            'xl/styles.xml' => ascb_xlsx_styles_xml(),
            'xl/worksheets/sheet1.xml' => ascb_xlsx_sheet_xml($rows, $merges, $colWidths, $opts),
        );
        if ($img) {
            $cx = (int) (isset($img['cx']) ? $img['cx'] : 6096000); $cy = (int) (isset($img['cy']) ? $img['cy'] : 1343025);
            $col = (int) (isset($img['col']) ? $img['col'] : 0); $row = (int) (isset($img['row']) ? $img['row'] : 0);
            $files['xl/worksheets/_rels/sheet1.xml.rels'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' .
                '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>';
            $files['xl/drawings/drawing1.xml'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
                '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">' .
                '<xdr:oneCellAnchor><xdr:from><xdr:col>' . $col . '</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>' . $row . '</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>' .
                '<xdr:ext cx="' . $cx . '" cy="' . $cy . '"/>' .
                '<xdr:pic><xdr:nvPicPr><xdr:cNvPr id="2" name="Letterhead" descr="Andres Soriano Colleges of Bislig, Inc."/><xdr:cNvPicPr><a:picLocks noChangeAspect="1"/></xdr:cNvPicPr></xdr:nvPicPr>' .
                '<xdr:blipFill><a:blip xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:embed="rId1"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill>' .
                '<xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' . $cx . '" cy="' . $cy . '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor></xdr:wsDr>';
            $files['xl/drawings/_rels/drawing1.xml.rels'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' .
                '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image1.png"/></Relationships>';
            $files['xl/media/image1.png'] = file_get_contents($img['path']);
        }

        if (class_exists('ZipArchive')) {
            $tmpPath = tempnam(sys_get_temp_dir(), 'ascb_xlsx_');
            $zip = new ZipArchive();
            if ($zip->open($tmpPath, ZipArchive::OVERWRITE) !== true) {
                @unlink($tmpPath);
                throw new Exception('Hindi magawa ang pansamantalang .xlsx file sa server.');
            }
            foreach ($files as $name => $content) {
                $zip->addFromString($name, $content);
            }
            $zip->close();
            $bytes = file_get_contents($tmpPath);
            @unlink($tmpPath);
            if ($bytes === false) {
                throw new Exception('Hindi mabasa ang nagawang .xlsx file mula sa server.');
            }
            return $bytes;
        }

        // FALLBACK: walang ZipArchive extension sa server — gumamit na lang
        // ng built-in pure-PHP ZIP builder (zlib + crc32 lang ang kailangan)
        // para gumana pa rin ang export kahit hindi ma-enable ang ext-zip.
        return ascb_zip_build_nozip($files);
    }

    /* =====================================================
       STREAMING WRITER (para sa malalaking export / backup)
       -----------------------------------------------------
       Ang ascb_xlsx_build() ay kailangang nasa memory ang LAHAT ng
       row bago isulat. Para sa automatic backup (libu-libong row),
       ito ang gamitin: isinusulat ang bawat row diretso sa temp
       file, kaya bounded ang memory kahit napakalaki ng data.

         $w = ascb_xlsx_stream_open($tmpSheetPath, $colWidths, $freezeRows);
         ascb_xlsx_stream_row($w, array(array('v'=>'Hello','style'=>1), ...));
         ascb_xlsx_stream_close($w, 'Sheet Name', $outXlsxPath);
       ===================================================== */

    // XML ng isang row (parehong cell rules ng ascb_xlsx_sheet_xml()).
    function ascb_xlsx_row_xml($rowNum, $cells) {
        $xml = '<row r="' . $rowNum . '">';
        foreach ($cells as $c => $cell) {
            if ($cell === null) continue;
            $ref = ascb_xlsx_col_letter($c) . $rowNum;
            $value = is_array($cell) ? (isset($cell['v']) ? $cell['v'] : '') : $cell;
            $style = is_array($cell) && isset($cell['style']) ? (int) $cell['style'] : 0;
            $type = is_array($cell) && isset($cell['type']) ? $cell['type'] : (is_numeric($value) && $value !== '' ? 'n' : 's');
            $styleAttr = $style ? ' s="' . $style . '"' : '';
            if ($value === '' || $value === null) {
                if ($styleAttr !== '') $xml .= '<c r="' . $ref . '"' . $styleAttr . '/>';
                continue;
            }
            if ($type === 'n') {
                $xml .= '<c r="' . $ref . '"' . $styleAttr . '><v>' . ascb_xlsx_escape((0 + $value)) . '</v></c>';
            } else {
                $xml .= '<c r="' . $ref . '"' . $styleAttr . ' t="inlineStr"><is><t xml:space="preserve">' . ascb_xlsx_escape($value) . '</t></is></c>';
            }
        }
        return $xml . '</row>';
    }

    // Binubuksan ang temp sheet file at isinusulat ang simula ng worksheet XML.
    // $freezeRows > 0 = i-freeze ang unang N row (hal. title + header) para
    // nakikita pa rin ang header habang nag-s-scroll.
    function ascb_xlsx_stream_open($sheetTmpPath, $colWidths = array(), $freezeRows = 0) {
        $fh = @fopen($sheetTmpPath, 'wb');
        if (!$fh) throw new Exception('Hindi magawa ang pansamantalang .xlsx sheet file (check storage/backups permissions).');
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';
        $freezeRows = (int) $freezeRows;
        if ($freezeRows > 0) {
            $xml .= '<sheetViews><sheetView workbookViewId="0"><pane ySplit="' . $freezeRows . '" topLeftCell="A' . ($freezeRows + 1) . '" activePane="bottomLeft" state="frozen"/>' .
                '<selection pane="bottomLeft" activeCell="A' . ($freezeRows + 1) . '" sqref="A' . ($freezeRows + 1) . '"/></sheetView></sheetViews>';
        }
        if ($colWidths) {
            $xml .= '<cols>';
            foreach ($colWidths as $letter => $width) {
                $idx = ascb_xlsx_letter_to_index($letter) + 1;
                $xml .= '<col min="' . $idx . '" max="' . $idx . '" width="' . (float) $width . '" customWidth="1"/>';
            }
            $xml .= '</cols>';
        }
        $xml .= '<sheetData>';
        fwrite($fh, $xml);
        return array('fh' => $fh, 'path' => $sheetTmpPath, 'row' => 0);
    }

    function ascb_xlsx_stream_row(&$w, $cells) {
        $w['row']++;
        fwrite($w['fh'], ascb_xlsx_row_xml($w['row'], $cells));
    }

    // Tinatapos ang sheet at binubuo ang .xlsx sa $outPath. Binubura ang temp sheet file.
    function ascb_xlsx_stream_close(&$w, $sheetName, $outPath, $merges = array()) {
        $tail = '</sheetData>';
        if ($merges) {
            $tail .= '<mergeCells count="' . count($merges) . '">';
            foreach ($merges as $m) $tail .= '<mergeCell ref="' . ascb_xlsx_escape($m) . '"/>';
            $tail .= '</mergeCells>';
        }
        $tail .= '</worksheet>';
        fwrite($w['fh'], $tail);
        fclose($w['fh']);
        $w['fh'] = null;

        $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" ' .
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' .
            '<bookViews><workbookView/></bookViews>' .
            '<sheets><sheet name="' . ascb_xlsx_escape($sheetName) . '" sheetId="1" r:id="rId1"/></sheets></workbook>';
        $parts = array(
            '[Content_Types].xml' => ascb_xlsx_content_types_xml(),
            '_rels/.rels' => ascb_xlsx_root_rels_xml(),
            'xl/workbook.xml' => $workbook,
            'xl/_rels/workbook.xml.rels' => ascb_xlsx_workbook_rels_xml(),
            'xl/styles.xml' => ascb_xlsx_styles_xml(),
        );

        if (class_exists('ZipArchive')) {
            // addFile() = binabasa ng ZipArchive ang sheet mula sa disk habang nag-close(), hindi sa PHP memory.
            $zip = new ZipArchive();
            if ($zip->open($outPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
                @unlink($w['path']);
                throw new Exception('Hindi magawa ang .xlsx file sa server.');
            }
            foreach ($parts as $name => $content) $zip->addFromString($name, $content);
            $zip->addFile($w['path'], 'xl/worksheets/sheet1.xml');
            $closed = $zip->close();
            @unlink($w['path']);
            if (!$closed) throw new Exception('Hindi ma-finalize ang .xlsx file (check disk space / permissions).');
        } else {
            // FALLBACK (walang ZipArchive): pure-PHP ZIP builder — mas malakas sa memory pero gumagana pa rin.
            $parts['xl/worksheets/sheet1.xml'] = file_get_contents($w['path']);
            @unlink($w['path']);
            if (file_put_contents($outPath, ascb_zip_build_nozip($parts)) === false) {
                throw new Exception('Hindi masulat ang .xlsx file sa server.');
            }
        }
    }
}
