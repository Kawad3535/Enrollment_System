<?php
/* =========================================================
   ASCB REGISTRAR SYSTEM — LOGIN PAGE
   Ngayon ay PHP + MySQL (database) na ang login sa halip na
   hardcoded array. Ang form sa ibaba ay direktang nagpo-POST
   dito mismo sa index.php.
   ========================================================= */

require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/security.php';
ascb_start_session();
ascb_send_security_headers();

/* =========================================================
   FRONT CONTROLLER — iisang URL lang ang makikita (ang domain).
   Kapag naka-login na, ang tamang screen ay ini-include dito mismo
   (walang redirect sa /dashboard, /student, /change_password), kaya
   laging "/" lang ang address bar. Ang pagpili ng screen ay kapareho
   ng server guard sa includes/auth_check.php:
     - may must-change-password  -> change_password.php
     - STUDENT                   -> student.php
     - ibang role (staff/admin)  -> dashboard.php
   Ang bawat screen ay dumadaan pa rin sa sarili nitong auth guard.

   (FIX) HOME PAGE HABANG NAKA-LOGIN:
   Dati, dahil laging ini-include ang dashboard/student, hindi na
   mabubuksan ang Home page kapag naka-login (ang "Home" button ay
   nag-reload lang ng sarili niyang page). Ngayon:
     ./?view=home    -> ipapakita ang Home page (HINDI ang login form);
                        ang "Login" button ay nagiging "Dashboard" /
                        "Student Profile".
     ./?view=portal  -> balik sa Dashboard / Student Profile.
   Ang dalawang ito ay nagse-set lang ng 'view' sa session at agad
   nagre-redirect pabalik sa "./", kaya domain lang pa rin ang kita.
   ========================================================= */
$isLoggedIn   = false;
$portalUrl    = './?view=portal';
$portalLabel  = 'Dashboard';

if (!empty($_SESSION['ascb_user']) && is_array($_SESSION['ascb_user'])) {
    $ascbRouteUser = $_SESSION['ascb_user'];
    $ascbMustChange = !empty($ascbRouteUser['mustChangePassword']);
    $ascbIsStudent  = isset($ascbRouteUser['role']) && $ascbRouteUser['role'] === 'STUDENT';

    /* View switch (GET lang; view preference lang ang binabago, walang data). */
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['view'])) {
        if ($_GET['view'] === 'home' && !$ascbMustChange) {
            $_SESSION['ascb_view'] = 'home';
        } else {
            unset($_SESSION['ascb_view']);
        }
        header('Location: ./');
        exit;
    }

    if ($ascbMustChange) {
        unset($_SESSION['ascb_view']);
        $ascbRouteScreen = 'change_password.php';
    } elseif ($ascbIsStudent) {
        $ascbRouteScreen = 'student.php';
    } else {
        $ascbRouteScreen = 'dashboard.php';
    }

    if ($ascbMustChange || (isset($_SESSION['ascb_view']) ? $_SESSION['ascb_view'] : '') !== 'home') {
        require __DIR__ . '/' . $ascbRouteScreen;
        exit;
    }

    /* Naka-login at pinili ang Home -> ipakita ang Home page (walang login form). */
    $isLoggedIn  = true;
    if ($ascbIsStudent) { $portalLabel = 'Student Profile'; }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['view'])) {
    /* Hindi naka-login pero may ?view=... (hal. expired na ang session):
       linisin ang address bar — domain lang. */
    header('Location: ./');
    exit;
}
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/activity_log.php';
require_once __DIR__ . '/includes/login_throttle.php';
require_once __DIR__ . '/includes/student_account_helper.php';

$loginError = '';

if (!$isLoggedIn && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = ascb_get($_POST, 'csrf_token', '');
    if (!ascb_verify_csrf($csrf)) {
        $loginError = 'The login form has expired. Please refresh the page and try again.';
    }

    $username = trim(ascb_get($_POST, 'username', ''));
    $password = ascb_get($_POST, 'password', '');
    $remember = !empty($_POST['remember']);

    // (2024 audit fix) Account lockout check — pinapatakbo bago pa man
    // i-verify ang password, para hindi na kailangang subukan pa ang
    // database query kung naka-lock na naman ang username na ito.
    $lockedSeconds = ($loginError === '' && $username !== '')
        ? ascb_login_locked_seconds_remaining($pdo, $username)
        : 0;

    if ($loginError !== '') {
        // CSRF validation already failed.
    } elseif ($lockedSeconds > 0) {
        $lockedMinutes = (int) ceil($lockedSeconds / 60);
        $loginError = 'Too many failed login attempts. Please try again in about ' . $lockedMinutes . ' minute(s).';
    } elseif ($username === '' || $password === '') {
        $loginError = 'Invalid username or password. Please try again.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND is_active = 1");
        $stmt->execute([$username]);

        $matchedUser = null;
        $tempExpired = false;
        foreach ($stmt->fetchAll() as $row) {
            $isTemp = !empty($row['must_change_password']);
            $ok = password_verify($password, $row['password_hash']);
            /* Temporary (one-time) password: the slip shows it as XXXX-XXXX-XX,
               so ignore dashes/spaces/case — ONLY while the account is still on
               its temporary password. Normal passwords are always exact. */
            if (!$ok && $isTemp) {
                $ok = password_verify(ascb_sa_normalize_temp_password($password), $row['password_hash']);
            }
            if (!$ok) continue;
            if ($isTemp && !empty($row['temp_password_expires_at']) && strtotime($row['temp_password_expires_at']) < time()) {
                $tempExpired = true;   // correct, but expired -> must be re-issued
                continue;
            }
            $matchedUser = $row;
            break;
        }

        if (!$matchedUser && $tempExpired) {
            $loginError = 'Your temporary password has expired. Please ask the Registrar\'s Office to issue a new one.';
        } elseif (!$matchedUser) {
            usleep(350000); // slow repeated password guessing without revealing which field was wrong
            ascb_login_record_failure($pdo, $username);
            $loginError = 'Invalid username or password. Please try again.';
        } else {
            ascb_login_reset_throttle($pdo, $username);
            session_regenerate_id(true);
            unset($_SESSION['ascb_view']);

            $_SESSION['ascb_user'] = [
                'id'          => (int)$matchedUser['id'],
                'username'    => $matchedUser['username'],
                'displayName' => $matchedUser['display_name'],
                'role'        => $matchedUser['role'],
                'departmentId' => isset($matchedUser['department_id']) ? (int)$matchedUser['department_id'] : null,
                'departmentName' => null,
                'preparedBy'  => $matchedUser['prepared_by_code'],
                'studentId'   => (isset($matchedUser['student_id']) && trim((string) $matchedUser['student_id']) !== '') ? trim((string) $matchedUser['student_id']) : null,
                'mustChangePassword' => !empty($matchedUser['must_change_password']),
            ];

            $_SESSION['ascb_remember'] = $remember ? 1 : 0;
            $_SESSION['ascb_last_activity'] = time();
            $_SESSION['ascb_csrf'] = ascb_random_token(32);

            ascb_log_activity($pdo, $_SESSION['ascb_user'], 'LOGIN', 'session', $matchedUser['display_name']);

            if ($remember) {
                // "Keep me signed in": 30-day cookie + SameSite/HttpOnly.
                ascb_extend_session_cookie(time() + 60 * 60 * 24 * 30);
            }

            /* First login with a temporary password -> forced password change
               BEFORE the Student Dashboard (also enforced by the server guards). */
            if (!empty($matchedUser['must_change_password'])) {
                header('Location: ./');
                exit;
            }
            header('Location: ./');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="ASCB_LOGO.png">
    <title>Office of the Registrar | ASCB</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="login.css?v=20261021-pvm1">
    <link rel="stylesheet" href="responsive.css?v=<?php echo (int) @filemtime(__DIR__ . '/responsive.css'); ?>">
    <script>document.documentElement.className+=" js"</script>
    <script src="auth.js"></script>
</head>
<body>
<header class="nav" id="nav">
    <a class="brand" href="#home"><img src="ASCB_LOGO.png" alt="ASCB Logo"><span>ANDRES SORIANO COLLEGES OF BISLIG, INC.</span></a>
    <nav class="nav-links" aria-label="Page sections">
        <a href="#about">About</a><a href="#philosophy">Philosophy</a><a href="#services">Services</a><a href="#contact">Contact</a>
        <?php if ($isLoggedIn): ?><a href="<?php echo htmlspecialchars($portalUrl); ?>" class="nav-cta"><?php echo htmlspecialchars($portalLabel); ?></a><?php else: ?><a href="#login" class="nav-cta" data-login>Login</a><?php endif; ?>
    </nav>
</header>

<main>
<section class="hero" id="home">
    <span class="blob b1"></span><span class="blob b2"></span>
    <div class="hero-copy">
        <p class="pill"><span class="dot"></span>74th Founding Anniversary &middot; 1952&ndash;2026</p>
        <p class="kicker">Your Academic Journey, Simplified.</p>
        <h1>Records, Enrollment &amp; <em>Student Management</em></h1>
        <p class="lead">Welcome to the official digital hub for Andres Soriano Colleges of Bislig, Inc. Seamlessly Manage Your Enrollment, Access your academic 						Records, and Track your progress all in one place.</p>
        <div class="hero-actions">
            <?php if ($isLoggedIn): ?><a href="<?php echo htmlspecialchars($portalUrl); ?>" class="btn-gold">Go to <?php echo htmlspecialchars($portalLabel); ?> <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a><?php else: ?><button type="button" class="btn-gold" data-login>Login <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button><?php endif; ?>
            <a href="#services" class="btn-ghost">Explore Services</a>
        </div>
    </div>
    <div class="hero-vis">
        <div class="vis-main"><img src="ascb_login_bg.jpg" alt="ASCB campus"></div>
        <div class="chip c1"><span class="dot"></span>SECURE YOUR DATA?</div>
        <div class="chip c2"><img src="ASCB_LOGO.png" alt=""><div><small>Official portal of</small><strong>Andres Soriano Colleges of Bislig, Inc.</strong></div></div>
    </div>
</section>

<div class="marquee" aria-hidden="true"><div class="mq-track"><span>Accountability</span><span>Stewardship</span><span>Compassion</span><span>Brilliance</span><span>Bislig&rsquo;s Pioneer in Private Education</span><span>ASCB, Ascending!</span><span>Accountability</span><span>Stewardship</span><span>Compassion</span><span>Brilliance</span><span>Bislig&rsquo;s Pioneer in Private Education</span><span>ASCB, Ascending!</span></div></div>

<section class="sec" id="about">
    <div class="wrap">
        <p class="eyebrow">ABOUT ANDRES SORIANO COLLEGES OF BISLIG, INC.</p>
        <h2>Bislig&rsquo;s Pioneer in <em>Private Education</em></h2>
        <div class="bento">
            <div class="bx bx-img reveal"><img src="ascb_anniversary.jpg" alt="ASCB 74th Founding Anniversary, 1952&ndash;2026" loading="lazy"></div>
            <div class="bx bx-txt reveal"><p>Founded in 1952, Andres Soriano Colleges of Bislig, Inc. is celebrating its 74th Founding Anniversary. The Office of the Registrar keeps the school&rsquo;s official student records, enrollment and grades in one secure system.</p></div>
            <div class="bx bx-stat reveal"><strong>1952</strong><span>Year Founded</span></div>
            <div class="bx bx-stat gold reveal"><strong>74<sup>th</sup></strong><span>Founding Anniversary</span></div>
            <div class="bx bx-vals reveal"><div><b>A</b>Accountability</div><div><b>S</b>Stewardship</div><div><b>C</b>Compassion</div><div><b>B</b>Brilliance</div></div>
        </div>
    </div>
</section>

<section class="sec pvm" id="philosophy">
    <div class="wrap">
        <p class="eyebrow">WHO WE ARE</p>
        <h2>Our <em>Philosophy, Vision</em> &amp; Mission</h2>
        <div class="pvm-grid">
            <article class="pvm-card pvm-phil reveal">
                <span class="pvm-no" aria-hidden="true">01</span>
                <h3>Philosophy</h3>
                <p>Andres Soriano Colleges of Bislig believes that education is a powerful catalyst for human dignity, social equity, and national progress. As a private, non-stock, non-profit institution, we uphold the principles of academic freedom, inclusive growth, and lifelong learning. We are committed to nurturing individuals who are competent, compassionate, and community-oriented&mdash;dedicated to uplifting society and embracing global citizenship.</p>
            </article>
            <article class="pvm-card reveal">
                <span class="pvm-no" aria-hidden="true">02</span>
                <h3>Vision</h3>
                <p>ASCB envisions itself as a leading private educational institution in the region and beyond, fostering an empowering and transformative education that develops globally competent, values-driven, and socially engaged individuals.</p>
            </article>
            <article class="pvm-card reveal">
                <span class="pvm-no" aria-hidden="true">03</span>
                <h3>Mission</h3>
                <p>Guided by a commitment to excellence, inclusivity, and service, ASCB provides holistic, accessible, and quality education programs that cultivate lifelong learning, critical thinking, and innovation; uphold integrity, social responsibility, and cultural heritage; equip graduates with 21st century competencies; and strengthen local and international linkages to advance internationalization and sustainable development.</p>
            </article>
        </div>
    </div>
</section>

<section class="sec tint" id="services">
    <div class="wrap">
        <p class="eyebrow">OFFICE OF THE REGISTRAR</p>
        <h2>Registrar <em>Services</em></h2>
        <div class="svcs"><article class="svc reveal"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></svg></span><h3>Admissions & Enrollment</h3><p>Streamline student onboarding and seamlessly launch new academic terms.</p><i><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></i></article><article class="svc reveal"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.7-.9L9.6 3.9A2 2 0 0 0 7.9 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/></svg></span><h3>Secure Student Data.</h3><p>Maintain fully Encrypted, Compliant, and Protected Student Records.</p><i><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></i></article><article class="svc reveal"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg></span><h3>Advanced Grade Tracking.</h3><p>Manage Grading Workflows and Performance Evaluations Efficiently.</p><i><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></i></article></div>
    </div>
</section>

<section class="sec" id="contact">
    <div class="wrap">
        <div class="cta reveal">
            <div>
                <p class="eyebrow">GET IN TOUCH</p>
                <h2>Office of the <em>Registrar</em></h2>
                <?php if ($isLoggedIn): ?><a href="<?php echo htmlspecialchars($portalUrl); ?>" class="btn-gold">Go to <?php echo htmlspecialchars($portalLabel); ?> <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a><?php else: ?><button type="button" class="btn-gold" data-login>Login <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button><?php endif; ?>
            </div>
            <div class="cta-list">
                <a href="mailto:collegeregistrar.ascb@gmail.com"><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-10 7L2 7"/></svg></span><div><small>Email</small><strong>collegeregistrar.ascb@gmail.com</strong></div></a>
                <div><span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.4 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></span><div><small>Phone</small><strong>(086) 853-2306 (PhilCom)</strong></div></div>
            </div>
        </div>
    </div>
</section>
</main>

<footer class="foot">
    <img src="ASCB_LOGO.png" alt="ASCB Badge">
    <span>&copy; 1952–2026 Andres Soriano Colleges of Bislig, Inc. &mdash; All Rights Reserved.</span>
</footer>

<!-- LOGIN MODAL (same form + PHP login logic, now opened from the Login buttons).
     Hindi na nire-render kapag naka-login na. -->
<?php if (!$isLoggedIn): ?>
<div class="lm" id="login" role="dialog" aria-modal="true" aria-labelledby="loginTitle" aria-hidden="true">
    <div class="lm-ov" data-close></div>
    <div class="lm-box">
        <button type="button" class="lm-x" data-close aria-label="Close login">&times;</button>
        <form class="login-card<?php echo $loginError ? ' shake' : ''; ?>" id="loginCard" method="POST" action="./" autocomplete="off">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(ascb_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
            <img class="lm-logo" src="ASCB_LOGO.png" alt="ASCB Logo">
            <div class="login-head">
                <h2 id="loginTitle">ANDRES SORIANO COLLEGES OF BISLIG, INC.</h2>
                <p>Login Your Account.</p>
            </div>
            <div class="login-error<?php echo $loginError ? ' show' : ''; ?>" id="loginError" role="alert"><?php echo htmlspecialchars($loginError); ?></div>

            <div class="login-field">
                <label for="loginUsername">Username</label>
                <div class="login-input-wrap">
                    <input type="text" id="loginUsername" name="username" placeholder="Enter your username" autocomplete="username" required>
                </div>
            </div>
            <div class="login-field">
                <label for="loginPassword">Password</label>
                <div class="login-input-wrap">
                    <input type="password" id="loginPassword" name="password" placeholder="Enter your password" autocomplete="current-password" required>
                    <button type="button" class="login-toggle-pw" id="loginTogglePw" onclick="ascbTogglePasswordVisibility()">Show</button>
                </div>
            </div>
            <div class="login-remember">
                <div class="login-remember-check">
                    <input type="checkbox" id="loginRemember" name="remember">
                    <label for="loginRemember">Keep me signed in</label>
                </div>
            </div>
            <button type="submit" class="login-submit" id="loginSubmitBtn">LOGIN <span class="login-submit-arrow">&rarr;</span></button>
            <div class="login-hint">Authorized Registrar Personnel and Enrolled Students only.</div>
        </form>
    </div>
</div>
<?php endif; ?>

<script>
(function () {
    var nav = document.getElementById('nav');
    function f() { nav.classList.toggle('solid', window.scrollY > 24); }
    f(); window.addEventListener('scroll', f, { passive: true });

    var els = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window) {
        var io = new IntersectionObserver(function (es) {
            es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
        }, { threshold: 0.15 });
        els.forEach(function (el, i) { el.style.transitionDelay = (i % 3) * 90 + 'ms'; io.observe(el); });
    } else { els.forEach(function (el) { el.classList.add('in'); }); }

    var modal = document.getElementById('login'), u = document.getElementById('loginUsername');
    if (!modal) { return; } // naka-login na: walang login modal
    function openLogin() {
        modal.classList.add('open'); modal.setAttribute('aria-hidden', 'false');
        document.documentElement.classList.add('lm-lock');
        setTimeout(function () { if (u) u.focus({ preventScroll: true }); }, 60);
    }
    function closeLogin() {
        modal.classList.remove('open'); modal.setAttribute('aria-hidden', 'true');
        document.documentElement.classList.remove('lm-lock');
    }
    document.querySelectorAll('[data-login]').forEach(function (b) {
        b.addEventListener('click', function (e) { e.preventDefault(); openLogin(); });
    });
    modal.querySelectorAll('[data-close]').forEach(function (b) { b.addEventListener('click', closeLogin); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && modal.classList.contains('open')) closeLogin(); });
    <?php if ($loginError): ?>openLogin();<?php endif; ?>

})();
</script>
</body>
</html>
