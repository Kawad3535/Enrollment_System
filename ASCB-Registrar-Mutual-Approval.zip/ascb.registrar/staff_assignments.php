<?php
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/security.php';
ascb_start_session();
if (empty($_SESSION['ascb_user'])) { header('Location: ./'); exit; }
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/permissions.php';
$me=$_SESSION['ascb_user'];
if (!ascb_can((string)($me['role']??''),'manage_users')) { http_response_code(403); exit('Access denied.'); }
$csrf = function_exists('ascb_csrf_token') ? ascb_csrf_token() : '';
$isModal = !empty($_GET['modal']);
$theme = (($_GET['theme'] ?? '') === 'dark') ? 'dark' : 'light';
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Staff Assignments | ASCB Registrar</title><style>
:root{--bg:#f3f6fb;--card:#fff;--line:#dce4ef;--text:#17243b;--muted:#64748b;--brand:#0a6ed9;--brand-dark:#112252;--brand-soft:#e8f1fd;--ok:#1f7a3d;--ok-soft:#e3f3ea;--bad:#a92720;--bad-soft:#fbe8e6;--chip:#f6f8fc;--chip-line:#e5ebf3;--shadow:0 4px 16px #17335b12;font-family:Inter,"Segoe UI",Arial,sans-serif;color:var(--text);background:var(--bg)}
body.dark{--bg:#0f2238;--card:#16324f;--line:#27425f;--text:#eaf1f7;--muted:#9bb0c6;--brand:#4da3ff;--brand-dark:#dbe9f8;--brand-soft:#1b3b5f;--ok:#5fd392;--ok-soft:#173d2e;--bad:#ff8a80;--bad-soft:#4a2220;--chip:#1b3a58;--chip-line:#2c4c6c;--shadow:none}
*{box-sizing:border-box}body{margin:0;padding:24px;background:var(--bg);color:var(--text)}
.wrap{max-width:1000px;margin:auto}
.page-head{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:20px 22px;margin-bottom:16px;box-shadow:var(--shadow)}
.page-head h1{font-size:22px;margin:0 0 4px}.page-head p{margin:0;color:var(--muted);font-size:14px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:0;border-radius:10px;padding:11px 18px;font:inherit;font-size:14px;font-weight:700;cursor:pointer;background:var(--brand);color:#fff;transition:transform .15s,box-shadow .15s,opacity .15s,background .15s}
body:not(.dark) .btn{background:#0a5fc0}
.btn:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 6px 14px #0a5fc033}.btn:disabled{opacity:.6;cursor:not-allowed}
.btn.secondary{background:var(--brand-soft);color:var(--brand-dark);box-shadow:none}
body.dark .btn{color:#06172b}body.dark .btn.secondary{color:#dbe9f8}
.spinner{width:15px;height:15px;border:2px solid #ffffff66;border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;display:none}.btn.busy .spinner{display:inline-block}@keyframes spin{to{transform:rotate(360deg)}}
.picker{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px 18px;margin-bottom:14px;box-shadow:var(--shadow)}
.picker label{display:block;font-weight:700;font-size:13px;margin-bottom:6px}
select{width:100%;padding:11px 12px;border:1px solid var(--line);border-radius:10px;background:var(--card);color:var(--text);font:inherit}
.staff-card{display:flex;align-items:center;gap:14px;background:linear-gradient(135deg,#112252,#0a6ed9);color:#fff;border-radius:16px;padding:16px 18px;margin-bottom:14px;box-shadow:var(--shadow)}
.avatar{width:46px;height:46px;border-radius:50%;background:#ffffff26;display:grid;place-items:center;font-weight:800;font-size:18px;flex:0 0 auto}
.staff-meta{min-width:0;flex:1}.staff-meta strong{display:block;font-size:16px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.staff-meta span{font-size:12.5px;opacity:.85}
.pill{background:#ffffff26;border-radius:999px;padding:6px 12px;font-size:12px;font-weight:700;white-space:nowrap}
.hint{font-size:13px;color:var(--muted);margin:0 2px 12px}
.dept{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px 16px;margin-bottom:12px;box-shadow:var(--shadow);transition:border-color .15s,box-shadow .15s}
.dept.on{border-color:var(--brand);box-shadow:0 0 0 3px #0a6ed91a}.dept.invalid{border-color:var(--bad);box-shadow:0 0 0 3px #a927201f}
.dept-head{display:flex;align-items:center;justify-content:space-between;gap:12px}
.dept-title{display:flex;align-items:center;gap:10px;min-width:0}.dept-title strong{font-size:14.5px}
.dept-ico{width:34px;height:34px;border-radius:10px;background:var(--brand-soft);color:var(--brand);display:grid;place-items:center;flex:0 0 auto}.dept-ico svg{width:18px;height:18px}
.dept-count{font-size:11.5px;font-weight:700;color:var(--ok);background:var(--ok-soft);border-radius:999px;padding:3px 9px;display:none}.dept.on .dept-count{display:inline-block}
.switch{position:relative;display:inline-flex;align-items:center;gap:9px;cursor:pointer;font-size:13px;font-weight:700;user-select:none}
.switch input{position:absolute;opacity:0;width:0;height:0}
.track{width:42px;height:24px;border-radius:999px;background:#b9c5d6;position:relative;transition:background .18s;flex:0 0 auto}.track::after{content:"";position:absolute;top:3px;left:3px;width:18px;height:18px;border-radius:50%;background:#fff;box-shadow:0 1px 3px #0003;transition:transform .18s}
.switch input:checked+.track{background:var(--brand)}.switch input:checked+.track::after{transform:translateX(18px)}.switch input:focus-visible+.track{outline:2px solid var(--brand);outline-offset:2px}
.dept-body{display:none;margin-top:14px;padding-top:14px;border-top:1px dashed var(--line)}.dept.on .dept-body{display:block}
.tools{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:10px}
.allprog{display:inline-flex;align-items:center;gap:8px;font-size:13px;font-weight:700;cursor:pointer}
.allprog input{width:16px;height:16px;accent-color:var(--brand)}
.links{display:flex;gap:6px}.linkbtn{border:0;background:var(--brand-soft);color:var(--brand-dark);border-radius:8px;padding:6px 10px;font:inherit;font-size:12px;font-weight:700;cursor:pointer}.linkbtn:hover{background:var(--brand);color:#fff}.dept.all .links{opacity:.4;pointer-events:none}
.programs{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
.program{display:flex;align-items:flex-start;gap:10px;background:var(--chip);border:1px solid var(--chip-line);padding:10px 12px;border-radius:10px;font-size:13px;line-height:1.35;cursor:pointer;transition:border-color .15s,background .15s}
.program:hover{border-color:var(--brand)}.program:has(input:checked){background:var(--brand-soft);border-color:var(--brand)}
.program input{width:16px;height:16px;margin-top:1px;accent-color:var(--brand);flex:0 0 auto}.program b{color:var(--brand-dark)}
.dept.all .program{opacity:.55;cursor:default}
.muted{font-size:12.5px;color:var(--muted)}.empty{padding:26px;text-align:center;color:var(--muted);background:var(--card);border:1px dashed var(--line);border-radius:14px}
.footer{position:sticky;bottom:0;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;padding:12px 4px 2px;margin-top:6px;background:linear-gradient(180deg,transparent,var(--bg) 28%)}
.summary{font-size:13px;font-weight:700;color:var(--muted)}.summary b{color:var(--brand)}
.actions{display:flex;gap:10px;margin-left:auto}
.overlay{position:fixed;inset:0;z-index:50;display:none;place-items:center;padding:16px;background:#08142899}.overlay.active{display:grid}
.dialog{width:min(380px,100%);background:var(--card);border-radius:18px;padding:26px 22px 20px;text-align:center;box-shadow:0 24px 60px #08142866;animation:rise .2s ease}@keyframes rise{from{transform:translateY(10px);opacity:0}to{transform:none;opacity:1}}
.dicon{width:62px;height:62px;border-radius:50%;margin:0 auto 12px;display:grid;place-items:center}.dicon svg{width:30px;height:30px}
.overlay[data-type=success] .dicon{background:var(--ok-soft);color:var(--ok)}.overlay[data-type=error] .dicon{background:var(--bad-soft);color:var(--bad)}
.dialog h3{margin:0 0 6px;font-size:18px}.dialog p{margin:0;color:var(--muted);font-size:14px;line-height:1.55;white-space:pre-line}.dialog .btn{margin-top:18px;min-width:120px}
.overlay[data-type=error] .dialog .btn{background:var(--bad)}body.dark .overlay[data-type=error] .dialog .btn{color:#2a0b09}
@media(max-width:700px){body{padding:12px}.programs{grid-template-columns:1fr}.page-head{padding:16px}}
body.modal-mode{padding:4px 2px 0}body.modal-mode .wrap{max-width:none;margin:0}body.modal-mode .page-head,body.modal-mode .picker{display:none}
</style></head><body class="<?= $isModal ? 'modal-mode ' : '' ?><?= $theme === 'dark' ? 'dark' : '' ?>"><div class="wrap">
<header class="page-head"><div><h1>Staff &amp; Dean Assignments</h1><p>Piliin ang departments at courses na puwedeng ma-access ng Admin Staff o Dean.</p></div><button class="btn secondary" type="button" onclick="location.href='./'">← Back to Dashboard</button></header>
<div class="picker"><label for="staff">Admin Staff / Dean account</label><select id="staff"><option value="">Loading staff…</option></select></div>
<div id="staffCard"></div>
<p class="hint" id="hint" style="display:none">I-on ang department, tapos pumili ng isa o higit pang course — o i-check ang “Allow all programs” para sa lahat ng kasalukuyan at darating na course.</p>
<div id="assignmentArea" class="empty">Choose a staff account to load assignments.</div>
<div class="footer"><div class="summary" id="summary"></div><div class="actions"><button type="button" class="btn secondary" onclick="cancelAssignment()">Cancel</button><button type="button" class="btn" id="saveBtn" onclick="saveAssignments()"><span class="spinner"></span><span id="saveLabel">✓ Save Assignments</span></button></div></div>
</div>
<div class="overlay" id="result" role="alertdialog" aria-modal="true"><div class="dialog"><div class="dicon" id="rIcon"></div><h3 id="rTitle"></h3><p id="rMsg"></p><button type="button" class="btn" id="rOk">OK</button></div></div>
<script>
const initialStaffId=<?=json_encode((int)($_GET['staff']??0))?>;const csrfToken=<?=json_encode($csrf)?>;const IS_MODAL=<?=json_encode($isModal)?>;
let data={users:[],departments:[],programs:[],assignments:[],programAssignments:[]};let saving=false;
const el=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ICON_OK='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>';
const ICON_BAD='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18"/><path d="M6 6l12 12"/></svg>';
const ICON_DEPT='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"/><path d="M5 21V8l7-5 7 5v13"/><path d="M9 21v-6h6v6"/></svg>';
async function api(payload){
  let r;
  try{r=await fetch('api/staff_assignments.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':csrfToken},body:JSON.stringify(payload)});}
  catch(e){throw new Error('Hindi maabot ang server. Tingnan ang koneksyon (o kung tumatakbo ang Apache/MySQL) at subukan muli.');}
  let j=null;const txt=await r.text();
  try{j=JSON.parse(txt);}catch(e){throw new Error(r.status===403||r.status===401?'Natapos na ang session o walang pahintulot. Mag-login muli.':'Hindi inaasahang sagot ng server (HTTP '+r.status+'). Subukan muli o ipaalam sa IT/Admin.');}
  if(!j||!j.ok)throw new Error((j&&j.error)||'Hindi natuloy ang request.');
  return j;
}
/* Result dialog: sa modal mode, ang parent (dashboard) ang nagpapakita para nasa ibabaw ng lahat. */
function showResult(ok,title,message){
  if(IS_MODAL&&window.parent!==window){window.parent.postMessage({type:'ascb-staff-assignments-result',ok:ok,title:title,message:message},location.origin);return;}
  const o=el('result');o.dataset.type=ok?'success':'error';el('rIcon').innerHTML=ok?ICON_OK:ICON_BAD;el('rTitle').textContent=title;el('rMsg').textContent=message;el('rOk').textContent=ok?'OK':'Try Again';o.classList.add('active');el('rOk').focus();
}
el('rOk').addEventListener('click',()=>el('result').classList.remove('active'));
function cancelAssignment(){if(IS_MODAL&&window.parent!==window){window.parent.postMessage({type:'ascb-staff-assignments-cancel'},location.origin);return}location.href='./'}
function currentUser(){return data.users.find(u=>Number(u.id)===Number(el('staff').value))||null}
async function init(){
  try{
    data=await api({action:'list'});
    el('staff').innerHTML='<option value="">— Select Admin Staff / Dean —</option>'+data.users.map(u=>`<option value="${u.id}">${esc(u.display_name)} (${esc(u.username)}) — ${esc(u.role||'')}${Number(u.is_active)?'':' — INACTIVE'}</option>`).join('');
    el('staff').addEventListener('change',renderAssignments);
    if(initialStaffId&&data.users.some(u=>Number(u.id)===initialStaffId)){el('staff').value=String(initialStaffId);}
    renderAssignments();
  }catch(e){el('assignmentArea').className='empty';el('assignmentArea').textContent='Hindi ma-load ang assignments.';showResult(false,'Unable to Load',e.message)}
}
function renderAssignments(){
  const uid=Number(el('staff').value);const u=currentUser();
  if(!uid||!u){el('staffCard').innerHTML='';el('hint').style.display='none';el('assignmentArea').className='empty';el('assignmentArea').innerHTML='Choose a staff account to load assignments.';updateSummary();return}
  const initial=(u.display_name||u.username||'?').trim().charAt(0).toUpperCase();
  el('staffCard').innerHTML=`<div class="staff-card"><div class="avatar">${esc(initial)}</div><div class="staff-meta"><strong>${esc(u.display_name)}</strong><span>@${esc(u.username)} · ${esc(u.role||'ADMIN STAFF')}${Number(u.is_active)?'':' · INACTIVE'}</span></div><div class="pill" id="pillCount"></div></div>`;
  el('hint').style.display='block';
  const existing=new Map(data.assignments.filter(a=>Number(a.user_id)===uid).map(a=>[Number(a.department_id),a]));
  el('assignmentArea').className='';
  el('assignmentArea').innerHTML=data.departments.map(d=>{
    const a=existing.get(Number(d.id));const isAll=!!(a&&Number(a.all_programs));
    const selected=new Set(data.programAssignments.filter(x=>a&&Number(x.user_department_assignment_id)===Number(a.id)).map(x=>Number(x.program_id)));
    const ps=data.programs.filter(p=>Number(p.department_id)===Number(d.id));
    return `<div class="dept${a?' on':''}${isAll?' all':''}" id="dept-${d.id}" data-dept="${d.id}">
      <div class="dept-head"><div class="dept-title"><span class="dept-ico">${ICON_DEPT}</span><strong>${esc(d.name)}${d.code?' ('+esc(d.code)+')':''}</strong><span class="dept-count" id="count-${d.id}"></span></div>
      <label class="switch"><input type="checkbox" class="dept-enabled" data-dept="${d.id}" ${a?'checked':''} onchange="toggleDept(${d.id},this.checked)"><span class="track"></span><span>Assigned</span></label></div>
      <div class="dept-body"><div class="tools"><label class="allprog"><input type="checkbox" class="all-programs" data-dept="${d.id}" ${isAll?'checked':''} onchange="toggleAll(${d.id},this.checked)"> Allow all current and future programs</label>
      <div class="links"><button type="button" class="linkbtn" onclick="selectAllPrograms(${d.id},true)">Select all</button><button type="button" class="linkbtn" onclick="selectAllPrograms(${d.id},false)">Clear</button></div></div>
      <div class="programs">${ps.length?ps.map(p=>`<label class="program"><input type="checkbox" class="program-choice dept-${d.id}" value="${p.id}" ${selected.has(Number(p.id))?'checked':''} ${isAll?'disabled':''} onchange="updateSummary()"><span><b>${esc(p.code||'')}</b> ${esc(p.course_name||'')}${p.major?' — '+esc(p.major):''}</span></label>`).join(''):'<span class="muted">No active programs found in this department.</span>'}</div></div></div>`;
  }).join('')||'<div class="empty">No active departments found.</div>';
  updateSummary();
}
function toggleDept(id,on){const d=el('dept-'+id);d.classList.toggle('on',on);d.classList.remove('invalid');updateSummary()}
function toggleAll(id,on){const d=el('dept-'+id);d.classList.toggle('all',on);document.querySelectorAll('.dept-'+id).forEach(c=>{c.disabled=on;if(on)c.checked=false});d.classList.remove('invalid');updateSummary()}
function selectAllPrograms(id,on){document.querySelectorAll('.dept-'+id).forEach(c=>{if(!c.disabled)c.checked=on});el('dept-'+id).classList.remove('invalid');updateSummary()}
function updateSummary(){
  let depts=0,progs=0,all=0;
  document.querySelectorAll('.dept-enabled:checked').forEach(c=>{
    const id=c.dataset.dept;depts++;
    const isAll=!!document.querySelector(`.all-programs[data-dept="${id}"]`)?.checked;
    const n=document.querySelectorAll('.dept-'+id+':checked').length;
    if(isAll)all++;else progs+=n;
    const badge=el('count-'+id);if(badge)badge.textContent=isAll?'All programs':(n+' selected');
  });
  const txt=!currentUser()?'':(depts?`<b>${depts}</b> department${depts>1?'s':''} · ${all?`<b>${all}</b> all-programs`+(progs?' + ':''):''}${(progs||!all)?`<b>${progs}</b> program${progs===1?'':'s'}`:''}`:'Walang department na naka-assign.');
  el('summary').innerHTML=txt;
  const pill=el('pillCount');if(pill)pill.textContent=depts+' dept'+(depts===1?'':'s');
}
async function saveAssignments(){
  if(saving)return;
  const userId=Number(el('staff').value);const u=currentUser();
  if(!userId||!u){showResult(false,'Walang Napiling Staff','Pumili muna ng Admin Staff o Dean account bago mag-save.');return}
  document.querySelectorAll('.dept.invalid').forEach(d=>d.classList.remove('invalid'));
  const assignments=[];
  for(const c of document.querySelectorAll('.dept-enabled:checked')){
    const id=Number(c.dataset.dept),all=!!document.querySelector(`.all-programs[data-dept="${id}"]`)?.checked;
    const programIds=all?[]:[...document.querySelectorAll('.dept-'+id+':checked')].map(x=>Number(x.value));
    if(!all&&!programIds.length){
      const card=el('dept-'+id);card.classList.add('invalid');card.scrollIntoView({behavior:'smooth',block:'center'});
      const dn=(data.departments.find(d=>Number(d.id)===id)||{}).name||'department';
      showResult(false,'Kulang ang Napili','Sa “'+dn+'”, pumili ng kahit isang course o i-check ang “Allow all current and future programs”.');return;
    }
    assignments.push({departmentId:id,allPrograms:all,programIds});
  }
  saving=true;const btn=el('saveBtn');btn.disabled=true;btn.classList.add('busy');el('saveLabel').textContent='Saving…';
  try{
    await api({action:'save',userId,assignments});
    const msg=assignments.length?`Na-save na ang access ni ${u.display_name} sa ${assignments.length} department${assignments.length>1?'s':''}.`:`Inalis ang lahat ng department/course access ni ${u.display_name}.`;
    try{data=await api({action:'list'});renderAssignments();}catch(e){}
    showResult(true,'Assignments Saved',msg);
  }catch(e){
    showResult(false,'Unable to Save',e.message||'Hindi na-save ang assignments. Subukan muli.');
  }finally{saving=false;btn.disabled=false;btn.classList.remove('busy');el('saveLabel').textContent='✓ Save Assignments';}
}
init();
</script></body></html>
