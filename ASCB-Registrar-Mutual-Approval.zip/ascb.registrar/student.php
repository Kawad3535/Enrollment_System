<?php
/* =========================================================
   ASCB REGISTRAR SYSTEM — STUDENT PORTAL
   ---------------------------------------------------------
   Read-only na view ng SARILING Grades at Enrolled Subjects
   ng naka-login na STUDENT, naka-group sa Academic Year ->
   Trimester.

   - ASCB_ALLOW_STUDENT: opt-in sa deny-by-default guard.
   - ASCB_STUDENT_ONLY : staff ay ibinabalik sa dashboard.php.
   - Walang form na nagse-save ng anumang record dito. Ang
     data ay kinukuha lang sa api/student_portal.php (GET).
   ========================================================= */
define('ASCB_ALLOW_STUDENT', true);
define('ASCB_STUDENT_ONLY', true);

require_once __DIR__ . '/includes/auth_check.php';

/* Fail-closed: kung walang naka-link na Student ID, walang ipapakitang record. */
$studentLinked = !empty($ascbUser['studentId']);
$displayName   = (string) ascb_get($ascbUser, 'displayName', '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="theme-color" content="#c7e2fb">
    <meta name="robots" content="noindex, nofollow">
    <link rel="icon" type="image/png" href="ASCB_LOGO.png">
    <title>Student Profile | ASCB</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="student.css">
    <link rel="stylesheet" href="responsive.css?v=<?php echo (int) @filemtime(__DIR__ . '/responsive.css'); ?>">

    <script>
        (function () {
            var t = localStorage.getItem("ascbTheme") === "dark" ? "dark" : "light";
            document.documentElement.setAttribute("data-theme", t);
        })();
    </script>
</head>
<body>

<header class="sp-top">
    <div class="sp-top-inner">
        <img class="sp-logo" src="ASCB_LOGO.png" alt="ASCB Logo">
        <div class="sp-brand">
            <small>Andres Soriano Colleges of Bislig, Inc.</small>
            <strong>Student Profile</strong>
        </div>
        <div class="sp-top-actions">
            <a class="sp-btn" href="./?view=home" id="spHomeBtn">Home</a>
            <button type="button" class="sp-btn" id="spPwBtn">Change Password</button>
            <a class="sp-btn" href="logout" id="spLogoutBtn">Log out</a>
        </div>
    </div>
</header>

<main class="sp-main">

    <div class="sp-summary">
        <dl class="sp-profile" id="spProfile">
            <div><dt>Student Name</dt><dd id="spName"><?php echo htmlspecialchars($displayName, ENT_QUOTES, 'UTF-8'); ?></dd></div>
            <div><dt>Student ID</dt><dd id="spSid"><?php echo $studentLinked ? htmlspecialchars((string) $ascbUser['studentId'], ENT_QUOTES, 'UTF-8') : '—'; ?></dd></div>
            <div><dt>Program</dt><dd id="spProgram">—</dd></div>
        </dl>

        <!-- Cumulative GWA (lahat ng numeric na grade; mas mababa = mas mataas ang marka) -->
        <section class="sp-gwa" aria-labelledby="spGwaLabel">
            <div class="sp-gwa-label" id="spGwaLabel">General Weighted Average (GWA)</div>
            <div class="sp-gwa-val" id="spGwa">—</div>
            <p class="sp-gwa-note" id="spGwaNote">Loading…</p>
            <div class="sp-scale" id="spScale" role="img" aria-label="GWA position on the 1.00 to 5.00 scale" hidden><i id="spScaleMark"></i></div>
            <div class="sp-scale-ends" id="spScaleEnds" hidden><span>1.00</span><span>5.00</span></div>
        </section>
    </div>

    <p class="sp-readonly-note">
        This page is view-only. For corrections to your grades, subjects, or personal records, please contact Your Dean or Registrar.
    </p>
    <p class="sp-withheld-note" id="spWithheldNotice" hidden>
       The Dean's Office has placed a temporary hold on your grade due to missing course requirements. To resolve this, please coordinate immediately with your 		professor or department chair.
    </p>

    <div class="sp-bar">
        <div class="sp-tabs" role="tablist">
            <button type="button" class="sp-tab active" role="tab" id="spTabGrades" aria-selected="true" data-tab="grades">My Grades</button>
            <button type="button" class="sp-tab" role="tab" id="spTabSubjects" aria-selected="false" data-tab="subjects">Enrolled Subjects</button>
        </div>
        <button type="button" class="sp-toggle" id="spToggleAll">Expand all</button>
    </div>

    <div id="spContent"><div class="sp-state">Loading your records…</div></div>
</main>

<!-- Change password (sariling account lang) -->
<div class="sp-modal" id="spPwModal" role="dialog" aria-modal="true" aria-labelledby="spPwTitle">
    <div class="sp-modal-card">
        <h3 id="spPwTitle">Change Password</h3>
        <input type="password" id="spPwCur" placeholder="Current password" autocomplete="current-password">
        <input type="password" id="spPwNew" placeholder="New password (at least 8 characters)" autocomplete="new-password">
        <input type="password" id="spPwNew2" placeholder="Confirm new password" autocomplete="new-password">
        <div class="sp-modal-msg" id="spPwMsg"></div>
        <div class="sp-modal-row">
            <button type="button" class="sp-btn" id="spPwCancel">Cancel</button>
            <button type="button" class="sp-btn primary" id="spPwSave">Save</button>
        </div>
    </div>
</div>

<!-- Confirm log out -->
<div class="sp-modal" id="spOutModal" role="dialog" aria-modal="true" aria-labelledby="spOutTitle">
    <div class="sp-modal-card">
        <h3 id="spOutTitle">Log out?</h3>
        <p>You will need to sign in again to view your grades and subjects.</p>
        <div class="sp-modal-row">
            <button type="button" class="sp-btn" id="spOutCancel">Stay logged in</button>
            <button type="button" class="sp-btn primary" id="spOutConfirm">Log out</button>
        </div>
    </div>
</div>

<!-- Auto logout (idle / expired session) -->
<div class="sp-modal" id="spIdleModal" role="alertdialog" aria-modal="true" aria-labelledby="spIdleTitle" aria-describedby="spIdleMsg">
    <div class="sp-modal-card">
        <h3 id="spIdleTitle">You have been logged out</h3>
        <p id="spIdleMsg">For your security, you were logged out after 5 minutes of inactivity.</p>
        <div class="sp-modal-row">
            <button type="button" class="sp-btn primary" id="spIdleLogin">Log in again</button>
        </div>
    </div>
</div>

<script>
(function () {
    "use strict";

    var CSRF = <?php echo json_encode(ascb_csrf_token(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    var LINKED = <?php echo $studentLinked ? 'true' : 'false'; ?>;

    var state = { tab: "grades", data: null, expandAll: false };
    var content = document.getElementById("spContent");

    /* ---------- tiny DOM helpers (textContent only → walang XSS) ---------- */
    function el(tag, cls, text) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text !== undefined && text !== null) n.textContent = text;
        return n;
    }
    function fmtUnits(u) {
        if (u === null || u === undefined || u === "") return "—";
        var n = Number(u);
        if (!isFinite(n)) return "—";
        return (Math.round(n * 100) / 100).toString();
    }
    var REMARK_CLASS = { "PASSED": "ok", "FAILED": "bad", "INCOMPLETE": "warn", "DROPPED": "none", "NO GRADE": "none", "NOT YET GRADED": "info" };
    var STATUS_CLASS = { "Completed": "ok", "Failed": "bad", "Incomplete": "warn", "Dropped": "none", "No Grade": "none", "Enrolled": "info" };
    function pill(text, map) {
        return el("span", "sp-pill " + (map[text] || "none"), text || "—");
    }

    function showState(msg, isError) {
        content.textContent = "";
        content.appendChild(el("div", "sp-state" + (isError ? " error" : ""), msg));
    }

    /* ---------- rendering ---------- */
    function fmtGwa(v) {
        if (v === null || v === undefined || v === "") return "—";
        var n = Number(v);
        return isFinite(n) ? n.toFixed(2) : "—";
    }
    function cell(cls, text, label) {
        var td = el("td", cls, text);
        if (label) td.setAttribute("data-label", label);
        return td;
    }

    function buildTable(term, tab) {
        var wrap = el("div", "sp-table-wrap");
        var table = el("table", "sp-table");
        // Units ay makikita na sa My Grades at sa Enrolled Subjects.
        var heads = tab === "grades"
            ? ["Course Code", "Course Description", "Grade", "Units", "Remarks"]
            : ["Course Code", "Course Description", "Units", "Status"];
        var thead = el("thead"), hr = el("tr");
        heads.forEach(function (h) {
            hr.appendChild(el("th", (h === "Units" || h === "Grade") ? "num" : "", h));
        });
        thead.appendChild(hr); table.appendChild(thead);

        var tbody = el("tbody");
        if (!term.subjects.length) {
            var er = el("tr"), ec = el("td", "sp-empty", "No subjects recorded for this term.");
            ec.colSpan = heads.length; er.appendChild(ec); tbody.appendChild(er);
        }
        term.subjects.forEach(function (s) {
            var tr = el("tr");
            tr.appendChild(cell("c-code", s.courseCode || "—"));
            tr.appendChild(cell("c-desc", s.description || "—"));
            if (tab === "grades") {
                tr.appendChild(cell("num c-grade", s.grade, "Grade"));
                tr.appendChild(cell("num c-units", fmtUnits(s.units), "Units"));
                var rt = el("td", "c-stat"); rt.appendChild(pill(s.remarks, REMARK_CLASS)); tr.appendChild(rt);
            } else {
                tr.appendChild(cell("num c-units", fmtUnits(s.units), "Units"));
                var st = el("td", "c-stat"); st.appendChild(pill(s.status, STATUS_CLASS)); tr.appendChild(st);
            }
            tbody.appendChild(tr);
        });
        table.appendChild(tbody);
        wrap.appendChild(table);
        return wrap;
    }

    /* Total Units (at Term GWA sa My Grades tab) */
    function sumItem(label, value, cls) {
        var s = el("span", "sp-sum-item" + (cls ? " " + cls : ""));
        s.appendChild(el("small", "", label));
        s.appendChild(el("b", "", value));
        return s;
    }
    function buildSummary(term, tab) {
        if (!term.subjects.length) return null;
        var box = el("div", "sp-term-sum");
        // Total Units: makikita sa My Grades at sa Enrolled Subjects.
        box.appendChild(sumItem("Total Units", fmtUnits(term.totalUnits)));
        if (tab === "grades") {
            box.appendChild(sumItem("Term GWA", fmtGwa(term.gwa), "gwa"));
            var graded = Number(term.gradedUnits) || 0, total = Number(term.totalUnits) || 0;
            if (term.gwa === null || term.gwa === undefined) {
                box.appendChild(el("p", "sp-sum-note", "GWA will appear once numeric grades are posted."));
            } else if (graded < total - 0.001) {
                box.appendChild(el("p", "sp-sum-note", "Based on " + fmtUnits(graded) + " of " + fmtUnits(total) + " units with a numeric grade."));
            }
        }
        return box;
    }

    function render() {
        var d = state.data;
        if (!d) return;
        content.textContent = "";
        if (!d.academicYears.length) {
            showState("No approved enrollment records found yet.", false);
            return;
        }
        d.academicYears.forEach(function (ay, idx) {
            var box = el("section", "sp-ay");
            var open = state.expandAll || idx === 0;
            if (!open) box.classList.add("collapsed");

            var head = el("button", "sp-ay-head");
            head.type = "button";
            head.setAttribute("aria-expanded", open ? "true" : "false");
            head.appendChild(el("span", "", "Academic Year " + (ay.schoolYear || "—")));
            if (state.tab === "grades" && ay.gwa !== null && ay.gwa !== undefined) {
                head.appendChild(el("span", "sp-ay-gwa", "GWA " + fmtGwa(ay.gwa)));
            }
            head.appendChild(el("span", "sp-chev", "▾"));
            head.addEventListener("click", function () {
                var c = box.classList.toggle("collapsed");
                head.setAttribute("aria-expanded", c ? "false" : "true");
            });
            box.appendChild(head);

            var body = el("div", "sp-ay-body");
            ay.terms.forEach(function (t) {
                var sec = el("div", "sp-term");
                var h3 = el("h3", "", t.trimester || "—");
                var meta = [t.yearLevel, t.program].filter(Boolean).join(" · ");
                if (meta) h3.appendChild(el("span", "", meta));
                sec.appendChild(h3);
                sec.appendChild(buildTable(t, state.tab));
                var sum = buildSummary(t, state.tab);
                if (sum) sec.appendChild(sum);
                body.appendChild(sec);
            });
            box.appendChild(body);
            content.appendChild(box);
        });
    }

    /* Cumulative GWA tile */
    function applyOverall(o, hasHiddenSubjects) {
        var val = document.getElementById("spGwa"), note = document.getElementById("spGwaNote");
        var scale = document.getElementById("spScale"), ends = document.getElementById("spScaleEnds");
        if (!o || o.gwa === null || o.gwa === undefined) {
            val.textContent = "—";
            note.textContent = hasHiddenSubjects ? "No visible numeric grades posted." : "No numeric grades posted yet.";
            scale.hidden = true; ends.hidden = true;
            return;
        }
        var g = Number(o.gwa);
        val.textContent = fmtGwa(g);
        note.textContent = "Cumulative · based on " + fmtUnits(o.gradedUnits) + (hasHiddenSubjects ? " visible graded units" : " graded units");
        var pct = Math.max(0, Math.min(100, (g - 1) / 4 * 100));
        document.getElementById("spScaleMark").style.left = pct + "%";
        scale.setAttribute("aria-label", "GWA " + fmtGwa(g) + " on the 1.00 to 5.00 scale");
        scale.hidden = false; ends.hidden = false;
    }

    function applyProfile(p) {
        if (!p) return;
        if (p.name) document.getElementById("spName").textContent = p.name;
        if (p.studentId) document.getElementById("spSid").textContent = p.studentId;
        var prog = p.program || "";
        /* Huwag ulitin ang major kung nasa program text na. */
        if (p.major && prog.toLowerCase().indexOf(String(p.major).toLowerCase()) === -1) prog += " — " + p.major;
        document.getElementById("spProgram").textContent = prog || "—";
    }

    /* ---------- load (GET lang) ---------- */
    function load() {
        if (!LINKED) {
            applyOverall(null);
            showState("Your account is not linked to a Student ID yet. Please contact the Office of the Registrar.", true);
            return;
        }
        fetch("api/student_portal.php", { method: "GET", credentials: "same-origin", headers: { "Accept": "application/json" } })
            .then(function (r) {
                if (r.status === 401) { window.location.href = "./"; return null; }
                return r.json().catch(function () { return { ok: false, error: "Unexpected server response." }; });
            })
            .then(function (j) {
                if (!j) return;
                if (!j.ok) { showState(j.error || "Unable to load your records.", true); return; }
                state.data = j;
                applyProfile(j.profile);
                var withheldNotice = document.getElementById("spWithheldNotice");
                if (withheldNotice) withheldNotice.hidden = !j.hasHiddenSubjects;
                applyOverall(j.overall, !!j.hasHiddenSubjects);
                render();
            })
            .catch(function () { showState("Unable to reach the server. Please check your connection and refresh the page.", true); });
    }

    /* ---------- tabs ---------- */
    Array.prototype.forEach.call(document.querySelectorAll(".sp-tab[data-tab]"), function (b) {
        b.addEventListener("click", function () {
            state.tab = b.getAttribute("data-tab");
            Array.prototype.forEach.call(document.querySelectorAll(".sp-tab[data-tab]"), function (x) {
                var on = x === b;
                x.classList.toggle("active", on);
                x.setAttribute("aria-selected", on ? "true" : "false");
            });
            render();
        });
    });
    document.getElementById("spToggleAll").addEventListener("click", function () {
        state.expandAll = !state.expandAll;
        this.textContent = state.expandAll ? "Collapse older years" : "Expand all";
        render();
    });

    /* ---------- change password (sariling account lang) ---------- */
    var pwModal = document.getElementById("spPwModal"), pwMsg = document.getElementById("spPwMsg");
    function pwMessage(t, kind) { pwMsg.textContent = t || ""; pwMsg.className = "sp-modal-msg" + (kind ? " " + kind : ""); }
    document.getElementById("spPwBtn").addEventListener("click", function () {
        ["spPwCur", "spPwNew", "spPwNew2"].forEach(function (id) { document.getElementById(id).value = ""; });
        pwMessage("");
        pwModal.classList.add("active");
        document.getElementById("spPwCur").focus();
    });
    document.getElementById("spPwCancel").addEventListener("click", function () { pwModal.classList.remove("active"); });
    pwModal.addEventListener("click", function (e) { if (e.target === pwModal) pwModal.classList.remove("active"); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") pwModal.classList.remove("active"); });
    document.getElementById("spPwSave").addEventListener("click", function () {
        var cur = document.getElementById("spPwCur").value,
            nw = document.getElementById("spPwNew").value,
            nw2 = document.getElementById("spPwNew2").value;
        if (!cur || !nw) { pwMessage("Please fill in all fields.", "err"); return; }
        if (nw.length < 8) { pwMessage("The new password must be at least 8 characters.", "err"); return; }
        if (nw !== nw2) { pwMessage("The new passwords do not match.", "err"); return; }
        pwMessage("Saving…");
        fetch("api/users.php", {
            method: "POST", credentials: "same-origin",
            headers: { "Content-Type": "application/json", "X-CSRF-Token": CSRF },
            body: JSON.stringify({ action: "change_password", currentPassword: cur, newPassword: nw })
        }).then(function (r) { return r.json(); }).then(function (j) {
            if (j && j.ok) { pwMessage("Password successfully changed.", "good"); setTimeout(function () { pwModal.classList.remove("active"); }, 1200); }
            else pwMessage((j && j.error) || "Unable to change the password.", "err");
        }).catch(function () { pwMessage("Unable to reach the server.", "err"); });
    });

    /* ---------- log out modal + auto-logout kapag 5 minutong idle ---------- */
    var IDLE_MS = 5 * 60 * 1000;      /* dapat tugma sa ASCB_STUDENT_IDLE_SECONDS (security.php) */
    var PING_EVERY_MS = 30 * 1000;    /* keep-alive habang aktibo */
    var outModal = document.getElementById("spOutModal"), idleModal = document.getElementById("spIdleModal");
    var lastActive = Date.now(), lastPing = Date.now(), loggedOut = false;

    document.getElementById("spLogoutBtn").addEventListener("click", function (e) {
        e.preventDefault();               /* kung walang JS, gagana pa rin ang normal na link */
        pwModal.classList.remove("active");
        outModal.classList.add("active");
        document.getElementById("spOutConfirm").focus();
    });
    document.getElementById("spOutCancel").addEventListener("click", function () { outModal.classList.remove("active"); });
    outModal.addEventListener("click", function (e) { if (e.target === outModal) outModal.classList.remove("active"); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") outModal.classList.remove("active"); });
    document.getElementById("spOutConfirm").addEventListener("click", function () {
        loggedOut = true;
        window.location.href = "logout";
    });
    document.getElementById("spIdleLogin").addEventListener("click", function () { window.location.href = "./"; });

    /* Itinatago ang mga record at ipinapakita ang modal. */
    function endSession(reason) {
        loggedOut = true;
        document.querySelector(".sp-main").hidden = true;
        pwModal.classList.remove("active");
        outModal.classList.remove("active");
        document.getElementById("spIdleMsg").textContent = reason === "idle"
            ? "For your security, you were logged out after 5 minutes of inactivity."
            : "Your session has expired. Please log in again.";
        idleModal.classList.add("active");
        document.getElementById("spIdleLogin").focus();
    }
    function autoLogout() {
        if (loggedOut) return;
        fetch("logout", { credentials: "same-origin", redirect: "manual" }).catch(function () {});
        endSession("idle");
    }
    function ping() {
        lastPing = Date.now();
        fetch("api/session_ping.php", { credentials: "same-origin", headers: { "Accept": "application/json" } })
            .then(function (r) { if (r.status === 401 && !loggedOut) endSession("expired"); })
            .catch(function () {});
    }
    function markActive() {
        if (loggedOut) return;
        var now = Date.now();
        lastActive = now;
        if (now - lastPing >= PING_EVERY_MS) ping();
    }
    function checkIdle() {
        /* Timestamp ang basehan (hindi countdown) para tama pa rin kahit natulog ang device. */
        if (!loggedOut && Date.now() - lastActive >= IDLE_MS) autoLogout();
    }
    ["mousemove", "mousedown", "keydown", "touchstart", "wheel", "scroll", "click"].forEach(function (ev) {
        document.addEventListener(ev, markActive, { passive: true, capture: true });
    });
    setInterval(checkIdle, 5000);
    document.addEventListener("visibilitychange", function () { if (!document.hidden) checkIdle(); });

    load();
})();
</script>
</body>
</html>
