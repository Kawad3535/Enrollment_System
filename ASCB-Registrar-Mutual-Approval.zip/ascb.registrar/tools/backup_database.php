<?php
/**
 * CLI-only production database backup.
 * Usage: php tools/backup_database.php
 * Optional: ASCB_BACKUP_DIR=/path/to/backups
 *
 * Uses an unbuffered PDO connection and multi-row INSERT batches so PHP
 * memory stays bounded even when the database grows very large.
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit("Not found\n"); }
require_once __DIR__ . '/../config/db.php';
if (!$pdo) exit("Database unavailable.\n");

$dir = getenv('ASCB_BACKUP_DIR');
if (!$dir) $dir = __DIR__ . '/../storage/backups';
if (!is_dir($dir) && !mkdir($dir, 0750, true)) exit("Cannot create backup directory\n");
$filename = 'ascb_registrar_' . date('Ymd_His') . '.sql';
$path = rtrim($dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $filename;
$fh = fopen($path, 'wb');
if (!$fh) exit("Cannot write backup file\n");

$dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
$db = new PDO($dsn, DB_USER, DB_PASS, array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => false,
));
$db->exec("SET time_zone = '+08:00'");

fwrite($fh, "-- ASCB Registrar database backup\n-- Generated: " . date('c') . "\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n");
$tablesStmt = $db->query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'");
$tables = array();
while ($r = $tablesStmt->fetch(PDO::FETCH_NUM)) $tables[] = $r[0];
$tablesStmt->closeCursor();

foreach ($tables as $table) {
    $safe = str_replace('`','``',$table);
    $create = $db->query("SHOW CREATE TABLE `$safe`")->fetch(PDO::FETCH_NUM);
    fwrite($fh, "DROP TABLE IF EXISTS `$safe`;\n" . $create[1] . ";\n\n");
    $stmt = $db->query("SELECT * FROM `$safe`");
    $columns = null;
    $batch = array();
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if ($columns === null) $columns = array_map(function($c){ return '`'.str_replace('`','``',$c).'`'; }, array_keys($row));
        $vals = array();
        foreach ($row as $v) $vals[] = ($v === null ? 'NULL' : $db->quote((string)$v));
        $batch[] = '(' . implode(',', $vals) . ')';
        if (count($batch) >= 250) {
            fwrite($fh, 'INSERT INTO `'.$safe.'` ('.implode(',',$columns).') VALUES '.implode(',',$batch).";\n");
            $batch = array();
        }
    }
    if ($batch && $columns !== null) fwrite($fh, 'INSERT INTO `'.$safe.'` ('.implode(',',$columns).') VALUES '.implode(',',$batch).";\n");
    $stmt->closeCursor();
    fwrite($fh, "\n");
}
fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
fclose($fh);
@chmod($path, 0600);
echo "Backup created: $path\n";
