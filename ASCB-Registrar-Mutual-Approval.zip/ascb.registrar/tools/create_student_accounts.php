<?php
/* ASCB Registrar — ONE-TIME BACKFILL of STUDENT accounts for existing students.
 *
 * New enrollments get their account automatically. This tool creates the
 * account for students who were enrolled BEFORE this feature existed:
 * every distinct Student ID with an approved, non-archived enrollment that
 * has no linked account yet.
 *
 * Usage (project root):
 *   php database/migrate_master.php                 # once, adds the new columns
 *   php tools/create_student_accounts.php            # DRY RUN: only counts
 *   php tools/create_student_accounts.php --apply    # creates accounts + writes CSV
 *   php tools/create_student_accounts.php --apply --out=storage/student_credentials.csv
 *
 * The one-time temporary passwords exist ONLY in the CSV (the database keeps
 * hashes). Hand the slips out, then DELETE the CSV. Students must change the
 * password at first login. Safe to run again: students that already have an
 * account are skipped (no duplicates).
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("CLI only.\n");
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/student_account_helper.php';

if (!isset($pdo) || !$pdo) { fwrite(STDERR, "Database connection failed.\n"); exit(1); }
if (!ascb_sa_available($pdo)) {
    fwrite(STDERR, "Student account columns are missing. Run first: php database/migrate_master.php\n");
    exit(1);
}

$apply = in_array('--apply', $argv, true);
$out   = __DIR__ . '/../storage/student_credentials_' . date('Ymd_His') . '.csv';
foreach ($argv as $a) {
    if (strpos($a, '--out=') === 0) {
        $p = substr($a, 6);
        $out = (strpos($p, '/') === 0 || preg_match('/^[A-Za-z]:[\\\\\/]/', $p)) ? $p : getcwd() . '/' . $p;
    }
}

$ids = $pdo->query(
    "SELECT DISTINCT TRIM(e.student_id) AS sid
       FROM enrollees e
      WHERE e.status = 'approved' AND e.archived_at IS NULL
        AND e.student_id IS NOT NULL AND TRIM(e.student_id) <> ''
      ORDER BY sid"
)->fetchAll(PDO::FETCH_COLUMN);

$todo = array();
foreach ($ids as $sid) {
    if (!ascb_sa_find_by_student($pdo, $sid)) $todo[] = $sid;
}

fwrite(STDOUT, count($ids) . " student(s) with approved enrollments; " . count($todo) . " without an account.\n");
if (!$apply) {
    fwrite(STDOUT, "Dry run only. Re-run with --apply to create the accounts.\n");
    exit(0);
}
if (!$todo) { fwrite(STDOUT, "Nothing to do.\n"); exit(0); }
if (file_exists($out)) { fwrite(STDERR, "Refusing to overwrite $out\n"); exit(1); }

$fh = fopen($out, 'w');
if (!$fh) { fwrite(STDERR, "Cannot write $out\n"); exit(1); }
@chmod($out, 0600);
fwrite($fh, "\xEF\xBB\xBF");
fputcsv($fh, array('Student ID', 'Name', 'Username', 'Temporary Password'));

$created = 0; $failed = 0;
foreach ($todo as $sid) {
    $nm  = ascb_sa_name_for_student($pdo, $sid);
    $res = ascb_sa_ensure_account($pdo, $sid, (array) $nm, null);
    if ($res['status'] === 'created') {
        fputcsv($fh, array($sid, $nm ? ($nm['surname'] . ', ' . $nm['first_name']) : '', $res['username'], $res['tempPassword']));
        $created++;
    } elseif ($res['status'] !== 'exists') {
        $failed++;
        fwrite(STDERR, "  FAILED $sid: " . (isset($res['message']) ? $res['message'] : $res['status']) . "\n");
    }
}
fclose($fh);

fwrite(STDOUT, "Created $created account(s), $failed failed.\n");
fwrite(STDOUT, "Credentials: $out\n");
fwrite(STDOUT, "Print/hand out the slips, then DELETE this file — it contains the temporary passwords.\n");
exit($failed > 0 ? 2 : 0);
