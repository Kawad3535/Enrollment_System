<?php
/**
 * CLI-only: tumakbo kung due na ang naka-set na Automatic Backup schedule.
 * Para sa totoong cron (VPS / hosting na may cron):
 *     * * * * * php /path/to/tools/run_scheduled_backup.php
 * Gamitin ang --force para tumakbo kahit hindi pa due (hindi ginagalaw ang schedule).
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit("Not found\n"); }
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/backup_engine.php';
if (!$pdo) exit("Database unavailable.\n");
$force = in_array('--force', $argv, true);
$r = $force ? ascb_backup_run($pdo, null, 'manual') : ascb_backup_run_if_due($pdo);
echo json_encode($r) . "\n";
