<?php
/* =========================================================
   ASCB CERTIFICATE VERIFICATION  (PUBLIC PAGE — walang login)
   ---------------------------------------------------------
   Bubukas kapag na-scan ang QR code ng Certificate of
   Enrollment / Certificate of Registration, o kapag in-type
   ang verification code sa form sa ibaba.

   Ipinapakita LANG: certificate type, Student Name, Student ID,
   Course/Program, Enrollment Date, Term/AY, Status, Issued date.
   WALANG grades, address, o ibang personal na impormasyon.

   Hindi gumagamit ng session; read-only ang buong page.
   ========================================================= */

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/certificate_verify_helper.php';

header('Content-Type: text/html; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header('X-Robots-Tag: noindex, nofollow, noarchive');
header('Cache-Control: no-store, max-age=0');
header("Content-Security-Policy: default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");

function vh($v) { return htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

/* --- Basahin ang code (tinatanggap kahit may dash/space at lowercase) --- */
$raw = isset($_GET['c']) ? (string) $_GET['c'] : '';
$code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $raw));
$state = 'form';      // form | valid | invalid
$cert = null;
$programText = '';

if ($raw !== '') {
    if (!ascb_cert_verify_valid_token($code)) {
        $state = 'invalid';
    } else {
        try {
            ascb_cert_verify_ensure_schema($pdo);
            $st = $pdo->prepare(
                "SELECT certificate_type, student_name, student_id, program, year_level, trimester,
                        academic_year, enrollment_date, status, created_at
                 FROM certificates
                 WHERE verify_token = ? AND certificate_type IN ('ENROLLMENT','REGISTRATION')
                 LIMIT 1"
            );
            $st->execute(array($code));
            $cert = $st->fetch();
            $state = $cert ? 'valid' : 'invalid';
        } catch (Throwable $e) {
            error_log('ASCB verify.php lookup failed: ' . $e->getMessage());
            http_response_code(503);
            $state = 'error';
        }
    }

    if ($state === 'valid') {
        $programText = (string) $cert['program'];
        try {
            $ps = $pdo->prepare("SELECT course_name, major FROM programs WHERE UPPER(TRIM(code)) = UPPER(TRIM(?)) LIMIT 1");
            $ps->execute(array($cert['program']));
            $p = $ps->fetch();
            if ($p && trim((string) $p['course_name']) !== '') {
                $name = trim((string) $p['course_name']);
                if (trim((string) $p['major']) !== '') $name .= ' Major in ' . trim((string) $p['major']);
                $programText = $cert['program'] . ' — ' . $name;
            }
        } catch (Throwable $e) {
            // programs table wala/hindi mabasa: ipakita na lang ang program code
        }
    }
}

$enrollDate = ($state === 'valid') ? ascb_cert_verify_format_date($cert['enrollment_date']) : '';
$issuedOn = '';
if ($state === 'valid' && !empty($cert['created_at'])) {
    $ts = strtotime($cert['created_at']);
    $issuedOn = $ts ? date('F j, Y', $ts) : '';
}
$term = '';
if ($state === 'valid') {
    $parts = array();
    if (trim((string) $cert['year_level']) !== '') $parts[] = trim((string) $cert['year_level']);
    if (trim((string) $cert['trimester']) !== '') $parts[] = trim((string) $cert['trimester']);
    $term = implode(', ', $parts);
    if (trim((string) $cert['academic_year']) !== '') $term .= ($term !== '' ? ' — ' : '') . 'AY ' . trim((string) $cert['academic_year']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Certificate Verification — ASCB</title>
<style>
    *{box-sizing:border-box}
    html,body{margin:0;padding:0}
    body{font-family:"Segoe UI",Roboto,Arial,sans-serif;background:#eef3f9;color:#16202b;min-height:100vh;display:flex;justify-content:center;padding:18px 14px 40px}
    .wrap{width:100%;max-width:560px}
    .brand{display:flex;align-items:center;gap:12px;margin:6px 4px 16px}
    .brand img{width:54px;height:54px;object-fit:contain}
    .brand h1{font-size:15px;line-height:1.25;margin:0;color:#0b3a73;letter-spacing:.2px}
    .brand p{margin:2px 0 0;font-size:12px;color:#51606f}
    .card{background:#fff;border-radius:14px;box-shadow:0 6px 24px rgba(11,58,115,.12);overflow:hidden}
    .banner{padding:18px 20px;display:flex;gap:14px;align-items:center}
    .banner .ico{flex:0 0 46px;height:46px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:26px;font-weight:700;color:#fff}
    .banner h2{margin:0;font-size:19px}
    .banner p{margin:3px 0 0;font-size:13px}
    .ok{background:#e8f6ec}.ok .ico{background:#1f9d4d}.ok h2{color:#14783a}.ok p{color:#2f5d41}
    .bad{background:#fdeceb}.bad .ico{background:#c9302c}.bad h2{color:#a52420}.bad p{color:#6b3a38}
    .info{background:#eaf1fb}.info .ico{background:#0b3a73}.info h2{color:#0b3a73}.info p{color:#3d5775}
    dl{margin:0;padding:6px 20px 10px}
    .row{display:grid;grid-template-columns:130px 1fr;gap:10px;padding:11px 0;border-bottom:1px solid #e6ecf3;font-size:14px}
    .row:last-child{border-bottom:0}
    dt{color:#5b6b7b;font-weight:600;text-transform:uppercase;font-size:11px;letter-spacing:.4px;padding-top:2px}
    dd{margin:0;font-weight:600;word-break:break-word}
    .big{font-size:17px;color:#0b3a73}
    .note{padding:14px 20px 18px;font-size:12.5px;color:#51606f;background:#f7f9fc;border-top:1px solid #e6ecf3;line-height:1.5}
    form{padding:16px 20px 20px}
    label{display:block;font-size:12px;font-weight:700;color:#51606f;text-transform:uppercase;letter-spacing:.4px;margin-bottom:6px}
    input[type=text]{width:100%;padding:12px;font-size:16px;border:1px solid #b9c7d8;border-radius:8px;font-family:Consolas,monospace;letter-spacing:1px;text-transform:uppercase}
    button{margin-top:12px;width:100%;padding:12px;font-size:15px;font-weight:700;color:#fff;background:#0b3a73;border:0;border-radius:8px;cursor:pointer}
    .again{display:block;text-align:center;padding:12px;font-size:13px;color:#0b3a73}
    .foot{text-align:center;font-size:11.5px;color:#7a8896;margin-top:16px}
    @media(max-width:420px){.row{grid-template-columns:1fr;gap:3px}}
</style>
</head>
<body>
<div class="wrap">

    <div class="brand">
        <img src="ASCB_LOGO.png" alt="ASCB logo">
        <div>
            <h1>Andres Soriano Colleges of Bislig, Inc.</h1>
            <p>Office of the Registrar &middot; Certificate Verification</p>
        </div>
    </div>

    <div class="card">

    <?php if ($state === 'valid'): ?>

        <div class="banner ok">
            <div class="ico">&#10003;</div>
            <div>
                <h2>Valid Certificate</h2>
                <p>This certificate was issued by the ASCB Office of the Registrar.</p>
            </div>
        </div>
        <dl>
            <div class="row"><dt>Certificate</dt><dd><?php echo vh(ascb_cert_verify_type_label($cert['certificate_type'])); ?></dd></div>
            <div class="row"><dt>Student Name</dt><dd class="big"><?php echo vh($cert['student_name']); ?></dd></div>
            <div class="row"><dt>Student ID</dt><dd><?php echo vh($cert['student_id']); ?></dd></div>
            <div class="row"><dt>Course / Program</dt><dd><?php echo vh($programText); ?></dd></div>
            <div class="row"><dt>Enrollment Date</dt><dd><?php echo vh($enrollDate); ?></dd></div>
            <?php if ($term !== ''): ?>
            <div class="row"><dt>Term</dt><dd><?php echo vh($term); ?></dd></div>
            <?php endif; ?>
            <?php if (trim((string) $cert['status']) !== ''): ?>
            <div class="row"><dt>Status</dt><dd><?php echo vh($cert['status']); ?></dd></div>
            <?php endif; ?>
            <?php if ($issuedOn !== ''): ?>
            <div class="row"><dt>Date Issued</dt><dd><?php echo vh($issuedOn); ?></dd></div>
            <?php endif; ?>
            <div class="row"><dt>Verification Code</dt><dd style="font-family:Consolas,monospace"><?php echo vh(ascb_cert_verify_display_code($code)); ?></dd></div>
        </dl>
        <div class="note">
            Compare the details above with the printed certificate. If the name, Student ID, program or date
            on the paper is different, do not accept the paper. For concerns, contact the ASCB Office of the Registrar.
        </div>
        <a class="again" href="verify">Verify another certificate</a>

    <?php elseif ($state === 'invalid'): ?>

        <div class="banner bad">
            <div class="ico">&#10007;</div>
            <div>
                <h2>Certificate Not Found</h2>
                <p>This code does not match any certificate issued by the ASCB Registrar.</p>
            </div>
        </div>
        <div class="note">
            The paper may be fake, altered, or the code was typed or scanned incorrectly. Please scan the QR again or
            enter the code printed on the certificate. If it still fails, contact the ASCB Office of the Registrar.
        </div>
        <a class="again" href="verify">Try again</a>

    <?php elseif ($state === 'error'): ?>

        <div class="banner bad">
            <div class="ico">!</div>
            <div>
                <h2>Verification Unavailable</h2>
                <p>The system could not be reached right now. Please try again in a few minutes.</p>
            </div>
        </div>
        <a class="again" href="verify">Try again</a>

    <?php else: ?>

        <div class="banner info">
            <div class="ico">?</div>
            <div>
                <h2>Verify a Certificate</h2>
                <p>Scan the QR code on the certificate, or enter the verification code printed on it.</p>
            </div>
        </div>
        <form method="get" action="verify" autocomplete="off">
            <label for="c">Verification Code</label>
            <input type="text" id="c" name="c" maxlength="40" placeholder="XXXXX-XXXXX-XXXXX-XXXXX" required>
            <button type="submit">Verify</button>
        </form>

    <?php endif; ?>

    </div>

    <div class="foot">This page only shows basic certificate details. Grades are never shown.</div>
</div>
</body>
</html>
