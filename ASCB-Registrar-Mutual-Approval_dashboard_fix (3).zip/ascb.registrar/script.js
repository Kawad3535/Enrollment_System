/* =========================================================
   FULL-NAME + STUDENT ID SEARCH (client-side)
   Hinahati ang tinype sa mga salita; LAHAT ng salita ay
   kailangang tumama sa alinman sa $fields. Kaya gumagana ang
   "Juan Dela Cruz", "Dela Cruz, Juan", o Student ID.
   Kapareho ng includes/student_search.php sa server.
   ========================================================= */
function ascbNameMatch(term, fields) {
    const toks = String(term || '').toLowerCase().replace(/[,;.\u00a0]/g, ' ').split(/\s+/).filter(Boolean);
    if (!toks.length) return true;
    const hay = (fields || []).map(v => String(v || '').toLowerCase()).filter(Boolean);
    return toks.every(t => hay.some(h => h.includes(t)));
}

/* =========================================================
   AUTO-DISMISS MESSAGE MODAL
   Ito ang gagamitin sa DALAWANG paraan para makakuha ng modal
   message ANG LAHAT ng function button (kahit yung mga wala
   talagang alert() calls dati):
     1) Ino-override ang native window.alert() — kaya lahat ng
        existing alert("...") sa script.js ay lalabas na bilang
        modal (auto-mawawala after 2s) sa halip na yung native
        browser alert box.
     2) Ang bawat same-origin POST/PUT/DELETE fetch() (lahat ng
        Save/Add/Update/Delete/Approve/Reject/Archive/Restore
        buttons) ay awtomatikong magpapakita ng modal batay sa
        JSON response ({ok:true/false, error:"..."}) — kahit
        walang inilagay na explicit alert() sa function mismo.
   ========================================================= */
(function () {
    if (typeof window === "undefined") return;

    const AUTO_DISMISS_MS = 900;
    const FADE_MS = 180;

    let overlayEl = null;
    let messageEl = null;
    let hideTimer = null;
    let fadeTimer = null;

    const ICONS = { success: "\u2713", error: "\u2715", info: "\u2139" };

    function buildModal() {
        if (overlayEl) return;

        overlayEl = document.createElement("div");
        overlayEl.className = "ascb-toast-overlay";
        overlayEl.id = "ascbToastOverlay";

        const card = document.createElement("div");
        card.className = "ascb-toast-card";

        const icon = document.createElement("div");
        icon.className = "ascb-toast-icon";
        icon.id = "ascbToastIcon";

        messageEl = document.createElement("p");
        messageEl.id = "ascbToastMessage";

        card.appendChild(icon);
        card.appendChild(messageEl);
        overlayEl.appendChild(card);

        overlayEl.addEventListener("click", function () {
            closeToast();
        });
        card.addEventListener("click", function (e) {
            e.stopPropagation();
        });

        document.body.appendChild(overlayEl);
    }

    function closeToast() {
        if (!overlayEl || !overlayEl.classList.contains("active")) return;
        clearTimeout(hideTimer);
        clearTimeout(fadeTimer);
        overlayEl.classList.add("closing");
        fadeTimer = setTimeout(function () {
            overlayEl.classList.remove("active", "closing");
        }, FADE_MS);
    }

    function showToast(message, type) {
        if (typeof document === "undefined") return;
        if (!document.body) {
            document.addEventListener("DOMContentLoaded", function () {
                showToast(message, type);
            });
            return;
        }
        buildModal();

        clearTimeout(hideTimer);
        clearTimeout(fadeTimer);
        overlayEl.classList.remove("closing");
        overlayEl.setAttribute("data-type", type && ICONS[type] ? type : "info");
        const iconEl = document.getElementById("ascbToastIcon");
        if (iconEl) iconEl.textContent = ICONS[type] || ICONS.info;
        messageEl.textContent = message === undefined || message === null || message === "" ? "Done." : String(message);
        overlayEl.classList.add("active");

        // Palagi itong nasa ibabaw ng ibang modal (.modal, .f137-mini-modal,
        // atbp.) kahit anong oras ito lumabas.
        overlayEl.style.zIndex = 2147483000;

        hideTimer = setTimeout(closeToast, AUTO_DISMISS_MS);
    }

    // Global na function — pwedeng tawagin kahit saan sa script.js kung
    // gusto ng custom message (hal. matapos ng successful save).
    window.ascbNotify = showToast;

    // (1) I-override ang native window.alert() para sa buong system.
    window.alert = function (message) {
        showToast(message, "info");
    };

    // (2) Auto-detect ng JSON API result sa bawat mutating fetch() —
    // tingnan sa fetch-override IIFE sa ibaba (ginagamit ang
    // window.ascbNotify na dinefine dito).
})();


/* =========================================================
   CONFIRM / PROMPT MODAL (replaces native confirm() / prompt())
   window.ascbConfirm(message, opts) -> Promise<boolean>
   window.ascbPrompt(message, defaultValue, opts)  -> Promise<string|null>
   Ginagamit ito sa halip na ang native browser confirm()/prompt()
   dialogs para tumugma sa disenyo ng system. Dahil Promise-based
   ito, ang bawat function na gumagamit nito ay dapat "async" at
   gamitin ang "await" (hal. `if(!await ascbConfirm("..."))return;`).
   ========================================================= */
(function () {
    if (typeof window === "undefined") return;

    let overlayEl = null, cardEl = null, iconEl = null, titleEl = null,
        msgEl = null, inputWrapEl = null, inputEl = null, cancelBtn = null, okBtn = null;
    let activeResolve = null;
    let lastFocused = null;

    function buildModal() {
        if (overlayEl) return;

        overlayEl = document.createElement("div");
        overlayEl.className = "ascb-confirm-overlay";
        overlayEl.id = "ascbConfirmOverlay";

        cardEl = document.createElement("div");
        cardEl.className = "ascb-confirm-card";

        iconEl = document.createElement("div");
        iconEl.className = "ascb-confirm-icon";

        titleEl = document.createElement("h3");
        titleEl.className = "ascb-confirm-title";

        msgEl = document.createElement("p");
        msgEl.className = "ascb-confirm-message";

        inputWrapEl = document.createElement("div");
        inputWrapEl.className = "ascb-confirm-input-wrap";
        inputEl = document.createElement("input");
        inputEl.type = "text";
        inputEl.className = "ascb-confirm-input";
        inputWrapEl.appendChild(inputEl);

        const actions = document.createElement("div");
        actions.className = "ascb-confirm-actions";

        cancelBtn = document.createElement("button");
        cancelBtn.type = "button";
        cancelBtn.className = "btn btn-secondary";
        cancelBtn.textContent = "Cancel";

        okBtn = document.createElement("button");
        okBtn.type = "button";
        okBtn.className = "btn btn-primary";
        okBtn.textContent = "OK";

        actions.appendChild(cancelBtn);
        actions.appendChild(okBtn);

        cardEl.appendChild(iconEl);
        cardEl.appendChild(titleEl);
        cardEl.appendChild(msgEl);
        cardEl.appendChild(inputWrapEl);
        cardEl.appendChild(actions);
        overlayEl.appendChild(cardEl);

        overlayEl.addEventListener("click", function (e) {
            if (e.target === overlayEl) settle(null);
        });
        cancelBtn.addEventListener("click", function () { settle(null); });
        okBtn.addEventListener("click", function () {
            settle(inputWrapEl.style.display === "none" ? true : inputEl.value);
        });
        inputEl.addEventListener("keydown", function (e) {
            if (e.key === "Enter") { e.preventDefault(); okBtn.click(); }
        });
        document.addEventListener("keydown", function (e) {
            if (!overlayEl || !overlayEl.classList.contains("active")) return;
            if (e.key === "Escape") { e.preventDefault(); settle(null); }
        });

        document.body.appendChild(overlayEl);
    }

    function settle(value) {
        if (!overlayEl || !overlayEl.classList.contains("active")) return;
        overlayEl.classList.remove("active");
        const resolve = activeResolve;
        activeResolve = null;
        if (lastFocused && typeof lastFocused.focus === "function") lastFocused.focus();
        if (resolve) resolve(value);
    }

    function open(opts) {
        if (typeof document === "undefined") return Promise.resolve(null);
        buildModal();

        const isPrompt = opts.type === "prompt";
        lastFocused = document.activeElement;

        iconEl.textContent = opts.danger ? "!" : (isPrompt ? "\u270E" : "?");
        iconEl.classList.toggle("is-danger", !!opts.danger);
        titleEl.textContent = opts.title || (isPrompt ? "Input needed" : "Please confirm");
        msgEl.textContent = opts.message || "";

        inputWrapEl.style.display = isPrompt ? "block" : "none";
        inputEl.value = opts.defaultValue || "";

        cancelBtn.style.display = opts.hideCancel ? "none" : "inline-flex";
        cancelBtn.textContent = opts.cancelLabel || "Cancel";
        okBtn.textContent = opts.okLabel || (isPrompt ? "Save" : "OK");
        okBtn.classList.toggle("btn-danger", !!opts.danger);
        okBtn.classList.toggle("btn-primary", !opts.danger);

        overlayEl.classList.add("active");
        setTimeout(function () { (isPrompt ? inputEl : okBtn).focus(); }, 10);

        return new Promise(function (resolve) { activeResolve = resolve; });
    }

    // Promise<boolean> — true kung OK, false kung Cancel/Esc/outside click.
    window.ascbConfirm = function (message, opts) {
        opts = opts || {};
        return open(Object.assign({}, opts, { type: "confirm", message })).then(function (v) {
            return v === true;
        });
    };

    // Promise<string|null> — string ang value kung OK (pwedeng blangko),
    // null kung Cancel/Esc/outside click (tugma sa native prompt()).
    window.ascbPrompt = function (message, defaultValue, opts) {
        opts = opts || {};
        return open(Object.assign({}, opts, { type: "prompt", message, defaultValue })).then(function (v) {
            return (v === null || v === undefined) ? null : String(v);
        });
    };
})();


/* =========================================================
   DEPLOYMENT SAFETY: all same-origin write requests carry the
   server-generated CSRF token automatically. Existing fetch()
   calls do not need to be rewritten one by one.

   Dinagdagan din ito ng auto-toast: pagkatapos ng bawat
   same-origin na mutating request (POST/PUT/DELETE/PATCH),
   titingnan ang JSON response ({ok:true/false, error:"..."})
   at awtomatikong magpapakita ng modal message — kahit walang
   alert() na tinawag ang function mismo.
   ========================================================= */
(function () {
    if (typeof window === "undefined" || typeof window.fetch !== "function") return;
    const nativeFetch = window.fetch.bind(window);

    const ACTION_MESSAGES = {
        create: "Successfully added.",
        add: "Successfully added.",
        add_subject: "Subject added.",
        update: "Successfully updated.",
        edit: "Successfully updated.",
        update_subject: "Subject updated.",
        delete: "Successfully deleted.",
        delete_subject: "Subject deleted.",
        remove: "Successfully deleted.",
        toggle_active: "Account status updated.",
        activate: "Activated.",
        deactivate: "Deactivated.",
        block: "Blocked.",
        change_password: "Password changed.",
        approve: "Approved.",
        reject: "Rejected.",
        archive: "Moved to Archive.",
        restore: "Restored.",
        upload: "Successfully uploaded.",
        save: "Successfully saved.",
        assign_department_bulk: "Assigned to Department.",
        marriage: "Record updated after marriage.",
        photo: "Photo updated.",
        remove_photo: "Photo removed.",
        sync: "Sync complete."
    };

    // Mga read-only/"loading" na actions — tumatakbo ito palagi tuwing
    // nagbubukas o nagre-refresh ng listahan (hindi resulta ng isang
    // "Save/Add/Delete" button), kaya HINDI ito dapat magpakita ng
    // toast (baka mag-spam ito sa user tuwing mag-navigate lang).
    const NOTIFY_SKIP_ACTIONS = new Set(["list", "list_subjects", "structured", "tick", "run_now", "regen_token"]);

    function actionFromBody(body) {
        try {
            if (!body) return "";
            if (typeof FormData !== "undefined" && body instanceof FormData) {
                return String(body.get("action") || "");
            }
            if (typeof body === "string") {
                const parsed = JSON.parse(body);
                return String((parsed && parsed.action) || "");
            }
        } catch (e) {
            // hindi JSON / hindi FormData — walang action na makukuha.
        }
        return "";
    }

    function notifyFromResult(data, body) {
        if (!data || typeof data !== "object" || !("ok" in data)) return;

        const action = actionFromBody(body).toLowerCase();
        if (NOTIFY_SKIP_ACTIONS.has(action)) return;

        if (data.ok) {
            const msg = ACTION_MESSAGES[action] || "Action completed successfully.";
            if (typeof window.ascbNotify === "function") window.ascbNotify(msg, "success");
        } else {
            const msg = data.error || "Something went wrong. Please try again.";
            if (typeof window.ascbNotify === "function") window.ascbNotify(msg, "error");
        }
    }

    window.fetch = async function (resource, options) {
        const opts = options ? Object.assign({}, options) : {};
        let method = (opts.method || "GET").toUpperCase();
        let requestUrl = "";

        try {
            if (typeof resource === "string") {
                requestUrl = new URL(resource, window.location.href).href;
            } else if (resource && resource.url) {
                requestUrl = new URL(resource.url, window.location.href).href;
                if (!opts.method && resource.method) method = String(resource.method).toUpperCase();
            }
        } catch (e) {
            requestUrl = "";
        }

        const sameOrigin = requestUrl && new URL(requestUrl).origin === window.location.origin;
        const mutating = !["GET", "HEAD", "OPTIONS"].includes(method);

        if (sameOrigin && mutating && typeof ASCB_CSRF_TOKEN !== "undefined" && ASCB_CSRF_TOKEN) {
            const headers = new Headers(opts.headers || (resource && resource.headers ? resource.headers : undefined));
            headers.set("X-CSRF-Token", ASCB_CSRF_TOKEN);
            opts.headers = headers;
            opts.credentials = "same-origin";
        }

        const response = await nativeFetch(resource, opts);

        if (sameOrigin && mutating) {
            try {
                const data = await response.clone().json();
                notifyFromResult(data, opts.body);
            } catch (e) {
                // Hindi JSON ang response (hal. file download) — walang toast.
            }
        }

        return response;
    };
})();


/* Program catalog and prospectus are injected from the database by dashboard.php.
   No program list or curriculum is maintained in this JavaScript file. */
const structuredPrograms = (typeof ASCB_CUSTOM_PROGRAMS !== "undefined" && ASCB_CUSTOM_PROGRAMS) || {};
const programNames = (typeof ASCB_CUSTOM_PROGRAM_NAMES !== "undefined" && ASCB_CUSTOM_PROGRAM_NAMES) || {};
const programTermTypes = (typeof ASCB_CUSTOM_PROGRAM_TERM_TYPES !== "undefined" && ASCB_CUSTOM_PROGRAM_TERM_TYPES) || {};

function ascbGetProgramTermType(programCode) {
    return (programCode && programTermTypes[programCode]) || "Trimester";
}

function ascbTermOptionsFor(termType) {
    return termType === "Semester"
        ? ["1st Semester", "2nd Semester", "Summer"]
        : ["1st Trimester", "2nd Trimester", "3rd Trimester"];
}

/* Ire-refresh ang mga <option> ng isang Trimester/Semester
   <select> base sa term system ng currently selected program,
   pati na ang kaukulang <label> text nito ("Trimester" o
   "Semester"). Tinatawag ito ni ascbEnrollProgramChanged(). */
function ascbEnrollUpdateTermSelect(trimesterSelectId, programCode) {

    const select = document.getElementById(trimesterSelectId);
    if (!select) return;

    const termType = ascbGetProgramTermType(programCode);
    const options = ascbTermOptionsFor(termType);
    const oldValue = select.value;

    select.innerHTML = `<option value="">Select ${termType}</option>` +
        options.map(o => `<option>${o}</option>`).join("");

    if (options.includes(oldValue)) {
        select.value = oldValue;
    }

    const label = document.querySelector(`label[for="${trimesterSelectId}"]`);
    if (label) label.textContent = termType;
}

/* Kinukuha ang pinaka-bagong Programs & Subjects mula sa server
   (Admin -> Programs & Subjects) at ini-merge sa structuredPrograms/
   programNames/programTermTypes, tapos ire-refresh ang mga
   Course/Program <select> sa Enrollment (Enroll / Edit / New Term)
   para agad lumabas ang bagong idinagdag, kahit hindi pa
   nirre-reload ang buong page. */
async function ascbRefreshCustomPrograms() {
    const data = await ascbApiPost("api/programs.php", { action: "structured" });
    if (!data || !data.ok) return;

    // Replace the catalog so deleted/deactivated programs cannot linger in the form.
    [structuredPrograms, programNames, programTermTypes].forEach(map => {
        Object.keys(map).forEach(code => delete map[code]);
    });
    Object.assign(structuredPrograms, data.structured || {});
    Object.assign(programNames, data.names || {});
    Object.assign(programTermTypes, data.termTypes || {});

    const namesMap = data.names || {};
    ["program", "enroll_program", "enroll_edit_program", "enroll_newterm_program"].forEach(selectId => {
        const select = document.getElementById(selectId);
        if (!select) return;

        const currentValue = select.value;

        // IMPORTANT: The Enrollment selects are already populated from the
        // database when dashboard.php loads. Do NOT append another copy of
        // the same programs after Add/Edit Program. Rebuild the program
        // options from the latest database catalog instead. This prevents
        // every Course/Program from appearing twice after Add Program.
        const placeholder = [...select.options].find(opt => !String(opt.value || '').trim());
        select.innerHTML = '';
        if (placeholder) {
            select.appendChild(placeholder.cloneNode(true));
        }

        Object.keys(namesMap).sort((a, b) => String(namesMap[a]).localeCompare(String(namesMap[b]))).forEach(code => {
            const option = document.createElement("option");
            option.value = code;
            option.textContent = namesMap[code];
            option.dataset.custom = "1";
            select.appendChild(option);
        });

        if ([...select.options].some(o => o.value === currentValue)) {
            select.value = currentValue;
        } else if (selectId === "program" && currentValue && ascbCertificateEditingId) {
            select.add(new Option(currentValue, currentValue));
            select.value = currentValue;
        }
    });
    ascbCertificateUpdateTermSelect();
    loadSubjects();
}


/* =========================================================
   INITIALIZE
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        ascbCertificateUpdateTermSelect();
        loadSubjects();

        addSubjectRow();

        setToday();

        setDefaultAcademicYear();

    }
);

/* =========================================================
   DEFAULT ACADEMIC YEAR
   Kinukwenta base sa kasalukuyang petsa sa halip na naka-hardcode
   na text, para hindi na kailangang i-update ito taon-taon.
   Karaniwang nagsisimula ang school year sa Pilipinas sa
   Agosto/Setyembre, kaya:
     - Jan–Jul  -> (lastYear)–(thisYear)
     - Aug–Dec  -> (thisYear)–(nextYear)
========================================================= */

function getDefaultAcademicYear() {
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth() + 1; // 1-12

    const startYear = month >= 8 ? year : year - 1;
    return `${startYear}\u2013${startYear + 1}`;
}

function setDefaultAcademicYear() {
    const input = document.getElementById("academicYear");
    if (input && !input.value.trim()) {
        input.value = getDefaultAcademicYear();
    }
}


/* =========================================================
   SET TODAY
========================================================= */

function setToday() {

    const dateInput =
        document.getElementById("enrollmentDate");

    if (!dateInput.value) {

        const today = new Date();

        const year = today.getFullYear();

        const month =
            String(today.getMonth() + 1).padStart(2, "0");

        const day =
            String(today.getDate()).padStart(2, "0");

        dateInput.value = `${year}-${month}-${day}`;
    }
}


/* =========================================================
   LOAD SUBJECT DROPDOWNS
   Every program is now a structured program (Year/Trimester
   optgroups), sourced directly from each program's official
   ASCB curriculum prospectus.
========================================================= */

/* =========================================================
   LOAD SUBJECT DROPDOWNS
   Fine-filtered by Program + Year Level + Trimester.
========================================================= */

function ascbCertificateUpdateTermSelect(preserveTerm = null) {
    const program = document.getElementById("program").value;
    const select = document.getElementById("trimester");
    if (!select) return;
    const termType = ascbGetProgramTermType(program);
    const previous = preserveTerm === null ? select.value : preserveTerm;
    const terms = ascbTermOptionsFor(termType);
    // Keep any term used in the actual prospectus, including Summer.
    (structuredPrograms[program] || []).forEach(group => {
        if (group.trimester && !terms.includes(group.trimester)) terms.push(group.trimester);
    });
    select.replaceChildren(new Option(`Select ${termType}`, ""),
        ...terms.map(term => new Option(term, term)));
    if (previous && !terms.includes(previous) &&
        (!programNames[program] || ascbCertificateEditingId !== null)) {
        select.add(new Option(previous, previous));
    }
    select.value = [...select.options].some(option => option.value === previous) ? previous : "";
    const label = document.querySelector('label[for="trimester"]');
    if (label) label.textContent = termType;
}

function ascbCertificateSelectionChanged(programChanged = false, termChanged = false) {
    if (programChanged) ascbCertificateUpdateTermSelect("");
    // Choosing a different year requires an explicit new term selection.
    else if (!termChanged) document.getElementById("trimester").value = "";
    const tbody = document.getElementById("subjectRows");
    // Never carry subjects over from another program, year, or term.
    tbody.replaceChildren();
    const program = document.getElementById("program").value;
    const year = document.getElementById("yearLevel").value;
    const term = document.getElementById("trimester").value;
    const group = termChanged && term && (structuredPrograms[program] || []).find(
        item => item.year === year && item.trimester === term
    );
    if (group && group.subjects.length) {
        group.subjects.forEach(subject => addSubjectRow(subject));
    } else {
        addSubjectRow();
    }
    loadSubjects();
}

function loadSubjects() {
    const selects = document.querySelectorAll(".subject-select");
    const program = document.getElementById("program").value;
    const year = document.getElementById("yearLevel").value;
    const term = document.getElementById("trimester").value;

    /* FIX v2: Ang dropdown ng "Add Subject" ay nagpapakita lang ng
       subjects ng NAPILING COURSE/PROGRAM — lahat ng year levels at
       terms nito (grouped per Year — Term para madaling hanapin).
       Nasa itaas ang subjects ng napiling Year Level + Term kung may
       napili na; wala nang subjects mula sa ibang programs. */

    const matchesSelection = group =>
        (!year || group.year === year) && (!term || group.trimester === term);

    const sections = [];
    const currentGroups = structuredPrograms[program] || [];
    const matched = currentGroups.filter(matchesSelection);
    const otherTerms = currentGroups.filter(group => !matchesSelection(group));

    if (matched.length) sections.push({ prefix: "", groups: matched });
    if (otherTerms.length) {
        sections.push({
            prefix: (programNames[program] || program || "Program") + " — ",
            groups: otherTerms
        });
    }

    selects.forEach(select => {
        const oldValue = select.value;
        select.replaceChildren(new Option("Select Subject", ""),
            new Option("+ Add Custom Subject", "__CUSTOM__"));

        const seen = new Set();

        sections.forEach(section => {
            section.groups.forEach(group => {
                const subjects = Array.isArray(group.subjects) ? group.subjects : [];
                if (!subjects.length) return;
                const optgroup = document.createElement("optgroup");
                optgroup.label = `${section.prefix}${group.year} — ${group.trimester}`;
                subjects.forEach(subject => {
                    const value = JSON.stringify(subject);
                    if (seen.has(value)) return;
                    seen.add(value);
                    optgroup.appendChild(new Option(
                        `${subject.code} — ${subject.description} (${subject.units} units)`,
                        value
                    ));
                });
                if (optgroup.children.length) select.appendChild(optgroup);
            });
        });

        if (oldValue && [...select.options].some(option => option.value === oldValue)) {
            select.value = oldValue;
        } else if (oldValue && oldValue !== "__CUSTOM__") {
            /* Huwag mawala ang naka-record nang subject (hal. galing sa
               Records/History o sa custom entry) kahit wala na ito sa
               kasalukuyang prospectus. */
            try {
                const subject = JSON.parse(oldValue);
                if (subject && subject.code) {
                    const keep = new Option(
                        `${subject.code} — ${subject.description} (${subject.units} units)`,
                        oldValue
                    );
                    select.appendChild(keep);
                    select.value = oldValue;
                }
            } catch (error) { /* hindi JSON — laktawan */ }
        }
    });
}


/* =========================================================
   ADD SUBJECTS FOR TERM
   Uses the Year Level + Trimester already selected in
   STUDENT INFORMATION (no separate/duplicate selectors) and
   appends that term's prospectus subjects to the table,
   without clearing what's already there. Skips subjects
   already added (matched by course code) to avoid duplicates,
   and clears out the single unused starter row if present.
========================================================= */

function addSubjectsForTerm() {

    const program =
        document.getElementById("program").value;

    const year =
        document.getElementById("yearLevel").value;

    const trimester =
        document.getElementById("trimester").value;

    if (!program) {
        alert("Please select a Course / Program first.");
        return;
    }

    if (!year || !trimester) {
        alert("Please select the Year Level and Term in Student Information before loading subjects.");
        return;
    }

    if (!structuredPrograms[program]) {
        alert("This program has no structured prospectus.");
        return;
    }

    const group =
        structuredPrograms[program].find(
            g => g.year === year && g.trimester === trimester
        );

    if (!group) {
        alert("No subjects are listed for this Year Level and Term.");
        return;
    }

    /* Collect codes already present sa table, para
       hindi na madoble kapag pinindot ulit. */

    const existingCodes = new Set();

    document.querySelectorAll(".subject-row").forEach(
        row => {

            const code =
                row.dataset.customCode || getRowSubjectCode(row);

            if (code) {
                existingCodes.add(code);
            }
        }
    );

    /* If the table only has the untouched starter row (blank,
       nothing selected, nothing typed), drop it first so the
       loaded term doesn't leave a stray empty row behind. */

    removeUnusedStarterRow();

    let addedCount = 0;

    group.subjects.forEach(
        subject => {

            if (existingCodes.has(subject.code)) {
                return;
            }

            addSubjectRow(subject);

            addedCount++;
        }
    );

    calculateTotalUnits();

    if (addedCount === 0) {

        alert("All subjects for this term have already been added.");
    }
}


/* =========================================================
   REMOVE UNUSED STARTER ROW
   Helper — if the subject table has exactly one row and it's
   completely empty (no subject picked, no custom code, no
   description typed), remove it. Keeps the table tidy when
   loading a term into a freshly-opened form.
========================================================= */

function removeUnusedStarterRow() {

    const rows =
        document.querySelectorAll(".subject-row");

    if (rows.length !== 1) {
        return;
    }

    const row = rows[0];

    const select = row.querySelector(".subject-select");
    const description = row.querySelector(".subject-description");

    const isEmpty =
        !row.dataset.customCode &&
        (!select || !select.value) &&
        (!description || !description.value.trim());

    if (isEmpty) {
        row.remove();
    }
}


/* =========================================================
   GET ROW SUBJECT CODE
   Helper — reads the course code currently selected in a
   subject row's dropdown (used for duplicate checking).
========================================================= */

function getRowSubjectCode(row) {

    const select = row.querySelector(".subject-select");

    if (!select || !select.value || select.value === "__CUSTOM__") {
        return null;
    }

    try {

        return JSON.parse(select.value).code;

    } catch (error) {

        return null;
    }
}


/* =========================================================
   ADD SUBJECT ROW
========================================================= */

function addSubjectRow(subjectData = null) {

    const tbody =
        document.getElementById("subjectRows");

    const row = document.createElement("tr");

    row.className = "subject-row";

    row.innerHTML =
        `
        <td>
            <select class="subject-select" onchange="selectSubject(this)">
                <option value="">Select Subject</option>
            </select>
        </td>

        <td>
            <input type="text" class="subject-description" placeholder="Course Description">
        </td>

        <td>
            <input type="text" class="subject-grade" placeholder="e.g. 1.5" oninput="calculateGWA()">
        </td>

        <td>
            <input type="number" class="subject-units" min="0" step="1" value="0" oninput="calculateTotalUnits()">
        </td>

        <td style="text-align:center">
            <button type="button" class="btn btn-danger action-icon-btn" title="Remove" aria-label="Remove" onclick="removeSubjectRow(this)">${ascbIcon('reject')}</button>
        </td>
        `;

    tbody.appendChild(row);

    loadSubjects();

    if (subjectData) {

        const select = row.querySelector(".subject-select");
        const description = row.querySelector(".subject-description");
        const units = row.querySelector(".subject-units");

        select.value = JSON.stringify(subjectData);
        description.value = subjectData.description;
        units.value = subjectData.units;
    }

    calculateTotalUnits();
}


/* =========================================================
   SELECT SUBJECT
========================================================= */

async function selectSubject(select) {

    const row = select.closest(".subject-row");

    if (select.value === "__CUSTOM__") {

        const code = await ascbPrompt("Enter Course Code:");

        if (!code) {
            select.value = "";
            return;
        }

        const description = await ascbPrompt("Enter Course Description:");

        if (!description) {
            select.value = "";
            return;
        }

        const units = await ascbPrompt("Enter Units:", "3");

        row.querySelector(".subject-description").value = description;
        row.querySelector(".subject-units").value = units || 0;

        /* Store custom code on row itself. */
        row.dataset.customCode = code;

        calculateTotalUnits();

        return;
    }

    if (!select.value) {

        row.querySelector(".subject-description").value = "";
        row.querySelector(".subject-units").value = 0;

        delete row.dataset.customCode;

        calculateTotalUnits();

        return;
    }

    try {

        const subject = JSON.parse(select.value);

        /* Duplicate check: hindi dapat paulit-ulit na mapili ang
           parehong subject code sa loob ng iisang term — dati,
           tahimik itong nagme-merge sa server nang walang anumang
           babala, kaya posibleng mabura nang hindi sinasadya ang
           units/grade ng unang row. */
        if (subject.code) {
            const tbody = document.getElementById("subjectRows");
            const isDuplicate = tbody && [...tbody.querySelectorAll(".subject-row")].some(otherRow => {
                if (otherRow === row) return false;
                return (otherRow.dataset.customCode || getRowSubjectCode(otherRow)) === subject.code;
            });
            if (isDuplicate) {
                alert(`"${subject.code} — ${subject.description}" has already been added to this term. Please choose a different subject.`);
                select.value = "";
                row.querySelector(".subject-description").value = "";
                row.querySelector(".subject-units").value = 0;
                calculateTotalUnits();
                return;
            }
        }

        row.querySelector(".subject-description").value = subject.description;
        row.querySelector(".subject-units").value = subject.units;

        delete row.dataset.customCode;

        calculateTotalUnits();

    } catch (error) {

        console.error(error);
    }
}


/* =========================================================
   REMOVE SUBJECT
========================================================= */

function removeSubjectRow(button) {

    const rows =
        document.querySelectorAll(".subject-row");

    if (rows.length <= 1) {

        alert("At least one subject row is required.");

        return;
    }

    button.closest(".subject-row").remove();

    calculateTotalUnits();
}


/* =========================================================
   TOTAL UNITS
========================================================= */

function calculateTotalUnits() {

    const unitsInputs =
        document.querySelectorAll(".subject-units");

    let total = 0;

    unitsInputs.forEach(
        input => {

            const value = parseFloat(input.value) || 0;

            total += value;
        }
    );

    document.getElementById("totalUnitsInput").textContent = total;

    calculateGWA();
}


/* =========================================================
   GWA (GENERAL WEIGHTED AVERAGE)
   GWA = sum(grade x units) / sum(units), counting only rows
   that have both a valid numeric grade and units. Rows with
   a blank or non-numeric grade (e.g. INC, DRP) are excluded
   from the computation entirely.
========================================================= */

function calculateGWA() {

    const rows =
        document.querySelectorAll(".subject-row");

    let gradedUnits = 0;
    let weightedSum = 0;

    rows.forEach(
        row => {

            const gradeInput = row.querySelector(".subject-grade");
            const unitsInput = row.querySelector(".subject-units");

            if (!gradeInput || !unitsInput) {
                return;
            }

            const grade = parseFloat(gradeInput.value);
            const units = parseFloat(unitsInput.value) || 0;

            if (isNaN(grade) || units <= 0) {
                return;
            }

            weightedSum += grade * units;
            gradedUnits += units;
        }
    );

    const gwa =
        gradedUnits > 0
            ? (weightedSum / gradedUnits)
            : 0;

    const gwaCell =
        document.getElementById("gwaValueInput");

    if (gwaCell) {

        gwaCell.textContent =
            gradedUnits > 0
                ? gwa.toFixed(2)
                : "0.00";
    }

    return gwa;
}


/* =========================================================
   FORMAT DATE
========================================================= */

function formatDate(dateString) {

    if (!dateString) {

        return "________________";
    }

    const date = new Date(dateString + "T00:00:00");

    return date.toLocaleDateString(
        "en-US",
        { month: "long", day: "numeric", year: "numeric" }
    );
}


/* =========================================================
   ORDINAL DAY SUFFIX (1st, 2nd, 3rd, 4th... 25th...)
========================================================= */

function getOrdinalSuffix(day) {

    const remainder10 = day % 10;
    const remainder100 = day % 100;

    if (remainder10 === 1 && remainder100 !== 11) return "st";
    if (remainder10 === 2 && remainder100 !== 12) return "nd";
    if (remainder10 === 3 && remainder100 !== 13) return "rd";

    return "th";
}

function formatDateOrdinal(dateString) {

    if (!dateString) {

        return "________________";
    }

    const date = new Date(dateString + "T00:00:00");

    const month = date.toLocaleDateString("en-US", { month: "long" });
    const day = date.getDate();
    const year = date.getFullYear();

    return `${month} ${day}${getOrdinalSuffix(day)}, ${year}`;
}


/* =========================================================
   GENERATE CERTIFICATE
========================================================= */

/* =========================================================
   CERTIFICATE TYPE
========================================================= */

function changeCertificateType() {

    const certificateType =
        document.getElementById("certificateType").value;

    const title =
        document.getElementById("previewCertificateTitle");

    const intro =
        document.getElementById("certificateIntro");

    const summaryTitleText =
        document.getElementById("summaryTitleText");

    const certificationTextContent =
        document.getElementById("certificationTextContent");

    const headRow =
        document.getElementById("certTableHeadRow");

    const totalLabelCell =
        document.getElementById("certTotalLabelCell");

    const certificationTextBlock =
        document.getElementById("certificationTextBlock");

    const issuedDateBlock =
        document.getElementById("issuedDateBlock");

    const detailRowEnrollmentDate =
        document.getElementById("detailRowEnrollmentDate");

    const detailRowStatus =
        document.getElementById("detailRowStatus");

    const isGradeEvaluation =
        certificateType === "GRADE_EVALUATION";


    /* ===================================== GRADE EVALUATION — HIDE/SHOW BLOCKS
       Grade Evaluation drops the intro sentence, the certification
       text, the "Issued this..." line, and the Date of Enrollment /
       Status rows — everything else stays the same as Enrollment
       and Registration. */

    intro.style.display = isGradeEvaluation ? "none" : "";
    certificationTextBlock.style.display = isGradeEvaluation ? "none" : "";
    issuedDateBlock.style.display = isGradeEvaluation ? "none" : "";
    detailRowEnrollmentDate.style.display = isGradeEvaluation ? "none" : "";
    detailRowStatus.style.display = isGradeEvaluation ? "none" : "";

    document
        .querySelector(".signature-area")
        .classList.toggle("signature-area--grade-eval", isGradeEvaluation);


    /* ===================================== SUBJECT TABLE HEAD */

    if (isGradeEvaluation) {

        headRow.innerHTML = `
            <th class="code-column">Course Code</th>
            <th>Course Description</th>
            <th class="grades-column">Grades</th>
            <th class="units-column">Units</th>
        `;

    } else {

        headRow.innerHTML = `
            <th class="code-column">Course Code</th>
            <th>Course Description</th>
            <th class="units-column">Units</th>
        `;
    }

    totalLabelCell.colSpan = isGradeEvaluation ? 3 : 2;

    const certGwaRow =
        document.getElementById("certGwaRow");

    const certGwaLabelCell =
        document.getElementById("certGwaLabelCell");

    if (certGwaRow) {
        certGwaRow.style.display = isGradeEvaluation ? "" : "none";
    }

    if (certGwaLabelCell) {
        certGwaLabelCell.colSpan = isGradeEvaluation ? 3 : 2;
    }


    /* ===================================== SUMMARY & CERTIFICATION TEXT */

    summaryTitleText.textContent =
        isGradeEvaluation
            ? "Below is the Summary of the Student's Grades:"
            : "Below is the Summary of the Student's Enrollment:";

    certificationTextContent.textContent =
        isGradeEvaluation
            ? "This Grade Evaluation is issued upon the request of the student for whatever lawful purpose it may serve."
            : "This certification is issued upon the request of the student for whatever lawful purpose it may serve.";


    /* ===================================== TITLE & INTRO */

    if (isGradeEvaluation) {

        title.textContent = "GRADE EVALUATION";

        intro.innerHTML = `
            This is to certify that

            <strong id="previewStudentName">
                ______________________________
            </strong>

            is officially enrolled at

            <strong>
                Andres Soriano Colleges of Bislig, Inc.
            </strong>

            in the

            <strong id="previewProgram">
                ______________________________
            </strong>

            program, and has earned the following grades for the

            <strong id="previewTrimester">
                ______________________________
            </strong>,

            <strong>Academic Year</strong>

            <strong id="previewAcademicYear">
                ____________
            </strong>.
        `;

    } else if (certificateType === "REGISTRATION") {

        title.textContent = "CERTIFICATE OF REGISTRATION";

        intro.innerHTML = `
            This is to certify that

            <strong id="previewStudentName">
                ______________________________
            </strong>

            is officially enrolled at

            <strong>
                Andres Soriano Colleges of Bislig, Inc.
            </strong>

            in the

            <strong id="previewProgram">
                ______________________________
            </strong>

            program for the

            <strong id="previewTrimester">
                ______________________________
            </strong>,

            <strong>Academic Year</strong>

            <strong id="previewAcademicYear">
                ____________
            </strong>.
        `;

    } else {

        title.textContent = "CERTIFICATE OF ENROLLMENT";

        intro.innerHTML = `
            This is to certify that

            <strong id="previewStudentName">
                ______________________________
            </strong>

            is officially enrolled at

            <strong>
                Andres Soriano Colleges of Bislig, Inc.
            </strong>

            in the

            <strong id="previewProgram">
                ______________________________
            </strong>

            program for the

            <strong id="previewTrimester">
                ______________________________
            </strong>,

            <strong>Academic Year</strong>

            <strong id="previewAcademicYear">
                ____________
            </strong>.
        `;
    }
}

let ascbCertificateMode = "AUTO"; // "AUTO" (galing sa enrollment record) o "MANUAL"
let ascbCertificateSelectedEnrollment = null;
let ascbCertificateSearchTimer = null;
let ascbCertificateSearchRequest = 0;
let ascbCertificateEditingId = null;

function ascbCertificateSetSourceLocked(locked) {
    /* MANUAL mode: hayagang bukás ang lahat ng field — walang
       official enrollment record na pinagbabatayan. */
    if (ascbCertificateMode === "MANUAL") locked = false;
    const textIds = ["studentName", "studentId", "academicYear", "enrollmentDate"];
    textIds.forEach(id => {
        const field = document.getElementById(id);
        if (field) field.readOnly = !!locked;
    });

    ["program", "yearLevel", "trimester", "status"].forEach(id => {
        const field = document.getElementById(id);
        if (field) field.disabled = !!locked;
    });

    document.querySelectorAll("#subjectRows input, #subjectRows select, #subjectRows button").forEach(field => {
        if (field.matches("input")) field.readOnly = !!locked;
        else field.disabled = !!locked;
    });

    const addSubjectButton = document.getElementById("addCertificateSubjectButton");
    if (addSubjectButton) addSubjectButton.disabled = !!locked;

    const submitButton = document.getElementById("generateCertificateButton");
    if (submitButton) {
        submitButton.disabled = !!locked
            && !ascbCertificateSelectedEnrollment
            && !ascbCertificateEditingId;
    }
}

function ascbCertificateClearAutofill() {
    ["studentName", "studentId", "academicYear", "enrollmentDate", "orNumber"].forEach(id => {
        const field = document.getElementById(id);
        if (field) field.value = "";
    });
    const program = document.getElementById("program");
    const yearLevel = document.getElementById("yearLevel");
    const status = document.getElementById("status");
    if (program) program.value = "";
    if (yearLevel) yearLevel.value = "";
    if (status) status.value = "OFFICIALLY ENROLLED";
    ascbCertificateUpdateTermSelect("");

    const tbody = document.getElementById("subjectRows");
    if (tbody) tbody.replaceChildren();
    calculateTotalUnits();
}

function ascbCertificateRenderSearchResults(students) {
    const results = document.getElementById("certificateStudentSearchResults");
    if (!results) return;
    results.replaceChildren();

    students.forEach(student => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "certificate-student-result";
        button.textContent = [
            `${student.studentName} (${student.studentId})`,
            student.programLabel,
            `${student.trimester}, AY ${student.academicYear}`
        ].filter(Boolean).join(" · ");
        button.addEventListener("click", () => {
            ascbCertificateSelectStudent(student.enrollmentId);
        });
        results.appendChild(button);
    });
}

async function ascbCertificateStudentSearch() {
    if (ascbCertificateEditingId) return;
    const input = document.getElementById("certificateStudentSearch");
    const status = document.getElementById("certificateStudentSearchStatus");
    const query = input ? input.value.trim() : "";
    const requestId = ++ascbCertificateSearchRequest;

    clearTimeout(ascbCertificateSearchTimer);
    ascbCertificateSelectedEnrollment = null;
    ascbCertificateClearAutofill();
    ascbCertificateSetSourceLocked(true);
    ascbCertificateRenderSearchResults([]);

    if (query.length < 2) {
        if (status) status.textContent = "Enter at least 2 characters to search approved enrollment records.";
        return;
    }

    if (status) status.textContent = "Searching official enrollment records…";
    ascbCertificateSearchTimer = setTimeout(async () => {
        try {
            const response = await fetch(`api/certificate_students.php?q=${encodeURIComponent(query)}`, {
                credentials: "same-origin",
                headers: { Accept: "application/json" },
                cache: "no-store"
            });
            const data = await response.json();
            if (requestId !== ascbCertificateSearchRequest) return;
            if (!response.ok || !data.ok) {
                if (status) status.textContent = data.error || "Unable to search enrollment records.";
                return;
            }

            const students = Array.isArray(data.students) ? data.students : [];
            ascbCertificateRenderSearchResults(students);
            if (status) {
                status.textContent = students.length
                    ? `${students.length} matching approved enrollment record${students.length === 1 ? "" : "s"}. Select the correct program and term.`
                    : "No approved enrollment records matched. Check the Student ID, name, or course/program.";
            }
        } catch (error) {
            if (requestId === ascbCertificateSearchRequest && status) {
                status.textContent = "Student search is unavailable. Please try again.";
            }
        }
    }, 250);
}

function ascbCertificateEnsureOption(select, value, label) {
    if (!select || !value) return;
    const text = label || value;
    let option = [...select.options].find(item => item.value === String(value));
    if (!option) {
        option = new Option(text, String(value));
        select.add(option);
    } else if (label) {
        option.textContent = text;
    }
    select.value = String(value);
}

async function ascbCertificateSelectStudent(enrollmentId) {
    const status = document.getElementById("certificateStudentSearchStatus");
    if (status) status.textContent = "Loading the selected enrollment…";
    ascbCertificateRenderSearchResults([]);
    ++ascbCertificateSearchRequest;

    try {
        const response = await fetch(`api/certificate_students.php?enrollment_id=${encodeURIComponent(enrollmentId)}`, {
            credentials: "same-origin",
            headers: { Accept: "application/json" },
            cache: "no-store"
        });
        const data = await response.json();
        if (!response.ok || !data.ok || !data.student) {
            if (status) status.textContent = data.error || "Unable to load the selected enrollment.";
            return;
        }

        const student = data.student;
        ascbCertificateSelectedEnrollment = student;
        document.getElementById("studentName").value = student.studentName || "";
        document.getElementById("studentId").value = student.studentId || "";
        ascbCertificateEnsureOption(
            document.getElementById("program"),
            student.programCode,
            student.programLabel
        );

        const yearSelect = document.getElementById("yearLevel");
        ascbCertificateEnsureOption(yearSelect, student.yearLevel, student.yearLevel);
        ascbCertificateUpdateTermSelect(student.trimester || "");
        const termSelect = document.getElementById("trimester");
        if (student.trimester && ![...termSelect.options].some(option => option.value === student.trimester)) {
            termSelect.add(new Option(student.trimester, student.trimester));
        }
        termSelect.value = student.trimester || "";

        document.getElementById("academicYear").value = student.academicYear || "";
        document.getElementById("enrollmentDate").value = student.enrollmentDate || "";
        document.getElementById("status").value = student.status || "OFFICIALLY ENROLLED";

        const tbody = document.getElementById("subjectRows");
        tbody.replaceChildren();
        const subjects = Array.isArray(student.subjects) ? student.subjects : [];
        const normalizedSubjects = subjects.map(subject => ({
                code: subject.code || "",
                description: subject.description || "",
                units: Number(subject.units) || 0
            }));
        normalizedSubjects.forEach(subject => addSubjectRow(subject));
        if (!normalizedSubjects.length) addSubjectRow();

        // addSubjectRow/loadSubjects refreshes every dropdown, so add the
        // official enrollment options only after all rows have been created.
        loadSubjects();
        normalizedSubjects.forEach((normalized, index) => {
            const row = tbody.children[index];
            if (!row) return;

            const subjectSelect = row.querySelector(".subject-select");
            const optionValue = JSON.stringify(normalized);
            let option = [...subjectSelect.options].find(item => item.value === optionValue);
            if (!option) {
                const label = [normalized.code, normalized.description].filter(Boolean).join(" — ");
                option = new Option(label || "Enrollment subject", optionValue);
                subjectSelect.add(option);
            }
            subjectSelect.value = optionValue;
            row.querySelector(".subject-description").value = normalized.description;
            row.querySelector(".subject-grade").value = subjects[index].grade || "";
            row.querySelector(".subject-units").value = normalized.units;
        });

        const search = document.getElementById("certificateStudentSearch");
        if (search) search.value = `${student.studentName} (${student.studentId})`;
        if (status) {
            status.textContent = `Selected: ${student.studentName} · ${student.programLabel} · ${student.trimester}, AY ${student.academicYear}.`;
        }
        calculateTotalUnits();
        if (typeof calculateGWA === "function") calculateGWA();
        ascbCertificateSetSourceLocked(true);
    } catch (error) {
        if (status) status.textContent = "Unable to load the selected enrollment. Please search again.";
    }
}


/* =========================================================
   CERTIFICATE DATA SOURCE MODE — AUTOMATIC / MANUAL
   AUTOMATIC (default): naka-lock ang mga field, ang student,
   term, subject at grades ay galing sa approved enrollment
   record (api/certificate_students.php).
   MANUAL: bukás lahat ng field para sa walk-in, legacy, o
   special na certificate na wala sa enrollment records.
========================================================= */

function ascbCertificateManualMode() {
    return ascbCertificateMode === "MANUAL";
}

function ascbCertificateSyncModeRadio() {
    const radio = document.querySelector(
        `input[name="certificateMode"][value="${ascbCertificateMode}"]`
    );
    if (radio) radio.checked = true;
}

function ascbCertificateChangeMode(mode) {

    const nextMode = mode === "MANUAL" ? "MANUAL" : "AUTO";

    /* Ang Records/History correction ay may sariling prefilled na
       state — huwag itong sisirain ng biglaang pagpalit ng mode. */
    if (ascbCertificateEditingId) {
        alert("Finish or clear the Records correction first before changing the data source.");
        ascbCertificateSyncModeRadio();
        return;
    }

    if (nextMode === ascbCertificateMode) {
        ascbCertificateSyncModeRadio();
        return;
    }

    ascbCertificateMode = nextMode;
    ascbCertificateSyncModeRadio();

    const picker = document.getElementById("certificateStudentPickerBlock");
    const infoNote = document.getElementById("certificateStudentInfoNote");
    const subjectsNote = document.getElementById("certificateSubjectsNote");
    const search = document.getElementById("certificateStudentSearch");
    const searchStatus = document.getElementById("certificateStudentSearchStatus");

    /* Iwas halo-halong data: bawat pagpalit ng mode ay malinis na simula. */
    ascbCertificateSelectedEnrollment = null;
    clearTimeout(ascbCertificateSearchTimer);
    ascbCertificateSearchRequest++;
    ascbCertificateRenderSearchResults([]);
    ascbCertificateClearAutofill();

    if (search) {
        search.disabled = false;
        search.value = "";
    }

    if (nextMode === "MANUAL") {
        if (picker) picker.style.display = "none";
        if (infoNote) {
            infoNote.textContent = "Manual entry — type the student and term details yourself. Nothing is read from the enrollment records, so please double-check every field before submitting.";
        }
        if (subjectsNote) {
            subjectsNote.textContent = "Add each subject manually. Use \u201C+ Add Custom Subject\u201D for courses outside the prospectus.";
        }
        ascbCertificateSetSourceLocked(false);
        setDefaultAcademicYear();
        setToday();
        const tbody = document.getElementById("subjectRows");
        if (tbody && !tbody.querySelector(".subject-row")) addSubjectRow();
        calculateTotalUnits();
        if (typeof calculateGWA === "function") calculateGWA();
    } else {
        if (picker) picker.style.display = "";
        if (searchStatus) {
            searchStatus.textContent = "Enter at least 2 characters. Only approved, non-archived enrollment records are shown.";
        }
        if (infoNote) {
            infoNote.textContent = "Search the official enrollment record. Student and term details fill in automatically.";
        }
        if (subjectsNote) {
            subjectsNote.textContent = "Subjects, units, and recorded grades are loaded from the selected enrollment.";
        }
        ascbCertificateSetSourceLocked(true);
    }
}

function ascbCertificateInitStudentPicker() {
    ascbCertificateSyncModeRadio();
    ascbCertificateSetSourceLocked(ascbCertificateMode !== "MANUAL");
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", ascbCertificateInitStudentPicker, { once: true });
} else {
    ascbCertificateInitStudentPicker();
}

/* =========================================================
   CERTIFICATE VERIFICATION QR (Enrollment / Registration)
   ---------------------------------------------------------
   - Ang QR ay ginagawa dito mismo sa browser (js/qrcode.js),
     walang internet/CDN na kailangan.
   - Ang laman nito ay galing sa server (api/certificates.php ->
     "verify"): plain text na may Name, Student ID, Program,
     Enrollment Date + link sa verify.php. Kaya:
       OFFLINE: kahit anong QR scanner ay makakabasa ng text.
       ONLINE : bubukas ang verify.php na kumukuha ng LIVE record.
   - Hindi pwedeng i-print ang certificate hangga't wala pang QR,
     para walang papel na lalabas na hindi ma-verify.
========================================================= */

let ascbCertificateReprintVerify = null;
let ascbCertificateQrRun = 0;

/* QR NAKA-OFF MUNA: false ang ibinabalik para sa lahat ng certificate.
   Para ibalik ang QR, gawing `type === "ENROLLMENT" || type === "REGISTRATION"` ulit. */
function ascbCertificateNeedsQr(type) {
    return false;
}

/* Kapag mahaba ang listahan ng subjects at hindi na kasya ang QR sa ilalim
   ng School Registrar, liliit ito (compact) para hindi maputol sa papel. */
function ascbCertificateQrFit() {
    const box = document.getElementById("certQrBox");
    const area = document.getElementById("printArea");
    if (!box || !area) return;

    box.classList.remove("cert-qr-box--compact");
    if (box.style.display === "none" || !box.offsetParent) return;

    const areaRect = area.getBoundingClientRect();
    const ratio = areaRect.height / (11 * 96);            // sumasabay sa zoom/scale ng preview
    const limit = areaRect.bottom - (0.10 * 96 * ratio);

    if (box.getBoundingClientRect().bottom > limit) {
        box.classList.add("cert-qr-box--compact");
    }
}

function ascbCertificateQrSetState(state, verify, message) {
    const box = document.getElementById("certQrBox");
    const img = document.getElementById("certQrImg");
    const code = document.getElementById("certQrCode");
    const site = document.getElementById("certQrSite");
    const area = document.getElementById("printArea");
    if (!box || !img) return;

    box.dataset.state = state;
    if (area) area.dataset.qrReady = state === "ready" ? "1" : (state === "hidden" ? "na" : "0");
    if (code) code.textContent = "";
    if (site) site.textContent = "";

    if (state === "hidden") {
        box.style.display = "none";
        img.innerHTML = "";
        return;
    }

    box.style.display = "";

    if (state === "pending") {
        img.textContent = "Preparing QR code...";
        return;
    }

    if (state === "ready" && verify && verify.qrText) {
        try {
            img.innerHTML = ASCBQR.svg(verify.qrText, { ecc: "L", quiet: 2 });
            if (code) code.textContent = verify.code || "";
            if (site) site.textContent = String(verify.url || "").replace(/^https?:\/\//i, "").replace(/\?.*$/, "");
            ascbCertificateQrFit();
            return;
        } catch (error) {
            console.error("QR generation failed:", error);
            message = "QR code could not be drawn.";
        }
    }

    box.dataset.state = "failed";
    if (area) area.dataset.qrReady = "0";
    img.textContent = message || "QR code unavailable.";
}

function generateCertificate(saveToHistory = true) {

    const certificateType =
        document.getElementById("certificateType").value;

    changeCertificateType();

    const isManualMode = ascbCertificateManualMode();

    if (saveToHistory && !isManualMode && !ascbCertificateEditingId && !ascbCertificateSelectedEnrollment) {
        alert("Search for and select an approved student enrollment before generating a certificate.");
        return;
    }

    const studentName =
        document.getElementById("studentName").value.trim();

    const studentId =
        document.getElementById("studentId").value.trim();

    const program =
        document.getElementById("program").value;

    const yearLevel =
        document.getElementById("yearLevel").value;

    const trimester =
        document.getElementById("trimester").value;

    const academicYear =
        document.getElementById("academicYear").value.trim();

    const enrollmentDate =
        document.getElementById("enrollmentDate").value;

    const status =
        document.getElementById("status").value;

    const orNumber =
        document.getElementById("orNumber").value.trim();

    const preparedBy =
        document.getElementById("preparedBy").value.trim();


    /* ========================================== VALIDATION */

    if (!studentName) {
        alert("Please enter the student's name.");
        return;
    }

    if (!studentId) {
        alert("Please enter the Student ID.");
        return;
    }

    if (!program) {
        alert("Please select a Course / Program.");
        return;
    }

    if (!yearLevel) {
        alert("Please select the Year Level.");
        return;
    }

    if (!trimester) {
        alert("Please select the Semester or Trimester.");
        return;
    }

    if (isManualMode) {

        if (!academicYear) {
            alert("Please enter the Academic Year.");
            return;
        }

        const hasSubject =
            [...document.querySelectorAll(".subject-row")].some(row => {
                const select = row.querySelector(".subject-select");
                const description = row.querySelector(".subject-description");
                return !!row.dataset.customCode
                    || (select && select.value && select.value !== "__CUSTOM__")
                    || (description && description.value.trim() !== "");
            });

        if (!hasSubject) {
            alert("Add at least one subject before generating a certificate.");
            return;
        }
    }

    if (certificateType === "GRADE_EVALUATION") {

        const hasGrade =
            [...document.querySelectorAll(".subject-grade")].some(
                input => input.value.trim() !== ""
            );

        if (!hasGrade) {
            alert("No grades are recorded for this enrollment. Grade Evaluation cannot be generated.");
            return;
        }
    }


    /* ========================================== BASIC INFO */

    document.getElementById("previewStudentName").textContent = studentName;
    document.getElementById("previewName2").textContent = studentName;
    document.getElementById("previewStudentId").textContent = studentId;
    document.getElementById("previewProgram").textContent =
        (ascbCertificateSelectedEnrollment && ascbCertificateSelectedEnrollment.programLabel)
            || programNames[program]
            || program;
    document.getElementById("previewCourse").textContent = getShortProgram(program);
    document.getElementById("previewYearLevel").textContent = yearLevel;
    document.getElementById("previewTrimester").textContent = trimester;
    document.getElementById("previewTerm").textContent =
        `${trimester}, AY ${academicYear}`;
    document.getElementById("previewAcademicYear").textContent = academicYear;
    document.getElementById("previewEnrollmentDate").textContent =
        formatDate(enrollmentDate);
    document.getElementById("previewStatus").textContent = status;
    document.getElementById("previewOrNumber").textContent = orNumber || "—";
    document.getElementById("previewPreparedBy").textContent = preparedBy || "—";


    /* ========================================== VERIFICATION QR */

    const qrNeeded = ascbCertificateNeedsQr(certificateType);
    const qrRun = ++ascbCertificateQrRun;

    if (!qrNeeded) {
        ascbCertificateReprintVerify = null;
        ascbCertificateQrSetState("hidden");
    } else if (!saveToHistory) {
        // REPRINT mula sa Records: gamitin ang token ng naka-save nang record.
        const savedVerify = ascbCertificateReprintVerify;
        ascbCertificateReprintVerify = null;
        if (savedVerify && savedVerify.qrText) {
            ascbCertificateQrSetState("ready", savedVerify);
        } else {
            ascbCertificateQrSetState("failed", null, "QR code unavailable for this record. Reload Records and try again.");
        }
    } else {
        ascbCertificateQrSetState("pending");
    }


    /* ========================================== SUBJECTS */

    const rows =
        document.querySelectorAll(".subject-row");

    const previewBody =
        document.getElementById("previewSubjects");

    previewBody.innerHTML = "";

    const isGradeEvaluation =
        certificateType === "GRADE_EVALUATION";

    let totalUnits = 0;
    let gwaWeightedSum = 0;
    let gwaGradedUnits = 0;
    const subjectsForLog = [];

    rows.forEach(
        row => {

            const select = row.querySelector(".subject-select");
            const description = row.querySelector(".subject-description");
            const grade = row.querySelector(".subject-grade");
            const units = row.querySelector(".subject-units");

            if (
                !description.value.trim() &&
                (!select.value || select.value === "__CUSTOM__")
            ) {
                return;
            }

            let code = "";

            if (row.dataset.customCode) {

                code = row.dataset.customCode;

            } else if (select.value && select.value !== "__CUSTOM__") {

                try {

                    const subject = JSON.parse(select.value);

                    code = subject.code;

                } catch (error) {

                    code = "";
                }
            }

            const unitValue = parseFloat(units.value) || 0;

            totalUnits += unitValue;

            const gradeValue = parseFloat(grade ? grade.value : "");

            if (!isNaN(gradeValue) && unitValue > 0) {

                gwaWeightedSum += gradeValue * unitValue;
                gwaGradedUnits += unitValue;
            }

            const tr = document.createElement("tr");

            tr.innerHTML =
                isGradeEvaluation
                    ? `
                        <td>${escapeHTML(code)}</td>
                        <td>${escapeHTML(description.value)}</td>
                        <td>${escapeHTML(grade ? grade.value.trim() : "")}</td>
                        <td>${unitValue}</td>
                        `
                    : `
                        <td>${escapeHTML(code)}</td>
                        <td>${escapeHTML(description.value)}</td>
                        <td>${unitValue}</td>
                        `;

            previewBody.appendChild(tr);

            subjectsForLog.push({
                code,
                description: description.value.trim(),
                grade: grade ? grade.value.trim() : "",
                units: unitValue
            });
        }
    );

    document.getElementById("previewTotalUnits").textContent = totalUnits;

    const previewGWACell =
        document.getElementById("previewGWA");

    if (previewGWACell) {

        previewGWACell.textContent =
            gwaGradedUnits > 0
                ? (gwaWeightedSum / gwaGradedUnits).toFixed(2)
                : "0.00";
    }


    /* ========================================== ISSUED DATE */

    document.getElementById("previewIssuedDate").textContent =
        formatDateOrdinal(new Date().toISOString().split("T")[0]);


    /* ========================================== LOG TO DATABASE */
    /* Normal Generate = save to History.
       Reprint from History = preview/print ONLY; never create
       another database record.
       Update from History = update the SAME existing record. */

    if (saveToHistory) {
    const ascbCertPayload = {
        certificateType,
        manual: isManualMode,
        enrollmentId: ascbCertificateSelectedEnrollment ? ascbCertificateSelectedEnrollment.enrollmentId : null,
        studentName,
        studentId,
        program,
        yearLevel,
        trimester,
        academicYear,
        enrollmentDate,
        status,
        orNumber,
        totalUnits,
        gwa: gwaGradedUnits > 0 ? (gwaWeightedSum / gwaGradedUnits).toFixed(2) : null,
        preparedBy,
        subjects: subjectsForLog
    };
    if (ascbCertificateEditingId) {
        ascbCertPayload.action = "update";
        ascbCertPayload.id = ascbCertificateEditingId;
    }
    ascbApiPost("api/certificates.php", ascbCertPayload).then(result => {
        if (qrNeeded && qrRun === ascbCertificateQrRun) {
            if (result.ok && result.verify && result.verify.qrText) {
                ascbCertificateQrSetState("ready", result.verify);
            } else if (result.ok) {
                ascbCertificateQrSetState("failed", null, "QR code could not be created. Run database/migrate_master.php, then generate again.");
            } else {
                ascbCertificateQrSetState("failed", null, "Not saved, so no QR code. " + (result.error || ""));
            }
        }
        if (!result.ok) { console.error("Certificate log failed:", result.error); return; }
        if (ascbCertificateEditingId) {
            ascbCertificateEditingId = null;
            const banner = document.getElementById("ascbCertEditBanner");
            if (banner) banner.remove();
            const search = document.getElementById("certificateStudentSearch");
            if (search) search.disabled = false;
            const searchStatus = document.getElementById("certificateStudentSearchStatus");
            if (searchStatus) {
                searchStatus.textContent = "Record updated. Search for an approved enrollment to create a new certificate.";
            }
            ascbCertificateSetSourceLocked(true);
            if (typeof ascbLoadRecords === "function" && ascbRecordsType === "certificates") ascbLoadRecords("certificates");
        }
    });
    }

    /* ========================================== OPEN MODAL */

    document.getElementById("certificateModal").classList.add("active");
    ascbCertificateQrFit();
}


/* =========================================================
   SHORT PROGRAM
========================================================= */

function getShortProgram(program) {
    return (program == null) ? "" : String(program);
}



/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHTML(value) {

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


/* =========================================================
   ACTION ICONS
   ---------------------------------------------------------
   Simple SVG line-icons na ginagamit sa mga action button
   (View, Update, Delete, atbp.) sa halip na text label.
   Gumagamit ng currentColor kaya sumusunod ito sa kulay ng
   button (btn-outline, btn-danger-solid, atbp). May title
   (tooltip) at aria-label pa rin ang bawat button kaya
   malinaw pa rin kung ano ang gagawin nito kahit icon lang.
   ========================================================= */

const ASCB_ICON_PATHS = {
    assign: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6"/><path d="M22 11h-6"/>',
    key: '<circle cx="7.5" cy="15.5" r="5.5"/><path d="M21 2l-9.6 9.6"/><path d="M15.5 7.5l3 3L22 7l-3-3"/>',
    view: '<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/><circle cx="12" cy="12" r="3"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/>',
    delete: '<path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/>',
    deleteForever: '<path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M9.5 11l5 5"/><path d="M14.5 11l-5 5"/>',
    approve: '<path d="M20 6L9 17l-5-5"/>',
    reject: '<path d="M18 6L6 18"/><path d="M6 6l12 12"/>',
    newTerm: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h18"/><path d="M12 14v6"/><path d="M9 17h6"/>',
    restore: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
    exportExcel: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
    viewGrades: '<path d="M3 3v18h18"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-4"/>',
    activate: '<path d="M12 2v6"/><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/>',
    deactivate: '<path d="M12 2v6"/><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/>',
    print: '<polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
};

function ascbIcon(name, label) {
    const path = ASCB_ICON_PATHS[name] || "";
    const safeLabel = escapeHTML(label || "");
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ` +
        `stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${path}</svg>` +
        (safeLabel ? `<span class="sr-only">${safeLabel}</span>` : "");
}


/* =========================================================
   CLOSE CERTIFICATE
========================================================= */

function closeCertificate() {

    document.getElementById("certificateModal").classList.remove("active");
}


/* =========================================================
   PRINT CERTIFICATE — ONE COPY ONLY
========================================================= */

function printCertificate() {

    const printArea = document.getElementById("printArea");

    if (!printArea) {
        alert("Certificate print area not found.");
        return;
    }

    if (printArea.dataset.qrReady === "0") {
        alert("The verification QR code is not ready yet. Wait a moment, or generate the certificate again if it shows an error.");
        return;
    }

    const printWindow = window.open(
        "",
        "_blank",
        "width=900,height=1000"
    );

    if (!printWindow) {
        alert("Please allow pop-ups for this website to print the certificate.");
        return;
    }

    const styles = [...document.querySelectorAll("link[rel='stylesheet'], style")]
        .map(style => {
            if (style.tagName === "STYLE") {
                return `<style>${style.innerHTML}</style>`;
            }

            return `<link rel="stylesheet" href="${style.href}">`;
        })
        .join("");

    printWindow.document.open();

    printWindow.document.write(`
        <!DOCTYPE html>
        <html lang="en">
        <head>

            <meta charset="UTF-8">

            <title>${document.getElementById("previewCertificateTitle").textContent}</title>

            ${styles}

            <style>

                @page {
                    size: Letter portrait;
                    margin: 0;
                }

                html,
                body {
                    width: 8.5in;
                    height: 11in;
                    margin: 0;
                    padding: 0;
                    background: #ffffff;
                    overflow: hidden;
                }

                body {
                    font-family: "Poppins", Arial, sans-serif;
                }

                .print-area {
                    width: 8.5in !important;
                    height: 11in !important;
                    min-height: 11in !important;
                    max-height: 11in !important;

                    margin: 0 !important;
                    padding: 0 !important;

                    overflow: hidden !important;

                    box-shadow: none !important;
                    background: #ffffff !important;
                }

                /* WATERMARK */

                .watermark-container {
                    position: absolute !important;

                    left: 0 !important;
                    right: 0 !important;

                    top: 2.20in !important;
                    bottom: 0 !important;

                    display: flex !important;
                    align-items: center !important;
                    justify-content: center !important;

                    overflow: hidden !important;

                    z-index: 1 !important;
                    pointer-events: none !important;
                }

                .document-watermark {
                    position: relative !important;

                    width: 4.35in !important;
                    height: 4.35in !important;

                    max-width: 4.35in !important;
                    max-height: 4.35in !important;

                    transform: none !important;

                    display: block !important;
                    visibility: visible !important;

                    object-fit: contain !important;

                    opacity: 0.055 !important;

                    z-index: 1 !important;
                    pointer-events: none !important;
                }

                .document-content {
                    position: relative !important;
                    z-index: 3 !important;
                }

                .document-header {
                    position: relative !important;
                    z-index: 5 !important;
                }

                .student-details,
                .certificate-title,
                .certificate-intro,
                .summary-title,
                .certificate-table,
                .certification-text,
                .signature-area {
                    position: relative !important;
                    z-index: 3 !important;
                }

                /* HIDE UI CONTROLS */

                button,
                .btn,
                .modal-toolbar,
                .modal-overlay {
                    display: none !important;
                }

                /* PRINT COLORS */

                * {
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                }

            </style>

        </head>

        <body>

            ${printArea.outerHTML}

        </body>
        </html>
    `);

    printWindow.document.close();

    printWindow.focus();

    /*
       Wait for logo/fonts/images to finish loading
       before opening print dialog.
    */

    setTimeout(() => {

        printWindow.print();

        /*
           Close the temporary print window
           after printing.
        */

        setTimeout(() => {
            printWindow.close();
        }, 500);

    }, 700);
}

/* =========================================================
   CLEAR FORM
========================================================= */

async function clearForm() {

    const confirmation =
        await ascbConfirm("Clear all enrollment information and subjects?");

    if (!confirmation) {
        return;
    }

    ascbCertificateEditingId = null;
    const ascbCertBanner = document.getElementById("ascbCertEditBanner");
    if (ascbCertBanner) ascbCertBanner.remove();
    ascbCertificateSelectedEnrollment = null;
    clearTimeout(ascbCertificateSearchTimer);
    ascbCertificateSearchRequest++;
    ascbCertificateClearAutofill();
    const searchInput = document.getElementById("certificateStudentSearch");
    const searchStatus = document.getElementById("certificateStudentSearchStatus");
    if (searchInput) {
        searchInput.disabled = false;
        searchInput.value = "";
    }
    if (searchStatus) {
        searchStatus.textContent = "Enter at least 2 characters. Only approved, non-archived enrollment records are shown.";
    }
    ascbCertificateRenderSearchResults([]);

    /* "Prepared By" is auto-credited to the logged-in user and is
       server-rendered directly in dashboard.php, so there is nothing
       to re-apply here client-side (see auth.js header comment). */

    addSubjectRow();
    calculateTotalUnits();

    /* Nananatili ang napiling Data Source mode pagkatapos mag-clear. */
    if (ascbCertificateManualMode()) {
        ascbCertificateSetSourceLocked(false);
        setDefaultAcademicYear();
        setToday();
    } else {
        ascbCertificateSetSourceLocked(true);
    }
}

function closeModal() {

    const modal = document.getElementById("certificateModal");

    if (modal) {

        modal.classList.remove("active");
    }
}

document.addEventListener("keydown", function (event) {

    if (event.key === "Escape") {

        closeModal();
    }
});


/* =========================================================
   FORM 137 REQUEST MODULE
   Added to the ASCB Certificate System
========================================================= */

const F137_SCHOOLS_KEY = "ascb_form137_schools";
const F137_COURSES_KEY = "ascb_form137_courses";
const F137_FORM_KEY = "ascb_form137_current_form";
const F137_MAX_STUDENTS = 8;

const F137_DEFAULT_SCHOOLS = [
    { name: "ANDRES SORIANO COLLEGES OF BISLIG, INC.", address: "Mangagoy, Bislig City" },
    { name: "TABON M. ESTRELLA NATIONAL HIGH SCHOOL", address: "Tabon, Bislig City" },
    { name: "STAND ALONE SENIOR HIGH SCHOOL", address: "Comawas, Bislig City" },
    { name: "SOUTHERN TECHNOLOGICAL INSTITUTE OF THE PHILIPPINES, INC.", address: "Andres Soriano Avenue, Mangagoy, Bislig City" },
    { name: "AGUSAN NATIONAL HIGH SCHOOL", address: "Butuan City, Surigao del Sur" },
    { name: "BERNARDO D. CARPIO NATIONAL HIGH SCHOOL", address: "Pioneer Village, Buhangin, Davao City" },
    { name: "BISLIG CITY NATIONAL HIGH SCHOOL", address: "Purok 10 Villa Josefa Poblacion, Bislig City" },
    { name: "HINATUAN NATIONAL COMPREHENSIVE HIGH SCHOOL", address: "Sto. Niño, Hinatuan, Surigao del Sur" },
    { name: "LAWIGAN NATIONAL HIGH SCHOOL", address: "Lawigan, Bislig City" },
    { name: "LINGIG NATIONAL HIGH SCHOOL", address: "Lingig 1 District" },
    { name: "MAHARLIKA NATIONAL HIGH SCHOOL", address: "Maharlika, Bislig City" }
];

const F137_DEFAULT_COURSES = Array.isArray(ASCB_PROGRAM_CODES) ? [...ASCB_PROGRAM_CODES] : [];

let f137Students = [];

function f137El(id) {
    return document.getElementById(id);
}

function f137Escape(value) {
    const div = document.createElement("div");
    div.textContent = value == null ? "" : String(value);
    return div.innerHTML;
}

function f137Today() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

function f137FormatDate(value) {
    if (!value) return "";
    const d = new Date(value + "T00:00:00");
    if (Number.isNaN(d.getTime())) return "";
    return d.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
}

/* =========================================================
   SCHOOLS / COURSES — now backed by the MySQL database
   (`schools` / `courses` tables) instead of localStorage.
   dashboard.php injects the current lists as ASCB_SCHOOLS /
   ASCB_COURSES on page load; we keep an in-memory cache here
   so the dropdowns can be updated instantly after an Add/
   Delete without a full page reload, then sync to the DB via
   fetch() to api/schools.php and api/courses.php.
   ========================================================= */

let ascbSchoolsCache = (typeof ASCB_SCHOOLS !== "undefined" && Array.isArray(ASCB_SCHOOLS))
    ? ASCB_SCHOOLS.map(s => ({ name: s.name, address: s.address || "" }))
    : [...F137_DEFAULT_SCHOOLS];

let ascbCoursesCache = (typeof ASCB_COURSES !== "undefined" && Array.isArray(ASCB_COURSES))
    ? [...ASCB_COURSES]
    : [...F137_DEFAULT_COURSES];

function f137GetSchools() {
    return ascbSchoolsCache;
}

function f137GetCourses() {
    return ascbCoursesCache;
}

/* Kept as a harmless no-op so any old callers don't break —
   ang starter data ay nasa database na (database/ascb_registrar.sql),
   hindi na sa localStorage. */
function f137InitStorage() {}

/* =========================================================
   AUTO STUDENT ACCOUNT — one-time credentials popup / slip / CSV
   ---------------------------------------------------------
   Ang temporary password ay galing LANG sa response ng pag-create (o
   ng "Issue / Reset temporary password"); hindi ito naka-store kahit
   saan sa server (hash lang). Kaya ipinapakita ito nang ISANG BESES.
========================================================= */
function ascbStudentCredsClose() {
    const m = document.getElementById("ascbStudentCredsModal");
    if (m) m.remove();
}

function ascbStudentCredsCopy(btn) {
    const m = document.getElementById("ascbStudentCredsModal");
    if (!m) return;
    const text = "Student ID / Username: " + m.dataset.username + "\nTemporary password: " + m.dataset.password;
    const done = () => { if (btn) { const t = btn.textContent; btn.textContent = "Copied!"; setTimeout(() => { btn.textContent = t; }, 1500); } };
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, () => window.prompt("Copy:", text));
    } else {
        window.prompt("Copy:", text);
    }
}

function ascbStudentCredsPrint() {
    const m = document.getElementById("ascbStudentCredsModal");
    if (!m) return;
    const w = window.open("", "_blank", "width=520,height=620");
    if (!w) { alert("Please allow pop-ups to print the slip."); return; }
    const u = escapeHTML(m.dataset.username), p = escapeHTML(m.dataset.password), n = escapeHTML(m.dataset.name || "");
    w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Student Portal Account</title>
        <style>body{font-family:Arial,sans-serif;padding:28px;color:#111}h2{margin:0 0 2px}small{color:#555}
        .box{border:2px dashed #444;border-radius:10px;padding:16px;margin:16px 0}
        .k{font-size:12px;color:#555;margin-top:10px}.v{font-size:22px;font-weight:700;font-family:Consolas,monospace;letter-spacing:1px}
        ol{padding-left:18px;font-size:13px;line-height:1.6}</style></head><body>
        <h2>Andres Soriano Colleges of Bislig, Inc.</h2><small>Office of the Registrar &mdash; Student Portal Account</small>
        <div class="box">${n ? `<div class="k">Student</div><div class="v" style="font-size:16px">${n}</div>` : ""}
        <div class="k">Username (Student ID)</div><div class="v">${u}</div>
        <div class="k">Temporary password (one-time)</div><div class="v">${p}</div></div>
        <ol><li>Open the Registrar Student Portal and sign in with the Student ID and the temporary password above.</li>
        <li>You will be asked to create your own password right away. The temporary password stops working after that.</li>
        <li>Keep your password private. Do not share it with anyone.</li></ol>
        <script>window.onload=function(){window.print();}<\/script></body></html>`);
    w.document.close();
}

/* acct = { status, username, tempPassword, expiresAt, reset } ; name = optional display name */
function ascbShowStudentCredentials(acct, name) {
    if (!acct || !acct.tempPassword) return;
    ascbStudentCredsClose();
    const exp = acct.expiresAt ? ` It expires on ${escapeHTML(acct.expiresAt.substring(0, 10))}.` : "";
    const m = document.createElement("div");
    m.id = "ascbStudentCredsModal";
    m.dataset.username = acct.username || "";
    m.dataset.password = acct.tempPassword;
    m.dataset.name = name || "";
    m.setAttribute("role", "dialog");
    m.setAttribute("aria-modal", "true");
    m.style.cssText = "position:fixed;inset:0;background:rgba(10,17,38,.6);display:flex;align-items:center;justify-content:center;padding:16px;z-index:100000;";
    m.innerHTML = `
        <div style="background:var(--card,#fff);color:var(--ink,#131c33);width:100%;max-width:460px;border-radius:16px;padding:22px;box-shadow:0 18px 50px rgba(0,0,0,.35);">
            <h3 style="margin:0 0 6px;">${acct.reset ? "New temporary password issued" : "Student account created"}</h3>
            ${name ? `<div style="font-size:13px;opacity:.8;margin-bottom:8px;">${escapeHTML(name)}</div>` : ""}
            <div style="border:1.5px dashed var(--line,#c2d3e6);border-radius:10px;padding:12px 14px;margin:8px 0;">
                <div style="font-size:11.5px;opacity:.75;">Username (Student ID)</div>
                <div style="font:700 20px Consolas,monospace;">${escapeHTML(acct.username || "")}</div>
                <div style="font-size:11.5px;opacity:.75;margin-top:8px;">Temporary password (one-time)</div>
                <div style="font:700 22px Consolas,monospace;letter-spacing:1px;">${escapeHTML(acct.tempPassword)}</div>
            </div>
            <p style="font-size:12.5px;margin:8px 0 14px;opacity:.85;">
                <strong>Shown only once.</strong> Give this to the student now (print the slip or copy it). The student must change it on first login.${exp}
                If it is lost, use the <em>Student account</em> (key) button to issue a new one.
            </p>
            <div style="display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;">
                <button type="button" class="btn btn-outline" onclick="ascbStudentCredsCopy(this)">Copy</button>
                <button type="button" class="btn btn-outline" onclick="ascbStudentCredsPrint()">Print slip</button>
                <button type="button" class="btn btn-primary" onclick="ascbStudentCredsClose()">Done</button>
            </div>
        </div>`;
    document.body.appendChild(m);
}

/* Maikling paalala kung hindi nakagawa ng account (hindi nito sinisira ang enrollment). */
function ascbStudentAccountNotice(acct) {
    if (!acct) return;
    if (acct.status === "failed" || acct.status === "unavailable") {
        alert("The enrollment was saved, but the student account could not be created automatically.\n\n" + (acct.message || "") +
              "\n\nYou can issue it later using the Student account (key) button.");
    }
}

/* Isang entry point para sa create / approve responses. */
function ascbHandleStudentAccountResponse(data, name) {
    if (!data || !data.studentAccount) return;
    if (data.studentAccount.tempPassword) ascbShowStudentCredentials(data.studentAccount, name || "");
    else ascbStudentAccountNotice(data.studentAccount);
}

/* Ligtas na JS string literal para sa loob ng onclick="..." attribute. */
function ascbJsAttr(v) {
    return JSON.stringify(String(v == null ? "" : v)).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
}

/* "Issue / Reset temporary password" — Registrar / Unit Head. */
async function ascbIssueStudentAccount(studentId, name) {
    if (!studentId) return;
    if (!(await ascbConfirm(
        "Issue a NEW one-time temporary password for Student ID " + studentId + "?\n\n" +
        "If the student already has an account, the current password stops working immediately and the student must set a new one at the next login."
    ))) return;
    const data = await ascbApiPost("api/users.php", { action: "issue_student_account", studentId });
    if (!data || !data.ok) { alert((data && data.error) || "Unable to issue the temporary password."); return; }
    ascbShowStudentCredentials(data.studentAccount, name || "");
    if (typeof ascbLoadUsers === "function" && document.getElementById("usersTableBody")) ascbLoadUsers();
}

function ascbDownloadStudentCredentialsCsv(list) {
    const esc = v => '"' + String(v == null ? "" : v).replace(/"/g, '""') + '"';
    const rows = [["Student ID", "Name", "Username", "Temporary Password"]].concat(
        (list || []).map(c => [c.studentId, c.name, c.username, c.tempPassword]));
    const csv = "\ufeff" + rows.map(r => r.map(esc).join(",")).join("\r\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "student_account_credentials_" + new Date().toISOString().slice(0, 10) + ".csv";
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
window.__ascbImportCreds = [];

async function ascbApiPost(url, payload) {
    try {
        const response = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        return await response.json();
    } catch (error) {
        console.error("API request failed:", url, error);
        return { ok: false, error: "Unable to reach the server. Suriin ang koneksyon o i-refresh ang page." };
    }
}

function f137LoadSchools(selected = "") {
    const select = f137El("f137_schoolSelect");
    if (!select) return;
    select.innerHTML = `<option value="">Select School</option>`;
    f137GetSchools().forEach(school => {
        const option = document.createElement("option");
        option.value = school.name;
        option.textContent = school.name;
        option.dataset.address = school.address || "";
        select.appendChild(option);
    });
    if (selected) {
        select.value = selected;
        f137UpdateSchoolAddress();
    }
}

function f137LoadCourses(selected = "") {
    const select = f137El("f137_courseSelect");
    if (!select) return;
    select.innerHTML = `<option value="">Select Course</option>`;
    f137GetCourses().forEach(course => {
        const option = document.createElement("option");
        option.value = course;
        option.textContent = course;
        select.appendChild(option);
    });
    if (selected) select.value = selected;
}

function f137UpdateSchoolAddress() {
    const select = f137El("f137_schoolSelect");
    const address = f137El("f137_schoolAddress");
    const option = select.options[select.selectedIndex];
    if (option && select.value) address.value = option.dataset.address || "";
}

/* Kept as a thin alias to the view switch: some buttons still
   call openForm137() by habit, and it now behaves exactly like
   navigating to Certificates does — no separate init needed,
   since f137Setup() below already prepares the view on load. */
function openForm137() {
    if (typeof ascbForm137NavReset === "function") ascbForm137NavReset();
    else if (typeof ascbNavigate === "function") ascbNavigate("form137");
}

function ascbToggleF137ActionsPanel() {
    const panel = f137El("f137ActionsPanel");
    if (panel) panel.classList.toggle("collapsed");
}

function closeForm137Preview() {
    const modal = f137El("form137PreviewModal");
    if (modal) modal.classList.remove("active");
}

function f137Setup() {
    f137InitStorage();
    f137LoadSchools();
    f137LoadCourses();
    f137El("f137_requestDate").value = f137Today();

    f137El("f137_schoolSelect").addEventListener("change", () => {
        f137UpdateSchoolAddress();
        f137UpdatePreview();
        f137Save();
    });

    f137El("f137_schoolAddress").addEventListener("input", () => {
        f137UpdatePreview();
        f137Save();
    });

    ["f137_requestDate","f137_firstRequest","f137_secondRequest","f137_urgentRequest","f137_bearerRequest","f137_copyForASCB"]
        .forEach(id => {
            const el = f137El(id);
            el.addEventListener("input", () => { f137UpdatePreview(); f137Save(); });
            el.addEventListener("change", () => { f137UpdatePreview(); f137Save(); });
        });

    ["f137_studentName","f137_schoolYear","f137_yearSection"].forEach(id => {
        const el = f137El(id);
        el.addEventListener("input", f137Save);
    });

    f137El("f137_schoolSelect").addEventListener("dblclick", f137DeleteSelectedSchool);
    f137El("f137_courseSelect").addEventListener("dblclick", f137DeleteSelectedCourse);

    f137El("f137_firstRequest").addEventListener("change", () => {
        if (f137El("f137_firstRequest").checked) f137El("f137_secondRequest").checked = false;
        f137UpdatePreview(); f137Save();
    });

    f137El("f137_secondRequest").addEventListener("change", () => {
        if (f137El("f137_secondRequest").checked) f137El("f137_firstRequest").checked = false;
        f137UpdatePreview(); f137Save();
    });

    f137LoadSaved();
    f137UpdatePreview();
}

function addF137Student() {
    const name = f137El("f137_studentName").value.trim();
    const course = f137El("f137_courseSelect").value;
    const year = f137El("f137_schoolYear").value.trim();
    const section = f137El("f137_yearSection").value.trim();

    if (!name || !course || !year || !section) {
        alert("Please complete the Student Name, Course, School Year, and Year & Section first.");
        return;
    }

    if (f137Students.length >= F137_MAX_STUDENTS) {
        alert(`Maximum ${F137_MAX_STUDENTS} students per request.`);
        return;
    }

    f137Students.push({ name, course, schoolYear: year, yearSection: section });

    f137El("f137_studentName").value = "";
    f137El("f137_courseSelect").value = "";
    f137El("f137_schoolYear").value = "";
    f137El("f137_yearSection").value = "";

    f137RenderStudentList();
    f137UpdatePreview();
    f137Save();
    f137El("f137_studentName").focus();
}

function f137RemoveStudent(index) {
    f137Students.splice(index, 1);
    f137RenderStudentList();
    f137UpdatePreview();
    f137Save();
}

function f137RenderStudentList() {
    const container = f137El("f137_studentsList");
    container.innerHTML = "";
    f137Students.forEach((student, index) => {
        const item = document.createElement("div");
        item.className = "f137-student-chip";
        item.innerHTML = `
            <span>
                <span class="f137-student-chip-name">${index + 1}. ${f137Escape(student.name)}</span>
                <span class="f137-student-chip-meta">${f137Escape(student.course)} • ${f137Escape(student.schoolYear)} • ${f137Escape(student.yearSection)}</span>
            </span>
            <button type="button" class="f137-remove-student" onclick="f137RemoveStudent(${index})">×</button>
        `;
        container.appendChild(item);
    });
}

function f137BuildRows() {
    if (f137Students.length) return f137Students;
    return [{
        name: f137El("f137_studentName").value.trim() || "STUDENT NAME",
        course: f137El("f137_courseSelect").value || "COURSE",
        schoolYear: f137El("f137_schoolYear").value.trim() || "SCHOOL YEAR",
        yearSection: f137El("f137_yearSection").value.trim() || "YEAR & SECTION"
    }];
}

function f137UpdatePreview() {
    const rows = f137BuildRows();
    const school = f137El("f137_schoolSelect").value || "ANDRES SORIANO COLLEGES OF BISLIG, INC.";
    const address = f137El("f137_schoolAddress").value.trim() || "Mangagoy, Bislig City";
    const plural = rows.length > 1;

    f137El("f137_previewDate").textContent = f137FormatDate(f137El("f137_requestDate").value);
    f137El("f137_previewSchool").textContent = school;
    f137El("f137_previewSchoolAddress").textContent = address;
    f137El("f137_pluralTag").textContent = plural ? "s" : "";
    f137El("f137_pluralTag2").textContent = plural ? "s" : "";
    f137El("f137_isAreTag").textContent = plural ? "are" : "is";

    const body = f137El("f137_studentTableBody");
    body.innerHTML = "";
    rows.forEach(student => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${f137Escape(student.name)}</td>
            <td>${f137Escape(student.course)}</td>
            <td>${f137Escape(student.schoolYear)}</td>
            <td>${f137Escape(student.yearSection)}</td>
        `;
        body.appendChild(tr);
    });

    const checks = [
        ["f137_checkFirst","f137_firstRequest"],
        ["f137_checkSecond","f137_secondRequest"],
        ["f137_checkUrgent","f137_urgentRequest"],
        ["f137_checkBearer","f137_bearerRequest"],
        ["f137_checkCopy","f137_copyForASCB"]
    ];
    checks.forEach(([target, source]) => {
        f137El(target).classList.toggle("active", !!f137El(source).checked);
    });
}

function generateForm137(saveToHistory = true) {
    const hasPending =
        f137El("f137_studentName").value.trim() ||
        f137El("f137_courseSelect").value ||
        f137El("f137_schoolYear").value.trim() ||
        f137El("f137_yearSection").value.trim();

    if (hasPending) {
        const name = f137El("f137_studentName").value.trim();
        const course = f137El("f137_courseSelect").value;
        const year = f137El("f137_schoolYear").value.trim();
        const section = f137El("f137_yearSection").value.trim();

        if (name && course && year && section && f137Students.length < F137_MAX_STUDENTS) {
            f137Students.push({ name, course, schoolYear: year, yearSection: section });
            f137El("f137_studentName").value = "";
            f137El("f137_courseSelect").value = "";
            f137El("f137_schoolYear").value = "";
            f137El("f137_yearSection").value = "";
            f137RenderStudentList();
        }
    }

    f137UpdatePreview();

    if (!f137Students.length) {
        alert("Please add at least one student first.");
        return;
    }

    if (!f137El("f137_schoolSelect").value) {
        alert("Please select a receiving school first.");
        return;
    }

    /* Normal Generate = save draft + History.
       Reprint from History = preview/print ONLY; no draft save
       and no new database record.
       Update from History = update the SAME existing record. */

    if (saveToHistory) {
    f137Save();

    const ascbF137Payload = {
        requestDate: f137El("f137_requestDate")?.value || "",
        school: f137El("f137_schoolSelect")?.value || "",
        schoolAddress: f137El("f137_schoolAddress")?.value || "",
        firstRequest: !!f137El("f137_firstRequest")?.checked,
        secondRequest: !!f137El("f137_secondRequest")?.checked,
        urgentRequest: !!f137El("f137_urgentRequest")?.checked,
        bearerRequest: !!f137El("f137_bearerRequest")?.checked,
        copyForASCB: !!f137El("f137_copyForASCB")?.checked,
        students: f137Students
    };
    if (ascbF137EditingId) {
        ascbF137Payload.action = "update";
        ascbF137Payload.id = ascbF137EditingId;
    }
    ascbApiPost("api/form137.php", ascbF137Payload).then(result => {
        if (!result.ok) { console.error("Form 137 request log failed:", result.error); return; }
        if (ascbF137EditingId) {
            ascbF137EditingId = null;
            const banner = document.getElementById("ascbF137EditBanner");
            if (banner) banner.remove();
            if (typeof ascbLoadRecords === "function" && ascbRecordsType === "form137") ascbLoadRecords("form137");
        }
    });
    }

    const modal = f137El("form137PreviewModal");
    if (modal) modal.classList.add("active");
}

function f137OpenMini(id) {
    f137El(id).classList.add("active");
}

function openF137SchoolDialog() {
    f137El("f137_newSchoolName").value = "";
    f137El("f137_newSchoolAddress").value = "";
    f137OpenMini("f137SchoolDialog");
    setTimeout(() => f137El("f137_newSchoolName").focus(), 50);
}

function closeF137SchoolDialog() {
    f137El("f137SchoolDialog").classList.remove("active");
}

async function saveF137School() {
    const name = f137El("f137_newSchoolName").value.trim();
    const address = f137El("f137_newSchoolAddress").value.trim();
    if (!name) { alert("Enter the school name."); return; }

    if (ascbSchoolsCache.some(s => s.name.toLowerCase() === name.toLowerCase())) {
        alert("This school is already saved.");
        return;
    }

    const result = await ascbApiPost("api/schools.php", { action: "add", name, address });
    if (!result.ok) {
        alert(result.error || "Unable to save the school.");
        return;
    }

    ascbSchoolsCache.push({ name, address });
    f137LoadSchools(name);
    f137El("f137_schoolAddress").value = address;
    closeF137SchoolDialog();
    f137UpdatePreview();
    f137Save();
}

function openF137CourseDialog() {
    f137El("f137_newCourseName").value = "";
    f137OpenMini("f137CourseDialog");
    setTimeout(() => f137El("f137_newCourseName").focus(), 50);
}

function closeF137CourseDialog() {
    f137El("f137CourseDialog").classList.remove("active");
}

async function saveF137Course() {
    const course = f137El("f137_newCourseName").value.trim();
    if (!course) { alert("Enter the course name."); return; }

    if (ascbCoursesCache.some(c => c.toLowerCase() === course.toLowerCase())) {
        alert("This course is already saved.");
        return;
    }

    const result = await ascbApiPost("api/courses.php", { action: "add", name: course });
    if (!result.ok) {
        alert(result.error || "Unable to save the course.");
        return;
    }

    ascbCoursesCache.push(course);
    f137LoadCourses(course);
    closeF137CourseDialog();
    f137Save();
}

async function f137DeleteSelectedSchool() {
    const select = f137El("f137_schoolSelect");
    if (!select.value) return;
    if (!(await ascbConfirm("Remove this school from the saved dropdown?"))) return;

    const name = select.value;
    const result = await ascbApiPost("api/schools.php", { action: "delete", name });
    if (!result.ok) {
        alert(result.error || "Unable to delete the school.");
        return;
    }

    ascbSchoolsCache = ascbSchoolsCache.filter(s => s.name !== name);
    f137LoadSchools();
    f137El("f137_schoolAddress").value = "";
    f137UpdatePreview();
    f137Save();
}

async function f137DeleteSelectedCourse() {
    const select = f137El("f137_courseSelect");
    if (!select.value) return;
    if (!(await ascbConfirm("Remove this course from the saved dropdown?"))) return;

    const name = select.value;
    const result = await ascbApiPost("api/courses.php", { action: "delete", name });
    if (!result.ok) {
        alert(result.error || "Unable to delete the course.");
        return;
    }

    ascbCoursesCache = ascbCoursesCache.filter(c => c !== name);
    f137LoadCourses();
    f137Save();
}

function f137Save() {
    const data = {
        students: f137Students,
        school: f137El("f137_schoolSelect")?.value || "",
        schoolAddress: f137El("f137_schoolAddress")?.value || "",
        studentName: f137El("f137_studentName")?.value || "",
        course: f137El("f137_courseSelect")?.value || "",
        schoolYear: f137El("f137_schoolYear")?.value || "",
        yearSection: f137El("f137_yearSection")?.value || "",
        requestDate: f137El("f137_requestDate")?.value || "",
        firstRequest: !!f137El("f137_firstRequest")?.checked,
        secondRequest: !!f137El("f137_secondRequest")?.checked,
        urgentRequest: !!f137El("f137_urgentRequest")?.checked,
        bearerRequest: !!f137El("f137_bearerRequest")?.checked,
        copyForASCB: !!f137El("f137_copyForASCB")?.checked
    };
    sessionStorage.setItem(F137_FORM_KEY, JSON.stringify(data));
}

function f137LoadSaved() {
    try {
        const saved = sessionStorage.getItem(F137_FORM_KEY);
        if (!saved) {
            f137RenderStudentList();
            return;
        }
        const data = JSON.parse(saved);
        f137Students = Array.isArray(data.students) ? data.students : [];
        f137LoadSchools(data.school || "");
        f137El("f137_schoolAddress").value = data.schoolAddress || f137El("f137_schoolAddress").value;
        f137LoadCourses(data.course || "");
        f137El("f137_studentName").value = data.studentName || "";
        f137El("f137_schoolYear").value = data.schoolYear || "";
        f137El("f137_yearSection").value = data.yearSection || "";
        f137El("f137_requestDate").value = data.requestDate || f137Today();
        f137El("f137_firstRequest").checked = !!data.firstRequest;
        f137El("f137_secondRequest").checked = !!data.secondRequest;
        f137El("f137_urgentRequest").checked = !!data.urgentRequest;
        f137El("f137_bearerRequest").checked = !!data.bearerRequest;
        f137El("f137_copyForASCB").checked = !!data.copyForASCB;
        f137RenderStudentList();
    } catch (error) {
        console.error("Form 137 load error:", error);
    }
}

async function clearForm137() {
    if (!(await ascbConfirm("Clear all Form 137 request information?"))) return;
    ascbF137EditingId = null;
    const ascbF137Banner = document.getElementById("ascbF137EditBanner");
    if (ascbF137Banner) ascbF137Banner.remove();
    f137Students = [];
    ["f137_studentName","f137_schoolYear","f137_yearSection","f137_schoolAddress"].forEach(id => {
        f137El(id).value = "";
    });
    f137El("f137_courseSelect").value = "";
    f137El("f137_schoolSelect").value = "";
    f137El("f137_requestDate").value = f137Today();
    ["f137_firstRequest","f137_secondRequest","f137_urgentRequest","f137_bearerRequest","f137_copyForASCB"].forEach(id => {
        f137El(id).checked = false;
    });
    f137RenderStudentList();
    f137UpdatePreview();
    f137Save();
}

function printForm137() {
    // Update preview bago mag-print
    f137UpdatePreview();

    const area = document.getElementById("f137PrintArea");
    const modal = document.getElementById("form137PreviewModal");

    if (!area || !modal) {
        alert("Form 137 print area is not available.");
        return;
    }

    if (!f137Students || f137Students.length === 0) {
        alert("Please add at least one student before printing.");
        return;
    }

    const schoolSelect = document.getElementById("f137_schoolSelect");

    if (!schoolSelect || !schoolSelect.value) {
        alert("Please select a receiving school before printing.");
        return;
    }

    // Ipakita ang preview
    modal.classList.add("active");

    // Activate print mode
    document.body.classList.add("f137-printing");

    // Cleanup pagkatapos lamang ng print
    const cleanup = () => {
        document.body.classList.remove("f137-printing");
        window.removeEventListener("afterprint", cleanup);
    };

    window.addEventListener("afterprint", cleanup);

    // Hintayin munang ma-render ang lahat
    const startPrint = () => {

        // Force browser layout refresh
        area.offsetHeight;

        requestAnimationFrame(() => {
            requestAnimationFrame(() => {

                window.print();

            });
        });
    };

    // Hintayin ang fonts
    if (document.fonts && document.fonts.ready) {

        document.fonts.ready.then(startPrint);

    } else {

        startPrint();

    }
}

/* =========================================================
   DASHBOARD STATS — Enrollment Overview
   TOTAL ENROLLED (isang beses lang bawat estudyante kahit
   ilang term na siya), MALE/FEMALE, at breakdown kada
   Course/Program — mula sa api/dashboard_stats.php.
   ========================================================= */

function ascbOpenPendingEnrollment() {
    // The enrollee list is rendered in the New Term/Enrollees view,
    // but it uses the same Enrollment API and loader. Open that view
    // and force the server-side status filter to Pending.
    const filter = document.getElementById("enrollStatusFilterInput");
    if (filter) filter.value = "pending";

    // Reset search and pagination so the user sees the complete pending queue.
    const search = document.getElementById("enrollSearchInput");
    if (search) search.value = "";
    if (typeof ascbEnrollPage !== "undefined") ascbEnrollPage = 1;
    if (typeof ascbEnrollShowAll !== "undefined") ascbEnrollShowAll = false;

    if (typeof ascbNavigate === "function") ascbNavigate("newterm");
    if (typeof ascbLoadEnrollment === "function") ascbLoadEnrollment();

    // Keep keyboard/focus behavior predictable after navigation.
    if (filter) setTimeout(() => filter.focus(), 50);
}

function ascbEscapeHtml(str) {
    return String(str ?? '').replace(/[&<>"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}

async function ascbLoadRegistrarAnalytics() {
    // DEAN accounts do not have the Registrar Analytics panel. Avoid making
    // an unnecessary analytics API request for those accounts.
    if (typeof ASCB_CURRENT_USER !== "undefined" && ASCB_CURRENT_USER && String(ASCB_CURRENT_USER.role || '').toUpperCase() === 'DEAN') {
        return;
    }
    const status = document.getElementById('analyticsStatus');
    const grid = document.getElementById('analyticsKpiGrid');
    const panels = document.getElementById('analyticsPanels');
    if (status) { status.style.display='block'; status.textContent='Loading analytics…'; }
    try {
        const trimester = document.getElementById('dashboardTrimesterFilter')?.value || '';
        const schoolYear = document.getElementById('dashboardSchoolYearFilter')?.value.trim() || '';
        const qs = new URLSearchParams({trimester, school_year:schoolYear});
        const r = await fetch('api/registrar_analytics.php?' + qs.toString(), {headers:{Accept:'application/json'},credentials:'same-origin',cache:'no-store'});
        const d = await r.json();
        if (!r.ok || !d.ok) throw new Error((d && d.error) ? d.error : ('Analytics API failed (HTTP ' + r.status + ')'));
        const fmt=n=>Number(n||0).toLocaleString();
        /* Null-safe setter: a missing KPI element (or a missing field in the
           API response) must never abort the rest of the analytics render. */
        const setText=(id,val)=>{const el=document.getElementById(id); if(el) el.textContent=fmt(val);};
        const sum=d.summary||{}, qu=d.queues||{}, sv=d.services||{};
        setText('analyticsTotal',sum.total);
        setText('analyticsPending',qu.pending);
        setText('analyticsDocuments',sv.documents);
        setText('analyticsCertificates',sv.certificates);
        setText('analyticsCourseFiles',sv.courseFiles);
        setText('analyticsSO',sv.approvedSO);
        setText('analyticsScannedDocuments',sv.scannedDocuments);
        const bars=(rows,labelKey)=>{
            const el=document.getElementById(labelKey==='course'?'analyticsCourseBars':'analyticsYearBars');
            if(!el) return;
            const max=Math.max(...rows.map(x=>Number(x.total||0)),1);
            el.innerHTML=rows.length?rows.map(x=>`<div class="analytics-bar-row"><div class="analytics-bar-label"><span>${ascbEscapeHtml(x[labelKey==='course'?'course':'year_level'])}</span><strong>${fmt(x.total)}</strong></div><div class="analytics-bar-track"><i style="width:${Math.max(3,(Number(x.total||0)/max)*100)}%"></i></div></div>`).join(''):'<div class="analytics-empty">No data</div>';
        };
        bars(d.byCourse||[],'course'); bars(d.byYearLevel||[],'year');
        const st=[['Regular',sum.regular_students],['Transferee',sum.transferees],['Irregular',sum.irregular_students]];
        const elType=document.getElementById('analyticsStudentType'); if(elType) elType.innerHTML=st.map(x=>`<div><span>${x[0]}</span><strong>${fmt(x[1])}</strong></div>`).join('');
        const elQueue=document.getElementById('analyticsQueue'); if(elQueue) elQueue.innerHTML=[['Pending Enrollment',qu.pending,'⏳'],['Pending Corrections',qu.correctionPending,'✎'],['Rejected Records',qu.rejected,'⚠'],['Archived Records',qu.archived,'🗄']].map(x=>`<div><span>${x[2]}</span><label>${x[0]}</label><strong>${fmt(x[1])}</strong></div>`).join('');
        const daily=d.daily30||[]; const maxD=Math.max(...daily.map(x=>Number(x.total||0)),1);
        const elDaily=document.getElementById('analyticsDaily'); if(elDaily) elDaily.innerHTML=daily.length?daily.map(x=>{const n=Number(x.total||0); const h=Math.max(5,(n/maxD)*100); return `<div class="analytics-day"><span title="${x.day}" style="--h:${h}%"></span><small>${n}</small></div>`}).join(''):'<div class="analytics-empty">No recent enrollment activity</div>';
        const elAct=document.getElementById('analyticsActivity'); if(elAct) elAct.innerHTML=(d.activity30||[]).length?(d.activity30||[]).map(x=>`<div><span>${ascbEscapeHtml(x.action||'Activity')}</span><strong>${fmt(x.total)}</strong></div>`).join(''):'<div class="analytics-empty">No recent activity</div>';
        if (status) status.style.display='none'; if(grid) grid.style.display='grid'; if(panels) panels.style.display='grid';
    } catch(e) { console.error('Registrar analytics failed:',e); if(status) status.textContent='Unable to load analytics: ' + (e && e.message ? e.message : 'unknown error') + '. Please reload the page or contact IT/Admin.'; }
}

async function ascbLoadDashboardStats() {
    const status = document.getElementById("dashboardStatsStatus");
    const cards = document.getElementById("dashboardStatsCards");
    const courseStats = document.getElementById("dashboardCourseStats");

    if (status) {
        status.style.display = "block";
        status.textContent = "Loading…";
    }
    if (cards) cards.style.display = "none";
    if (courseStats) courseStats.style.display = "none";

    try {
        const trimester = document.getElementById("dashboardTrimesterFilter")
            ? document.getElementById("dashboardTrimesterFilter").value
            : "";
        const schoolYear = document.getElementById("dashboardSchoolYearFilter")
            ? document.getElementById("dashboardSchoolYearFilter").value.trim()
            : "";
        const response = await fetch("api/dashboard_stats.php?trimester=" + encodeURIComponent(trimester) + "&school_year=" + encodeURIComponent(schoolYear), {
            headers: { "Accept": "application/json" },
            credentials: "same-origin",
            cache: "no-store"
        });

        const contentType = response.headers.get("content-type") || "";
        let data = null;
        if (contentType.indexOf("application/json") !== -1) {
            try {
                data = await response.json();
            } catch (parseErr) {
                console.error("Dashboard API returned invalid JSON:", response.status, parseErr);
            }
        } else {
            const raw = await response.text();
            console.error("Dashboard API returned non-JSON response:", response.status, raw.slice(0, 500));
        }

        if (!response.ok || !data || !data.ok) {
            /* Specific, actionable message (hindi generic) + technical detail sa console. */
            let reason;
            if (response.status === 401) {
                reason = "Your session has expired. Please log in again.";
                if (status) status.textContent = "Unable to load dashboard stats: " + reason;
                setTimeout(() => { window.location.href = "./"; }, 2000);
                return;
            } else if (response.status === 403) {
                reason = (data && data.error) ? data.error : "You do not have permission to view the dashboard statistics.";
            } else if (data && data.error) {
                reason = data.error;
            } else if (response.status >= 500) {
                reason = "The server reported an error (HTTP " + response.status + "). Check the PHP error log or contact IT/Admin.";
            } else {
                reason = "The server returned an unexpected response (HTTP " + response.status + ").";
            }
            console.error("Dashboard stats failed:", response.status, data);
            if (status) status.textContent = "Unable to load dashboard stats: " + reason;
            return;
        }

        const totalEl = document.getElementById("dashboardStatTotal");
        const maleEl = document.getElementById("dashboardStatMale");
        const femaleEl = document.getElementById("dashboardStatFemale");
        if (totalEl) totalEl.textContent = Number(data.totalEnrolled || 0).toLocaleString();
        if (maleEl) maleEl.textContent = Number(data.male || 0).toLocaleString();
        if (femaleEl) femaleEl.textContent = Number(data.female || 0).toLocaleString();

        const byCourse = Array.isArray(data.byCourse) ? data.byCourse : [];
        if (courseStats) {
            courseStats.innerHTML = byCourse.length
                ? byCourse.map(row => {
                    const total = Number(row.total || 0);
                    const overall = Number(data.totalEnrolled || 0);
                    const pct = overall > 0 ? Math.min(100, Math.round((total / overall) * 100)) : 0;
                    return `
                    <div class="dashboard-course-item">
                        <div class="dashboard-course-head">
                            <span class="dashboard-course-name">${escapeHTML(row.course || "Unspecified")}</span>
                            <strong class="dashboard-course-total">${total.toLocaleString()}</strong>
                        </div>
                        <div class="dashboard-course-progress" aria-hidden="true"><span style="width:${pct}%"></span></div>
                        <div class="dashboard-course-breakdown">
                            <span class="dashboard-course-count is-male">Male <strong>${Number(row.male || 0).toLocaleString()}</strong></span>
                            <span class="dashboard-course-count is-female">Female <strong>${Number(row.female || 0).toLocaleString()}</strong></span>
                            <span class="dashboard-course-percent">${pct}% of total</span>
                        </div>
                    </div>`;
                }).join("")
                : `<div class="dashboard-course-item-empty">No students found.</div>`;
        }

        if (status) status.style.display = "none";
        if (cards) cards.style.display = "grid";
        if (courseStats) courseStats.style.display = "grid";

    } catch (error) {
        console.error("Dashboard stats load failed:", error);
        if (status) status.textContent = "Unable to reach the server. Please check your connection or refresh the page.";
    }
}

/* "📄 Summary Report" button — ini-export bilang PDF ang official-style Summary of Enrollment
   Enrollment Overview (parehong datos na nakikita sa cards/breakdown
   sa itaas), naka-filter ayon sa napiling School Year at Trimester.
   Simpleng GET navigation lang ito papunta sa
   api/dashboard_stats_export.php, kaya awtomatikong mag-do-download
   ang browser ng file. */
function ascbExportDashboardReport() {
    const trimester = document.getElementById("dashboardTrimesterFilter")
        ? document.getElementById("dashboardTrimesterFilter").value
        : "";
    const schoolYear = document.getElementById("dashboardSchoolYearFilter")
        ? document.getElementById("dashboardSchoolYearFilter").value.trim()
        : "";
    // By Department / by Course — parehong dropdown gaya ng Department
    // Export. Optional; kung wala, lahat ng Department ang ilalabas
    // (parehong gawi gaya ng dati).
    const departmentId = ascbAdminEl("dashboardReportDepartment")?.value || "";
    const programId = ascbAdminEl("dashboardReportCourse")?.value || "";
    const q = new URLSearchParams({csrf: ASCB_CSRF_TOKEN}); if (trimester) q.set("trimester", trimester); if (schoolYear) q.set("school_year", schoolYear); if (departmentId) q.set("department_id", departmentId); if (programId) q.set("program_id", programId); window.location.href = "api/dashboard_summary_enrollment_pdf.php?" + q.toString();
}

/* Dependent "Course" dropdown for the Dashboard's Summary Report filter —
   same pattern as ascbLoadDeptExportCourses(), scoped to whichever
   Department is currently selected in dashboardReportDepartment. */
async function ascbLoadDashboardReportCourses() {
    const dep = Number(ascbAdminEl("dashboardReportDepartment")?.value || ASCB_CURRENT_USER?.departmentId || 0);
    const sel = ascbAdminEl("dashboardReportCourse");
    if (!sel) return;
    const cur = sel.value;
    sel.innerHTML = "<option value=\"\">— All Courses —</option>";
    if (!dep) return;
    const data = await ascbApiPost("api/programs.php", {action: "list"});
    if (!data.ok) return;
    const rows = (Array.isArray(data.programs) ? data.programs : []).filter(r => Number(r.department_id) === dep);
    sel.innerHTML = "<option value=\"\">— All Courses —</option>" + rows.map(r => `<option value="${Number(r.id)}">${escapeHTML(r.code || "")} — ${escapeHTML(r.course_name || "")}${r.major ? (" — " + escapeHTML(r.major)) : ""}</option>`).join("");
    if (cur) sel.value = cur;
}


/* =========================================================
   DARK MODE / THEME
   Theme is stored in localStorage ("ascbTheme": "light" |
   "dark") and applied via a `data-theme` attribute on
   <html>. The attribute itself is already set as early as
   possible by an inline script in dashboard.php's <head> so
   there is no light-mode flash on load — this section just
   keeps every on-screen switch (sidebar quick toggle +
   Settings > Appearance) in sync with that state.
   ========================================================= */

function ascbGetTheme() {
    return localStorage.getItem("ascbTheme") === "dark" ? "dark" : "light";
}

function ascbApplyTheme(theme) {
    const isDark = theme === "dark";
    document.documentElement.setAttribute("data-theme", isDark ? "dark" : "light");
    localStorage.setItem("ascbTheme", isDark ? "dark" : "light");
    ascbSyncThemeControls(isDark);
}

function ascbToggleTheme() {
    ascbApplyTheme(ascbGetTheme() === "dark" ? "light" : "dark");
}

function ascbSyncThemeControls(isDark) {
    document.querySelectorAll("[data-theme-switch]").forEach((el) => {
        el.setAttribute("aria-checked", isDark ? "true" : "false");
        el.classList.toggle("is-dark", isDark);
    });
    document.querySelectorAll("[data-theme-quick-toggle]").forEach((el) => {
        el.innerHTML = isDark
            ? '<span class="theme-quick-toggle-icon">☀</span> Light Mode'
            : '<span class="theme-quick-toggle-icon">🌙</span> Dark Mode';
    });
    document.querySelectorAll("[data-theme-status]").forEach((el) => {
        el.textContent = isDark ? "Dark mode is on." : "Light mode is on.";
    });
}

/* Prevent browser/password-manager autofill from copying the saved admin username into search boxes.
   Search inputs are never credentials; clear only autofilled values that are present before the user interacts. */
(function ascbProtectSearchAutofill(){
    const SEARCH_IDS = [
        "recordsSearchInput","docsSearchInput","enrollSearchInput","rejectedSearchInput",
        "archiveSearchInput","gradeMgmtSearchInput","gradeEvalSearchInput","honorsSearchInput",
        "soSearchInput","cfSearchInput","userSearchInput","admSchoolSearchInput",
        "admCourseSearchInput","deptAssign_search","admProgSearchInput","logSearchInput"
    ];
    function clearCredentialAutofill(){
        SEARCH_IDS.forEach(function(id){
            const el=document.getElementById(id);
            if(!el || el.dataset.ascbUserTyped === "1") return;
            const v=String(el.value || "").trim().toLowerCase();
            if(v === "admin") el.value="";
        });
    }
    function markTyped(e){
        const el=e.target;
        if(el && SEARCH_IDS.indexOf(el.id)!==-1) el.dataset.ascbUserTyped="1";
    }
    document.addEventListener("input", markTyped, true);
    document.addEventListener("change", markTyped, true);
    document.addEventListener("DOMContentLoaded", clearCredentialAutofill);
    window.addEventListener("pageshow", clearCredentialAutofill);
    if(document.readyState !== "loading") clearCredentialAutofill();
    [50, 250, 750, 1500, 3000].forEach(function(ms){ setTimeout(clearCredentialAutofill, ms); });
})();

document.addEventListener("DOMContentLoaded", () => {
    ascbSyncThemeControls(ascbGetTheme() === "dark");
    const gradeMgmtNav = document.getElementById("navGradeManagement");
    // (Grade Management visibility) Kasama na rin dito ang mga role na may
    // 'requestRecordCorrection' lang (hal. ADMIN STAFF), kahit wala silang
    // 'manageGrades' — makikita nila ang module para makapag-request ng
    // Subject/Grade Correction, pero hindi sila makaka-direktang mag-edit
    // ng grades (see ascbGradeManagementShowTerm / api/grades.php guard).
    if (gradeMgmtNav && typeof ASCB_PERMISSIONS !== "undefined" && !ASCB_PERMISSIONS.manageGrades && !ASCB_PERMISSIONS.requestRecordCorrection) gradeMgmtNav.style.display = "none";
    // (2024 audit fix) These four modules are now server-side restricted
    // (see includes/permissions.php: manage_office_records / view_records_log) —
    // hide the nav buttons too so a restricted role (currently DEAN) doesn't
    // see a link that will just 403. This is UI convenience only, same as
    // every other ASCB_PERMISSIONS check in this file; the api/*.php guard
    // is the real security boundary.
    if (typeof ASCB_PERMISSIONS !== "undefined") {
        const recordsNav = document.getElementById("navRecords");
        if (recordsNav && !ASCB_PERMISSIONS.viewRecordsLog) recordsNav.style.display = "none";
        ["navApprovedSO"].forEach((navId) => {
            const navEl = document.getElementById(navId);
            if (navEl && !ASCB_PERMISSIONS.manageOfficeRecords) navEl.style.display = "none";
        });
    }
    // Navbar-only visibility request: DEAN accounts should not see these
    // links in the sidebar at all (regardless of the permission matrix
    // above). This is UI hiding only, same convention as the rest of this
    // block — it does not change what the DEAN role is allowed to do via
    // the api/*.php endpoints.
    if (typeof ASCB_CURRENT_USER !== "undefined" && ASCB_CURRENT_USER && ASCB_CURRENT_USER.role === "DEAN") {
        ["navEnrollment", "navNewTerm", "navCertificates", "navForm137", "navRejected", "navArchive"].forEach((navId) => {
            const navEl = document.getElementById(navId);
            if (navEl) navEl.style.display = "none";
        });
    }
    /* ROOT-CAUSE FIX (Dashboard stuck on "Loading…"):
       Dati, ang handler na ito ay tumatawag ng ascbDocsSetup() — pero WALANG
       definition ang function na iyon kahit saan (inalis na ang Documents
       module pero naiwan ang tawag). Nag-throw ito ng ReferenceError, kaya
       HINDI na tumakbo ang lahat ng kasunod: ascbLoadDashboardStats(),
       analytics, departments, badges at clock → laging "Loading…".
       Ngayon, bawat init step ay hiwalay na protektado: kung may isang
       pumalya, naka-log ito sa console pero tuloy pa rin ang iba. */
    const ascbSafeInit = (label, fn) => {
        try {
            const result = fn();
            if (result && typeof result.catch === "function") {
                result.catch((err) => console.error("ASCB init failed [" + label + "]:", err));
            }
        } catch (err) {
            console.error("ASCB init failed [" + label + "]:", err);
        }
    };
    ascbSafeInit("birthdate selects (new)", () => ascbEnrollPopulateBirthdateSelects("enroll_birthMonth", "enroll_birthDay", "enroll_birthYear"));
    ascbSafeInit("birthdate selects (edit)", () => ascbEnrollPopulateBirthdateSelects("enroll_edit_birthMonth", "enroll_edit_birthDay", "enroll_edit_birthYear"));
    ascbSafeInit("form137 setup", () => f137Setup());
    // Dashboard cards ang pinakaunang dapat mag-load — huwag nang ipagpaliban.
    ascbSafeInit("dashboard stats", () => ascbLoadDashboardStats());
    ascbSafeInit("registrar analytics", () => ascbLoadRegistrarAnalytics());
    // Kailangan ito para may laman agad ang "By Department" filter ng
    // Summary Report kahit hindi pa binubuksan ang Admin > Departments panel.
    ascbSafeInit("departments", () => ascbLoadDepartments(true));
    ascbSafeInit("correction badge", () => ascbRefreshCorrectionBadge());
    ascbSafeInit("enrollment badge", () => ascbRefreshEnrollmentBadge());
    ascbSafeInit("grade approval badge", () => ascbRefreshApprovalBadge());
    setInterval(() => ascbSafeInit("grade approval badge (poll)", () => ascbRefreshApprovalBadge()), 30000);
    document.addEventListener("visibilitychange", () => { if (!document.hidden) ascbSafeInit("grade approval badge (visible)", () => ascbRefreshApprovalBadge()); });
    setInterval(() => ascbSafeInit("correction badge (poll)", () => ascbRefreshCorrectionBadge()), 60000);
    setInterval(() => ascbSafeInit("enrollment badge (poll)", () => ascbRefreshEnrollmentBadge()), 60000);
    // initBlueFireworks(); // temporarily disabled
    ascbSafeInit("dashboard clock", () => ascbInitDashboardClock());
});

/* =========================================================
   DASHBOARD HERO CLOCK — round analog clock, digital time,
   at mini calendar sa right side ng Dashboard banner. Client-side
   lang ito (gamit ang oras ng browser/device ng user) — walang
   kinukunang oras sa server, kaya UI convenience lang ito, hindi
   authoritative timestamp source.
========================================================= */
function ascbInitDashboardClock() {
    // Reuse one timer only. Rebind to the current DOM nodes on every tick,
    // because dashboard content can be replaced while navigating the SPA.
    if (window.__ascbDashboardClockTimer) {
        window.clearInterval(window.__ascbDashboardClockTimer);
        window.__ascbDashboardClockTimer = null;
    }

    const MONTHS_SHORT = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
    const WEEKDAYS_LONG = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

    function tick() {
        // Query live elements each time, not once during initialization.
        const hourHand = document.getElementById("dashboardClockHourHand");
        const minuteHand = document.getElementById("dashboardClockMinuteHand");
        const secondHand = document.getElementById("dashboardClockSecondHand");
        const digitalEl = document.getElementById("dashboardDigitalClock");
        const calMonthEl = document.getElementById("dashboardCalendarMonth");
        const calDayEl = document.getElementById("dashboardCalendarDay");
        const calWeekdayEl = document.getElementById("dashboardCalendarWeekday");

        // No clock on this page/view; keep the timer alive so it recovers if
        // the dashboard widget is inserted again later.
        if (!hourHand || !minuteHand || !secondHand || !digitalEl) return;

        const now = new Date();
        const hours24 = now.getHours();
        const minutes = now.getMinutes();
        const seconds = now.getSeconds();
        const hours12 = hours24 % 12;
        const secondDeg = seconds * 6;
        const minuteDeg = minutes * 6 + seconds * 0.1;
        const hourDeg = hours12 * 30 + minutes * 0.5;

        hourHand.style.transform = `rotate(${hourDeg}deg)`;
        minuteHand.style.transform = `rotate(${minuteDeg}deg)`;
        secondHand.style.transform = `rotate(${secondDeg}deg)`;

        const displayHour = hours12 === 0 ? 12 : hours12;
        const pad2 = (n) => String(n).padStart(2, "0");
        const ampm = hours24 < 12 ? "AM" : "PM";
        digitalEl.textContent = `${displayHour}:${pad2(minutes)}:${pad2(seconds)} ${ampm}`;

        if (calMonthEl) calMonthEl.textContent = MONTHS_SHORT[now.getMonth()];
        if (calDayEl) calDayEl.textContent = String(now.getDate());
        if (calWeekdayEl) calWeekdayEl.textContent = WEEKDAYS_LONG[now.getDay()];
    }

    tick();
    window.__ascbDashboardClockTimer = window.setInterval(tick, 1000);
}

// Recover after browser tab restore / returning from another page. The
// initializer itself guards against creating duplicate intervals.
if (!window.__ascbDashboardClockLifecycleBound) {
    window.__ascbDashboardClockLifecycleBound = true;
    window.addEventListener("pageshow", function () {
        ascbInitDashboardClock();
    });
    document.addEventListener("visibilitychange", function () {
        if (!document.hidden) ascbInitDashboardClock();
    });
}

/* Pending Correction Request notification badge — para agad
   mapansin ng UNIT HEAD (approve_record_correction lang) kapag
   may bagong Subject/Grade correction request na naghihintay ng
   review, kahit hindi pa nabubuksan ang Correction Requests modal.
   Nagre-refresh ito paminsan-minsan (60s) at pagkatapos ng bawat
   approve/reject action. UI convenience lang ito — ang totoong
   access control ay nasa includes/permissions.php pa rin. */
async function ascbRefreshCorrectionBadge() {
    if (typeof ASCB_PERMISSIONS === "undefined" || !ASCB_PERMISSIONS.approveRecordCorrection) return;
    try {
        const res = await fetch('api/record_corrections.php?status=PENDING');
        const data = await res.json();
        const count = (res.ok && data && data.ok && Array.isArray(data.rows)) ? data.rows.length : 0;
        window.__ascbCorrectionCount = count;
        [ "gradeCorrectionReviewBtnBadge" ].forEach(id => {
            const el = document.getElementById(id);
            if (!el) return;
            if (count > 0) { el.textContent = count > 99 ? "99+" : String(count); el.style.display = "inline-flex"; }
            else { el.style.display = "none"; }
        });
    } catch (e) {
        console.error('Correction badge refresh failed:', e);
    }
    ascbRenderGradeMgmtNavBadge();
}

/* =========================================================
   GRADE APPROVAL NOTIFICATION (UNIT HEAD / SCHOOL REGISTRAR)
   - Badge sa sidebar "Grade Management" (kasama ang pending Correction Requests)
   - Badge sa "Grade Approval Workflow" button
   - Corner notice (hindi nakaharang) na may "Review now" kapag may bagong submission
   - Bilang sa tab title, para makita kahit nasa ibang tab
   Magaan na COUNT lang ang tinatawag (api/gradebook_approvals.php?action=pending_count),
   nagre-refresh bawat 30s, kapag bumalik sa tab, at pagkatapos ng approve/reject.
   UI convenience lang ito — ang totoong access control ay nasa api pa rin.
   ========================================================= */
window.__ascbCorrectionCount = window.__ascbCorrectionCount || 0;
window.__ascbApprovalCount = 0;
window.__ascbBaseTitle = window.__ascbBaseTitle || document.title;

function ascbRenderGradeMgmtNavBadge() {
    const el = document.getElementById("gradeMgmtNavBadge");
    if (!el) return;
    const corr = Number(window.__ascbCorrectionCount) || 0;
    const appr = Number(window.__ascbApprovalCount) || 0;
    const total = corr + appr;
    if (total > 0) {
        el.textContent = total > 99 ? "99+" : String(total);
        el.style.display = "inline-flex";
        const parts = [];
        if (appr) parts.push(appr + " grade submission" + (appr === 1 ? "" : "s") + " awaiting approval");
        if (corr) parts.push(corr + " correction request" + (corr === 1 ? "" : "s"));
        el.title = parts.join(" • ");
    } else {
        el.style.display = "none";
    }
}

function ascbHideApprovalNotice() {
    const n = document.getElementById("gbaNotice");
    if (!n) return;
    n.classList.remove("show");
    setTimeout(() => { if (n.parentNode && !n.classList.contains("show")) n.parentNode.removeChild(n); }, 250);
}

function ascbShowApprovalNotice(data) {
    ascbHideApprovalNotice();
    const count = Number(data.count) || 0;
    const items = Number(data.items) || 0;
    const roleLabel = (data.role === "SCHOOL REGISTRAR") ? "final approval" : "your approval";
    const depts = (data.departments || []).map(d => String(d.name) + " (" + d.n + ")").join(", ");
    const box = document.createElement("div");
    box.id = "gbaNotice";
    box.className = "gba-notice";
    box.setAttribute("role", "status");
    box.setAttribute("aria-live", "polite");
    const icon = document.createElement("div"); icon.className = "gba-notice-icon"; icon.textContent = "🔔";
    const body = document.createElement("div"); body.className = "gba-notice-body";
    const title = document.createElement("strong");
    title.textContent = count + " grade submission" + (count === 1 ? "" : "s") + " waiting for " + roleLabel;
    const sub = document.createElement("span");
    sub.textContent = (items ? items + " grade" + (items === 1 ? "" : "s") + " to review" : "") + (depts ? (items ? " • " : "") + depts : "");
    body.appendChild(title); if (sub.textContent) body.appendChild(sub);
    const actions = document.createElement("div"); actions.className = "gba-notice-actions";
    const go = document.createElement("button"); go.type = "button"; go.className = "gba-notice-go"; go.textContent = "Review now";
    go.onclick = function () { ascbHideApprovalNotice(); ascbOpenApprovalsFromNotice(); };
    const x = document.createElement("button"); x.type = "button"; x.className = "gba-notice-x"; x.setAttribute("aria-label", "Dismiss"); x.textContent = "×";
    x.onclick = ascbHideApprovalNotice;
    actions.appendChild(go); actions.appendChild(x);
    box.appendChild(icon); box.appendChild(body); box.appendChild(actions);
    document.body.appendChild(box);
    requestAnimationFrame(() => box.classList.add("show"));
    clearTimeout(window.__ascbApprovalNoticeTimer);
    window.__ascbApprovalNoticeTimer = setTimeout(ascbHideApprovalNotice, 15000);
}

function ascbOpenApprovalsFromNotice() {
    try { ascbNavigate("grademanagement"); ascbLoadGradeManagement(); } catch (e) { console.error(e); }
    setTimeout(() => { try { ascbGradebookApprovalsOpen(); } catch (e) { console.error(e); } }, 150);
}

async function ascbRefreshApprovalBadge() {
    const role = String((typeof ASCB_CURRENT_USER !== "undefined" && ASCB_CURRENT_USER && ASCB_CURRENT_USER.role) || "").toUpperCase();
    if (role !== "UNIT HEAD" && role !== "SCHOOL REGISTRAR") return;
    try {
        const res = await fetch("api/gradebook_approvals.php?action=pending_count", { cache: "no-store" });
        const data = await res.json();
        if (!res.ok || !data || !data.ok) return;
        const count = Number(data.count) || 0;
        const prevCount = window.__ascbApprovalCount;
        const prevLatest = window.__ascbApprovalLatest;
        window.__ascbApprovalCount = count;
        window.__ascbApprovalLatest = Number(data.latest_id) || 0;

        const btnBadge = document.getElementById("gradebookApprovalWorkflowBadge");
        if (btnBadge) {
            if (count > 0) { btnBadge.textContent = count > 99 ? "99+" : String(count); btnBadge.style.display = "inline-flex"; btnBadge.title = count + " submission" + (count === 1 ? "" : "s") + " awaiting approval"; }
            else btnBadge.style.display = "none";
        }
        ascbRenderGradeMgmtNavBadge();
        document.title = (count > 0 ? "(" + count + ") " : "") + window.__ascbBaseTitle;

        /* Corner notice: sa unang load (isang beses kada bagong listahan sa session) at kapag may BAGONG submission. */
        let sig = String(count) + ":" + String(data.latest_id || 0), seen = null;
        try { seen = sessionStorage.getItem("ascb_gba_notified"); } catch (e) { /* walang storage: ok lang */ }
        const isNew = (prevLatest !== undefined && (Number(data.latest_id) || 0) > prevLatest) || (prevCount !== undefined && count > prevCount);
        if (count > 0 && (isNew || (prevLatest === undefined && seen !== sig))) {
            ascbShowApprovalNotice(data);
            try { sessionStorage.setItem("ascb_gba_notified", sig); } catch (e) { /* ok */ }
        } else if (count === 0) {
            ascbHideApprovalNotice();
            try { sessionStorage.removeItem("ascb_gba_notified"); } catch (e) { /* ok */ }
        }
    } catch (e) {
        console.error("Approval badge refresh failed:", e);
    }
}

/* Refresh pagkatapos mag-load/mag-close ng Grade Approval Workflow (approve/reject/re-submit ay dumadaan dito). */
(function () {
    const wrap = (name, after) => {
        const orig = window[name];
        if (typeof orig !== "function" || orig.__ascbWrapped) return;
        const fn = function () {
            const r = orig.apply(this, arguments);
            Promise.resolve(r).then(after, after);
            return r;
        };
        fn.__ascbWrapped = true;
        try { window[name] = fn; } catch (e) { /* ok */ }
    };
    window.addEventListener("load", function () {
        wrap("ascbGradebookApprovalsLoad", () => ascbRefreshApprovalBadge());
        wrap("ascbGradebookApprovalsClose", () => ascbRefreshApprovalBadge());
    });
})();

/* Pending Enrollee notification badge — para agad mapansin ng
   UNIT HEAD / SCHOOL REGISTRAR (approve_enrollment lang) kapag
   may bagong enrollee (New Term) na na-encode ng ADMIN STAFF at
   naghihintay pa ng approval, kahit hindi pa nabubuksan ang New
   Term view. Sa "New Term" nav lang ito lumalabas dahil dito
   nangyayari ang approval workflow. Nagre-refresh ito paminsan-
   paminsan (60s) at pagkatapos ng bawat approve/reject action.
   UI convenience lang ito — ang totoong access control ay nasa
   api/enrollment.php pa rin. */
async function ascbRefreshEnrollmentBadge() {
    if (typeof ASCB_PERMISSIONS === "undefined" || !ASCB_PERMISSIONS.approveEnrollment) return;
    try {
        const res = await fetch('api/enrollment.php?status=pending&scope=active&limit=1&page=1');
        const data = await res.json();
        const count = (res.ok && data && data.ok) ? (Number(data.total) || 0) : 0;
        ["newTermNavBadge"].forEach(id => {
            const el = document.getElementById(id);
            if (!el) return;
            if (count > 0) { el.textContent = count > 99 ? "99+" : String(count); el.style.display = "inline-flex"; }
            else { el.style.display = "none"; }
        });
    } catch (e) {
        console.error('Enrollment badge refresh failed:', e);
    }
}



/* =========================================================
   PAGINATION HELPER (reusable sa Records, Docs, at Approved SO
   tables). Client-side lang ang pagination — ang buong filtered
   na listahan ang hinahati sa "pages" base sa ASCB_PAGE_SIZE.
   ========================================================= */

const ASCB_PAGE_SIZE = 12;

/* Ibinabalik: { pageRows, page, totalPages, total, start }
   - pageRows  = mga row na ipapakita sa kasalukuyang page
   - page      = na-clamp na page number (1-based)
   - totalPages, total = para sa "Showing X–Y of Z" at buttons */
function ascbPaginate(rows, page, pageSize) {
    const total = rows.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const clampedPage = Math.min(Math.max(1, page || 1), totalPages);
    const start = (clampedPage - 1) * pageSize;
    const pageRows = rows.slice(start, start + pageSize);
    return { pageRows, page: clampedPage, totalPages, total, start };
}

/* Nagre-render ng "Showing X–Y of Z" + Prev/Next/page-number
   buttons sa loob ng elemento na may id = containerId.
   onPageChangeFn = pangalan (string) ng global function na
   tatawagin kapag pinindot ang isang page button, e.g.
   "ascbRecordsGoToPage". */
function ascbRenderPagination(containerId, page, totalPages, total, pageSize, onPageChangeFn) {
    const el = document.getElementById(containerId);
    if (!el) return;

    if (!total) {
        el.innerHTML = "";
        return;
    }

    const start = (page - 1) * pageSize + 1;
    const end = Math.min(page * pageSize, total);

    const maxButtons = 5;
    let startPage = Math.max(1, page - Math.floor(maxButtons / 2));
    let endPage = Math.min(totalPages, startPage + maxButtons - 1);
    startPage = Math.max(1, endPage - maxButtons + 1);

    let numberButtons = "";
    for (let p = startPage; p <= endPage; p++) {
        numberButtons += `<button type="button" class="pagination-btn${p === page ? " active" : ""}" ${p === page ? 'aria-current="page"' : ""} onclick="${onPageChangeFn}(${p})">${p}</button>`;
    }

    el.innerHTML = `
        <div class="pagination-info">Showing ${start}–${end} of ${total}</div>
        <div class="pagination-controls">
            <button type="button" class="pagination-btn pagination-nav" ${page <= 1 ? "disabled" : ""} onclick="${onPageChangeFn}(${page - 1})">‹ Prev</button>
            ${numberButtons}
            <button type="button" class="pagination-btn pagination-nav" ${page >= totalPages ? "disabled" : ""} onclick="${onPageChangeFn}(${page + 1})">Next ›</button>
        </div>`;
}


/* =========================================================
   RECORDS VIEW MODULE
   Nagpapakita ng mga naka-log na Certificates at Form 137-A
   requests mula sa database, sa pamamagitan ng api/records.php.
   Ino-fetch lang ito kapag pumunta ang user sa Records view
   (tingnan ang onclick ng "Records" button sa dashboard.php).
   ========================================================= */

let ascbRecordsType = "certificates";
let ascbRecordsRows = [];
let ascbRecordsFilteredCache = [];
let ascbRecordsPage = 1;

/* Kapag hindi null, ang susunod na "SUBMIT DATA"/generateCertificate()
   ay mag-UPDATE sa record na ito (Records/History correction) sa halip
   na gumawa ng bagong hiwalay na log entry. Reprint (walang editing id)
   ay sadyang gumagawa pa rin ng bagong entry bilang audit trail ng
   bawat pag-reprint. */
let ascbF137EditingId = null;

// (bug fix) Kung papunta lang ang user sa Certificates/Form 137-A view
// mula sa normal na nav link o sa Dashboard shortcut card — HINDI mula
// sa "✏ Update" ng Records/History — dapat malinis (walang naka-stick
// na "editing mode") ang view. Kung hindi ito ire-reset dito, sakaling
// mag-"Update" ang isang tauhan tapos umalis na lang sa Certificates/
// Form 137-A view NANG HINDI pa pinipindot ang Submit, ang susunod
// niyang totoong bagong Certificate/Request ay MAI-UPDATE na lang nang
// tahimik sa DATING record sa halip na gumawa ng bago.
function ascbCertificatesNavReset() {
    const search = document.getElementById("certificateStudentSearch");
    const wasHistoricalMode = !!ascbCertificateEditingId || !!(search && search.disabled);
    ascbCertificateEditingId = null;
    const banner = document.getElementById("ascbCertEditBanner");
    if (banner) banner.remove();
    /* Bumalik sa Automatic kada bagong pasok sa Certificates view para
       hindi tahimik na ma-manual ang susunod na certificate. */
    if (ascbCertificateManualMode()) ascbCertificateChangeMode("AUTO");
    if (wasHistoricalMode) {
        ascbCertificateSelectedEnrollment = null;
        clearTimeout(ascbCertificateSearchTimer);
        ascbCertificateSearchRequest++;
        if (search) {
            search.disabled = false;
            search.value = "";
        }
        const searchStatus = document.getElementById("certificateStudentSearchStatus");
        if (searchStatus) {
            searchStatus.textContent = "Enter at least 2 characters. Only approved, non-archived enrollment records are shown.";
        }
        ascbCertificateRenderSearchResults([]);
        ascbCertificateClearAutofill();
        ascbCertificateSetSourceLocked(true);
    }
    ascbNavigate("certificates");
    ascbRefreshCustomPrograms();
}
function ascbForm137NavReset() {
    ascbF137EditingId = null;
    const banner = document.getElementById("ascbF137EditBanner");
    if (banner) banner.remove();
    ascbNavigate("form137");
}

function ascbRecordsEl(id) {
    return document.getElementById(id);
}

const ascbRecordsRequestGuard = ascbMakeRequestGuard();
async function ascbLoadRecords(forceType) {
    const type = forceType || ascbRecordsType;
    ascbRecordsType = type;

    const status = ascbRecordsEl("recordsStatus");
    const wrapper = ascbRecordsEl("recordsTableWrapper");

    if (status) {
        status.style.display = "block";
        status.textContent = "Loading records…";
    }
    if (wrapper) wrapper.style.display = "none";

    const ascbRecordsToken = ascbRecordsRequestGuard.start();
    try {
        const response = await fetch(`api/records.php?type=${encodeURIComponent(type)}&limit=500`);
        const data = await response.json();
        if (!ascbRecordsRequestGuard.isCurrent(ascbRecordsToken)) return; // may mas bagong request na — laktawan itong lumang resulta

        if (!data || !data.ok) {
            if (status) status.textContent = "Unable to load records. Please try again.";
            return;
        }

        ascbRecordsRows = Array.isArray(data.rows) ? data.rows : [];
        ascbRecordsPage = 1;
        ascbRecordsRenderTable();

        if (status) status.style.display = "none";
        if (wrapper) wrapper.style.display = "block";

    } catch (error) {
        if (!ascbRecordsRequestGuard.isCurrent(ascbRecordsToken)) return;
        console.error("Records load failed:", error);
        if (status) status.textContent = "Unable to reach the server. Please check your connection or refresh the page.";
    }
}

function ascbRecordsSwitchTab(type) {
    ascbRecordsType = type;

    const certTab = ascbRecordsEl("recordsTabCertificates");
    const f137Tab = ascbRecordsEl("recordsTabForm137");
    if (certTab) certTab.classList.toggle("active", type === "certificates");
    if (f137Tab) f137Tab.classList.toggle("active", type === "form137");

    const search = ascbRecordsEl("recordsSearchInput");
    if (search) search.value = "";

    ascbLoadRecords(type);
}

function ascbRecordsFilter() {
    ascbRecordsPage = 1;
    ascbRecordsRenderTable();
}

function ascbRecordsGoToPage(page) {
    ascbRecordsPage = page;
    ascbRecordsRenderTable();
}

function ascbRecordsCertLabel(type) {
    if (type === "ENROLLMENT") return "Enrollment";
    if (type === "REGISTRATION") return "Registration";
    if (type === "GRADE_EVALUATION") return "Grade Evaluation";
    return type || "—";
}

function ascbRecordsFormatDate(value, withTime) {
    if (!value) return "—";
    const d = new Date(String(value).replace(" ", "T"));
    if (Number.isNaN(d.getTime())) return value;
    const datePart = d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
    if (!withTime) return datePart;
    const timePart = d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
    return `${datePart}, ${timePart}`;
}

function ascbRecordsRenderTable() {
    const head = ascbRecordsEl("recordsTableHead");
    const body = ascbRecordsEl("recordsTableBody");
    if (!head || !body) return;

    const term = (ascbRecordsEl("recordsSearchInput")?.value || "").trim().toLowerCase();

    if (ascbRecordsType === "form137") {

        head.innerHTML = `
            <tr>
                <th>Date</th>
                <th>Receiving School</th>
                <th>Students</th>
                <th>Flags</th>
                <th>Requested By</th>
                <th></th>
            </tr>`;

        const filtered = ascbRecordsRows.filter(row => {
            if (!term) return true;
            const studentNames = (row.students || []).map(s => s.name || "").join(" ").toLowerCase();
            return (row.school_name || "").toLowerCase().includes(term) || studentNames.includes(term);
        });

        ascbRecordsFilteredCache = filtered;

        if (!filtered.length) {
            body.innerHTML = `<tr><td colspan="6" class="records-empty">Record Not Found.</td></tr>`;
            ascbRenderPagination("recordsPagination", 1, 1, 0, ASCB_PAGE_SIZE, "ascbRecordsGoToPage");
            return;
        }

        const { pageRows, page, totalPages, total, start } = ascbPaginate(filtered, ascbRecordsPage, ASCB_PAGE_SIZE);
        ascbRecordsPage = page;

        body.innerHTML = pageRows.map((row, i) => {
            const idx = start + i;
            const flags = [];
            if (Number(row.first_request) === 1) flags.push("1st");
            if (Number(row.second_request) === 1) flags.push("2nd");
            if (Number(row.urgent_request) === 1) flags.push("Urgent");
            if (Number(row.bearer_request) === 1) flags.push("Bearer");
            if (Number(row.copy_for_ascb) === 1) flags.push("Copy-ASCB");

            const studentCount = (row.students || []).length;

            return `
                <tr>
                    <td data-label="Date">${escapeHTML(ascbRecordsFormatDate(row.request_date))}</td>
                    <td data-label="Receiving School">${escapeHTML(row.school_name || "")}</td>
                    <td data-label="Students">${studentCount} student${studentCount === 1 ? "" : "s"}</td>
                    <td data-label="Flags">${escapeHTML(flags.join(", ") || "—")}</td>
                    <td data-label="Requested By">${escapeHTML(row.requested_by_name || "—")}</td>
                    <td data-label="Action" style="white-space:nowrap;">
                        <button type="button" class="btn btn-outline records-view-btn action-icon-btn" title="View" aria-label="View" onclick="ascbRecordsShowDetail('form137', ${idx})">${ascbIcon('view')}</button>
                        ${ASCB_PERMISSIONS?.manageOfficeRecords ? `<button type="button" class="btn btn-outline action-icon-btn" title="Update" aria-label="Update" onclick="ascbRecordsUpdateForm137(${idx})">${ascbIcon('edit')}</button>
                        <button type="button" class="btn btn-outline action-icon-btn" title="Reprint" aria-label="Reprint" onclick="ascbRecordsReprintForm137(${idx})">${ascbIcon('print')}</button>` : ""}
                    </td>
                </tr>`;
        }).join("");

        ascbRenderPagination("recordsPagination", page, totalPages, total, ASCB_PAGE_SIZE, "ascbRecordsGoToPage");

    } else {

        head.innerHTML = `
            <tr>
                <th>Date</th>
                <th>Type</th>
                <th>Student</th>
                <th>Student ID</th>
                <th>Program</th>
                <th>OR No.</th>
                <th>Prepared By</th>
                <th></th>
            </tr>`;

        const filtered = ascbRecordsRows.filter(row => {
            if (!term) return true;
            return ascbNameMatch(term, [row.student_name, row.student_id, row.or_number]);
        });

        ascbRecordsFilteredCache = filtered;

        if (!filtered.length) {
            body.innerHTML = `<tr><td colspan="8" class="records-empty">No Record Found</td></tr>`;
            ascbRenderPagination("recordsPagination", 1, 1, 0, ASCB_PAGE_SIZE, "ascbRecordsGoToPage");
            return;
        }

        const { pageRows, page, totalPages, total, start } = ascbPaginate(filtered, ascbRecordsPage, ASCB_PAGE_SIZE);
        ascbRecordsPage = page;

        body.innerHTML = pageRows.map((row, i) => {
            const idx = start + i;
            const programLabel = (typeof getShortProgram === "function" ? getShortProgram(row.program) : null) || row.program || "";
            return `
                <tr>
                    <td data-label="Date">${escapeHTML(ascbRecordsFormatDate(row.created_at, true))}</td>
                    <td data-label="Type">${escapeHTML(ascbRecordsCertLabel(row.certificate_type))}</td>
                    <td data-label="Student">${escapeHTML(row.student_name || "")}</td>
                    <td data-label="Student ID">${escapeHTML(row.student_id || "")}</td>
                    <td data-label="Program">${escapeHTML(programLabel)}</td>
                    <td data-label="OR No.">${escapeHTML(row.or_number || "—")}</td>
                    <td data-label="Prepared By">${escapeHTML(row.prepared_by || row.issued_by_name || "—")}</td>
                    <td data-label="Action" style="white-space:nowrap;">
                        <button type="button" class="btn btn-outline records-view-btn action-icon-btn" title="View" aria-label="View" onclick="ascbRecordsShowDetail('certificates', ${idx})">${ascbIcon('view')}</button>
                        ${ASCB_PERMISSIONS?.manageOfficeRecords ? `<button type="button" class="btn btn-outline action-icon-btn" title="Update" aria-label="Update" onclick="ascbRecordsUpdateCertificate(${idx})">${ascbIcon('edit')}</button>
                        <button type="button" class="btn btn-outline action-icon-btn" title="Reprint" aria-label="Reprint" onclick="ascbRecordsReprintCertificate(${idx})">${ascbIcon('print')}</button>` : ""}
                    </td>
                </tr>`;
        }).join("");

        ascbRenderPagination("recordsPagination", page, totalPages, total, ASCB_PAGE_SIZE, "ascbRecordsGoToPage");
    }
}

function ascbRecordsShowDetail(type, idx) {
    const row = ascbRecordsFilteredCache[idx];
    if (!row) return;

    const modal = ascbRecordsEl("recordsDetailModal");
    const title = ascbRecordsEl("recordsDetailTitle");
    const body = ascbRecordsEl("recordsDetailBody");
    if (!modal || !title || !body) return;

    if (type === "form137") {

        title.textContent = `Form 137-A Request — ${row.school_name || ""}`;

        const studentRows = (row.students || []).map(s => `
            <tr>
                <td>${escapeHTML(s.name || "")}</td>
                <td>${escapeHTML(s.course || "")}</td>
                <td>${escapeHTML(s.schoolYear || "")}</td>
                <td>${escapeHTML(s.yearSection || "")}</td>
            </tr>`).join("");

        body.innerHTML = `
            <p><strong>Request Date:</strong> ${escapeHTML(ascbRecordsFormatDate(row.request_date))}</p>
            <p><strong>Receiving School:</strong> ${escapeHTML(row.school_name || "")}</p>
            <p><strong>Address:</strong> ${escapeHTML(row.school_address || "—")}</p>
            <p><strong>Requested By:</strong> ${escapeHTML(row.requested_by_name || "—")}</p>
            <table class="f137-student-table">
                <thead><tr><th>Name</th><th>Admitted To</th><th>School Year</th><th>Year &amp; Section</th></tr></thead>
                <tbody>${studentRows || `<tr><td colspan="4">—</td></tr>`}</tbody>
            </table>`;

    } else {

        title.textContent = `${ascbRecordsCertLabel(row.certificate_type)} — ${row.student_name || ""}`;

        const subjectRows = (row.subjects || []).map(s => `
            <tr>
                <td>${escapeHTML(s.code || "")}</td>
                <td>${escapeHTML(s.description || "")}</td>
                <td>${escapeHTML(s.grade || "—")}</td>
                <td>${escapeHTML(s.units ?? "")}</td>
            </tr>`).join("");

        body.innerHTML = `
            <p><strong>Student:</strong> ${escapeHTML(row.student_name || "")} (${escapeHTML(row.student_id || "")})</p>
            <p><strong>Program:</strong> ${escapeHTML(row.program || "")} — ${escapeHTML(row.year_level || "")}, ${escapeHTML(row.trimester || "")}</p>
            <p><strong>Academic Year:</strong> ${escapeHTML(row.academic_year || "—")}</p>
            <p><strong>OR No.:</strong> ${escapeHTML(row.or_number || "—")} &nbsp; <strong>Total Units:</strong> ${escapeHTML(String(row.total_units ?? "—"))} &nbsp; <strong>GWA:</strong> ${escapeHTML(String(row.gwa ?? "—"))}</p>
            <p><strong>Prepared By:</strong> ${escapeHTML(row.prepared_by || row.issued_by_name || "—")}</p>
            <table class="f137-student-table">
                <thead><tr><th>Code</th><th>Description</th><th>Grade</th><th>Units</th></tr></thead>
                <tbody>${subjectRows || `<tr><td colspan="4">—</td></tr>`}</tbody>
            </table>`;
    }

    modal.classList.add("active");
}

function ascbCloseRecordsDetail() {
    const modal = ascbRecordsEl("recordsDetailModal");
    if (modal) modal.classList.remove("active");
}

/* =========================================================
   RECORDS — UPDATE / REPRINT
   ---------------------------------------------------------
   Kinukuha ang datos ng isang naka-log nang Certificate o
   Form 137-A request mula sa Records (History) at ino-open
   ito muli sa orihinal na form:
     - "Update"  — kung may mali, itinatama dito, tapos kapag
       na-Submit ay ina-UPDATE ang SAME record (hindi gagawa
       ng bagong hiwalay na row).
     - "Reprint" — pre-fill lang gamit ang naka-log na datos,
       binubuksan ang parehong preview para ma-print ulit;
       HINDI ito gumagawa ng bagong History/DB record.
   ========================================================= */

function ascbRecordsPrefillCertificateForm(row) {
    ascbCertificateSelectedEnrollment = null;
    clearTimeout(ascbCertificateSearchTimer);
    ascbCertificateSearchRequest++;
    const searchInput = document.getElementById("certificateStudentSearch");
    const searchStatus = document.getElementById("certificateStudentSearchStatus");
    if (searchInput) {
        searchInput.disabled = true;
        searchInput.value = "";
    }
    if (searchStatus) {
        searchStatus.textContent = "Viewing a saved certificate record. Clear the form to select an enrolled student.";
    }
    ascbCertificateRenderSearchResults([]);

    document.getElementById("certificateType").value = row.certificate_type || "ENROLLMENT";
    changeCertificateType();

    document.getElementById("studentName").value = row.student_name || "";
    document.getElementById("studentId").value = row.student_id || "";
    const programSelect = document.getElementById("program");
    if (row.program && ![...programSelect.options].some(option => option.value === row.program)) {
        programSelect.add(new Option(row.program, row.program));
    }
    programSelect.value = row.program || "";
    document.getElementById("yearLevel").value = row.year_level || "";
    ascbCertificateUpdateTermSelect(row.trimester || "");
    loadSubjects();
    document.getElementById("academicYear").value = row.academic_year || "";
    const enrollDateEl = document.getElementById("enrollmentDate");
    if (enrollDateEl) enrollDateEl.value = row.enrollment_date ? String(row.enrollment_date).slice(0, 10) : "";
    const statusEl = document.getElementById("status");
    if (statusEl && row.status) statusEl.value = row.status;
    document.getElementById("orNumber").value = row.or_number || "";

    const tbody = document.getElementById("subjectRows");
    tbody.innerHTML = "";
    const subjects = (Array.isArray(row.subjects) && row.subjects.length)
        ? row.subjects
        : [{ code: "", description: "", grade: "", units: 0 }];
    subjects.forEach(s => {
        addSubjectRow();
        const lastRow = tbody.lastElementChild;
        if (!lastRow) return;
        const desc = lastRow.querySelector(".subject-description");
        const grade = lastRow.querySelector(".subject-grade");
        const units = lastRow.querySelector(".subject-units");
        const select = lastRow.querySelector(".subject-select");
        if (desc) desc.value = s.description || "";
        if (grade) grade.value = s.grade || "";
        if (units) units.value = s.units ?? 0;
        if (s.code) lastRow.dataset.customCode = s.code;
        // Kung may eksaktong tugmang option sa dropdown (parehong program
        // at parehong master subject), gamitin — kung wala, mananatili
        // pa rin ang description/grade/units na direktang na-set sa itaas.
        if (select) {
            const match = [...select.options].find(o => {
                try {
                    const parsed = JSON.parse(o.value);
                    return parsed.code === (s.code || "") && parsed.description === (s.description || "");
                } catch (e) { return false; }
            });
            if (match) select.value = match.value;
        }
    });
    calculateTotalUnits();
    if (typeof calculateGWA === "function") calculateGWA();
    ascbCertificateSetSourceLocked(!ascbCertificateEditingId);
}

function ascbRecordsShowCertEditBanner(text) {
    let banner = document.getElementById("ascbCertEditBanner");
    const body = document.getElementById("actionsPanelBody") || document.querySelector("#certificatesView .card");
    if (!banner) {
        banner = document.createElement("div");
        banner.id = "ascbCertEditBanner";
        banner.className = "record-correction-banner";
        banner.style.margin = "0 0 12px";
        (document.getElementById("certificatesView") || document.body).prepend(banner);
    }
    banner.innerHTML = `<strong>${escapeHTML(text)}</strong>`;
}

function ascbRecordsUpdateCertificate(idx) {
    const row = ascbRecordsFilteredCache[idx];
    if (!row || !row.id) return;
    ascbCertificateEditingId = Number(row.id);
    ascbRecordsPrefillCertificateForm(row);
    ascbRecordsShowCertEditBanner(`✏ Do you want to Update this Certificate Record #${row.id} (${row.student_name || ""}) — Click "SUBMIT DATA" .`);
    ascbNavigate("certificates");
    window.scrollTo({ top: 0, behavior: "smooth" });
}

function ascbRecordsReprintCertificate(idx) {
    const row = ascbRecordsFilteredCache[idx];
    if (!row) return;
    ascbCertificateEditingId = null; // reprint = no database write
    ascbRecordsPrefillCertificateForm(row);
    ascbNavigate("certificates");
    window.scrollTo({ top: 0, behavior: "smooth" });
    ascbCertificateReprintVerify = row.verify || null;
    generateCertificate(false); // REPRINT: preview/print only; do not create a new History record.
}

function ascbRecordsPrefillForm137(row) {
    f137Students = (Array.isArray(row.students) ? row.students : []).map(s => ({
        name: s.name || "", course: s.course || "", schoolYear: s.schoolYear || "", yearSection: s.yearSection || ""
    }));
    f137LoadSchools(row.school_name || "");
    f137El("f137_schoolAddress").value = row.school_address || "";
    f137LoadCourses();
    f137El("f137_studentName").value = "";
    f137El("f137_schoolYear").value = "";
    f137El("f137_yearSection").value = "";
    f137El("f137_requestDate").value = row.request_date ? String(row.request_date).slice(0, 10) : f137Today();
    f137El("f137_firstRequest").checked = Number(row.first_request) === 1;
    f137El("f137_secondRequest").checked = Number(row.second_request) === 1;
    f137El("f137_urgentRequest").checked = Number(row.urgent_request) === 1;
    f137El("f137_bearerRequest").checked = Number(row.bearer_request) === 1;
    f137El("f137_copyForASCB").checked = Number(row.copy_for_ascb) === 1;
    f137RenderStudentList();
    f137UpdatePreview();
}

function ascbRecordsShowF137EditBanner(text) {
    let banner = document.getElementById("ascbF137EditBanner");
    if (!banner) {
        banner = document.createElement("div");
        banner.id = "ascbF137EditBanner";
        banner.className = "record-correction-banner";
        banner.style.margin = "0 0 12px";
        (document.getElementById("form137View") || document.body).prepend(banner);
    }
    banner.innerHTML = `<strong>${escapeHTML(text)}</strong>`;
}

function ascbRecordsUpdateForm137(idx) {
    const row = ascbRecordsFilteredCache[idx];
    if (!row || !row.id) return;
    ascbF137EditingId = Number(row.id);
    ascbRecordsPrefillForm137(row);
    ascbRecordsShowF137EditBanner(`✏ Are you sure you want to Update this Form 137-A Request #${row.id} (${row.school_name || ""}) — Click the button Submit to save a updated record.`);
    ascbNavigate("form137");
    window.scrollTo({ top: 0, behavior: "smooth" });
}

function ascbRecordsReprintForm137(idx) {
    const row = ascbRecordsFilteredCache[idx];
    if (!row) return;
    ascbF137EditingId = null; // reprint = no database write
    ascbRecordsPrefillForm137(row);
    ascbNavigate("form137");
    window.scrollTo({ top: 0, behavior: "smooth" });
    generateForm137(false); // REPRINT: preview/print only; do not create a new History record.
}

document.addEventListener("keydown", function (event) {
    if (event.key !== "Escape") return;
    const modal = ascbRecordsEl("recordsDetailModal");
    if (modal && modal.classList.contains("active")) {
        ascbCloseRecordsDetail();
    }
    const enrollModal = document.getElementById("enrollDetailModal");
    if (enrollModal && enrollModal.classList.contains("active")) {
        ascbEnrollCloseDetail();
    }
});


/* =========================================================
   ENROLLMENT
   Basic info ng estudyante bawat entry (Surname, Given Name,
   Middle Name, Birth Date, Address, Previous School — Junior
   HS at Senior HS). May Add, Edit, at Delete.
   ========================================================= */

let ascbEnrollRows = [];

let ascbEnrollPage = 1;
let ascbEnrollTotalPages = 1;
let ascbEnrollTotal = 0;

// "View All" toggle — dati, ipinapakita LAHAT ng records sa isang
// tingin nang walang limitasyon (delikado sa 100k+ students, browser
// memory pressure). Ngayon, "malaking pahina" na lang (200 rows) sa
// halip na totoong walang-hanggan, at may pagination pa rin kung
// lalagpas pa rito ang bilang. Naka-store sa sessionStorage para
// hindi mawala ang preference pagpalit ng view.
let ascbEnrollShowAll = false; // View All removed; use normal pagination.
const ASCB_ENROLL_VIEW_ALL_LIMIT = 200;

/* Generic debounce — ginagamit para sa search inputs na nagre-request
   sa server (sa halip na mag-request ang browser bawat pindot ng
   titik, maghihintay muna ito ng ilang saglit matapos ang huling
   pagta-type bago mag-request). */
function ascbDebounce(fn, delayMs) {
    let timer = null;
    return function (...args) {
        clearTimeout(timer);
        timer = setTimeout(() => fn.apply(this, args), delayMs);
    };
}

/* RACE-CONDITION GUARD — ginagamit ng mga search-driven na loader sa
   ibaba (Enrollment, Rejected, Archive, Records, Student 360).

   Dahil naka-debounce lang ang PAG-SIMULA ng request (hindi ang
   pagbalik nito), posible pa ring dalawang request ang parehong
   nakalipad papunta sa server nang magkasunod — at hindi garantisado
   ang PAGKABALIK nila sa parehong pagkakasunod-sunod (hal. mas
   mabagal ang network sa unang request). Kung hindi ito babantayan,
   puwedeng ang MAS LUMANG (at mali na, hindi na tumutugma sa
   kasalukuyang laman ng search box) na resulta ang siyang huling
   makarating at mapalitan ang tamang mas-bagong resulta na nakita
   na ng user.

   Paggamit: isang beses gawin ang guard bawat loader (module-level),
   tapos sa simula ng bawat pag-tawag, kunin ang "token" gamit ang
   start(); pagkatapos ma-await ang response, i-check ang
   isCurrent(token) BAGO galawin ang anumang shared state/DOM — kung
   false na ito, may mas bago nang request na tumakbo habang
   naghihintay ito, kaya ito na lang ang lalaktawan. */
function ascbMakeRequestGuard() {
    let latest = 0;
    return {
        start: function () { return ++latest; },
        isCurrent: function (token) { return token === latest; },
    };
}

function ascbEnrollEl(id) {
    return document.getElementById(id);
}

function ascbEnrollFormatDate(value) {
    if (!value) return "—";
    const d = new Date(String(value).replace(" ", "T"));
    if (Number.isNaN(d.getTime())) return value;
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

/* Ginagamit sa Student 360 — buong pangalan ng buwan (hal. "January 15, 2005")
   sa halip na numero, para mas madaling basahin. */
function ascbEnrollFormatDateLong(value) {
    if (!value) return "—";
    const d = new Date(String(value).replace(" ", "T"));
    if (Number.isNaN(d.getTime())) return value;
    return d.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
}

/* ---------------------------------------------------------
   BIRTH DATE — Month / Day / Year na magkakahiwalay na <select>
   (Month, Day, Year ang pagkakasunod-sunod) sa halip na katutubong
   <input type="date"> ng browser, para consistent ang format kahit
   anong device/locale ang gamit ng user. Isinasama pa rin bilang
   "YYYY-MM-DD" string papunta sa backend, kaya hindi na kailangang
   baguhin ang api/enrollment.php.
   --------------------------------------------------------- */
const ASCB_BIRTH_MONTH_NAMES = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];

function ascbEnrollPopulateBirthdateSelects(monthId, dayId, yearId) {
    const monthEl = ascbEnrollEl(monthId);
    const dayEl = ascbEnrollEl(dayId);
    const yearEl = ascbEnrollEl(yearId);

    if (monthEl && monthEl.options.length <= 1) {
        ASCB_BIRTH_MONTH_NAMES.forEach((name, idx) => {
            const opt = document.createElement("option");
            opt.value = String(idx + 1).padStart(2, "0");
            opt.textContent = name;
            monthEl.appendChild(opt);
        });
    }
    if (dayEl && dayEl.options.length <= 1) {
        for (let day = 1; day <= 31; day++) {
            const opt = document.createElement("option");
            opt.value = String(day).padStart(2, "0");
            opt.textContent = String(day);
            dayEl.appendChild(opt);
        }
    }
    if (yearEl && yearEl.options.length <= 1) {
        const currentYear = new Date().getFullYear();
        for (let year = currentYear; year >= currentYear - 100; year--) {
            const opt = document.createElement("option");
            opt.value = String(year);
            opt.textContent = String(year);
            yearEl.appendChild(opt);
        }
    }
}

function ascbEnrollSetBirthdateSelects(monthId, dayId, yearId, isoValue) {
    ascbEnrollPopulateBirthdateSelects(monthId, dayId, yearId);
    const monthEl = ascbEnrollEl(monthId);
    const dayEl = ascbEnrollEl(dayId);
    const yearEl = ascbEnrollEl(yearId);
    const parts = isoValue ? String(isoValue).slice(0, 10).split("-") : [];
    if (monthEl) monthEl.value = parts[1] || "";
    if (dayEl) dayEl.value = parts[2] || "";
    if (yearEl) yearEl.value = parts[0] || "";
}

function ascbEnrollClearBirthdateSelects(monthId, dayId, yearId) {
    [monthId, dayId, yearId].forEach(id => {
        if (ascbEnrollEl(id)) ascbEnrollEl(id).value = "";
    });
}

function ascbEnrollGetBirthdateValue(monthId, dayId, yearId) {
    const month = ascbEnrollEl(monthId) ? ascbEnrollEl(monthId).value : "";
    const day = ascbEnrollEl(dayId) ? ascbEnrollEl(dayId).value : "";
    const year = ascbEnrollEl(yearId) ? ascbEnrollEl(yearId).value : "";
    if (!month || !day || !year) return "";
    return `${year}-${month}-${day}`;
}

/* =========================================================
   SUFFIX + PSA PLACEMENT (Jr., Sr., II, III ...)
   Hiwalay ang suffix sa database; ang suffix_position ang nagsasabi
   kung saan ito ilalabas ayon sa PSA Birth Certificate:
     separate   -> Santos, Juan Reyes Jr.   (default)
     first_name -> Santos, Juan Jr. Reyes
     surname    -> Santos Jr., Juan Reyes
   ========================================================= */
function ascbNamePrintParts(surname, first, middle, suffix, position) {
    let s = String(surname || "").trim();
    let f = String(first || "").trim();
    const m = String(middle || "").trim();
    const x = String(suffix || "").trim();
    let tail = "";
    if (x) {
        if (position === "first_name") f = `${f} ${x}`.trim();
        else if (position === "surname") s = `${s} ${x}`.trim();
        else tail = x;
    }
    return { surname: s, first: f, middle: m, tail };
}
function ascbNamePrint(surname, first, middle, suffix, position) {
    const p = ascbNamePrintParts(surname, first, middle, suffix, position);
    const given = `${p.first} ${p.middle}`.trim();
    let out = p.surname;
    if (given) out += (out ? ", " : "") + given;
    if (p.tail) out += " " + p.tail;
    return out;
}
function ascbEnrollFullName(row) {
    /* (fix) Kapag may CURRENT na pangalan/suffix sa Master Record, iyon ang ipakita. */
    if (row && row._masterName) return row._masterName;
    const parts = [row.surname || "", row.first_name || "", row.middle_name || ""].filter(Boolean);
    if (!parts.length) return "—";
    /* Kapag galing sa server na dumaan na sa ascb_row_print_split (may raw_surname),
       nakalagay na ang suffix sa surname / first / middle — huwag na itong idagdag ulit. */
    if (row.raw_surname !== undefined || row.raw_first_name !== undefined) {
        const given = [row.first_name, row.middle_name].map(v => String(v || "").trim()).filter(Boolean).join(" ");
        const sur = String(row.surname || "").trim();
        return sur + (given ? (sur ? ", " : "") + given : "");
    }
    return ascbNamePrint(row.surname, row.first_name, row.middle_name, row.suffix, row.suffix_position);
}

/* Live preview: i-update habang tina-type ang pangalan. */
document.addEventListener("input", function (e) {
    const id = e.target && e.target.id;
    const m = id && /^(enroll|enroll_edit)_(surname|firstName|middleName)$/.exec(id);
    if (m) ascbEnrollSuffixRefresh(m[1]);
});

/* ----- Suffix UI (Enrollment New / Edit forms) ----- */
function ascbEnrollSuffixValues(prefix) {
    const sel = ascbEnrollEl(prefix + "_suffix");
    const suffix = sel ? sel.value.trim() : "";
    let suffixPosition = "separate";
    if (suffix) {
        if (ascbEnrollEl(prefix + "_suffixFirst") && ascbEnrollEl(prefix + "_suffixFirst").checked) suffixPosition = "first_name";
        else if (ascbEnrollEl(prefix + "_suffixSurname") && ascbEnrollEl(prefix + "_suffixSurname").checked) suffixPosition = "surname";
    }
    return { suffix, suffixPosition };
}
function ascbEnrollSuffixRefresh(prefix) {
    const v = ascbEnrollSuffixValues(prefix);
    const box = ascbEnrollEl(prefix + "_suffixPsa");
    if (box) box.style.display = v.suffix ? "" : "none";
    const prev = ascbEnrollEl(prefix + "_suffixPreview");
    if (prev) {
        const g = id => (ascbEnrollEl(prefix + id) ? ascbEnrollEl(prefix + id).value : "");
        const name = ascbNamePrint(g("_surname"), g("_firstName"), g("_middleName"), v.suffix, v.suffixPosition);
        prev.textContent = v.suffix && name ? `View on Record: ${name}` : "";
    }
}
function ascbEnrollSuffixChanged(prefix) {
    if (!ascbEnrollSuffixValues(prefix).suffix) {
        if (ascbEnrollEl(prefix + "_suffixFirst")) ascbEnrollEl(prefix + "_suffixFirst").checked = false;
        if (ascbEnrollEl(prefix + "_suffixSurname")) ascbEnrollEl(prefix + "_suffixSurname").checked = false;
    }
    ascbEnrollSuffixRefresh(prefix);
}
/* Dalawang checkbox pero isa lang ang puwedeng naka-check. */
function ascbEnrollSuffixToggle(prefix, which) {
    const first = ascbEnrollEl(prefix + "_suffixFirst");
    const surname = ascbEnrollEl(prefix + "_suffixSurname");
    if (which === "first_name" && first && first.checked && surname) surname.checked = false;
    if (which === "surname" && surname && surname.checked && first) first.checked = false;
    ascbEnrollSuffixRefresh(prefix);
}
function ascbEnrollSuffixSet(prefix, suffix, position) {
    const sel = ascbEnrollEl(prefix + "_suffix");
    if (sel) {
        const val = String(suffix || "").trim();
        /* Kung wala sa dropdown ang lumang suffix (hal. "Jr"), idagdag para hindi mawala. */
        if (val && ![...sel.options].some(o => o.value === val)) {
            const opt = document.createElement("option");
            opt.value = val; opt.textContent = val;
            sel.appendChild(opt);
        }
        sel.value = val;
    }
    if (ascbEnrollEl(prefix + "_suffixFirst")) ascbEnrollEl(prefix + "_suffixFirst").checked = !!suffix && position === "first_name";
    if (ascbEnrollEl(prefix + "_suffixSurname")) ascbEnrollEl(prefix + "_suffixSurname").checked = !!suffix && position === "surname";
    ascbEnrollSuffixRefresh(prefix);
}

/* ---------------------------------------------------------
   APPROVAL STATUS — kapag ADMIN STAFF ang nag-input (create o
   update) ng enrollee, "pending" muna ito hanggang aprubahan
   ng UNIT HEAD (tingnan ang api/enrollment.php).
   --------------------------------------------------------- */
function ascbEnrollStatusBadge(row) {
    const status = (row.status || "approved").toLowerCase();
    const map = {
        pending:  { label: "Pending",  cls: "status-badge-pending" },
        approved: { label: "Enrolled", cls: "status-badge-approved" },
        rejected: { label: "Rejected", cls: "status-badge-rejected" },
    };
    const info = map[status] || map.approved;

    let title = "";
    if (status === "approved" && row.approved_by_name) {
        title = `Inaprubahan ni ${row.approved_by_name}`;
    } else if (status === "rejected") {
        title = row.approval_remarks ? `Na-reject: ${row.approval_remarks}` : (row.approved_by_name ? `Na-reject ni ${row.approved_by_name}` : "Na-reject");
    } else if (status === "pending") {
        title = "Naghihintay ng approval ng Unit Head";
    }

    return `<span class="status-badge ${info.cls}" title="${escapeHTML(title)}">${info.label}</span>`;
}

const ascbEnrollRequestGuard = ascbMakeRequestGuard();
async function ascbLoadEnrollment() {
    const status = ascbEnrollEl("enrollStatus");
    const wrapper = ascbEnrollEl("enrollTableWrapper");

    if (status) {
        status.style.display = "block";
        status.textContent = "Loading records…";
    }
    if (wrapper) wrapper.style.display = "none";

    // Search/status filter at "latest term per student" ay ginagawa
    // na ngayon sa SERVER (api/enrollment.php) — hindi na dinodownload
    // dito ang LAHAT ng records para lang mag-filter sa browser.
    const term = (ascbEnrollEl("enrollSearchInput") ? ascbEnrollEl("enrollSearchInput").value : "").trim();
    const statusFilter = ascbEnrollEl("enrollStatusFilterInput") ? ascbEnrollEl("enrollStatusFilterInput").value : "";
    const limit = ASCB_PAGE_SIZE;

    const qs = new URLSearchParams({ scope: "active", page: String(ascbEnrollPage), limit: String(limit) });
    if (term) qs.set("q", term);
    if (statusFilter) qs.set("status", statusFilter);

    const ascbEnrollToken = ascbEnrollRequestGuard.start();
    try {
        const response = await fetch("api/enrollment.php?" + qs.toString());
        const data = await response.json();
        if (!ascbEnrollRequestGuard.isCurrent(ascbEnrollToken)) return; // may mas bagong request na (hal. bagong titik na na-type) — laktawan

        if (!data || !data.ok) {
            if (status) status.textContent = "Unable to load records. Please try again.";
            return;
        }

        ascbEnrollRows = Array.isArray(data.rows) ? data.rows : [];
        await ascbEnrollApplyMasterNames(ascbEnrollRows);
        if (!ascbEnrollRequestGuard.isCurrent(ascbEnrollToken)) return;
        ascbEnrollPage = data.page || 1;
        ascbEnrollTotalPages = data.totalPages || 1;
        ascbEnrollTotal = typeof data.total === "number" ? data.total : ascbEnrollRows.length;
        ascbEnrollRenderTable();

        if (status) status.style.display = "none";
        if (wrapper) wrapper.style.display = "block";

    } catch (error) {
        if (!ascbEnrollRequestGuard.isCurrent(ascbEnrollToken)) return;
        console.error("Enrollment load failed:", error);
        if (status) status.textContent = "Unable to reach the server. Please check your connection or refresh the page.";
    }
}

/* (fix) Ang enrollment / New Term list ay galing sa mga enrollees row (pangalan
   noong nag-enroll). Kapag binago sa Master Record ang pangalan o Suffix ng
   estudyante, ipakita ang CURRENT na pangalan dito. Hindi binabago ang mismong
   enrollees row - display lang. */
async function ascbEnrollApplyMasterNames(rows) {
    try {
        if (typeof ascbMrInvalidateNames === "function") ascbMrInvalidateNames();
        const names = await ascbMasterCurrentNames();
        (rows || []).forEach(r => {
            const n = names && names[r.student_id];
            r._masterName = (n && n.fullName) ? n.fullName : "";
        });
    } catch (e) { /* huwag harangan ang listahan */ }
    return rows;
}

// Debounced — naghihintay ng ~350ms matapos ang huling type bago
// mag-request sa server, para hindi bumaha ng request bawat titik.
const ascbEnrollFilter = ascbDebounce(function () {
    ascbEnrollPage = 1;
    ascbLoadEnrollment();
}, 350);

function ascbEnrollGoToPage(page) {
    ascbEnrollPage = page;
    ascbLoadEnrollment();
}

function ascbEnrollRenderTable() {
    const body = ascbEnrollEl("enrollTableBody");
    if (!body) return;

    const perms = (typeof ASCB_PERMISSIONS !== "undefined") ? ASCB_PERMISSIONS : {};

    // Ang search/status filter ay nagawa na sa SERVER (ascbLoadEnrollment) —
    // ang ascbEnrollRows dito ay ang mismong isang-pahina (o "view all"
    // na malaking pahina) na resulta na mula sa API.
    if (!ascbEnrollRows.length) {
        body.innerHTML = `<tr><td colspan="7" class="records-empty">Walang nahanap na record.</td></tr>`;
        const paginationEl = ascbEnrollEl("enrollPagination");
        if (paginationEl) paginationEl.innerHTML = "";
        return;
    }

    body.innerHTML = ascbEnrollRows.map(row => {
        const deleteBtn = perms.deleteEnrollment
            ? `<button type="button" class="btn btn-danger-solid approved-so-action-btn action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbEnrollDelete(${row.id})">${ascbIcon('delete')}</button>`
            : "";

        const isPending = (row.status || "approved") === "pending";
        const approvalBtns = (perms.approveEnrollment && isPending)
            ? `<button type="button" class="btn btn-success-solid approved-so-action-btn action-icon-btn" title="Approve" aria-label="Approve" onclick="ascbEnrollApprove(${row.id})">${ascbIcon('approve')}</button>
               <button type="button" class="btn btn-danger-solid approved-so-action-btn action-icon-btn" title="Reject" aria-label="Reject" onclick="ascbEnrollReject(${row.id})">${ascbIcon('reject')}</button>`
            : "";

        const updateBtn = perms.updateEnrollment
            ? `<button type="button" class="btn btn-outline approved-so-action-btn action-icon-btn" title="Update" aria-label="Update" onclick="ascbEnrollOpenEdit(${row.id})">${ascbIcon('edit')}</button>`
            : "";

        const acctBtn = (perms.issueStudentAccount && (row.status || "approved") === "approved" && row.student_id)
            ? `<button type="button" class="btn btn-outline approved-so-action-btn action-icon-btn" title="Student account (issue / reset temporary password)" aria-label="Student account" onclick="ascbIssueStudentAccount(${ascbJsAttr(String(row.student_id))}, ${ascbJsAttr(ascbEnrollFullName(row))})">${ascbIcon('key')}</button>`
            : "";

        const yearTrimester = [row.year_level, row.trimester].filter(Boolean).join(" — ");

        return `
            <tr>
                <td data-label="Student ID">${escapeHTML(row.student_id || "—")}</td>
                <td data-label="Name">${escapeHTML(ascbEnrollFullName(row))}</td>
                <td data-label="Course">${escapeHTML(row.course || "—")}</td>
                <td data-label="Major">${escapeHTML(row.major || "—")}</td>
                <td data-label="Year & Trimester">${escapeHTML(yearTrimester || "—")}</td>
                <td data-label="Approval Status">${ascbEnrollStatusBadge(row)}</td>
                <td data-label="Actions">
                    <button type="button" class="btn btn-outline approved-so-action-btn action-icon-btn" title="View" aria-label="View" onclick="ascbEnrollShowDetail(${row.id})">${ascbIcon('view')}</button>
                    ${updateBtn}
                    <button type="button" class="btn btn-success-solid approved-so-action-btn action-icon-btn" title="New Term" aria-label="New Term" onclick="ascbEnrollOpenNewTerm(${row.id})">${ascbIcon('newTerm')}</button>
                    ${approvalBtns}
                    ${acctBtn}
                    ${deleteBtn}
                </td>
            </tr>`;
    }).join("");

    // Normal pagination lang; View All toggle has been removed.
    ascbRenderPagination(
        "enrollPagination",
        ascbEnrollPage,
        ascbEnrollTotalPages,
        ascbEnrollTotal,
        ASCB_PAGE_SIZE,
        "ascbEnrollGoToPage"
    );
}

/* ---------------------------------------------------------
   VIEW DETAILS — modal na nagpapakita ng buong info ng isang
   enrollee (kasama na ang mga field na tinanggal na sa table
   mismo para gumaan ito: Mobile Number, Birth Date, Address,
   Previous School Junior/Senior HS).
   --------------------------------------------------------- */
function ascbEnrollShowDetail(id) {
    const row = ascbEnrollRows.find(r => r.id === id)
        || (typeof ascbRejectedRows !== "undefined" && ascbRejectedRows.find(r => r.id === id))
        || (typeof ascbArchiveRows !== "undefined" && ascbArchiveRows.find(r => r.id === id));
    if (!row) return;

    const modal = ascbEnrollEl("enrollDetailModal");
    const title = ascbEnrollEl("enrollDetailTitle");
    const body = ascbEnrollEl("enrollDetailBody");
    if (!modal || !title || !body) return;

    const yearTrimester = [row.year_level, row.trimester].filter(Boolean).join(" — ");
    const courseMajor = `${escapeHTML(row.course || "—")}${row.major ? " — " + escapeHTML(row.major) : ""}`;

    title.textContent = `${ascbEnrollFullName(row)} (${row.student_id || "—"})`;

    // Maayos na "info grid" na naka-group per section (dating
    // plain <p><strong>Label:</strong> value</p> stack lang) —
    // ang Approval Status ay inilipat sa itaas bilang prominent
    // na badge sa halip na nakatago sa ilalim ng listahan.
    const subjectCount = Array.isArray(row.subjects) ? row.subjects.length : 0;

    body.innerHTML = `
        <div class="enroll-detail-status-row">
            <span class="enroll-detail-kicker">Enrollment record</span>
            ${ascbEnrollStatusBadge(row)}
        </div>

        <div class="enroll-detail-primary">
            <section class="enroll-detail-section enroll-detail-section--enrollment">
                <div class="enroll-detail-section-heading">
                    <div>
                        <span class="enroll-detail-section-eyebrow">Academic details</span>
                        <h4>Enrollment Information</h4>
                    </div>
                </div>
                <div class="enroll-detail-grid">
                    <div class="enroll-detail-item enroll-detail-item--full enroll-detail-item--featured">
                        <span class="enroll-detail-label">Course / Major</span>
                        <span class="enroll-detail-value">${courseMajor}</span>
                    </div>
                    <div class="enroll-detail-item">
                        <span class="enroll-detail-label">Year &amp; Trimester</span>
                        <span class="enroll-detail-value">${escapeHTML(yearTrimester || "—")}</span>
                    </div>
                    <div class="enroll-detail-item">
                        <span class="enroll-detail-label">School Year</span>
                        <span class="enroll-detail-value">${escapeHTML(row.school_year || "—")}</span>
                    </div>
                    <div class="enroll-detail-item">
                        <span class="enroll-detail-label">Student Type</span>
                        <span class="enroll-detail-value">${escapeHTML(row.student_type || "—")}</span>
                    </div>
                    <div class="enroll-detail-item">
                        <span class="enroll-detail-label">Date Enrolled</span>
                        <span class="enroll-detail-value">${escapeHTML(ascbEnrollFormatDate(row.created_at))}</span>
                    </div>
                </div>
            </section>

            <section class="enroll-detail-section enroll-detail-section--subjects">
                <div class="enroll-detail-section-heading">
                    <div>
                        <span class="enroll-detail-section-eyebrow">Current load</span>
                        <h4>Latest Subjects Enrolled</h4>
                    </div>
                    <span class="enroll-detail-count">${subjectCount} ${subjectCount === 1 ? "subject" : "subjects"}</span>
                </div>
                <div class="table-wrapper enroll-detail-table-wrap">
                    <table class="subject-input-table enroll-detail-subject-table">
                        <thead>
                            <tr>
                                <th width="22%">Course Code</th>
                                <th width="58%">Course Description</th>
                                <th width="20%">Units</th>
                            </tr>
                        </thead>
                        <tbody>${
                            subjectCount
                                ? row.subjects.map(s => `
                            <tr>
                                <td data-label="Course Code"><strong>${escapeHTML(s.code || "—")}</strong></td>
                                <td data-label="Course Description">${escapeHTML(s.description || "—")}</td>
                                <td data-label="Units">${escapeHTML(String(s.units ?? "—"))}</td>
                            </tr>`).join("")
                                : `<tr><td colspan="3" class="records-empty">Walang naka-record na subjects.</td></tr>`
                        }</tbody>
                    </table>
                </div>
            </section>
        </div>

        <div class="enroll-detail-secondary">
            <section class="enroll-detail-section">
                <div class="enroll-detail-section-heading">
                    <div>
                        <span class="enroll-detail-section-eyebrow">Student profile</span>
                        <h4>Personal Information</h4>
                    </div>
                </div>
                <div class="enroll-detail-grid">
                    <div class="enroll-detail-item">
                        <span class="enroll-detail-label">Sex</span>
                        <span class="enroll-detail-value">${escapeHTML(row.sex || "—")}</span>
                    </div>
                    <div class="enroll-detail-item">
                        <span class="enroll-detail-label">Civil Status</span>
                        <span class="enroll-detail-value">${escapeHTML(row.civil_status || "—")}</span>
                    </div>
                    <div class="enroll-detail-item">
                        <span class="enroll-detail-label">Gmail / Email</span>
                        <span class="enroll-detail-value">${escapeHTML(row.email || "—")}</span>
                    </div>
                    <div class="enroll-detail-item">
                        <span class="enroll-detail-label">Birth Date</span>
                        <span class="enroll-detail-value">${escapeHTML(ascbEnrollFormatDate(row.birth_date))}</span>
                    </div>
                    <div class="enroll-detail-item">
                        <span class="enroll-detail-label">Birth Place</span>
                        <span class="enroll-detail-value">${escapeHTML(row.birth_place || "—")}</span>
                    </div>
                    <div class="enroll-detail-item">
                        <span class="enroll-detail-label">Mobile Number</span>
                        <span class="enroll-detail-value">${escapeHTML(row.mobile_number || "—")}</span>
                    </div>
                    <div class="enroll-detail-item enroll-detail-item--full">
                        <span class="enroll-detail-label">Address</span>
                        <span class="enroll-detail-value">${escapeHTML(row.address || "—")}</span>
                    </div>
                </div>
            </section>

            <section class="enroll-detail-section">
                <div class="enroll-detail-section-heading">
                    <div>
                        <span class="enroll-detail-section-eyebrow">Previous education</span>
                        <h4>School Background</h4>
                    </div>
                </div>
                <div class="enroll-detail-grid">
                    <div class="enroll-detail-item enroll-detail-item--full">
                        <span class="enroll-detail-label">Junior High School</span>
                        <span class="enroll-detail-value">${escapeHTML(row.prev_school_junior_hs || "—")}</span>
                    </div>
                    <div class="enroll-detail-item enroll-detail-item--full">
                        <span class="enroll-detail-label">Senior High School</span>
                        <span class="enroll-detail-value">${escapeHTML(row.prev_school_senior_hs || "—")}</span>
                    </div>
                    <div class="enroll-detail-item">
                        <span class="enroll-detail-label">Junior High School Graduated</span>
                        <span class="enroll-detail-value">${escapeHTML(row.junior_hs_graduated || "—")}</span>
                    </div>
                    <div class="enroll-detail-item">
                        <span class="enroll-detail-label">Senior High School Graduated</span>
                        <span class="enroll-detail-value">${escapeHTML(row.senior_hs_graduated || "—")}</span>
                    </div>
                </div>
            </section>
        </div>`;

    modal.classList.add("active");
}

function ascbEnrollCloseDetail() {
    const modal = ascbEnrollEl("enrollDetailModal");
    if (modal) modal.classList.remove("active");
}

/* ---------------------------------------------------------
   APPROVE / REJECT — Unit Head o School Registrar (ASCB_PERMISSIONS.approveEnrollment).
   Ang backend din ang tunay na nagpapatupad ng check na ito.
   --------------------------------------------------------- */
async function ascbEnrollApprove(id) {
    if (!(await ascbConfirm("Approve this enrollment record?"))) return;

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "approve", id }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            alert((data && data.error) ? data.error : "Unable to approve. Please try again.");
            return;
        }

        const apRow = (typeof ascbEnrollRows !== "undefined" && Array.isArray(ascbEnrollRows)) ? ascbEnrollRows.find(r => Number(r.id) === Number(id)) : null;
        alert("The enrollment has been approved.");
        ascbLoadEnrollment();
        ascbRefreshEnrollmentBadge();
        ascbHandleStudentAccountResponse(data, apRow ? ascbEnrollFullName(apRow) : "");

    } catch (error) {
        console.error("Enrollment approve failed:", error);
        alert("Unable to reach the server. Please check your connection.");
    }
}

async function ascbEnrollReject(id) {
    const remarks = await ascbPrompt("Optional: reason for rejection (may be left blank)", "");
    if (remarks === null) return; // cancelled

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "reject", id, remarks: remarks.trim() }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            alert((data && data.error) ? data.error : "Unable to reject. Please try again.");
            return;
        }

        ascbLoadEnrollment();
        ascbRefreshEnrollmentBadge();

    } catch (error) {
        console.error("Enrollment reject failed:", error);
        alert("Unable to reach the server. Please check your connection.");
    }
}

async function ascbEnrollSubmit() {
    const surname = ascbEnrollEl("enroll_surname") ? ascbEnrollEl("enroll_surname").value.trim() : "";
    const firstName = ascbEnrollEl("enroll_firstName") ? ascbEnrollEl("enroll_firstName").value.trim() : "";
    const middleName = ascbEnrollEl("enroll_middleName") ? ascbEnrollEl("enroll_middleName").value.trim() : "";
    const { suffix, suffixPosition } = ascbEnrollSuffixValues("enroll");
    const sex = ascbEnrollEl("enroll_sex") ? ascbEnrollEl("enroll_sex").value : "";
    const civilStatus = ascbEnrollEl("enroll_civilStatus") ? ascbEnrollEl("enroll_civilStatus").value : "";
    const email = ascbEnrollEl("enroll_email") ? ascbEnrollEl("enroll_email").value.trim() : "";
    const studentType = ascbEnrollEl("enroll_studentType") ? ascbEnrollEl("enroll_studentType").value : "";
    const birthDate = ascbEnrollGetBirthdateValue("enroll_birthMonth", "enroll_birthDay", "enroll_birthYear");
    const birthPlace = ascbEnrollEl("enroll_birthPlace") ? ascbEnrollEl("enroll_birthPlace").value.trim() : "";
    const address = ascbEnrollEl("enroll_address") ? ascbEnrollEl("enroll_address").value.trim() : "";
    const mobileNumber = ascbEnrollEl("enroll_mobileNumber") ? ascbEnrollEl("enroll_mobileNumber").value.trim() : "";
    const guardianName = ascbEnrollEl("enroll_guardianName") ? ascbEnrollEl("enroll_guardianName").value.trim() : "";
    const prevSchoolJuniorHs = ascbEnrollEl("enroll_prevSchoolJuniorHs") ? ascbEnrollEl("enroll_prevSchoolJuniorHs").value.trim() : "";
    const prevSchoolSeniorHs = ascbEnrollEl("enroll_prevSchoolSeniorHs") ? ascbEnrollEl("enroll_prevSchoolSeniorHs").value.trim() : "";
    const juniorHsGraduated = ascbEnrollEl("enroll_juniorHsGraduated") ? ascbEnrollEl("enroll_juniorHsGraduated").value.trim() : "";
    const seniorHsGraduated = ascbEnrollEl("enroll_seniorHsGraduated") ? ascbEnrollEl("enroll_seniorHsGraduated").value.trim() : "";
    const programCode = ascbEnrollEl("enroll_program") ? ascbEnrollEl("enroll_program").value : "";
    const courseMajor = ascbGetCourseMajor(programCode);
    const yearLevel = ascbEnrollEl("enroll_yearLevel") ? ascbEnrollEl("enroll_yearLevel").value : "";
    const trimester = ascbEnrollEl("enroll_trimester") ? ascbEnrollEl("enroll_trimester").value : "";
    const schoolYear = ascbEnrollEl("enroll_schoolYear") ? ascbEnrollEl("enroll_schoolYear").value.trim() : "";
    const subjects = ascbEnrollCollectSubjects("enroll_subjectRows");

    if (!surname || !firstName) {
        alert("Surname and Given Name are required.");
        return;
    }

    const status = ascbEnrollEl("enrollFormStatus");
    if (status) {
        status.style.display = "block";
        status.textContent = "Saving…";
    }

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                action: "create",
                surname, firstName, middleName, suffix, suffixPosition, sex, civilStatus, email, studentType, birthDate, birthPlace, address, mobileNumber, guardianName,
                prevSchoolJuniorHs, prevSchoolSeniorHs, juniorHsGraduated, seniorHsGraduated,
                programCode, course: courseMajor.course, major: courseMajor.major,
                yearLevel, trimester, schoolYear, subjects,
            }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = (data && data.error) ? data.error : "Hindi na-save. Subukan muli.";
            return;
        }

        if (status) {
            const statusNote = data.status === "pending" ? " (Pending — naghihintay ng approval ng Unit Head)" : "";
            status.textContent = (data.studentId ? `Na-save! Student ID: ${data.studentId}` : "Na-save!") + statusNote;
            setTimeout(() => { status.style.display = "none"; }, 7000);
        }
        // AUTO STUDENT ACCOUNT: ipakita ang one-time temporary password (isang beses lang).
        ascbHandleStudentAccountResponse(data, [surname, firstName].filter(Boolean).join(", "));

        ["enroll_surname", "enroll_firstName", "enroll_middleName",
         "enroll_birthPlace", "enroll_address", "enroll_mobileNumber", "enroll_guardianName", "enroll_email", "enroll_prevSchoolJuniorHs", "enroll_prevSchoolSeniorHs", "enroll_juniorHsGraduated", "enroll_seniorHsGraduated", "enroll_major",
         "enroll_schoolYear"].forEach(id => {
            if (ascbEnrollEl(id)) ascbEnrollEl(id).value = "";
        });
        ascbEnrollClearBirthdateSelects("enroll_birthMonth", "enroll_birthDay", "enroll_birthYear");
        ascbEnrollSuffixSet("enroll", "", "separate");
        if (ascbEnrollEl("enroll_program")) ascbEnrollEl("enroll_program").value = "";
        if (ascbEnrollEl("enroll_sex")) ascbEnrollEl("enroll_sex").value = "";
        if (ascbEnrollEl("enroll_civilStatus")) ascbEnrollEl("enroll_civilStatus").value = "";
        if (ascbEnrollEl("enroll_studentType")) ascbEnrollEl("enroll_studentType").value = "";
        if (ascbEnrollEl("enroll_yearLevel")) ascbEnrollEl("enroll_yearLevel").value = "";
        if (ascbEnrollEl("enroll_trimester")) ascbEnrollEl("enroll_trimester").value = "";
        if (ascbEnrollEl("enroll_subjectRows")) ascbEnrollEl("enroll_subjectRows").innerHTML = "";
        ascbEnrollCalculateTotalUnits("enroll_subjectRows");

        ascbLoadEnrollment();

    } catch (error) {
        console.error("Enrollment save failed:", error);
        if (status) status.textContent = "Unable to reach the server. Please check your connection.";
    }
}

function ascbEnrollOpenEdit(id) {
    const row = ascbEnrollRows.find(r => Number(r.id) === Number(id));
    if (!row) return;

    ascbEnrollEl("enroll_edit_id").value = row.id;
    if (ascbEnrollEl("enroll_edit_studentIdDisplay")) ascbEnrollEl("enroll_edit_studentIdDisplay").textContent = row.student_id || "—";
    ascbEnrollEl("enroll_edit_surname").value = row.surname || "";
    ascbEnrollEl("enroll_edit_firstName").value = row.first_name || "";
    ascbEnrollEl("enroll_edit_middleName").value = row.middle_name || "";
    ascbEnrollSuffixSet("enroll_edit", row.suffix, row.suffix_position);
    if (ascbEnrollEl("enroll_edit_sex")) ascbEnrollEl("enroll_edit_sex").value = row.sex || "";
    if (ascbEnrollEl("enroll_edit_civilStatus")) ascbEnrollEl("enroll_edit_civilStatus").value = row.civil_status || "";
    if (ascbEnrollEl("enroll_edit_studentType")) ascbEnrollEl("enroll_edit_studentType").value = row.student_type || "";
    ascbEnrollSetBirthdateSelects("enroll_edit_birthMonth", "enroll_edit_birthDay", "enroll_edit_birthYear", row.birth_date || "");
    if (ascbEnrollEl("enroll_edit_birthPlace")) ascbEnrollEl("enroll_edit_birthPlace").value = row.birth_place || "";
    ascbEnrollEl("enroll_edit_address").value = row.address || "";
    if (ascbEnrollEl("enroll_edit_mobileNumber")) ascbEnrollEl("enroll_edit_mobileNumber").value = row.mobile_number || "";
    if (ascbEnrollEl("enroll_edit_guardianName")) ascbEnrollEl("enroll_edit_guardianName").value = row.guardian_name || "";
    if (ascbEnrollEl("enroll_edit_email")) ascbEnrollEl("enroll_edit_email").value = row.email || "";
    ascbEnrollEl("enroll_edit_prevSchoolJuniorHs").value = row.prev_school_junior_hs || "";
    ascbEnrollEl("enroll_edit_prevSchoolSeniorHs").value = row.prev_school_senior_hs || "";
    if (ascbEnrollEl("enroll_edit_juniorHsGraduated")) ascbEnrollEl("enroll_edit_juniorHsGraduated").value = row.junior_hs_graduated || "";
    if (ascbEnrollEl("enroll_edit_seniorHsGraduated")) ascbEnrollEl("enroll_edit_seniorHsGraduated").value = row.senior_hs_graduated || "";

    if (ascbEnrollEl("enroll_edit_program")) ascbEnrollEl("enroll_edit_program").value = row.program_code || "";
    if (ascbEnrollEl("enroll_edit_major")) ascbEnrollEl("enroll_edit_major").value = row.major || "";
    if (ascbEnrollEl("enroll_edit_yearLevel")) ascbEnrollEl("enroll_edit_yearLevel").value = row.year_level || "";
    // I-refresh muna ang Trimester/Semester <select> (label + options)
    // base sa term_type ng napiling program bago i-set ang value —
    // kung hindi, mananatiling "Trimester" ang label kahit Semester
    // na ang course, dahil hindi na-trigger ang onchange ng dropdown
    // (programmatic set lang ito, hindi user click).
    ascbEnrollUpdateTermSelect("enroll_edit_trimester", row.program_code || "");
    if (ascbEnrollEl("enroll_edit_trimester")) ascbEnrollEl("enroll_edit_trimester").value = row.trimester || "";
    if (ascbEnrollEl("enroll_edit_schoolYear")) ascbEnrollEl("enroll_edit_schoolYear").value = row.school_year || "";

    ascbEnrollPopulateSubjects("enroll_edit_subjectRows", row.subjects || []);

    const status = ascbEnrollEl("enrollEditStatus");
    if (status) status.style.display = "none";

    ascbEnrollEl("enrollEditModal").classList.add("active");
}

function ascbEnrollCloseEdit() {
    ascbEnrollEl("enrollEditModal").classList.remove("active");
}

async function ascbEnrollSubmitEdit() {
    const id = ascbEnrollEl("enroll_edit_id") ? ascbEnrollEl("enroll_edit_id").value : "";
    const surname = ascbEnrollEl("enroll_edit_surname") ? ascbEnrollEl("enroll_edit_surname").value.trim() : "";
    const firstName = ascbEnrollEl("enroll_edit_firstName") ? ascbEnrollEl("enroll_edit_firstName").value.trim() : "";
    const middleName = ascbEnrollEl("enroll_edit_middleName") ? ascbEnrollEl("enroll_edit_middleName").value.trim() : "";
    const { suffix, suffixPosition } = ascbEnrollSuffixValues("enroll_edit");
    const sex = ascbEnrollEl("enroll_edit_sex") ? ascbEnrollEl("enroll_edit_sex").value : "";
    const civilStatus = ascbEnrollEl("enroll_edit_civilStatus") ? ascbEnrollEl("enroll_edit_civilStatus").value : "";
    const email = ascbEnrollEl("enroll_edit_email") ? ascbEnrollEl("enroll_edit_email").value.trim() : "";
    const studentType = ascbEnrollEl("enroll_edit_studentType") ? ascbEnrollEl("enroll_edit_studentType").value : "";
    const birthDate = ascbEnrollGetBirthdateValue("enroll_edit_birthMonth", "enroll_edit_birthDay", "enroll_edit_birthYear");
    const birthPlace = ascbEnrollEl("enroll_edit_birthPlace") ? ascbEnrollEl("enroll_edit_birthPlace").value.trim() : "";
    const address = ascbEnrollEl("enroll_edit_address") ? ascbEnrollEl("enroll_edit_address").value.trim() : "";
    const mobileNumber = ascbEnrollEl("enroll_edit_mobileNumber") ? ascbEnrollEl("enroll_edit_mobileNumber").value.trim() : "";
    const guardianName = ascbEnrollEl("enroll_edit_guardianName") ? ascbEnrollEl("enroll_edit_guardianName").value.trim() : "";
    const prevSchoolJuniorHs = ascbEnrollEl("enroll_edit_prevSchoolJuniorHs") ? ascbEnrollEl("enroll_edit_prevSchoolJuniorHs").value.trim() : "";
    const prevSchoolSeniorHs = ascbEnrollEl("enroll_edit_prevSchoolSeniorHs") ? ascbEnrollEl("enroll_edit_prevSchoolSeniorHs").value.trim() : "";
    const juniorHsGraduated = ascbEnrollEl("enroll_edit_juniorHsGraduated") ? ascbEnrollEl("enroll_edit_juniorHsGraduated").value.trim() : "";
    const seniorHsGraduated = ascbEnrollEl("enroll_edit_seniorHsGraduated") ? ascbEnrollEl("enroll_edit_seniorHsGraduated").value.trim() : "";
    const programCode = ascbEnrollEl("enroll_edit_program") ? ascbEnrollEl("enroll_edit_program").value : "";
    const courseMajor = ascbGetCourseMajor(programCode);
    const yearLevel = ascbEnrollEl("enroll_edit_yearLevel") ? ascbEnrollEl("enroll_edit_yearLevel").value : "";
    const trimester = ascbEnrollEl("enroll_edit_trimester") ? ascbEnrollEl("enroll_edit_trimester").value : "";
    const schoolYear = ascbEnrollEl("enroll_edit_schoolYear") ? ascbEnrollEl("enroll_edit_schoolYear").value.trim() : "";
    const subjects = ascbEnrollCollectSubjects("enroll_edit_subjectRows");

    if (!surname || !firstName) {
        alert("Surname and Given Name are required.");
        return;
    }

    const status = ascbEnrollEl("enrollEditStatus");
    if (status) {
        status.style.display = "block";
        status.textContent = "Saving…";
    }

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                action: "update", id, surname, firstName, middleName, suffix, suffixPosition, sex, civilStatus, email, studentType, birthDate, birthPlace, address, mobileNumber, guardianName,
                prevSchoolJuniorHs, prevSchoolSeniorHs, juniorHsGraduated, seniorHsGraduated,
                programCode, course: courseMajor.course, major: courseMajor.major,
                yearLevel, trimester, schoolYear, subjects,
            }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = (data && data.error) ? data.error : "Hindi na-save. Subukan muli.";
            return;
        }

        ascbEnrollCloseEdit();
        ascbLoadEnrollment();

        if (data.status === "pending") {
            alert("The update was saved, but it will go back to \"Pending\" — it still needs to be approved by the Unit Head.");
        }

    } catch (error) {
        console.error("Enrollment update failed:", error);
        if (status) status.textContent = "Unable to reach the server. Please check your connection.";
    }
}

/* ---------------------------------------------------------
   NEW TERM
   ---------------------------------------------------------
   Ginagamit kapag ie-enroll ulit ang isang estudyante para sa
   susunod na term (hal. 2nd Trimester). Kinokopya ang personal
   info AT ang Course/Major/Year Level/Trimester/School Year
   mula sa lumang record papunta sa BAGONG record (action=create,
   may sariling bagong id) — para hindi mas malito mag-encode;
   nananatili pa ring pwedeng i-edit/palitan ng user ang mga ito
   (hal. lipat ng trimester o school year) bago i-save. Blangko
   pa rin ang Subjects — kailangan pa ring piliin ng user para sa
   bagong term. Hindi ito humihipo sa lumang record, kaya buo pa
   rin ang history nito sa Grade Evaluation.
   --------------------------------------------------------- */

function ascbEnrollOpenNewTerm(id) {
    const row = ascbEnrollRows.find(r => Number(r.id) === Number(id));
    if (!row) return;

    ascbEnrollEl("enroll_newterm_sourceId").value = row.id;
    ascbEnrollEl("enroll_newterm_studentId").value = row.student_id || "";
    if (ascbEnrollEl("enroll_newterm_studentIdDisplay")) ascbEnrollEl("enroll_newterm_studentIdDisplay").textContent = row.student_id || "—";
    if (ascbEnrollEl("enroll_newterm_nameDisplay")) ascbEnrollEl("enroll_newterm_nameDisplay").textContent = ascbEnrollFullName(row);
    ascbEnrollEl("enroll_newterm_surname").value = row.surname || "";
    ascbEnrollEl("enroll_newterm_firstName").value = row.first_name || "";
    ascbEnrollEl("enroll_newterm_middleName").value = row.middle_name || "";
    if (ascbEnrollEl("enroll_newterm_suffix")) ascbEnrollEl("enroll_newterm_suffix").value = row.suffix || "";
    if (ascbEnrollEl("enroll_newterm_suffixPosition")) ascbEnrollEl("enroll_newterm_suffixPosition").value = row.suffix ? (row.suffix_position || "separate") : "separate";
    ascbEnrollEl("enroll_newterm_birthDate").value = row.birth_date ? String(row.birth_date).slice(0, 10) : "";
    if (ascbEnrollEl("enroll_newterm_birthPlace")) ascbEnrollEl("enroll_newterm_birthPlace").value = row.birth_place || "";
    ascbEnrollEl("enroll_newterm_address").value = row.address || "";
    if (ascbEnrollEl("enroll_newterm_mobileNumber")) ascbEnrollEl("enroll_newterm_mobileNumber").value = row.mobile_number || "";
    if (ascbEnrollEl("enroll_newterm_guardianName")) ascbEnrollEl("enroll_newterm_guardianName").value = row.guardian_name || "";
    ascbEnrollEl("enroll_newterm_prevSchoolJuniorHs").value = row.prev_school_junior_hs || "";
    ascbEnrollEl("enroll_newterm_prevSchoolSeniorHs").value = row.prev_school_senior_hs || "";
    if (ascbEnrollEl("enroll_newterm_juniorHsGraduated")) ascbEnrollEl("enroll_newterm_juniorHsGraduated").value = row.junior_hs_graduated || "";
    if (ascbEnrollEl("enroll_newterm_seniorHsGraduated")) ascbEnrollEl("enroll_newterm_seniorHsGraduated").value = row.senior_hs_graduated || "";

    // I-carry over ang Course/Major/Year Level/Trimester/School Year
    // ng dati niyang term — pwede pa ring baguhin ng user (hal.
    // lumipat ng trimester o bagong school year) bago i-save.
    if (ascbEnrollEl("enroll_newterm_sex")) ascbEnrollEl("enroll_newterm_sex").value = row.sex || "";
    if (ascbEnrollEl("enroll_newterm_civilStatus")) ascbEnrollEl("enroll_newterm_civilStatus").value = row.civil_status || "";
    if (ascbEnrollEl("enroll_newterm_email")) ascbEnrollEl("enroll_newterm_email").value = row.email || "";
    if (ascbEnrollEl("enroll_newterm_studentType")) ascbEnrollEl("enroll_newterm_studentType").value = row.student_type || "";
    if (ascbEnrollEl("enroll_newterm_program")) ascbEnrollEl("enroll_newterm_program").value = row.program_code || "";
    if (ascbEnrollEl("enroll_newterm_major")) ascbEnrollEl("enroll_newterm_major").value = row.major || "";
    if (ascbEnrollEl("enroll_newterm_yearLevel")) ascbEnrollEl("enroll_newterm_yearLevel").value = row.year_level || "";
    // I-refresh muna ang Trimester/Semester <select> (label + options)
    // base sa term_type ng napiling program bago i-set ang value —
    // kung hindi, mananatiling "Trimester" ang label kahit Semester
    // na ang course, dahil hindi na-trigger ang onchange ng dropdown
    // (programmatic set lang ito, hindi user click).
    ascbEnrollUpdateTermSelect("enroll_newterm_trimester", row.program_code || "");
    if (ascbEnrollEl("enroll_newterm_trimester")) ascbEnrollEl("enroll_newterm_trimester").value = row.trimester || "";
    if (ascbEnrollEl("enroll_newterm_schoolYear")) ascbEnrollEl("enroll_newterm_schoolYear").value = row.school_year || "";
    // Sadyang blangko pa rin ang Subjects — bagong term, bagong
    // listahan ng subjects ang piplan ng user.
    if (ascbEnrollEl("enroll_newterm_subjectRows")) ascbEnrollEl("enroll_newterm_subjectRows").innerHTML = "";
    ascbEnrollLoadSubjectSelects("enroll_newterm_subjectRows", "enroll_newterm_program");

    const note = ascbEnrollEl("enrollNewTermNote");
    if (note) {
        note.innerHTML = `Gagawa ito ng <strong>bagong record</strong> para sa susunod na term ni <strong>${escapeHTML(ascbEnrollFullName(row))}</strong>. Mananatiling buo at hindi mababago ang record ng dati niyang term — makikita pa rin ito sa Grade Evaluation.`;
    }

    const status = ascbEnrollEl("enrollNewTermStatus");
    if (status) status.style.display = "none";

    /* (design) Punan ang read-only na Personal Information / School Background. */
    const roMap = {
        sex: row.sex, civilStatus: row.civil_status, email: row.email,
        birthDate: row.birth_date ? ascbEnrollFormatDate(row.birth_date) : "",
        birthPlace: row.birth_place, mobileNumber: row.mobile_number,
        guardianName: row.guardian_name, address: row.address,
        prevSchoolJuniorHs: row.prev_school_junior_hs, prevSchoolSeniorHs: row.prev_school_senior_hs,
        juniorHsGraduated: row.junior_hs_graduated, seniorHsGraduated: row.senior_hs_graduated
    };
    Object.keys(roMap).forEach(k => {
        const el = ascbEnrollEl("enroll_newterm_view_" + k);
        if (el) el.textContent = (roMap[k] && String(roMap[k]).trim()) || "—";
    });

    ascbEnrollEl("enrollNewTermModal").classList.add("active");
    ascbEnrollNewTermApplyMaster(row);
}

/* (fix) Ang New Term form ay pre-filled mula sa LUMANG enrollment row, kaya
   luma pa rin ang Suffix (at pangalan) kahit na-update na sa Master Record.
   Pagkabukas ng form, kunin ang CURRENT na pangalan + suffix + PSA placement
   mula sa Master Record at ilagay dito. */
async function ascbEnrollNewTermApplyMaster(row) {
    try {
        if (!row || !row.student_id) return;
        if (typeof ascbMrInvalidateNames === "function") ascbMrInvalidateNames(); /* laging sariwa, hindi cached */
        const names = await ascbMasterCurrentNames();
        const n = names && names[row.student_id];
        if (!n) return;
        const srcEl = ascbEnrollEl("enroll_newterm_sourceId");
        if (!srcEl || Number(srcEl.value) !== Number(row.id)) return; /* ibang record na ang nakabukas */
        const set = (id, v) => { const el = ascbEnrollEl(id); if (el) el.value = v || ""; };
        set("enroll_newterm_surname", n.surname);
        set("enroll_newterm_firstName", n.firstName);
        set("enroll_newterm_middleName", n.middleName);
        set("enroll_newterm_suffix", n.suffix);
        set("enroll_newterm_suffixPosition", n.suffix ? (n.suffixPosition || "separate") : "separate");
        const fullName = n.fullName || ascbNamePrint(n.surname, n.firstName, n.middleName, n.suffix, n.suffixPosition);
        if (ascbEnrollEl("enroll_newterm_nameDisplay")) ascbEnrollEl("enroll_newterm_nameDisplay").textContent = fullName;
        const note = ascbEnrollEl("enrollNewTermNote");
        if (note) {
            note.innerHTML = `Gagawa ito ng <strong>bagong record</strong> para sa susunod na term ni <strong>${escapeHTML(fullName)}</strong>. Mananatiling buo at hindi mababago ang record ng dati niyang term — makikita pa rin ito sa Grade Evaluation.`;
        }
    } catch (e) { /* huwag harangan ang New Term form */ }
}

function ascbEnrollCloseNewTerm() {
    ascbEnrollEl("enrollNewTermModal").classList.remove("active");
}

async function ascbEnrollSubmitNewTerm() {
    const sourceEnrollmentId = ascbEnrollEl("enroll_newterm_sourceId") ? Number(ascbEnrollEl("enroll_newterm_sourceId").value || 0) : 0;
    const studentId = ascbEnrollEl("enroll_newterm_studentId") ? ascbEnrollEl("enroll_newterm_studentId").value.trim() : "";
    const surname = ascbEnrollEl("enroll_newterm_surname") ? ascbEnrollEl("enroll_newterm_surname").value.trim() : "";
    const firstName = ascbEnrollEl("enroll_newterm_firstName") ? ascbEnrollEl("enroll_newterm_firstName").value.trim() : "";
    const middleName = ascbEnrollEl("enroll_newterm_middleName") ? ascbEnrollEl("enroll_newterm_middleName").value.trim() : "";
    const suffix = ascbEnrollEl("enroll_newterm_suffix") ? ascbEnrollEl("enroll_newterm_suffix").value.trim() : "";
    const suffixPosition = suffix && ascbEnrollEl("enroll_newterm_suffixPosition") ? (ascbEnrollEl("enroll_newterm_suffixPosition").value || "separate") : "separate";
    const sex = ascbEnrollEl("enroll_newterm_sex") ? ascbEnrollEl("enroll_newterm_sex").value : "";
    const civilStatus = ascbEnrollEl("enroll_newterm_civilStatus") ? ascbEnrollEl("enroll_newterm_civilStatus").value : "";
    const email = ascbEnrollEl("enroll_newterm_email") ? ascbEnrollEl("enroll_newterm_email").value.trim() : "";
    const studentType = ascbEnrollEl("enroll_newterm_studentType") ? ascbEnrollEl("enroll_newterm_studentType").value : "";
    const birthDate = ascbEnrollEl("enroll_newterm_birthDate") ? ascbEnrollEl("enroll_newterm_birthDate").value : "";
    const birthPlace = ascbEnrollEl("enroll_newterm_birthPlace") ? ascbEnrollEl("enroll_newterm_birthPlace").value.trim() : "";
    const address = ascbEnrollEl("enroll_newterm_address") ? ascbEnrollEl("enroll_newterm_address").value.trim() : "";
    const mobileNumber = ascbEnrollEl("enroll_newterm_mobileNumber") ? ascbEnrollEl("enroll_newterm_mobileNumber").value.trim() : "";
    const guardianName = ascbEnrollEl("enroll_newterm_guardianName") ? ascbEnrollEl("enroll_newterm_guardianName").value.trim() : "";
    const prevSchoolJuniorHs = ascbEnrollEl("enroll_newterm_prevSchoolJuniorHs") ? ascbEnrollEl("enroll_newterm_prevSchoolJuniorHs").value.trim() : "";
    const prevSchoolSeniorHs = ascbEnrollEl("enroll_newterm_prevSchoolSeniorHs") ? ascbEnrollEl("enroll_newterm_prevSchoolSeniorHs").value.trim() : "";
    const juniorHsGraduated = ascbEnrollEl("enroll_newterm_juniorHsGraduated") ? ascbEnrollEl("enroll_newterm_juniorHsGraduated").value.trim() : "";
    const seniorHsGraduated = ascbEnrollEl("enroll_newterm_seniorHsGraduated") ? ascbEnrollEl("enroll_newterm_seniorHsGraduated").value.trim() : "";
    const programCode = ascbEnrollEl("enroll_newterm_program") ? ascbEnrollEl("enroll_newterm_program").value : "";
    const courseMajor = ascbGetCourseMajor(programCode);
    const yearLevel = ascbEnrollEl("enroll_newterm_yearLevel") ? ascbEnrollEl("enroll_newterm_yearLevel").value : "";
    const trimester = ascbEnrollEl("enroll_newterm_trimester") ? ascbEnrollEl("enroll_newterm_trimester").value : "";
    const schoolYear = ascbEnrollEl("enroll_newterm_schoolYear") ? ascbEnrollEl("enroll_newterm_schoolYear").value.trim() : "";
    const subjects = ascbEnrollCollectSubjects("enroll_newterm_subjectRows");

    const status = ascbEnrollEl("enrollNewTermStatus");
    const showError = (message, fieldId) => {
        if (status) {
            status.style.display = "block";
            status.textContent = message;
            status.classList.add("is-error");
            status.setAttribute("role", "alert");
        } else { alert(message); }
        if (fieldId) {
            const field = ascbEnrollEl(fieldId);
            if (field) { field.focus(); field.scrollIntoView({ behavior: "smooth", block: "center" }); }
        }
    };

    if (!sourceEnrollmentId) { showError("Unable to identify the source enrollment. Please close New Term and open it again from the student's current enrollment."); return; }
    if (!surname || !firstName) { showError("Please enter the student's Surname and Given Name.", !surname ? "enroll_newterm_surname" : "enroll_newterm_firstName"); return; }
    if (!programCode) { showError("Please select a Course / Program.", "enroll_newterm_program"); return; }
    if (!yearLevel) { showError("Please select a Year Level.", "enroll_newterm_yearLevel"); return; }
    if (!trimester) { showError("Please select a Trimester / Semester.", "enroll_newterm_trimester"); return; }
    if (!/^\d{4}-\d{4}$/.test(schoolYear)) { showError("Invalid School Year. Use the format YYYY-YYYY, for example 2026-2027.", "enroll_newterm_schoolYear"); return; }
    const sy = schoolYear.split("-").map(Number);
    if (sy[1] !== sy[0] + 1) { showError("Invalid School Year. The second year must be the first year + 1 (e.g. 2026-2027).", "enroll_newterm_schoolYear"); return; }
    if (!subjects.length) { showError("Please add or load at least one subject before saving the New Term."); return; }

    const saveButton = document.querySelector('#enrollNewTermModal button[onclick="ascbEnrollSubmitNewTerm()"]');
    if (saveButton) { saveButton.disabled = true; saveButton.dataset.originalText = saveButton.textContent; saveButton.textContent = "Saving…"; }
    if (status) { status.style.display = "block"; status.textContent = "Saving…"; status.classList.remove("is-error"); status.removeAttribute("role"); }

    try {
        // action=create palagi — kahit galing sa dati nang estudyante,
        // BAGONG row ito sa `enrollees` (hindi kailanman action=update),
        // kaya hindi kailanman mao-overwrite ang lumang term.
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                action: "create",
                sourceEnrollmentId,
                studentId,
                surname, firstName, middleName, suffix, suffixPosition, sex, civilStatus, email, studentType, birthDate, birthPlace, address, mobileNumber, guardianName,
                prevSchoolJuniorHs, prevSchoolSeniorHs, juniorHsGraduated, seniorHsGraduated,
                programCode, course: courseMajor.course, major: courseMajor.major,
                yearLevel, trimester, schoolYear, subjects,
            }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = (data && data.error) ? data.error : "Hindi na-save. Subukan muli.";
            return;
        }

        ascbEnrollCloseNewTerm();
        ascbLoadEnrollment();
        ascbHandleStudentAccountResponse(data, [surname, firstName].filter(Boolean).join(", "));

        if (data.status === "pending") {
            alert("The new term was saved, but it is \"Pending\" for now — it still needs to be approved by the Unit Head.");
        }

    } catch (error) {
        console.error("New term enrollment save failed:", error);
        showError("Unable to reach the server. Please check your connection and try again.");
    } finally {
        if (saveButton) { saveButton.disabled = false; saveButton.textContent = saveButton.dataset.originalText || "Save New Term"; }
    }
}

async function ascbEnrollDelete(id) {
    // "Delete" dito ay nag-a-ARCHIVE lang ng record (hindi tuluyang
    // binubura sa database) — makikita pa rin ito sa "Archive" menu,
    // "Restore" na lang ang gagamitin para ibalik.
    if (!(await ascbConfirm("This enrollee will be moved to Archive (it will not be permanently deleted from the database). Continue?"))) return;

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "delete", id }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            alert((data && data.error) ? data.error : "Unable to archive. Please try again.");
            return;
        }

        // Alinman sa Enrollment/New Term list o sa Rejected Students
        // list ang pinanggalingan nito, i-refresh ang parehong listahan
        // na kasalukuyang nakabukas (ligtas tawagin ang dalawa — ang
        // hindi kasalukuyang view lang ang tahimik na mag-uupdate).
        ascbLoadEnrollment();
        if (typeof ascbLoadRejectedStudents === "function") ascbLoadRejectedStudents();

    } catch (error) {
        console.error("Enrollment delete/archive failed:", error);
        alert("Unable to reach the server. Please check your connection.");
    }
}


/* =========================================================
   REJECTED STUDENTS
   ---------------------------------------------------------
   Hiwalay na listahan para sa mga enrollee na "rejected" ang
   status (hindi pa naka-archive) — scope=rejected sa
   api/enrollment.php. Habang nandito ang isang estudyante,
   HINDI siya lumalabas sa Enrollment / New Term list o sa
   Grade Evaluation. "Delete" dito ay gumagamit pa rin ng
   ascbEnrollDelete() sa itaas — nag-a-archive lang, hindi
   tuluyang binubura sa database.
   ========================================================= */

let ascbRejectedRows = [];
let ascbRejectedPage = 1;
let ascbRejectedTotalPages = 1;
let ascbRejectedTotal = 0;

const ascbRejectedRequestGuard = ascbMakeRequestGuard();
async function ascbLoadRejectedStudents() {
    const status = ascbEnrollEl("rejectedStatus");
    const wrapper = ascbEnrollEl("rejectedTableWrapper");

    if (status) {
        status.style.display = "block";
        status.textContent = "Loading records…";
    }
    if (wrapper) wrapper.style.display = "none";

    const term = (ascbEnrollEl("rejectedSearchInput") ? ascbEnrollEl("rejectedSearchInput").value : "").trim();
    const qs = new URLSearchParams({ scope: "rejected", page: String(ascbRejectedPage), limit: String(ASCB_PAGE_SIZE) });
    if (term) qs.set("q", term);

    const ascbRejectedToken = ascbRejectedRequestGuard.start();
    try {
        const response = await fetch("api/enrollment.php?" + qs.toString());
        const data = await response.json();
        if (!ascbRejectedRequestGuard.isCurrent(ascbRejectedToken)) return;

        if (!data || !data.ok) {
            if (status) status.textContent = "Unable to load records. Please try again.";
            return;
        }

        ascbRejectedRows = Array.isArray(data.rows) ? data.rows : [];
        ascbRejectedPage = data.page || 1;
        ascbRejectedTotalPages = data.totalPages || 1;
        ascbRejectedTotal = typeof data.total === "number" ? data.total : ascbRejectedRows.length;
        ascbRejectedRenderTable();

        if (status) status.style.display = "none";
        if (wrapper) wrapper.style.display = "block";

    } catch (error) {
        if (!ascbRejectedRequestGuard.isCurrent(ascbRejectedToken)) return;
        console.error("Rejected students load failed:", error);
        if (status) status.textContent = "Unable to reach the server. Please check your connection or refresh the page.";
    }
}

const ascbRejectedFilter = ascbDebounce(function () {
    ascbRejectedPage = 1;
    ascbLoadRejectedStudents();
}, 350);

function ascbRejectedGoToPage(page) {
    ascbRejectedPage = page;
    ascbLoadRejectedStudents();
}

function ascbRejectedRenderTable() {
    const body = ascbEnrollEl("rejectedTableBody");
    if (!body) return;

    const perms = (typeof ASCB_PERMISSIONS !== "undefined") ? ASCB_PERMISSIONS : {};

    if (!ascbRejectedRows.length) {
        body.innerHTML = `<tr><td colspan="7" class="records-empty">Walang rejected na estudyante.</td></tr>`;
        const paginationEl = ascbEnrollEl("rejectedPagination");
        if (paginationEl) paginationEl.innerHTML = "";
        return;
    }

    body.innerHTML = ascbRejectedRows.map(row => {
        const deleteBtn = perms.deleteEnrollment
            ? `<button type="button" class="btn btn-danger-solid approved-so-action-btn action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbEnrollDelete(${row.id})">${ascbIcon('delete')}</button>`
            : "";

        const reasonLabel = row.approval_remarks
            ? escapeHTML(row.approval_remarks)
            : (row.approved_by_name ? `Na-reject ni ${escapeHTML(row.approved_by_name)}` : "—");

        return `
            <tr>
                <td data-label="Student ID">${escapeHTML(row.student_id || "—")}</td>
                <td data-label="Name">${escapeHTML(ascbEnrollFullName(row))}</td>
                <td data-label="Course">${escapeHTML(row.course || "—")}</td>
                <td data-label="Major">${escapeHTML(row.major || "—")}</td>
                <td data-label="School Year">${escapeHTML(row.school_year || "—")}</td>
                <td data-label="Reason / Rejected By">${reasonLabel}</td>
                <td data-label="Actions">
                    <button type="button" class="btn btn-outline approved-so-action-btn action-icon-btn" title="View" aria-label="View" onclick="ascbEnrollShowDetail(${row.id})">${ascbIcon('view')}</button>
                    ${deleteBtn}
                </td>
            </tr>`;
    }).join("");

    ascbRenderPagination("rejectedPagination", ascbRejectedPage, ascbRejectedTotalPages, ascbRejectedTotal, ASCB_PAGE_SIZE, "ascbRejectedGoToPage");
}


/* =========================================================
   ARCHIVE
   ---------------------------------------------------------
   Mga enrollee na na-archive na (dating "Delete" mula sa
   Enrollment, New Term, o Rejected Students) — scope=archived
   sa api/enrollment.php. Hindi sila tuluyang nabubura sa
   database dito — "Restore" ang ibinabalik sa normal na
   listahan, at "Delete Permanently" na lang ang tunay na
   tumatanggal sa database (kailangan munang naka-archive).
   ========================================================= */

let ascbArchiveRows = [];
let ascbArchivePage = 1;
let ascbArchiveTotalPages = 1;
let ascbArchiveTotal = 0;
const ascbArchiveRequestGuard = ascbMakeRequestGuard();

async function ascbLoadArchive() {
    const status = ascbEnrollEl("archiveStatus");
    const wrapper = ascbEnrollEl("archiveTableWrapper");

    if (status) {
        status.style.display = "block";
        status.textContent = "Loading records…";
    }
    if (wrapper) wrapper.style.display = "none";

    const term = (ascbEnrollEl("archiveSearchInput") ? ascbEnrollEl("archiveSearchInput").value : "").trim();
    const qs = new URLSearchParams({ scope: "archived", page: String(ascbArchivePage), limit: String(ASCB_PAGE_SIZE) });
    if (term) qs.set("q", term);

    const ascbArchiveToken = ascbArchiveRequestGuard.start();
    try {
        const response = await fetch("api/enrollment.php?" + qs.toString());
        const data = await response.json();
        if (!ascbArchiveRequestGuard.isCurrent(ascbArchiveToken)) return;

        if (!data || !data.ok) {
            if (status) status.textContent = "Unable to load records. Please try again.";
            return;
        }

        ascbArchiveRows = Array.isArray(data.rows) ? data.rows : [];
        ascbArchivePage = data.page || 1;
        ascbArchiveTotalPages = data.totalPages || 1;
        ascbArchiveTotal = typeof data.total === "number" ? data.total : ascbArchiveRows.length;
        ascbArchiveRenderTable();

        if (status) status.style.display = "none";
        if (wrapper) wrapper.style.display = "block";

    } catch (error) {
        if (!ascbArchiveRequestGuard.isCurrent(ascbArchiveToken)) return;
        console.error("Archive load failed:", error);
        if (status) status.textContent = "Unable to reach the server. Please check your connection or refresh the page.";
    }
}

const ascbArchiveFilter = ascbDebounce(function () {
    ascbArchivePage = 1;
    ascbLoadArchive();
}, 350);

function ascbArchiveGoToPage(page) {
    ascbArchivePage = page;
    ascbLoadArchive();
}

function ascbArchiveRenderTable() {
    const body = ascbEnrollEl("archiveTableBody");
    if (!body) return;

    const perms = (typeof ASCB_PERMISSIONS !== "undefined") ? ASCB_PERMISSIONS : {};

    if (!ascbArchiveRows.length) {
        body.innerHTML = `<tr><td colspan="7" class="records-empty">Walang naka-archive na record.</td></tr>`;
        const paginationEl = ascbEnrollEl("archivePagination");
        if (paginationEl) paginationEl.innerHTML = "";
        return;
    }

    body.innerHTML = ascbArchiveRows.map(row => {
        const restoreBtn = perms.deleteEnrollment
            ? `<button type="button" class="btn btn-success-solid approved-so-action-btn action-icon-btn" title="Restore" aria-label="Restore" onclick="ascbEnrollRestore(${row.id})">${ascbIcon('restore')}</button>`
            : "";
        const permDeleteBtn = perms.deleteEnrollment
            ? `<button type="button" class="btn btn-danger-solid approved-so-action-btn action-icon-btn" title="Delete Permanently" aria-label="Delete Permanently" onclick="ascbEnrollPermanentDelete(${row.id})">${ascbIcon('deleteForever')}</button>`
            : "";

        const archivedByLabel = [
            row.archived_by_name ? ` ${escapeHTML(row.archived_by_name)}` : "",
            row.archive_reason ? escapeHTML(row.archive_reason) : "",
        ].filter(Boolean).join(" — ") || "—";

        return `
            <tr>
                <td data-label="Student ID">${escapeHTML(row.student_id || "—")}</td>
                <td data-label="Name">${escapeHTML(ascbEnrollFullName(row))}</td>
                <td data-label="Course">${escapeHTML(row.course || "—")}</td>
                <td data-label="Major">${escapeHTML(row.major || "—")}</td>
                <td data-label="Archived On">${escapeHTML(ascbEnrollFormatDate(row.archived_at))}</td>
                <td data-label="Archived By / Reason">${archivedByLabel}</td>
                <td data-label="Actions">
                    <button type="button" class="btn btn-outline approved-so-action-btn action-icon-btn" title="View" aria-label="View" onclick="ascbEnrollShowDetail(${row.id})">${ascbIcon('view')}</button>
                    ${restoreBtn}
                    ${permDeleteBtn}
                </td>
            </tr>`;
    }).join("");

    ascbRenderPagination("archivePagination", ascbArchivePage, ascbArchiveTotalPages, ascbArchiveTotal, ASCB_PAGE_SIZE, "ascbArchiveGoToPage");
}

async function ascbEnrollRestore(id) {
    if (!(await ascbConfirm("Restore?"))) return;

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "restore", id }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            alert((data && data.error) ? data.error : "Unable to restore. Please try again.");
            return;
        }

        ascbLoadArchive();
        ascbLoadEnrollment();
        if (typeof ascbLoadRejectedStudents === "function") ascbLoadRejectedStudents();

    } catch (error) {
        console.error("Enrollment restore failed:", error);
        alert("Unable to reach the server. Please check your connection.");
    }
}

async function ascbEnrollPermanentDelete(id) {
    if (!(await ascbConfirm("Are you sure you want to Remove this?", { danger: true }))) return;

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "delete", id }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            alert((data && data.error) ? data.error : "Unable to delete. Please try again.");
            return;
        }

        ascbLoadArchive();

    } catch (error) {
        console.error("Enrollment permanent delete failed:", error);
        alert("Unable to reach the server. Please check your connection.");
    }
}


/* =========================================================
   ENROLLMENT — COURSE / MAJOR / SUBJECTS (mula sa prospectus)
   ---------------------------------------------------------
   Generic helpers na ginagamit ng parehong "Enroll a Student"
   form (enroll_subjectRows) at ng Edit Enrollee modal
   (enroll_edit_subjectRows). Gumagamit ng `structuredPrograms`
   at `programNames` na naka-define na sa script.js
   (prospectus data) — parehong pinagmumulan ng Certificate /
   Grade Evaluation module, kaya laging magkatugma ang subjects.
   ========================================================= */

/* Hinahati ang programNames[code] sa { course, major } — kung
   walang "Major in" sa label, blangko ang major. */
function ascbGetCourseMajor(programCode) {

    const label = (typeof programNames !== "undefined" && programNames[programCode]) || "";

    const marker = " Major in ";
    const idx = label.indexOf(marker);

    if (idx === -1) {
        return { course: label, major: "" };
    }

    return {
        course: label.substring(0, idx).trim(),
        major: label.substring(idx + marker.length).trim(),
    };
}

/* Tinatawag kapag pinalitan ang Course/Program select — nire-refresh
   ang major field at ang mga subject dropdown sa loob ng
   kaukulang container. */
function ascbEnrollProgramChanged(programSelectId, majorInputId, rowsContainerId, trimesterSelectId) {

    programSelectId = programSelectId || "enroll_program";
    majorInputId = majorInputId || "enroll_major";
    rowsContainerId = rowsContainerId || "enroll_subjectRows";
    trimesterSelectId = trimesterSelectId || "enroll_trimester";

    const programSelect = document.getElementById(programSelectId);
    const majorInput = document.getElementById(majorInputId);

    const programCode = programSelect ? programSelect.value : "";
    const parts = ascbGetCourseMajor(programCode);

    if (majorInput) {
        majorInput.value = parts.major || "";
    }

    ascbEnrollUpdateTermSelect(trimesterSelectId, programCode);
    ascbEnrollLoadSubjectSelects(rowsContainerId, programSelectId);
}

/* Ire-refresh lang ang <option> ng mga .enroll-subject-select sa
   loob ng isang container, base sa currently selected program. */
function ascbEnrollLoadSubjectSelects(rowsContainerId, programSelectId) {

    const container = document.getElementById(rowsContainerId);
    if (!container) return;

    const programSelect = document.getElementById(programSelectId);
    const program = programSelect ? programSelect.value : "";

    const isStructured = program && typeof structuredPrograms !== "undefined" && structuredPrograms[program];

    container.querySelectorAll(".enroll-subject-select").forEach(select => {

        const oldValue = select.value;

        select.innerHTML = `
            <option value="">Select Subject</option>
            <option value="__CUSTOM__">+ Add Custom Subject</option>
        `;

        if (isStructured) {
            structuredPrograms[program].forEach(group => {

                const optgroup = document.createElement("optgroup");
                optgroup.label = `${group.year} — ${group.trimester}`;

                group.subjects.forEach(subject => {
                    const option = document.createElement("option");
                    option.value = JSON.stringify(subject);
                    option.textContent = `${subject.code} — ${subject.description} (${subject.units} units)`;
                    optgroup.appendChild(option);
                });

                select.appendChild(optgroup);
            });
        }

        if (oldValue && [...select.options].some(o => o.value === oldValue)) {
            select.value = oldValue;
        }
    });
}

/* Load-Subjects-for-Term — kagaya ng addSubjectsForTerm() ng
   Certificate module, pero naka-scope sa isang container at
   generic ang element ids (para magamit ulit sa Edit modal). */
function ascbEnrollAddSubjectsForTerm(rowsContainerId, programSelectId, yearSelectId, trimesterSelectId) {

    const programSelect = document.getElementById(programSelectId);
    const yearSelect = document.getElementById(yearSelectId);
    const trimesterSelect = document.getElementById(trimesterSelectId);

    const program = programSelect ? programSelect.value : "";
    const year = yearSelect ? yearSelect.value : "";
    const trimester = trimesterSelect ? trimesterSelect.value : "";

    if (!program) {
        alert("Please select a Course / Program first.");
        return;
    }

    if (!year || !trimester) {
        alert("Please select the Year Level and Trimester before loading subjects.");
        return;
    }

    if (typeof structuredPrograms === "undefined" || !structuredPrograms[program]) {
        alert("This program has no structured prospectus. Please use \"Add Subject\" instead.");
        return;
    }

    const group = structuredPrograms[program].find(g => g.year === year && g.trimester === trimester);

    if (!group) {
        alert("No subjects are listed for this Year Level and Trimester.");
        return;
    }

    const container = document.getElementById(rowsContainerId);
    if (!container) return;

    const existingCodes = new Set();
    container.querySelectorAll(".enroll-subject-row").forEach(row => {
        const code = row.dataset.customCode || ascbEnrollGetRowSubjectCode(row);
        if (code) existingCodes.add(code);
    });

    let addedCount = 0;

    group.subjects.forEach(subject => {
        if (existingCodes.has(subject.code)) return;
        ascbEnrollAddSubjectRow(rowsContainerId, subject);
        addedCount++;
    });

    ascbEnrollCalculateTotalUnits(rowsContainerId);

    if (addedCount === 0) {
        alert("All subjects for this term have already been added.");
    }
}

function ascbEnrollGetRowSubjectCode(row) {
    const select = row.querySelector(".enroll-subject-select");
    if (!select || !select.value || select.value === "__CUSTOM__") return null;
    try {
        return JSON.parse(select.value).code;
    } catch (error) {
        return null;
    }
}

/* Nalalaman ng function kung saang program-select/total-units-cell
   siya dapat sumangguni base sa containerId. BUG FIX: dati,
   kahit anong container id ang hindi "enroll_edit_subjectRows"
   ay bumabalik sa Total Units / GWA cells ng MAIN Enroll form —
   kaya kapag nagdagdag ng bagong container (hal. New Term),
   sisirain nito ang display ng ibang form. Ngayon, whitelist na
   ang bawat kilalang container, at ligtas (null/null) ang
   default kung hindi kilala. */
function ascbEnrollContainerConfig(rowsContainerId) {
    if (rowsContainerId === "enroll_subjectRows") {
        return { programSelectId: "enroll_program", totalUnitsId: "enroll_totalUnitsInput", gwaId: "enroll_gwaValueInput" };
    }
    if (rowsContainerId === "enroll_edit_subjectRows") {
        return { programSelectId: "enroll_edit_program", totalUnitsId: null, gwaId: null };
    }
    if (rowsContainerId === "enroll_newterm_subjectRows") {
        return { programSelectId: "enroll_newterm_program", totalUnitsId: null, gwaId: null };
    }
    return { programSelectId: "enroll_program", totalUnitsId: null, gwaId: null };
}

function ascbEnrollAddSubjectRow(rowsContainerId, subjectData) {

    const tbody = document.getElementById(rowsContainerId);
    if (!tbody) return;

    const row = document.createElement("tr");
    row.className = "enroll-subject-row";

    row.innerHTML = `
        <td>
            <select class="enroll-subject-select" onchange="ascbEnrollSelectSubject(this, '${rowsContainerId}')">
                <option value="">Select Subject</option>
            </select>
        </td>
        <td>
            <input type="text" class="enroll-subject-description" placeholder="Course Description">
        </td>
        <td>
            <input type="number" class="enroll-subject-units" min="0" step="1" value="0" oninput="ascbEnrollCalculateTotalUnits('${rowsContainerId}')">
        </td>
        <td style="text-align:center">
            <button type="button" class="btn btn-danger action-icon-btn" title="Remove" aria-label="Remove" onclick="ascbEnrollRemoveSubjectRow(this, '${rowsContainerId}')">${ascbIcon('reject')}</button>
        </td>
    `;

    tbody.appendChild(row);

    const config = ascbEnrollContainerConfig(rowsContainerId);
    ascbEnrollLoadSubjectSelects(rowsContainerId, config.programSelectId);

    if (subjectData) {
        const select = row.querySelector(".enroll-subject-select");
        const description = row.querySelector(".enroll-subject-description");
        const units = row.querySelector(".enroll-subject-units");
        if (subjectData.code) {
            select.value = JSON.stringify({ code: subjectData.code, description: subjectData.description, units: subjectData.units });
            if (select.value === "" || ![...select.options].some(o => o.value === select.value)) {
                row.dataset.customCode = subjectData.code;
            }
        }

        description.value = subjectData.description || "";
        units.value = subjectData.units || 0;
    }

    ascbEnrollCalculateTotalUnits(rowsContainerId);
}

async function ascbEnrollSelectSubject(select, rowsContainerId) {

    const row = select.closest(".enroll-subject-row");

    if (select.value === "__CUSTOM__") {

        const code = await ascbPrompt("Enter Course Code:");
        if (!code) { select.value = ""; return; }

        const description = await ascbPrompt("Enter Course Description:");
        if (!description) { select.value = ""; return; }

        const units = await ascbPrompt("Enter Units:", "3");

        row.querySelector(".enroll-subject-description").value = description;
        row.querySelector(".enroll-subject-units").value = units || 0;
        row.dataset.customCode = code;

        ascbEnrollCalculateTotalUnits(rowsContainerId);
        return;
    }

    if (!select.value) {
        row.querySelector(".enroll-subject-description").value = "";
        row.querySelector(".enroll-subject-units").value = 0;
        delete row.dataset.customCode;
        ascbEnrollCalculateTotalUnits(rowsContainerId);
        return;
    }

    try {
        const subject = JSON.parse(select.value);

        /* Duplicate check: hindi dapat paulit-ulit na mapili ang
           parehong subject code sa loob ng iisang term/container —
           dati, tahimik itong nagme-merge sa server nang walang
           anumang babala, kaya posibleng mabura nang hindi sinasadya
           ang units/grade ng unang row. */
        const container = document.getElementById(rowsContainerId);
        if (container && subject.code) {
            const isDuplicate = [...container.querySelectorAll(".enroll-subject-row")].some(otherRow => {
                if (otherRow === row) return false;
                return ascbEnrollGetRowSubjectCode(otherRow) === subject.code;
            });
            if (isDuplicate) {
                alert(`"${subject.code} — ${subject.description}" has already been added to this term. Please choose a different subject.`);
                select.value = "";
                row.querySelector(".enroll-subject-description").value = "";
                row.querySelector(".enroll-subject-units").value = 0;
                ascbEnrollCalculateTotalUnits(rowsContainerId);
                return;
            }
        }

        row.querySelector(".enroll-subject-description").value = subject.description;
        row.querySelector(".enroll-subject-units").value = subject.units;
        delete row.dataset.customCode;
        ascbEnrollCalculateTotalUnits(rowsContainerId);
    } catch (error) {
        console.error(error);
    }
}

function ascbEnrollRemoveSubjectRow(button, rowsContainerId) {
    button.closest(".enroll-subject-row").remove();
    ascbEnrollCalculateTotalUnits(rowsContainerId);
}

function ascbEnrollCalculateTotalUnits(rowsContainerId) {

    const container = document.getElementById(rowsContainerId);
    if (!container) return;

    let total = 0;
    container.querySelectorAll(".enroll-subject-units").forEach(input => {
        total += parseFloat(input.value) || 0;
    });

    const config = ascbEnrollContainerConfig(rowsContainerId);
    if (config.totalUnitsId && document.getElementById(config.totalUnitsId)) {
        document.getElementById(config.totalUnitsId).textContent = total;
    }

    ascbEnrollCalculateGWA(rowsContainerId);
}

/* Grades are intentionally not calculated in Enrollment.
   Enrollment records subjects and units only; Grade Management
   owns grade entry and GWA is calculated from the grade records. */
function ascbEnrollCalculateGWA(rowsContainerId) {
    // Grades are maintained separately in Grade Management.
    return 0;
}

/* Kinokolekta ang mga subject row (code/description/units) para
   isama sa POST body papunta sa api/enrollment.php. */
function ascbEnrollCollectSubjects(rowsContainerId) {

    const container = document.getElementById(rowsContainerId);
    if (!container) return [];

    const subjects = [];

    container.querySelectorAll(".enroll-subject-row").forEach(row => {

        const select = row.querySelector(".enroll-subject-select");
        const description = row.querySelector(".enroll-subject-description");
        const units = row.querySelector(".enroll-subject-units");
        let code = row.dataset.customCode || "";

        if (!code && select && select.value && select.value !== "__CUSTOM__") {
            try {
                code = JSON.parse(select.value).code || "";
            } catch (error) {
                code = "";
            }
        }

        const descriptionValue = description ? description.value.trim() : "";

        if (!code && !descriptionValue) return;

        subjects.push({
            code,
            description: descriptionValue,
            units: units ? (parseFloat(units.value) || 0) : 0,
        });
    });

    return subjects;
}

/* Pinupuno ang isang subject table (Edit modal) base sa
   `subjects` array na galing sa row.subjects (api response). */
function ascbEnrollPopulateSubjects(rowsContainerId, subjects) {

    const container = document.getElementById(rowsContainerId);
    if (!container) return;

    container.innerHTML = "";

    (Array.isArray(subjects) ? subjects : []).forEach(subject => {
        ascbEnrollAddSubjectRow(rowsContainerId, subject);
    });

    ascbEnrollCalculateTotalUnits(rowsContainerId);
}



/* =========================================================
   GRADE MANAGEMENT
   ---------------------------------------------------------
   Separate from Enrollment. Enrollment stores the term + subject
   assignment. This module stores/updates the actual grades.
   ========================================================= */
let ascbGradeMgmtRows = [];
let ascbGradeMgmtStudents = [];
let ascbGradeMgmtPage = 1;
let ascbGradeMgmtCurrent = null;
let ascbGradeMgmtBaseline = new Map(); // subjectId -> { units, grade } bago baguhin ng user; ginagamit para i-enable/disable ang Save Grades

function ascbGradeMgmtEl(id) { return document.getElementById(id); }

/* =========================================================
   BULK GRADE/STUDENT IMPORT (.xlsx / .csv, Department Export format)
   ---------------------------------------------------------
   Dalawang hakbang: PREVIEW muna (walang isinusulat sa DB,
   pinapakita lang ang buod/errors), tapos COMMIT lang kapag
   na-confirm na ng UNIT HEAD. Parehong tumatawag sa
   api/grade_import.php gamit ang parehong napiling file.
   ========================================================= */

function ascbGradeImportOpen() {
    const modal = document.getElementById('gradeImportModal');
    if (!modal) return;
    const fileInput = document.getElementById('gradeImportFile'); if (fileInput) fileInput.value = '';
    const result = document.getElementById('gradeImportResult'); if (result) result.innerHTML = '';
    const status = document.getElementById('gradeImportStatus'); if (status) { status.style.display = 'none'; status.textContent = ''; }
    const commitBtn = document.getElementById('gradeImportCommitBtn'); if (commitBtn) commitBtn.style.display = 'none';
    const normalizeBtn = document.getElementById('gradeImportNormalizeBtn'); if (normalizeBtn) normalizeBtn.style.display = 'none';
    const previewBtn = document.getElementById('gradeImportPreviewBtn'); if (previewBtn) previewBtn.style.display = 'inline-flex';
    modal.classList.add('active');
}

function ascbGradeImportClose() {
    const modal = document.getElementById('gradeImportModal');
    if (modal) modal.classList.remove('active');
}

function ascbGradeImportBadge(label, value, kind) {
    const cls = kind ? `gi-badge gi-${kind}` : 'gi-badge';
    return `<div class="gi-stat ${cls}"><div class="gi-stat-value">${escapeHTML(String(value ?? 0))}</div><div class="gi-stat-label">${escapeHTML(label)}</div></div>`;
}

function ascbGradeImportRenderAnalysis(data) {
    const result = document.getElementById('gradeImportResult');
    if (!result) return;

    const confidence = data.confidence || (data.errors?.length ? 'Needs Review' : 'High Confidence');
    const confidenceClass = confidence === 'High Confidence' ? 'high' : (confidence === 'Medium Confidence' ? 'medium' : 'review');
    const errors = Array.isArray(data.errors) ? data.errors : [];
    const warnings = Array.isArray(data.warnings) ? data.warnings : [];
    const unknown = Array.isArray(data.unrecognizedColumns) ? data.unrecognizedColumns : [];
    const normalizeBtn = document.getElementById('gradeImportNormalizeBtn');
    if (normalizeBtn) normalizeBtn.style.display = errors.length ? 'none' : 'inline-flex';

    const mappingRows = Object.keys(data.mapping || {}).map(sheet => {
        const cols = Array.isArray((data.mapping || {})[sheet]) ? (data.mapping || {})[sheet] : [];
        return `<tr><td>${escapeHTML(sheet)}</td><td>${cols.map(c => { const sem=c.semantic||c.field||''; return `<span class="gi-map-chip"><strong>${escapeHTML(c.header || '')}</strong> → ${escapeHTML(sem)}${c.field&&c.field!==sem?` <small>(${escapeHTML(c.field)})</small>`:''}</span>`; }).join(' ') || '—'}</td></tr>`;
    }).join('');

    const issueList = errors.length
        ? `<div class="gi-panel gi-danger"><strong>Needs Review / Import blockers (${errors.length})</strong><ul>${errors.slice(0,100).map(e=>`<li>${escapeHTML(e)}</li>`).join('')}</ul>${errors.length>100?'<small>Only the first 100 issues are shown.</small>':''}</div>`
        : '';
    const warningList = warnings.length
        ? `<div class="gi-panel gi-warning"><strong>Warnings (${warnings.length})</strong><ul>${warnings.slice(0,50).map(e=>`<li>${escapeHTML(e)}</li>`).join('')}</ul></div>`
        : '';
    const unknownList = unknown.length
        ? `<div class="gi-panel"><strong>Unrecognized / ignored columns</strong><div style="margin-top:6px;">${unknown.map(x=>`<span class="gi-map-chip">${escapeHTML(x)}</span>`).join(' ')}</div></div>`
        : '';

    const sampleRows=(data.sample||[]).map(s=>`<tr>
        <td>${escapeHTML(s.studentId||'—')}</td><td>${escapeHTML(s.name||'—')}</td>
        <td>${escapeHTML([s.term,s.schoolYear].filter(Boolean).join(' / ')||'—')}</td>
        <td>${escapeHTML(s.subjectCount)}</td><td>${escapeHTML(s.importCount)}</td>
        <td>${Number(s.duplicateCount||0)>0?escapeHTML(s.duplicateCount):'—'}</td>
    </tr>`).join('');

    result.innerHTML = `
      <style>
        .gi-summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;margin:10px 0}
        .gi-stat{border:1px solid var(--border,#ddd);border-radius:9px;padding:9px;text-align:center;background:var(--card,#fff)}
        .gi-stat-value{font-size:20px;font-weight:700}.gi-stat-label{font-size:11px;color:var(--muted)}
        .gi-badge{border-left:4px solid var(--muted,#777)}.gi-high{border-left-color:#238636}.gi-medium{border-left-color:#b7791f}.gi-review{border-left-color:#c62828}
        .gi-confidence{font-weight:700;margin:8px 0}.gi-panel{margin-top:10px;border:1px solid var(--border,#ddd);border-radius:8px;padding:10px;font-size:12.5px}
        .gi-danger{border-color:#e5a4a4}.gi-warning{border-color:#e5c98c}.gi-panel ul{margin:7px 0 0;padding-left:20px}.gi-panel li{margin:3px 0}
        .gi-map-chip{display:inline-block;border:1px solid var(--border,#ddd);border-radius:999px;padding:3px 7px;margin:2px;font-size:11px}
        .gi-table{width:100%;border-collapse:collapse;font-size:12px}.gi-table th,.gi-table td{padding:6px;border-bottom:1px solid var(--border,#ddd);text-align:left}
      </style>
      <div class="gi-confidence ${confidenceClass}">Detection result: <strong>${escapeHTML(confidence)}</strong> · ${escapeHTML(data.sheetsProcessed||0)} sheet(s) analyzed</div>
      <div class="gi-summary">
        ${ascbGradeImportBadge('Students detected',data.studentBlocks)}
        ${ascbGradeImportBadge('Existing students',data.studentsExisting,'high')}
        ${ascbGradeImportBadge('New students',data.studentsNew)}
        ${ascbGradeImportBadge('Existing enrollments',data.existingEnrollments,'high')}
        ${ascbGradeImportBadge('New enrollments',data.newEnrollments)}
        ${ascbGradeImportBadge('Subjects detected',data.subjectRows)}
        ${ascbGradeImportBadge('New subjects',data.subjectsNew)}
        ${ascbGradeImportBadge('Subject updates',data.subjectsExisting,'high')}
        ${ascbGradeImportBadge('Grade updates',data.gradeUpdates,'high')}
      </div>
      ${data.autoRepaired ? `<div class="gi-panel"><strong>Automatic data repair</strong>: ${escapeHTML(data.autoRepaired)} value(s) completed/normalized from the ASCB database or curriculum catalog.<br><small>${(data.repairNotes||[]).map(x=>escapeHTML(x)).join(' · ')}</small></div>` : ''}
      ${issueList}${warningList}${unknownList}
      ${mappingRows ? `<details class="gi-panel"><summary><strong>Detected column mapping</strong></summary><div style="margin:7px 0;color:var(--muted);">PROGRAM = student's degree/course; SUBJECT = individual subject/course code and description. The importer decides ambiguous "Course" labels from actual values and the program catalog.</div><table class="gi-table"><thead><tr><th>Sheet</th><th>Mapping</th></tr></thead><tbody>${mappingRows}</tbody></table></details>`:''}
      ${sampleRows ? `<details open class="gi-panel"><summary><strong>Import preview sample</strong></summary><table class="gi-table"><thead><tr><th>Student ID</th><th>Name</th><th>Term / SY</th><th>Subjects</th><th>To import</th><th>Conflicts</th></tr></thead><tbody>${sampleRows}</tbody></table></details>`:''}
    `;
}

async function ascbGradeImportPreview() {
    const fileInput=document.getElementById('gradeImportFile');
    const file=fileInput?.files?.[0]||null;
    const status=document.getElementById('gradeImportStatus');
    const result=document.getElementById('gradeImportResult');
    const commitBtn=document.getElementById('gradeImportCommitBtn');
    if(!file){alert('Please select an .xlsx or .csv file first.');return;}
    const ext=(file.name.split('.').pop()||'').toLowerCase();
    if(!['xlsx','csv'].includes(ext)){alert('Only .xlsx or .csv files are supported.');return;}
    if(status){status.style.display='block';status.textContent='Analyzing workbook, sheets, headers, students and subjects…';}
    if(result) result.innerHTML='';
    if(commitBtn) commitBtn.style.display='none';
    const fd=new FormData();fd.append('action','preview');fd.append('file',file);
    let res=null,data=null;
    try{
        res=await fetch('api/grade_import.php',{method:'POST',body:fd});
        data=await res.json();
    }catch(e){
        /* Tunay na network/timeout o hindi-JSON na sagot (hal. 504 mula sa hosting sa malaking file). */
        if(status)status.style.display='none';
        if(result)result.innerHTML='<div class="records-status" style="display:block;color:var(--danger,#a92720);">Unable to reach the server o naputol ang koneksyon habang ina-analyze ang file. Subukan ulit; kung malaki ang file at paulit-ulit ito, hatiin muna ang file. Walang binago sa database ang Analyze.</div>';
        return;
    }
    if(status)status.style.display='none';
    try{
        if(!res.ok||!data.ok){ascbGradeImportRenderAnalysis(data||{errors:[data?.error||'Unable to analyze the file.']});return;}
        ascbGradeImportRenderAnalysis(data);
        if(commitBtn && (!data.errors||!data.errors.length)) commitBtn.style.display='inline-flex';
    }catch(e){
        /* Sumagot nang maayos ang server; ang nag-error ay ang pagpapakita ng resulta sa screen. */
        console.error('Grade import analysis render failed:',e);
        if(result)result.innerHTML='<div class="records-status" style="display:block;color:var(--danger,#a92720);">Na-analyze ng server ang file, pero nagka-error sa pagpapakita ng resulta: '+escapeHTML(e&&e.message?e.message:'unknown')+'. I-refresh ang page (Ctrl+F5) at subukan ulit.</div>';
    }
}

function ascbGradeImportHistoryClose(){
    const m=document.getElementById('gradeImportHistoryModal'); if(m)m.classList.remove('active');
}
async function ascbGradeImportHistoryOpen(){
    const m=document.getElementById('gradeImportHistoryModal'), b=document.getElementById('gradeImportHistoryBody');
    if(!m||!b)return;
    m.classList.add('active'); b.innerHTML='<div class="records-status" style="display:block;">Loading import history…</div>';
    try{
        const res=await fetch('api/grade_import_history.php?limit=100');
        const data=await res.json();
        if(!res.ok||!data.ok) throw new Error(data?.error||'Unable to load history');
        if(!data.rows?.length){b.innerHTML=`<div class="records-status" style="display:block;">${escapeHTML(data.message||'No import history yet.')}</div>`;return;}
        b.innerHTML=`<div style="overflow:auto;"><table class="f137-mini-table" style="width:100%;font-size:12px;">
          <thead><tr><th>Date</th><th>File</th><th>Imported by</th><th>Students</th><th>Enrollments</th><th>Subjects</th><th>Grades</th><th>Warnings</th><th>Status</th></tr></thead>
          <tbody>${data.rows.map(r=>`<tr>
            <td>${escapeHTML(r.imported_at||'—')}</td><td>${escapeHTML(r.filename||'—')}</td><td>${escapeHTML(r.display_name||r.imported_by_username||'—')}</td>
            <td>${escapeHTML(`${r.students_processed} (${r.students_created} new / ${r.students_updated} existing)`)}</td>
            <td>${escapeHTML(r.enrollments_created)}</td>
            <td>${escapeHTML(`${r.subjects_processed} (${r.subjects_created} new / ${r.subjects_updated} updated)`)}</td>
            <td>${escapeHTML(`${r.grades_imported} new / ${r.grades_updated} updated`)}</td>
            <td>${escapeHTML(r.warning_count)}</td><td>${escapeHTML(r.status||'—')}</td>
          </tr>`).join('')}</tbody></table></div>`;
    }catch(e){b.innerHTML='<div class="records-status" style="display:block;color:var(--danger,#a92720);">Unable to load import history.</div>';}
}

async function ascbGradeImportNormalizeExport() {
    const fileInput=document.getElementById('gradeImportFile');
    const file=fileInput?.files?.[0]||null;
    const status=document.getElementById('gradeImportStatus');
    if(!file){alert('Please select the same workbook you analyzed.');return;}
    if(status){status.style.display='block';status.textContent='Building the normalized ASCB Excel format…';}
    const fd=new FormData(); fd.append('action','export_normalized'); fd.append('file',file);
    try{
        const res=await fetch('api/grade_import.php',{method:'POST',body:fd});
        const ct=(res.headers.get('content-type')||'').toLowerCase();
        if(!res.ok || !ct.includes('spreadsheetml')){
            let msg='Unable to create the normalized Excel file.';
            try{const d=await res.json(); if(d?.error) msg=d.error;}catch(e){}
            throw new Error(msg);
        }
        const blob=await res.blob();
        const cd=res.headers.get('content-disposition')||'';
        const m=cd.match(/filename="?([^";]+)"?/i);
        const name=m?m[1]:'ASCB_Normalized_Import.xlsx';
        const url=URL.createObjectURL(blob); const a=document.createElement('a');
        a.href=url; a.download=name; document.body.appendChild(a); a.click(); a.remove();
        setTimeout(()=>URL.revokeObjectURL(url),1000);
        if(status){status.style.display='block';status.textContent='Normalized ASCB Excel created successfully.';}
    }catch(e){
        if(status){status.style.display='block';status.textContent='';}
        alert(e.message||'Unable to create the normalized Excel file.');
    }
}

async function ascbGradeImportCommit() {
    const fileInput = document.getElementById('gradeImportFile');
    const file = fileInput?.files?.[0] || null;
    if (!file) { alert('Please select an .xlsx or .csv file first.'); return; }
    if (!(await ascbConfirm('This will be written to the database — Enrollment + Grade Evaluation. Are you sure?', { danger: true }))) return;

    const status = document.getElementById('gradeImportStatus');
    const result = document.getElementById('gradeImportResult');
    if (status) { status.style.display = 'block'; status.textContent = 'Importing…'; }

    const fd = new FormData(); fd.append('action', 'commit'); fd.append('file', file); fd.append('defer_accounts', '1');
    let data = null, importDone = false;
    try {
        let res;
        try {
            res = await fetch('api/grade_import.php', { method: 'POST', body: fd });
            data = await res.json();
        } catch (netErr) {
            /* (fix) Putol ang koneksyon/timeout o hindi JSON ang sagot: HINDI ito nangangahulugang hindi pumasok ang import —
               tuloy pa rin ito sa server (ignore_user_abort). Huwag sabihing "unable to reach" at huwag mag-upload ulit. */
            if (status) status.style.display = 'none';
            if (result) result.innerHTML = `<div class="records-status" style="display:block;color:var(--warning,#b45309);"><strong>⏳ Naputol ang koneksyon bago dumating ang sagot ng server.</strong><br>Maaaring <strong>tuloy pa at matatapos</strong> ang import sa server. Huwag munang mag-upload ulit — hintayin ng ilang minuto, tapos i-check ang <a href="#" onclick="ascbGradeImportHistoryOpen();return false;">Import History</a> o ang Grade Management.</div>`;
            return;
        }
        if (status) status.style.display = 'none';
        if (!res.ok || !data.ok) {
            const errList = Array.isArray(data.errors) && data.errors.length
                ? '<ul style="margin:8px 0 0;padding-left:18px;">' + data.errors.map(e => `<li>${escapeHTML(e)}</li>`).join('') + '</ul>'
                : '';
            if (result) result.innerHTML = `<div class="records-status" style="display:block;color:var(--danger,#a92720);">${escapeHTML(data.error || 'Unable to import the file.')}${errList}</div>`;
            return;
        }
        const dupDone = Number(data.duplicateRows || 0);
        const importedIds = Array.isArray(data.importedStudentIds) ? data.importedStudentIds : [];
        // Kadalasang dahilan kung bakit "successful ang import pero parang
        // hindi lumalabas sa View/Update": nandoon naman talaga ang record,
        // nasa ibang page lang (25 per page, alpabetikal) o na-mask ng
        // dating aktibong search sa Grade Management. Ibinibigay dito ang
        // bawat apektadong Student ID bilang isang click-to-locate chip.
        const chipsHtml = importedIds.length
            ? `<div style="margin-top:8px;font-size:12px;">Ma-a-access agad: ${importedIds.map(id => `<button type="button" class="btn btn-outline" style="padding:2px 8px;margin:2px;font-size:12px;" onclick="ascbGradeImportJumpToStudent('${escapeHTML(id).replace(/'/g, "\\'")}')">${escapeHTML(id)}</button>`).join('')}</div>`
            : '';
        if (result) result.innerHTML = `<div class="records-status" style="display:block;color:var(--success,#1a7f37);">
            <strong>✅ Migration completed successfully.</strong><br>
            ${data.studentBlocks||0} students processed · ${data.newEnrollments||0} enrollments created ·
            ${data.subjectRows||0} subjects processed · ${data.studentsCreated||0} students created ·
            ${data.studentsUpdated||0} existing students matched · ${data.subjectsCreated||0} subjects created ·
            ${data.subjectsUpdated||0} subjects updated · ${data.gradesImported||0} grades inserted ·
            ${data.gradesUpdated||0} grades updated.
            ${chipsHtml}</div>`;
        // AUTO STUDENT ACCOUNT: isang beses lang ibinibigay ang temporary passwords — i-download agad.
        importDone = true;
        document.getElementById('gradeImportCommitBtn').style.display = 'none';
        document.getElementById('gradeImportPreviewBtn').style.display = 'none';
        let sa = data.studentAccounts || null;
        if (data.accountsDeferred && importedIds.length) {
            sa = await ascbGradeImportCreateAccounts(importedIds, result);
        }
        ascbGradeImportRenderAccounts(result, sa);
        document.getElementById('gradeImportCommitBtn').style.display = 'none';
        document.getElementById('gradeImportPreviewBtn').style.display = 'none';
        // I-reset ang page/search ng Grade Management papuntang unang page
        // na walang filter, para hindi ma-mask ng dating context ang mga
        // bagong-import na record kapag na-reload ang listahan.
        ascbGradeMgmtPage = 1;
        const gmSearch = ascbGradeMgmtEl('gradeMgmtSearchInput');
        if (gmSearch) gmSearch.value = '';
        await ascbLoadGradeManagement();
    } catch (e) {
        if (status) status.style.display = 'none';
        console.error('Grade import post-processing failed:', e);
        if (importDone) {
            /* Pumasok na ang import; ang nagka-error ay ang paglalabas/pag-refresh sa screen, hindi ang server. */
            if (result) result.insertAdjacentHTML('beforeend', `<div class="records-status" style="display:block;color:var(--warning,#b45309);margin-top:8px;">Natapos ang import, pero may error sa pag-refresh ng screen. I-refresh ang page (Ctrl+F5) para makita ang listahan.</div>`);
        } else if (result) {
            result.innerHTML = `<div class="records-status" style="display:block;color:var(--danger,#a92720);">May error sa pagproseso ng sagot ng server: ${escapeHTML(e && e.message ? e.message : 'unknown')}. I-check ang Import History bago mag-upload ulit.</div>`;
        }
    }
}

/* Gumawa ng STUDENT accounts nang 20 bawat request, may progress. Ibinabalik ang pinagsamang resulta. */
async function ascbGradeImportCreateAccounts(ids, result) {
    const total = ids.length, BATCH = 20;
    const acc = { created: 0, existing: 0, failed: 0, credentials: [] };
    let box = null;
    if (result && result.firstElementChild) {
        result.firstElementChild.insertAdjacentHTML('beforeend', '<div id="gradeImportAcctProgress" style="margin-top:10px;font-size:12.5px;"></div>');
        box = document.getElementById('gradeImportAcctProgress');
    }
    for (let i = 0; i < total; i += BATCH) {
        const slice = ids.slice(i, i + BATCH);
        if (box) box.textContent = 'Creating student accounts… ' + Math.min(i, total) + ' / ' + total;
        let ok = false;
        for (let attempt = 0; attempt < 2 && !ok; attempt++) {
            try {
                const fd = new FormData(); fd.append('action', 'create_accounts'); fd.append('studentIds', JSON.stringify(slice));
                const res = await fetch('api/grade_import.php', { method: 'POST', body: fd });
                const d = await res.json();
                if (res.ok && d && d.ok) {
                    acc.created += d.created || 0; acc.existing += d.existing || 0; acc.failed += d.failed || 0;
                    if (Array.isArray(d.credentials)) acc.credentials.push(...d.credentials);
                    ok = true;
                }
            } catch (e) { /* subukan ulit nang isang beses (existing accounts ay hindi nadodoble) */ }
        }
        if (!ok) acc.failed += slice.length;
    }
    if (box && box.parentNode) box.parentNode.removeChild(box);
    return acc;
}

function ascbGradeImportRenderAccounts(result, sa) {
    if (!(sa && result && result.firstElementChild)) return;
    window.__ascbImportCreds = Array.isArray(sa.credentials) ? sa.credentials : [];
    result.firstElementChild.insertAdjacentHTML('beforeend',
        `<div style="margin-top:10px;font-size:12.5px;"><strong>Student accounts:</strong> ${sa.created||0} created · ${sa.existing||0} already had one${sa.failed ? ` · <span style="color:var(--danger,#a92720)">${sa.failed} failed (use the key button)</span>` : ''}.` +
        (window.__ascbImportCreds.length
            ? ` <button type="button" class="btn btn-outline" style="padding:2px 10px;font-size:12px;" onclick="ascbDownloadStudentCredentialsCsv(window.__ascbImportCreds)">Download credentials (CSV)</button><br><em>Temporary passwords are shown only once — download them now.</em>`
            : '') + `</div>`);
}

// Direktang pumunta sa isang partikular na estudyante sa Grade Management
// mula sa "✅ Successful!" na resulta ng Import — sinasagot nito ang
// pinaka-madalas na dahilan kung bakit "successful ang import pero parang
// hindi lumalabas sa View/Update": nasa ibang page lang o na-mask ng
// dating search filter ang bagong record.
async function ascbGradeImportJumpToStudent(studentId) {
    ascbGradeImportClose();
    ascbGradeMgmtPage = 1;
    const gmSearch = ascbGradeMgmtEl('gradeMgmtSearchInput');
    if (gmSearch) gmSearch.value = studentId;
    await ascbLoadGradeManagement(1);
    const idx = ascbGradeMgmtStudents.findIndex(s => s.studentId === studentId);
    if (idx >= 0) ascbGradeManagementOpenByIndex(idx);
}

async function ascbLoadGradeManagement(pageOverride = null) {
    if (pageOverride !== null) ascbGradeMgmtPage = Math.max(1, Number(pageOverride) || 1);
    // Kagaya ng Grade Evaluation, ang api/grades.php ang nagfi-filter na
    // ng status='approved' lang, kaya hindi rin makikita/ma-grade dito
    // ang mga estudyanteng "pending" pa (naghihintay ng approval ng
    // UNIT HEAD) o "rejected".
    const reviewBtn=ascbGradeMgmtEl('gradeCorrectionReviewBtn'); if(reviewBtn) reviewBtn.style.display=ASCB_PERMISSIONS?.approveRecordCorrection?'inline-flex':'none';
    const importBtn=ascbGradeMgmtEl('gradeImportBtn'); if(importBtn) importBtn.style.display=ASCB_PERMISSIONS?.importGrades?'inline-flex':'none';
    const gradebookBtn=ascbGradeMgmtEl('gradebookBtn'); if(gradebookBtn) gradebookBtn.style.display=ASCB_PERMISSIONS?.manageProfessorGradebook?'inline-flex':'none';
    const approvalWorkflowBtn=ascbGradeMgmtEl('gradebookApprovalWorkflowBtn'); if(approvalWorkflowBtn){const role=String(ASCB_CURRENT_USER?.role||'').toUpperCase();approvalWorkflowBtn.style.display=(ASCB_PERMISSIONS?.manageProfessorGradebook||role==='ADMIN STAFF'||role==='UNIT HEAD'||role==='SCHOOL REGISTRAR')?'inline-flex':'none';}
    ascbGradeMgmtRejectedLoad(); // badge lang sa Grade Approval Workflow button (Admin Staff)
    const scopeNote = ascbGradeMgmtEl('gradeMgmtScopeNote');
    if (scopeNote) {
        const currentRole = String(ASCB_CURRENT_USER?.role || '').toUpperCase();
        scopeNote.textContent = currentRole === 'ADMIN STAFF'
            ? 'Showing students from your assigned department(s) and course/program(s) only.'
            : 'Add & Update Grades of Student.';
    }
    const status = ascbGradeMgmtEl('gradeMgmtStatus');
    const wrapper = ascbGradeMgmtEl('gradeMgmtWrapper');
    if (status) { status.style.display = 'block'; status.textContent = 'Loading students…'; }
    if (wrapper) wrapper.style.display = 'none';
    try {
        const response = await fetch('api/grades.php?group=student&page=' + encodeURIComponent(String(ascbGradeMgmtPage)) + '&limit=25&q=' + encodeURIComponent((ascbGradeMgmtEl('gradeMgmtSearchInput')?.value||'').trim()));
        const data = await response.json();
        if (!data || !data.ok) throw new Error(data && data.error ? data.error : 'Load failed');
        ascbGradeMgmtRows = Array.isArray(data.rows) ? data.rows : [];
        ascbGradeMgmtTotal = Number(data.total || 0);
        const groups = new Map();
        ascbGradeMgmtRows.forEach(row => {
            const key = row.student_id || [row.surname,row.first_name,row.middle_name].map(v => (v||'').trim().toLowerCase()).join('|');
            if (!key) return;
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key).push(row);
        });
        ascbGradeMgmtStudents = [...groups.entries()].map(([key, rows]) => {
            rows.sort((a,b) => new Date(b.created_at||0)-new Date(a.created_at||0));
            const latest = rows[0];
            const terms = [];
            const termMap = new Map();
            rows.forEach(r => {
                const tk = String(r.enrollment_id);
                if (!termMap.has(tk)) { termMap.set(tk, { enrollmentId:r.enrollment_id, trimester:r.trimester||'', schoolYear:r.school_year||'', yearLevel:r.year_level||'', course:(r.program_code||r.course||''), major:r.major||'', rows:[] }); }
                if (r.enrollment_subject_id) termMap.get(tk).rows.push(r);
            });
            termMap.forEach(t => terms.push(t));
            terms.sort((a,b) => new Date((rows.find(r=>Number(r.enrollment_id)===Number(b.enrollmentId))||{}).created_at||0)-new Date((rows.find(r=>Number(r.enrollment_id)===Number(a.enrollmentId))||{}).created_at||0));
            return { key, fullName: [latest.surname, latest.first_name, latest.middle_name].filter(Boolean).join(', '), studentId:latest.student_id||'', course:(latest.program_code||latest.course||''), major:latest.major||'', terms };
        }).sort((a,b)=>a.fullName.localeCompare(b.fullName));
        await ascbMasterApplyCurrentNames(ascbGradeMgmtStudents, ', ');
        ascbGradeMgmtStudents.sort((a,b)=>a.fullName.localeCompare(b.fullName));
        ascbGradeMgmtPage = pageOverride === null ? 1 : ascbGradeMgmtPage;
        ascbGradeManagementRender();
        if (status) status.style.display='none';
        if (wrapper) wrapper.style.display='block';
    } catch (e) {
        console.error('Grade Management load failed:', e);
        if (status) status.textContent='Unable to load Grade Management. Please try again.' + (e && e.message && e.message!=='Load failed' ? ' (' + e.message + ')' : '');
    }
}

let ascbGradeMgmtSearchTimer = null;
function ascbGradeManagementFilter() {
    ascbGradeMgmtPage = 1;
    clearTimeout(ascbGradeMgmtSearchTimer);
    ascbGradeMgmtSearchTimer = setTimeout(() => ascbLoadGradeManagement(), 250);
}
function ascbGradeManagementGoToPage(page) { ascbLoadGradeManagement(page); }
function ascbGradeManagementRender() {
    const body=ascbGradeMgmtEl('gradeMgmtBody'); if(!body) return;
    const q=(ascbGradeMgmtEl('gradeMgmtSearchInput')?.value||'').trim().toLowerCase();
    const filtered=ascbGradeMgmtStudents.filter(s => !q || ascbNameMatch(q, [s.fullName, s.studentId, s.course]));
    if(!filtered.length){ body.innerHTML='<tr><td colspan="7" class="records-empty">No student found.</td></tr>'; return; }
    const per=25;
    const totalPages=Math.max(1,Math.ceil(ascbGradeMgmtTotal/per));
    ascbGradeMgmtPage=Math.min(ascbGradeMgmtPage,totalPages);
    const rows=filtered;
    const openBtnLabel=(typeof ASCB_PERMISSIONS!=='undefined' && ASCB_PERMISSIONS.manageGrades)?'Enter / Update Grades':'View / Request Correction';
    body.innerHTML=rows.map(s=>{ const t=s.terms[0]; return `<tr><td data-label="Student ID">${escapeHTML(s.studentId||'—')}</td><td data-label="Name">${escapeHTML(s.fullName)}</td><td data-label="Course">${escapeHTML(s.course||'—')}</td><td data-label="Latest Term">${escapeHTML([t?.trimester,t?.schoolYear].filter(Boolean).join(' / ')||'—')}</td><td data-label="Terms">${s.terms.length}</td><td data-label="Actions"><button type="button" class="btn btn-primary" onclick="ascbGradeManagementOpenByIndex(${ascbGradeMgmtStudents.indexOf(s)})">${openBtnLabel}</button></td></tr>`; }).join('');
    if(typeof ascbRenderPagination==='function') ascbRenderPagination('gradeMgmtPagination',ascbGradeMgmtPage,totalPages,ascbGradeMgmtTotal,per,'ascbGradeManagementGoToPage');
}

function ascbGradeManagementOpenByIndex(index) { const student=ascbGradeMgmtStudents[Number(index)]; if(student) ascbGradeManagementOpen(student.key); }

/* =========================================================
   PROFESSOR GRADE SHEET / SUBJECT GRADEBOOK
   ---------------------------------------------------------
   The spreadsheet is deliberately subject-free. The selected
   Gradebook subject/term determines the enrollment_subject_id
   mapping on the server.
   ========================================================= */
let ascbGradebookSubjects = [];
let ascbGradebookCurrent = null;
let ascbGradebookRows = [];
let ascbGradebookPage = 1;
let ascbGradebookCourse = '';
let ascbGradebookMeta = null;    // counters mula sa api (graded / total)
let ascbGradebookOnly = '';       // '' = lahat, 'ungraded' = kulang pa ng grade
let ascbGradebookHideGraded = false; // checkbox: itago ang may grade, ipakita ang wala pa
let ascbGradebookLimit = 200;
let ascbGradebookDirty = new Set(); // enrollment_subject_id na may hindi pa naise-save na grade
function ascbGradebookEl(id){return document.getElementById(id);}
/* (fix) Ligtas na pagbasa ng JSON: kapag HTML ang isinagot ng server/host (hal. 403 ng firewall),
   ipakita ang totoong HTTP status sa halip na "Unexpected token '<'". */
async function ascbReadJson(res){
    const text=await res.text();
    try{return JSON.parse(text);}catch(e){
        const plain=String(text||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,160);
        throw new Error('Server error (HTTP '+res.status+')'+(plain?': '+plain:'')+(res.status===403?' — hinarang ng web host/firewall ang request (hindi galing sa app). Subukan ulit sandali.':''));
    }
}
function ascbGradebookKey(r){return JSON.stringify([String(r.school_year||''),String(r.trimester||''),String(r.course_code||''),String(r.description||'')]);}
function ascbGradebookOpen(){
    const modal=ascbGradebookEl('gradebookModal'); if(!modal)return;
    modal.classList.add('active');
    ascbGradebookHideImport();
    ascbGradebookComboInit();
    ascbGradebookComboClose();
    ascbGradebookLoadSubjects();
}
function ascbGradebookClose(){try{ascbGradebookComboClose();}catch(e){}const m=ascbGradebookEl('gradebookModal');if(m)m.classList.remove('active');ascbGradebookCurrent=null;}
function ascbGradebookYears(){
    const seen=[];
    (ascbGradebookSubjects||[]).forEach(r=>{const y=String(r.school_year||'');if(y&&!seen.includes(y))seen.push(y);});
    return seen.sort().reverse();
}
function ascbGradebookTerms(year){
    const seen=[];
    (ascbGradebookSubjects||[]).forEach(r=>{if(String(r.school_year||'')!==String(year))return;const t=String(r.trimester||'');if(t&&!seen.includes(t))seen.push(t);});
    return seen.sort();
}
function ascbGradebookSubjectsFor(year,term){
    return (ascbGradebookSubjects||[]).filter(r=>String(r.school_year||'')===String(year)&&String(r.trimester||'')===String(term));
}
/* (combo) Subject dropdown na may search MISMO sa loob ng dropdown. Ang nakatagong <select id="gradebookSubjectSelect">
   ang pinagkukunan ng value (para gumana ang lahat ng lumang code); ang button + panel ang nakikita ng user. */
var ascbGradebookSubjectList=[];
var ascbGradebookComboShown=[];
var ascbGradebookComboActive=-1;
var ascbGradebookComboReady=false;
function ascbGradebookSubjectHay(r){
    const v=Array.isArray(r.description_variants)?r.description_variants.join(' '):'';
    return [r.course_code,r.description,v].join(' ').toLowerCase();
}
function ascbGradebookSubjectLabel(r){
    const count=Number(r.enrollee_count||r.student_count||0);
    return [r.course_code||'—',r.description||'—'].join(' — ')+' • '+count+' student(s)';
}
/* Buong listahan sa nakatagong select (walang filter). */
function ascbGradebookRenderSubjectOptions(){
    const sel=ascbGradebookEl('gradebookSubjectSelect'); if(!sel)return;
    sel.innerHTML=(ascbGradebookSubjectList||[]).map(r=>{
        const variants=Array.isArray(r.description_variants)?r.description_variants:[];
        const alt=variants.length>1?' (also recorded as: '+variants.slice(1).join('; ')+')':'';
        return `<option value="${escapeHTML(ascbGradebookKey(r)).replace(/"/g,'&quot;')}" title="${escapeHTML([r.course_code||'—',r.description||'—'].join(' — ')+alt).replace(/"/g,'&quot;')}">${escapeHTML(ascbGradebookSubjectLabel(r))}</option>`;
    }).join('');
}
/* Ipakita sa button ang kasalukuyang napiling subject. */
function ascbGradebookComboSync(){
    const sel=ascbGradebookEl('gradebookSubjectSelect'),txt=ascbGradebookEl('gradebookSubjectBtnText'); if(!sel||!txt)return;
    const opt=sel.selectedIndex>=0?sel.options[sel.selectedIndex]:null;
    txt.textContent=(opt&&sel.value!=='')?opt.textContent:(opt?opt.textContent:'Select subject');
    const btn=ascbGradebookEl('gradebookSubjectBtn'); if(btn)btn.title=txt.textContent;
}
function ascbGradebookComboInit(){
    if(ascbGradebookComboReady)return;
    const sel=ascbGradebookEl('gradebookSubjectSelect'); if(!sel)return;
    ascbGradebookComboReady=true;
    try{new MutationObserver(()=>ascbGradebookComboSync()).observe(sel,{childList:true});}catch(e){}
    sel.addEventListener('change',ascbGradebookComboSync);
    document.addEventListener('mousedown',e=>{
        const combo=ascbGradebookEl('gradebookSubjectCombo'),panel=ascbGradebookEl('gradebookSubjectPanel');
        if(panel&&!panel.hidden&&combo&&!combo.contains(e.target))ascbGradebookComboClose();
    });
    window.addEventListener('resize',()=>ascbGradebookComboPosition());
    window.addEventListener('scroll',()=>ascbGradebookComboPosition(),true);
    ascbGradebookComboSync();
}
function ascbGradebookComboPosition(){
    const panel=ascbGradebookEl('gradebookSubjectPanel'),btn=ascbGradebookEl('gradebookSubjectBtn');
    if(!panel||panel.hidden||!btn)return;
    const r=btn.getBoundingClientRect();
    const below=window.innerHeight-r.bottom, maxH=Math.max(180,Math.min(360,below>240?below-12:r.top-12));
    const width=Math.max(r.width,Math.min(520,window.innerWidth-16));
    const left=Math.max(8,Math.min(r.left,window.innerWidth-width-8));
    panel.style.position='fixed';panel.style.left=left+'px';panel.style.width=(r.width>=320?r.width:Math.min(width,420))+'px';
    if(below<240&&r.top>below){panel.style.top='auto';panel.style.bottom=(window.innerHeight-r.top+4)+'px';}
    else{panel.style.bottom='auto';panel.style.top=(r.bottom+4)+'px';}
    const list=ascbGradebookEl('gradebookSubjectList'); if(list)list.style.maxHeight=(maxH-52)+'px';
}
function ascbGradebookComboToggle(){
    const panel=ascbGradebookEl('gradebookSubjectPanel'); if(!panel)return;
    if(panel.hidden)ascbGradebookComboOpen();else ascbGradebookComboClose();
}
function ascbGradebookComboOpen(){
    ascbGradebookComboInit();
    const panel=ascbGradebookEl('gradebookSubjectPanel'),btn=ascbGradebookEl('gradebookSubjectBtn'),inp=ascbGradebookEl('gradebookSubjectSearch'); if(!panel)return;
    panel.hidden=false; if(btn)btn.setAttribute('aria-expanded','true');
    if(inp)inp.value='';
    ascbGradebookComboRender();
    ascbGradebookComboPosition();
    if(inp)setTimeout(()=>inp.focus(),0);
}
function ascbGradebookComboClose(focusBtn){
    const panel=ascbGradebookEl('gradebookSubjectPanel'),btn=ascbGradebookEl('gradebookSubjectBtn'); if(!panel||panel.hidden)return;
    panel.hidden=true; if(btn){btn.setAttribute('aria-expanded','false');if(focusBtn)btn.focus();}
}
function ascbGradebookComboRender(){
    const list=ascbGradebookEl('gradebookSubjectList'),inp=ascbGradebookEl('gradebookSubjectSearch'),sel=ascbGradebookEl('gradebookSubjectSelect'); if(!list)return;
    const tokens=String(inp?.value||'').toLowerCase().split(/\s+/).filter(Boolean);
    ascbGradebookComboShown=(ascbGradebookSubjectList||[]).filter(r=>{const h=ascbGradebookSubjectHay(r);return tokens.every(t=>h.includes(t));});
    const cur=sel?sel.value:'';
    if(!ascbGradebookComboShown.length){
        list.innerHTML='<li class="gb-combo-empty">'+((ascbGradebookSubjectList||[]).length?'No subject matches your search':'No subjects available')+'</li>';
        ascbGradebookComboActive=-1;return;
    }
    ascbGradebookComboActive=Math.max(0,ascbGradebookComboShown.findIndex(r=>ascbGradebookKey(r)===cur));
    if(tokens.length)ascbGradebookComboActive=0;
    list.innerHTML=ascbGradebookComboShown.map((r,i)=>`<li role="option" class="gb-combo-item${ascbGradebookKey(r)===cur?' is-selected':''}${i===ascbGradebookComboActive?' is-active':''}" data-i="${i}" aria-selected="${ascbGradebookKey(r)===cur?'true':'false'}" onmousedown="event.preventDefault();ascbGradebookComboChoose(${i})" onmousemove="ascbGradebookComboHover(${i})">${escapeHTML(ascbGradebookSubjectLabel(r))}</li>`).join('');
    const act=list.querySelector('.is-active'); if(act&&act.scrollIntoView)act.scrollIntoView({block:'nearest'});
}
function ascbGradebookComboHover(i){
    const list=ascbGradebookEl('gradebookSubjectList'); if(!list||i===ascbGradebookComboActive)return;
    list.querySelectorAll('.is-active').forEach(x=>x.classList.remove('is-active'));
    const it=list.querySelector('[data-i="'+i+'"]'); if(it)it.classList.add('is-active');
    ascbGradebookComboActive=i;
}
function ascbGradebookComboChoose(i){
    const r=ascbGradebookComboShown[i],sel=ascbGradebookEl('gradebookSubjectSelect'); if(!r||!sel)return;
    const key=ascbGradebookKey(r), changed=sel.value!==key;
    sel.value=key; ascbGradebookComboSync(); ascbGradebookComboClose(true);
    if(changed)sel.dispatchEvent(new Event('change'));
}
function ascbGradebookSubjectSearch(){ ascbGradebookComboRender(); }
function ascbGradebookSubjectSearchKey(e){
    const n=ascbGradebookComboShown.length;
    if(e.key==='Escape'){e.preventDefault();e.stopPropagation();ascbGradebookComboClose(true);return;}
    if(e.key==='ArrowDown'||e.key==='ArrowUp'){
        e.preventDefault(); if(!n)return;
        const next=(ascbGradebookComboActive+(e.key==='ArrowDown'?1:-1)+n)%n;
        ascbGradebookComboHover(next);
        const act=ascbGradebookEl('gradebookSubjectList')?.querySelector('.is-active'); if(act&&act.scrollIntoView)act.scrollIntoView({block:'nearest'});
        return;
    }
    if(e.key==='Enter'){e.preventDefault(); if(ascbGradebookComboActive>=0)ascbGradebookComboChoose(ascbGradebookComboActive);}
}
function ascbGradebookFillSubjects(){
    const ySel=ascbGradebookEl('gradebookYearSelect'),tSel=ascbGradebookEl('gradebookTermSelect'),sel=ascbGradebookEl('gradebookSubjectSelect'),body=ascbGradebookEl('gradebookBody');
    if(!sel)return;
    const list=ascbGradebookSubjectsFor(ySel?.value||'',tSel?.value||'');
    if(!list.length){
        ascbGradebookSubjectList=[];
        sel.innerHTML='<option value="">No subjects for this term</option>';
        ascbGradebookCurrent=null;ascbGradebookRows=[];
        if(body)body.innerHTML='<tr><td colspan="6" class="records-empty">No subjects found for the selected school year and term.</td></tr>';
        return;
    }
    ascbGradebookSubjectList=list;
    ascbGradebookRenderSubjectOptions();
    sel.value=ascbGradebookKey(list[0]);
    ascbGradebookComboSync();
    ascbGradebookPage=1;
    ascbGradebookCourse='';
    ascbGradebookLoad();
}
function ascbGradebookFillTerms(){
    const ySel=ascbGradebookEl('gradebookYearSelect'),tSel=ascbGradebookEl('gradebookTermSelect');
    if(!tSel)return;
    const terms=ascbGradebookTerms(ySel?.value||'');
    tSel.innerHTML=terms.length?terms.map(t=>`<option value="${escapeHTML(t).replace(/"/g,'&quot;')}">${escapeHTML(t)}</option>`).join(''):'<option value="">No term found</option>';
    if(terms.length)tSel.value=terms[0];
    ascbGradebookFillSubjects();
}
function ascbGradebookOnYearChange(){ascbGradebookPage=1;ascbGradebookCourse='';ascbGradebookFillTerms();}
function ascbGradebookOnTermChange(){ascbGradebookPage=1;ascbGradebookCourse='';ascbGradebookFillSubjects();}
function ascbGradebookOnOnlyChange(){ascbGradebookOnly='';ascbGradebookPage=1;ascbGradebookLoad();}
function ascbGradebookOnHideGradedChange(){
    ascbGradebookHideGraded=!!ascbGradebookEl('gradebookHideGradedToggle')?.checked;
    ascbGradebookPage=1;
    ascbGradebookApplyFilter();
}
function ascbGradebookOnLimitChange(){ascbGradebookPage=1;ascbGradebookLoad();}
/* Checkbox filter: kapag naka-check, itago ang may grade at ipakita ang kulang pa. */
function ascbGradebookSkipGraded(){return true;}
function ascbGradebookApplyFilter(){
    const q=String(ascbGradebookEl('gradebookSearchInput')?.value||'').trim().toLowerCase();
    const skip=ascbGradebookSkipGraded();
    let shown=0;
    Array.from(document.querySelectorAll('#gradebookBody tr[data-esid]')).forEach(tr=>{
        const esid=Number(tr.getAttribute('data-esid')||0);
        const input=ascbGradebookEl('gbGrade_'+esid);
        const row=(ascbGradebookRows||[]).find(r=>Number(r.enrollment_subject_id)===esid);
        const hayFields=[row?.student_id,row?.surname,row?.first_name,row?.middle_name,row?.program_code,row?.course];
        const savedGrade=String(row?.grade||'').trim();
        const isPendingPlaceholder=!savedGrade||/^0(?:\.0+)?$/i.test(savedGrade);
        const isDirty=ascbGradebookDirty.has(esid);
        const matchSearch=!q||ascbNameMatch(q,hayFields);
        const matchSkip=!skip||isPendingPlaceholder||isDirty||(document.activeElement===input);
        const show=matchSearch&&matchSkip;
        tr.style.display=show?'':'none';
        if(show)shown++;
    });
    const empty=ascbGradebookEl('gradebookFilterEmpty');
    if(empty)empty.style.display=(shown===0&&(ascbGradebookRows||[]).length)?'block':'none';
    ascbGradebookUpdateProgress();
}
/* Grade normalization habang nag-e-encode: "2" -> "2.00", "inc" -> "INC", "drp"/"dr" -> "Dr.". */
function ascbGradebookNormalize(v){
    const t=String(v||'').trim();
    if(t==='')return '';
    if(/^[-–—]$/.test(t))return '-';
    if(/^(drp|dr\.?)$/i.test(t))return 'Dr.';
    if(/^(inc|ng)$/i.test(t))return t.toUpperCase();
    if(/^(p|passed)$/i.test(t))return 'P';
    if(/^(c|competent)$/i.test(t))return 'C';
    if(/^\d+(\.\d+)?$/.test(t)){const n=parseFloat(t);if(n>=0&&n<=5)return n.toFixed(1);}
    return t;
}
function ascbGradebookValid(v){
    const t=String(v||'').trim();
    if(t==='')return true;
    if(/^(INC|DRP|DR\.?|NG|P|PASSED|C|COMPETENT|[-–—])$/i.test(t))return true;
    return ascbGradeScaleOk(Number(t));
}
/* Grading scale: 1.0–3.0 (0.1 steps), 4.0, 5.0; 0 = placeholder. */
function ascbGradeScaleOk(n){
    if(!Number.isFinite(n))return false;
    const t=Math.round(n*10);
    if(Math.abs(n*10-t)>1e-6)return false;
    return t===0||(t>=10&&t<=30)||t===40||t===50;
}
function ascbGradebookInputs(){
    return Array.from(document.querySelectorAll('#gradebookBody tr[data-esid]'))
        .filter(tr=>tr.style.display!=='none')
        .map(tr=>tr.querySelector('.gradebook-grade-input'))
        .filter(Boolean)
        .filter(i=>!i.disabled);
}
function ascbGradebookMarkDirty(esid){
    const input=ascbGradebookEl('gbGrade_'+esid);const status=ascbGradebookEl('gbStatus_'+esid);
    if(!input)return;
    const row=(ascbGradebookRows||[]).find(r=>Number(r.enrollment_subject_id)===Number(esid));
    const current=ascbGradebookNormalize(input.value);
    const saved=ascbGradebookNormalize(row?.grade||row?.pending_grade||'');
    const changed=current!==saved;
    input.classList.toggle('is-dirty',changed);
    input.classList.toggle('is-invalid',!ascbGradebookValid(input.value));
    if(changed)ascbGradebookDirty.add(Number(esid));else ascbGradebookDirty.delete(Number(esid));
    if(status&&changed)status.textContent='Not yet saved';
    if(status&&!changed&&status.textContent==='Not yet saved')status.textContent=row?.grade?'Graded':(row?.pending_grade?('Awaiting approval ('+row.pending_grade+')'):'Pending Grade');
    ascbGradebookUpdateProgress();
}
/* Enter = save + susunod na estudyante. Shift+Enter = pabalik. */
async function ascbGradebookKey_(event,esid){
    const key=event.key;
    if(key!=='Enter'&&key!=='ArrowDown'&&key!=='ArrowUp')return;
    event.preventDefault();
    const inputs=ascbGradebookInputs();
    const index=inputs.findIndex(i=>i.id==='gbGrade_'+esid);
    const back=(key==='ArrowUp')||(key==='Enter'&&event.shiftKey);
    if(key==='Enter'){const ok=await ascbGradebookSaveRow(esid);if(!ok)return;}
    let next=null;
    if(key==='Enter'&&!back&&ascbGradebookSkipGraded()){
        // Deretso sa susunod na estudyanteng wala pang grade — walang aaksayahing pindot.
        for(let i=index+1;i<inputs.length;i++){if(!String(inputs[i].value||'').trim()){next=inputs[i];break;}}
        if(!next)next=inputs.find(inp=>!String(inp.value||'').trim()&&inp!==inputs[index])||null;
    }
    if(!next)next=inputs[index+(back?-1:1)]||null;
    if(next){next.focus();next.select();}
    else if(key==='Enter'&&!back){
        const st=ascbGradebookEl('gradebookStatus');
        if(st){st.style.display='block';st.textContent='✅ All listed students for this subject already have a grade — nasa Grade Evaluation na agad ang mga ito.';}
    }
}
function ascbGradebookUpdateProgress(){
    const box=ascbGradebookEl('gradebookProgress');if(!box)return;
    const total=Number(ascbGradebookMeta?.course_total||0);
    const graded=Number(ascbGradebookMeta?.course_graded||0);
    const pending=Math.max(0,total-graded);
    const pct=total?Math.round((graded/total)*100):0;
    const dirty=ascbGradebookDirty.size;
    box.style.display='block';
    box.innerHTML=`<div class="gradebook-progress-bar"><span style="width:${pct}%"></span></div>`+
        `<div class="gradebook-progress-text"><strong>${graded}</strong> of <strong>${total}</strong> graded • <strong>${pending}</strong> still need a grade`+
        (dirty?` • <span class="gradebook-progress-dirty">${dirty} unsaved</span>`:'')+`</div>`;
}
function ascbGradebookOnCourseChange(){ascbGradebookCourse=String(ascbGradebookEl('gradebookCourseSelect')?.value||'');ascbGradebookPage=1;ascbGradebookLoad();}
function ascbGradebookFillCourses(courses,selected,subjectTotal){
    const sel=ascbGradebookEl('gradebookCourseSelect'); if(!sel)return;
    const list=Array.isArray(courses)?courses:[];
    sel.innerHTML=[`<option value="">All Courses${subjectTotal!==undefined?' • '+Number(subjectTotal||0)+' student(s)':''}</option>`]
        .concat(list.map(c=>`<option value="${escapeHTML(String(c.course||'')).replace(/"/g,'&quot;')}">${escapeHTML(String(c.course||'—'))} • ${escapeHTML(String(c.student_count||0))} student(s)</option>`)).join('');
    const want=String(selected||'');
    sel.value=list.some(c=>String(c.course||'')===want)?want:'';
    ascbGradebookCourse=sel.value;
}
async function ascbGradebookLoadSubjects(){
    const sel=ascbGradebookEl('gradebookSubjectSelect'),body=ascbGradebookEl('gradebookBody'),ySel=ascbGradebookEl('gradebookYearSelect'),tSel=ascbGradebookEl('gradebookTermSelect');
    if(sel)sel.innerHTML='<option value="">Loading subjects…</option>';
    if(body)body.innerHTML='<tr><td colspan="6" class="records-empty">Loading subjects…</td></tr>';
    try{
        const res=await fetch('api/professor_gradebook.php?action=subjects'); const data=await ascbReadJson(res);
        if(!data?.ok)throw new Error(data?.error||'Unable to load subjects.');
        ascbGradebookSubjects=Array.isArray(data.rows)?data.rows:[];
        if(!sel){return;}
        if(!ascbGradebookSubjects.length){
            const hintMsg=data.hint==='no_assignment'
                ? 'Wala pang Department/Program na naka-assign sa account mo. Ipa-Assign ito sa Unit Head (Staff Accounts → Assign).'
                : (data.hint==='no_match'
                    ? 'Walang subject na may pending na grade sa mga naka-assign sa iyo. Kung mali ito, ipa-check sa Unit Head ang Assign mo.'
                    : 'No approved subject records found.');
            sel.innerHTML='<option value="">No approved subjects found</option>';
            if(ySel)ySel.innerHTML='<option value="">—</option>';
            if(tSel)tSel.innerHTML='<option value="">—</option>';
            if(body)body.innerHTML='<tr><td colspan="6" class="records-empty">'+escapeHTML(hintMsg)+'</td></tr>';
            return;
        }
        const years=ascbGradebookYears();
        if(ySel){ySel.innerHTML=years.map(y=>`<option value="${escapeHTML(y).replace(/"/g,'&quot;')}">${escapeHTML(y)}</option>`).join('');ySel.value=years[0];}
        ascbGradebookFillTerms();
    }catch(e){if(sel)sel.innerHTML='<option value="">Unable to load subjects</option>';if(body)body.innerHTML=`<tr><td colspan="6" class="records-empty">${escapeHTML(e.message||'Unable to load subjects.')}</td></tr>`;}
}
function ascbGradebookSelected(){
    const key=ascbGradebookEl('gradebookSubjectSelect')?.value||'';
    try{return ascbGradebookSubjects.find(r=>ascbGradebookKey(r)===key)||null;}catch(e){return null;}
}
async function ascbGradebookLoad(pageOverride=null){
    const selected=ascbGradebookSelected(); if(!selected)return;
    if(pageOverride!==null)ascbGradebookPage=Math.max(1,Number(pageOverride)||1);
    ascbGradebookCurrent=selected;
    const body=ascbGradebookEl('gradebookBody'),status=ascbGradebookEl('gradebookStatus'),notice=ascbGradebookEl('gradebookLockNotice');
    if(status){status.style.display='block';status.textContent='Loading gradebook…';}
    if(body)body.innerHTML='<tr><td colspan="6" class="records-empty">Loading…</td></tr>';
    try{
        const qs=new URLSearchParams({action:'rows',school_year:selected.school_year,trimester:selected.trimester,course_code:selected.course_code||'',description:selected.description||'',course:ascbGradebookCourse||'',only:'ungraded',page:String(ascbGradebookPage),limit:String(ascbGradebookLimit||50)});
        const res=await fetch('api/professor_gradebook.php?'+qs.toString()); const data=await ascbReadJson(res);
        if(!data?.ok)throw new Error(data?.error||'Unable to load gradebook.');
        ascbGradebookRows=Array.isArray(data.rows)?data.rows:[];
        /* Suffix: kung binago sa Master Record ang pangalan/suffix, iyon ang ipakita. */
        try{
            if(typeof ascbMrInvalidateNames==='function')ascbMrInvalidateNames();
            const gbNames=await ascbMasterCurrentNames();
            ascbGradebookRows.forEach(r=>{
                const n=gbNames&&gbNames[r.student_id];
                if(n){const p=ascbNamePrintParts(n.surname,n.firstName,n.middleName,n.suffix,n.suffixPosition);r._gbName=[p.surname,p.first,[p.middle,p.tail].filter(Boolean).join(' ')].filter(Boolean).join(', ');}
            });
        }catch(e){}
        ascbGradebookMeta=data;
        ascbGradebookDirty=new Set();
        ascbGradebookFillCourses(data.courses,data.course,data.subject_total);
        const onlySel=ascbGradebookEl('gradebookOnlySelect'); if(onlySel)onlySel.value=ascbGradebookOnly||'';
        const limitSel=ascbGradebookEl('gradebookLimitSelect'); if(limitSel)limitSel.value=String(ascbGradebookLimit||50);
        // Lock/unlock feature removed: walang subject na naka-lock kaya laging
        // pwedeng i-encode o i-import ang grades.
        const locked=false;
        if(notice){notice.style.display='none';notice.innerHTML='';notice.classList.remove('is-locked');}
        const lockBtn=ascbGradebookEl('gradebookLockBtn'); if(lockBtn)lockBtn.style.display='none';
        const unlockBtn=ascbGradebookEl('gradebookUnlockBtn'); if(unlockBtn)unlockBtn.style.display='none';
        const importBtn=ascbGradebookEl('gradebookImportBtn'); if(importBtn)importBtn.disabled=false;
        const gbLockedNow=locked;
        if(body)body.innerHTML=ascbGradebookRows.length?ascbGradebookRows.map(r=>{
            const g=(r.grade||'').trim();
            const pg=String(r.pending_grade||'').trim();
            const isPendingGrade = !g || (/^0(?:\.0+)?$/.test(g));
            const shownGrade=(isPendingGrade&&pg)?pg:g;
            /* LOCK: lahat ng encoder ay hindi na puwedeng mag-edit ng grade na naipasa na at naghihintay ng peer approval. */
            const rowLocked=!!gbLockedNow||(!!(isPendingGrade&&pg)&&['ADMIN STAFF','UNIT HEAD','SCHOOL REGISTRAR'].includes(String(ASCB_CURRENT_USER?.role||'').toUpperCase()));
            const statusLabel=(isPendingGrade&&pg)?((rowLocked?'🔒 Submitted for approval (':'Awaiting approval (')+pg+')'):(isPendingGrade?'Pending Grade':'Graded');
            const esid=Number(r.enrollment_subject_id||0);
            return `<tr data-esid="${esid}"><td data-label="Student ID">${escapeHTML(r.student_id||'—')}</td><td data-label="Name">${escapeHTML(r._gbName||[r.surname,r.first_name,r.middle_name].filter(Boolean).join(', '))}</td><td data-label="Course">${escapeHTML(r.program_code||r.course||'—')}</td><td data-label="Year Level">${escapeHTML(r.year_level||'—')}</td><td data-label="Grade"><input type="text" class="gradebook-grade-input" id="gbGrade_${esid}" value="${escapeHTML(shownGrade)}" placeholder="1.0–3.0 / 4.0 / 5.0 / INC / Dr. / NG / P / C / -" maxlength="6" ${rowLocked?'disabled':''} onkeydown="ascbGradebookKey_(event,${esid})" oninput="ascbGradebookMarkDirty(${esid})" onblur="ascbGradebookAutoSave(${esid})" autocomplete="off"></td><td data-label="Status"><span class="gradebook-row-status" id="gbStatus_${esid}">${escapeHTML(statusLabel)}</span> <button type="button" class="btn btn-secondary btn-sm" ${rowLocked?'disabled':''} onclick="ascbGradebookSaveRow(${esid})">Save</button></td></tr>`;
        }).join(''):'<tr><td colspan="6" class="records-empty">No students match the selected course for this subject and term.</td></tr>';
        const saveAllBtn=ascbGradebookEl('gradebookSaveAllBtn'); if(saveAllBtn)saveAllBtn.disabled=locked||!ascbGradebookRows.length;
        if(typeof ascbRenderPagination==='function')ascbRenderPagination('gradebookPagination',Number(data.page||1),Math.max(1,Number(data.pages||1)),Number(data.total||0),Number(data.limit||50),'ascbGradebookLoad');
        ascbGradebookApplyFilter();
        ascbGradebookUpdateProgress();
        // Deretsong cursor sa unang estudyanteng wala pang grade — pwede nang mag-type agad.
        if(!locked){const list=ascbGradebookInputs();const first=list.find(i=>!String(i.value||'').trim())||list[0];if(first){first.focus();first.select();}}
        if(status)status.style.display='none';
    }catch(e){if(status){status.style.display='block';status.textContent=e.message||'Unable to load gradebook.';}if(body)body.innerHTML='<tr><td colspan="6" class="records-empty">Unable to load gradebook.</td></tr>';}
}
function ascbGradebookShowImport(){
    if(ascbGradebookCurrent?.locked){alert('This subject is locked. The UNIT HEAD must unlock it before importing.');return;}
    const p=ascbGradebookEl('gradebookImportPanel');if(p)p.style.display='block';
    const result=ascbGradebookEl('gradebookImportResult');if(result)result.innerHTML='';
    const file=ascbGradebookEl('gradebookFile');if(file)file.value='';
    const commit=ascbGradebookEl('gradebookCommitBtn');if(commit)commit.style.display='none';
}
function ascbGradebookHideImport(){const p=ascbGradebookEl('gradebookImportPanel');if(p)p.style.display='none';}
/* Isinasabay ang refresh ng Grade Evaluation para agad makita
   doon ang bagong encode na grade. */
function ascbGradebookSyncGradeEvaluation(){
    try{ if(typeof ascbLoadGradeEvaluation==='function'&&document.getElementById('gradeEvalStudentTableBody')) ascbLoadGradeEvaluation(); }catch(e){}
}
async function ascbGradebookSubmitGrades(payload,statusText){
    const s=ascbGradebookCurrent; if(!s)throw new Error('Please select a subject first.');
    const fd=new FormData();
    fd.append('action','save_grades');
    fd.append('school_year',s.school_year);
    fd.append('trimester',s.trimester);
    fd.append('course_code',s.course_code||'');
    fd.append('description',s.description||'');
    fd.append('grades',JSON.stringify(payload));
    const res=await fetch('api/professor_gradebook.php',{method:'POST',body:fd});
    const data=await ascbReadJson(res);
    if(!data?.ok)throw new Error((data?.error||'Unable to save grades.')+(Array.isArray(data?.errors)?' '+data.errors.slice(0,5).join(' '):''));
    return data;
}
async function ascbGradebookSaveRow(esid){
    const input=ascbGradebookEl('gbGrade_'+esid); const status=ascbGradebookEl('gbStatus_'+esid);
    if(!input||input.disabled)return false;
    if(!ascbGradebookValid(input.value)){
        input.classList.add('is-invalid');
        if(status)status.textContent='Invalid grade (1.0–3.0, 4.0, 5.0, INC, Dr., NG, P, C, -)';
        return false;
    }
    const grade=ascbGradebookNormalize(input.value);
    input.value=grade;
    const row=(ascbGradebookRows||[]).find(r=>Number(r.enrollment_subject_id)===Number(esid));
    // (fix) Naipasa na ang parehong grade at naghihintay ng approval: huwag ipasa ulit.
    if(grade!==''&&ascbGradebookNormalize(row?.pending_grade||'')===grade&&ascbGradebookNormalize(row?.grade||'')!==grade){
        input.classList.remove('is-dirty');
        ascbGradebookDirty.delete(Number(esid));
        if(status)status.textContent='Awaiting approval ('+grade+')';
        ascbGradebookUpdateProgress();
        return true;
    }
    // Walang pagbabago = walang request. Ito ang pinakamalaking bilis
    // kapag sunod-sunod ang Enter sa mga na-encode nang estudyante.
    if(ascbGradebookNormalize(row?.grade||'')===grade){
        input.classList.remove('is-dirty');
        ascbGradebookDirty.delete(Number(esid));
        if(status)status.textContent=grade?'Graded':'Pending Grade';
        ascbGradebookUpdateProgress();
        // Remove a fully graded subject from the Subject dropdown.
        if (ascbGradebookMeta && Number(ascbGradebookMeta.course_ungraded || 0) === 0 && !ascbGradebookCourse) {
            const subjectSel = ascbGradebookEl('gradebookSubjectSelect');
            const currentKey = ascbGradebookKey(ascbGradebookCurrent);
            if (subjectSel && currentKey) {
                const opt = [...subjectSel.options].find(o => o.value === currentKey);
                if (opt) opt.remove();
                ascbGradebookSubjects = (ascbGradebookSubjects || []).filter(r => ascbGradebookKey(r) !== currentKey);
                ascbGradebookSubjectList = (ascbGradebookSubjectList || []).filter(r => ascbGradebookKey(r) !== currentKey);
                subjectSel.value = '';
                ascbGradebookComboSync();
                ascbGradebookCurrent = null;
                ascbGradebookCourse = '';
                const courseSel = ascbGradebookEl('gradebookCourseSelect');
                if (courseSel) courseSel.innerHTML = '<option value="">All Courses</option>';
                const st2 = ascbGradebookEl('gradebookStatus');
                if (st2) { st2.style.display='block'; st2.textContent='All students in this subject already have grades. The subject was removed from the Gradebook dropdown.'; }
            }
        }
        return true;
    }
    if(status)status.textContent='Saving…';
    input.classList.add('is-saving');
    try{
        const saveRes=await ascbGradebookSubmitGrades([{enrollment_subject_id:Number(esid),grade}]);
        if(saveRes&&saveRes.pending_approval){
            /* Hindi pa official ang grade ng kahit sinong encoder. Ipakita na submitted, huwag saved/graded, at huwag alisin ang row. */
            if(row){row.pending_grade=grade;row.pending_status=String(ASCB_CURRENT_USER?.role||'').toUpperCase()==='UNIT HEAD'?'PENDING_REGISTRAR':'PENDING_UNIT_HEAD';}
            ascbGradebookDirty.delete(Number(esid));
            input.classList.remove('is-dirty');
            if(status)status.textContent='🔒 Submitted for peer approval ('+grade+')';
            input.disabled=true;
            const lockBtn=input.closest('tr')?.querySelector('button');if(lockBtn)lockBtn.disabled=true;
            ascbGradebookUpdateProgress();
            return true;
        }
        const hadGrade=!!String(row?.grade||'').trim();
        if(row)row.grade=grade;
        if(ascbGradebookMeta){
            if(grade&&!hadGrade)ascbGradebookMeta.course_graded=Number(ascbGradebookMeta.course_graded||0)+1;
            if(!grade&&hadGrade)ascbGradebookMeta.course_graded=Math.max(0,Number(ascbGradebookMeta.course_graded||0)-1);
        }
        ascbGradebookDirty.delete(Number(esid));
        input.classList.remove('is-dirty');
        if(status)status.textContent=grade?'Saved ✓':'Pending Grade';
        // Once a valid grade is saved, this student must leave the Subject Gradebook queue.
        // Keep the row out of the DOM so only students with no grade remain available.
        if(grade){
            const tr=input.closest('tr[data-esid]');
            if(tr)tr.remove();
            ascbGradebookRows=(ascbGradebookRows||[]).filter(r=>Number(r.enrollment_subject_id)!==Number(esid));
            if(ascbGradebookMeta){
                ascbGradebookMeta.course_ungraded=Math.max(0,Number(ascbGradebookMeta.course_ungraded||0)-1);
                ascbGradebookMeta.total=Math.max(0,Number(ascbGradebookMeta.total||0)-1);
            }
            const body=ascbGradebookEl('gradebookBody');
            if(body && !body.querySelector('tr[data-esid]')) body.innerHTML='<tr><td colspan="6" class="records-empty">All students for this subject already have a grade. The graded records are available in Grade Evaluation.</td></tr>';
        }
        ascbGradebookUpdateProgress();
        return true;
    }catch(e){ if(status)status.textContent='Not saved'; alert(e.message||'Unable to save grade.'); return false; }
    finally{ input.classList.remove('is-saving'); }
}
/* Kapag nag-click ang user sa ibang row (hindi Enter), awtomatiko pa ring
   nasi-save ang binagong grade — walang mawawalang encode. */
async function ascbGradebookAutoSave(esid){
    if(!ascbGradebookDirty.has(Number(esid)))return;
    await ascbGradebookSaveRow(esid);
}
async function ascbGradebookSaveAll(){
    // Ang mga binago lang ang ipinapadala — mas mabilis at hindi na
    // hinahawakan ang mga grade na walang pagbabago.
    const invalid=[];
    const payload=(ascbGradebookRows||[]).map(r=>{
        const esid=Number(r.enrollment_subject_id||0);
        const input=ascbGradebookEl('gbGrade_'+esid);
        if(!input||input.disabled)return null;
        if(!ascbGradebookValid(input.value)){invalid.push(r.student_id||esid);input.classList.add('is-invalid');return null;}
        const grade=ascbGradebookNormalize(input.value);
        if(grade===ascbGradebookNormalize(r.grade||''))return null;
        if(grade!==''&&grade===ascbGradebookNormalize(r.pending_grade||''))return null; // naghihintay na ng approval
        return {enrollment_subject_id:esid,grade};
    }).filter(Boolean);
    if(invalid.length){alert('Please fix the grade of: '+invalid.slice(0,10).join(', ')+'. Use 1.0–3.0 (0.1 steps), 4.0, 5.0, INC, Dr., NG, P, C, or -.');return;}
    if(!payload.length){alert('All grades on this page are already saved.');return;}
    if(!confirm('Save '+payload.length+' changed grade(s) for this subject?'))return;
    const st=ascbGradebookEl('gradebookStatus'); if(st){st.style.display='block';st.textContent='Saving grades…';}
    try{
        const data=await ascbGradebookSubmitGrades(payload);
        if(data&&data.pending_approval){
            await ascbGradebookLoad();
            const role=String(ASCB_CURRENT_USER?.role||'').toUpperCase();const review=role==='UNIT HEAD'?'School Registrar peer approval':(role==='SCHOOL REGISTRAR'?'Unit Head peer approval':'Unit Head verification and School Registrar final approval');alert('Submitted for approval: '+Number(data.submitted||0)+' grade(s)'+(Number(data.duplicates||0)?(', '+Number(data.duplicates)+' already waiting (skipped)'):'')+'. The official grades will change only after '+review+'.');
            return;
        }
        await ascbGradebookLoad();
        ascbGradebookSyncGradeEvaluation();
        alert('Saved. '+Number(data.changed||0)+' grade(s) updated, '+Number(data.unchanged||0)+' unchanged, '+Number(data.cleared||0)+' cleared.');
    }catch(e){ if(st){st.style.display='block';st.textContent=e.message||'Unable to save grades.';} alert(e.message||'Unable to save grades.'); }
}
function ascbGradebookImportForm(action){
    const s=ascbGradebookCurrent;if(!s)throw new Error('Please select a subject first.');
    const f=ascbGradebookEl('gradebookFile');if(!f?.files?.length)throw new Error('Please choose the professor Excel file.');
    const fd=new FormData();fd.append('action',action);fd.append('file',f.files[0]);fd.append('school_year',s.school_year);fd.append('trimester',s.trimester);fd.append('course_code',s.course_code||'');fd.append('description',s.description||'');return fd;
}
async function ascbGradebookImportPreview(){
    const result=ascbGradebookEl('gradebookImportResult'); if(result)result.innerHTML='<div class="gradebook-import-loading">Validating professor grade sheet…</div>';
    try{const res=await fetch('api/professor_gradebook.php',{method:'POST',body:ascbGradebookImportForm('professor_preview')});const data=await ascbReadJson(res);if(!data?.ok){let extra=Array.isArray(data?.errors)?'<ul>'+data.errors.slice(0,30).map(e=>`<li>${escapeHTML(e)}</li>`).join('')+'</ul>':'';throw new Error((data?.error||'Validation failed.')+extra);}
        if(result)result.innerHTML=`<div class="gradebook-import-success"><strong>Preview ready.</strong> ${Number(data.rows||0)} rows checked • ${Number(data.will_update||0)} will update • ${Number(data.unchanged||0)} unchanged • ${Number(data.blank_skipped||0)} blank skipped.<br><small>Subject: ${escapeHTML(data.course_code||'—')} — ${escapeHTML(data.description||'—')} • ${escapeHTML(data.trimester||'')} / ${escapeHTML(data.school_year||'')}</small></div>`;
        const commit=ascbGradebookEl('gradebookCommitBtn');if(commit)commit.style.display='inline-flex';
    }catch(e){if(result)result.innerHTML=`<div class="gradebook-import-error">${e.message||'Unable to preview.'}</div>`;const commit=ascbGradebookEl('gradebookCommitBtn');if(commit)commit.style.display='none';}
}
async function ascbGradebookImportCommit(){
    if(!confirm('Import these professor grades into the selected subject? This will update the official grades for the matched Student IDs.'))return;
    const result=ascbGradebookEl('gradebookImportResult');if(result)result.innerHTML='<div class="gradebook-import-loading">Saving grades…</div>';
    try{const res=await fetch('api/professor_gradebook.php',{method:'POST',body:ascbGradebookImportForm('professor_commit')});const data=await ascbReadJson(res);if(!data?.ok)throw new Error(data?.error||'Import failed.');
        if(result)result.innerHTML=`<div class="gradebook-import-success"><strong>Import completed.</strong> ${Number(data.changed||0)} grade(s) updated • ${Number(data.unchanged||0)} unchanged • ${Number(data.blank_skipped||0)} blank skipped.</div>`;
        const commit=ascbGradebookEl('gradebookCommitBtn');if(commit)commit.style.display='none';
        await ascbGradebookLoad();
    }catch(e){if(result)result.innerHTML=`<div class="gradebook-import-error">${escapeHTML(e.message||'Import failed.')}</div>`;}
}
function ascbGradebookLockSubject(){/* lock/unlock feature removed */}
function ascbGradebookUnlockSubject(){/* lock/unlock feature removed */}
/* Lock/unlock feature removed — every subject stays open for encoding and import. */
async function ascbGradebookSetLock(){ return; }

function ascbGradeManagementOpen(key) {
    const student=ascbGradeMgmtStudents.find(s=>s.key===key); if(!student) return;
    ascbGradeMgmtCurrent=student;
    ascbGradeMgmtEl('gradeMgmtModalName').textContent=student.fullName;
    const distinctCourses=[...new Set(student.terms.map(t=>(t.course||'').trim()).filter(Boolean))];
    const courseChanged=distinctCourses.length>1;
    const courseLabel=ascbGradeEvalFormatCourseMajor(student.course,student.major);
    ascbGradeMgmtEl('gradeMgmtModalSub').textContent=[
        student.studentId?'Student ID: '+student.studentId:'',
        courseLabel?`${courseChanged?'Current Course':'Course'}: ${courseLabel}`:'',
        courseChanged?'⚠ Course varies per term — check each term tab below':'',
    ].filter(Boolean).join(' | ')||'—';
    const tabs=ascbGradeMgmtEl('gradeMgmtTermTabs');
    // I-grupo ang mga term-button per Year Level (1st Year, 2nd Year, atbp.),
    // tapos sa loob ng bawat year group, isaayos pa ang mga trimester sa
    // tamang pagkakasunod (1st -> 2nd -> 3rd Trimester) sa halip na basta
    // pagkakasunod-sunod lang ng pagkarehistro. Ang orihinal na flat index
    // (i, papunta sa student.terms) ang laging gamit ng onclick/highlight
    // kahit magkaiba na ang visual na ayos.
    const ascbOrdVal = (label) => { const m=String(label||'').match(/^(\d+)/); return m ? parseInt(m[1],10) : 999; };
    const yearGroups = new Map();
    student.terms.forEach((t,i) => {
        const yl = (t.yearLevel||'').trim() || 'Year Level N/A';
        if (!yearGroups.has(yl)) yearGroups.set(yl, []);
        yearGroups.get(yl).push({ t, i });
    });
    const sortedYearLevels = [...yearGroups.keys()].sort((a,b)=>ascbOrdVal(a)-ascbOrdVal(b));
    tabs.innerHTML = sortedYearLevels.map(yl => {
        const items = yearGroups.get(yl).slice().sort((a,b)=>ascbOrdVal(a.t.trimester)-ascbOrdVal(b.t.trimester));
        const btns = items.map(({t,i}) => `<button type="button" class="btn ${i===0?'btn-primary':'btn-outline'} grade-mgmt-term-btn" data-term-index="${i}" onclick="ascbGradeManagementShowTerm(${i})">${escapeHTML(t.trimester||'Term')} ${escapeHTML(t.schoolYear||'')}${courseChanged&&t.course?` (${escapeHTML(t.course)})`:''}</button>`).join('');
        return `<div class="grade-mgmt-year-group"><div class="grade-mgmt-year-label">${escapeHTML(yl)}</div><div class="grade-mgmt-year-btns">${btns}</div></div>`;
    }).join('');
    ascbGradeManagementShowTerm(0);
    ascbGradeMgmtEl('gradeManagementModal').classList.add('active');
}
function ascbGradeManagementShowTerm(index) {
    const s=ascbGradeMgmtCurrent; if(!s||!s.terms[index]) return;
    s.activeTermIndex=index;
    // Gumagamit ng data-term-index (hindi DOM position) dahil hindi na
    // laging tumutugma ang visual order (grouped per Year Level/Trimester)
    // sa flat index papunta sa student.terms.
    document.querySelectorAll('#gradeMgmtTermTabs .grade-mgmt-term-btn').forEach(b=>{
        const isActive = Number(b.dataset.termIndex)===index;
        b.classList.toggle('btn-primary', isActive);
        b.classList.toggle('btn-outline', !isActive);
    });
    const t=s.terms[index];
    const body=ascbGradeMgmtEl('gradeMgmtEditorBody');
    const total=t.rows.reduce((sum,r)=>sum+(parseFloat(r.units)||0),0);
    const termCourseLine=t.course?`<br><strong>Course:</strong> ${escapeHTML(ascbGradeEvalFormatCourseMajor(t.course,t.major))}`:'';
    const isLatest=(index===0);
    const canManageDirectly=!!ASCB_PERMISSIONS?.manageGrades;
    const canCorrect=!!ASCB_PERMISSIONS?.requestRecordCorrection;
    // Pwedeng mag-encode ang authorized roles sa latest term, pero staged
    // ang submission at kailangan ng approval ng kabilang authorized reviewer — kahit sino pang role ang
    // may access dito (hal. ADMIN STAFF na may 'requestRecordCorrection'
    // lang), hindi editable ang input fields; correction request na lang
    // ang paraan nila, kahit sa latest term pa iyon. Ito ay UI convenience
    // lang — api/grades.php pa rin ang tunay na security boundary.
    const editable=isLatest && canManageDirectly;
    const rowsHtml=t.rows.length?t.rows.map(r=>`<tr><td>${escapeHTML(r.course_code||'—')}</td><td>${escapeHTML(r.description||'—')}</td><td><input type="text" inputmode="decimal" class="grade-management-units-input" data-subject-id="${Number(r.enrollment_subject_id)}" value="${escapeHTML((/^(-)$/i.test(String(r.grade||'').trim())?'-':((/^(INC|NG|DR\.?|DRP)$/i.test(String(r.grade||'').trim()))?'0':String(r.units??0))))}" placeholder="3 / -" maxlength="6" data-restore-units="${Number(r.restore_units||0)}" ${editable?'':'disabled'} oninput="ascbGradeManagementOnInput(event)"></td><td><input class="grade-management-input" data-subject-id="${Number(r.enrollment_subject_id)}" value="${escapeHTML(r.grade||'')}" placeholder="1.75 / INC / Dr. / NG / P / -" inputmode="decimal" ${editable?'':'disabled'} oninput="ascbGradeManagementOnInput(event)"></td></tr>`).join(''):'<tr><td colspan="4" class="records-empty">Walang subjects sa term na ito.</td></tr>';
    // Baseline snapshot ng kasalukuyang laman ng bawat subject row (bago
    // pa magbago ang user ng kahit ano) — ginagamit para malaman kung may
    // aktwal na binago (grade o units) bago paganahin ang Submit Grades for Approval.
    ascbGradeMgmtBaseline = new Map(t.rows.map(r => { const rg=String(r.grade||'').trim(); const ru=/^(-)$/i.test(rg)?'-':(/^(INC|NG|DR\.?|DRP)$/i.test(rg)?'0':String(r.units ?? 0)); return [Number(r.enrollment_subject_id), { units: ru, grade: r.grade || '' }]; }));
    let actionHtml;
    if (editable) {
        actionHtml=`<div style="display:flex;justify-content:flex-end;margin-top:12px;"><button type="button" id="gradeMgmtSaveBtn" class="btn btn-primary" disabled onclick="ascbGradeManagementSave()">Submit Grades for Approval</button></div>`;
    } else if (canCorrect) {
        const lockedLabel=isLatest?'🔒 Current Term':'🔒 Previous Term';
        const lockedNote=isLatest?'Hindi ka pwedeng direktang mag-encode/mag-edit ng grades dito. Gumamit ng correction request kung may idadagdag o itatama na subject/grade.':'Read-only ang historical record. Gumamit ng correction request kung may maling grade o subject.';
        actionHtml=`<div class="record-correction-banner"><strong>${lockedLabel}</strong><br><span style="font-size:12px;">${lockedNote}</span><div class="record-correction-actions"><button type="button" class="btn btn-primary" onclick="ascbRecordCorrectionOpen()">✏ Correct Subject / Grade</button></div></div>`;
    } else {
        actionHtml=`<div class="record-correction-banner"><strong>🔒 ${isLatest?'Current Term':'Previous Term'} — Read-only</strong></div>`;
    }
    body.innerHTML=`<div class="grade-mgmt-term-heading"><strong>${escapeHTML(t.trimester||'')}</strong> &nbsp; <strong>AY:</strong> ${escapeHTML(t.schoolYear||'')} &nbsp; <strong>Year:</strong> ${escapeHTML(t.yearLevel||'')}${termCourseLine}</div><div class="table-wrapper"><table class="subject-input-table grade-management-table"><thead><tr><th>Course Code</th><th>Description</th><th>Units</th><th>Grade</th></tr></thead><tbody>${rowsHtml}</tbody><tfoot><tr><td colspan="2" class="total-label">Total Units</td><td id="gradeMgmtTotalUnits">${total}</td><td></td></tr></tfoot></table></div>${actionHtml}`;
}
function ascbGradeManagementRecalcTotal() {
    const total=[...document.querySelectorAll('#gradeMgmtEditorBody .grade-management-units-input')].reduce((sum,i)=>sum+(parseFloat(i.value)||0),0);
    const cell=ascbGradeMgmtEl('gradeMgmtTotalUnits'); if(cell) cell.textContent=(Math.round(total*100)/100);
}
// Tinatawag sa bawat pag-type sa Units o Grade input. I-re-recalculate
// ang total units, at i-eenable lang ang Submit Grades for Approval button kapag may
// nag-iba talaga kumpara sa baseline (ascbGradeMgmtBaseline) — kung
// wala pang binago, disabled ito para hindi ma-click nang wala namang
// aktwal na pagbabago.
// "Bagsak"/failing grade check — dapat kaparehong panuntunan ng
// ascb_grade_is_failing() sa includes/helpers.php (server-side na
// pinal na desisyon). Ginagamit lang ito rito para sa LIVE preview
// (agad na ipinapakita ang 0 sa Units habang nagta-type pa, bago pa
// ma-submit) — ang approval API pa rin ang nagpapatupad ng final official save.
function ascbGradeIsFailing(grade) {
    grade = String(grade ?? '').trim();
    if (grade === '') return false;
    if (/^(INC|DRP|DR\.?|NG)$/i.test(grade)) return true;
    if (!isNaN(grade) && grade !== '') return parseFloat(grade) >= 4;
    return false;
}
function ascbGradeManagementOnInput(ev) {
    // Kapag ang Units input mismo ang tinype-an, markahan bilang "manual"
    // para hindi na ito awtomatikong galawin ng grade preview.
    const tgt = ev && ev.target;
    if (tgt && tgt.classList && tgt.classList.contains('grade-management-units-input')) tgt.dataset.manual = '1';
    // Live preview: bagsak na grade => 0 units. Kapag naitama na sa pasadong
    // grade (o binura ang grade), IBALIK ang dating units — hindi dapat
    // manatiling 0. Ang dating units ay galing sa data-restore-units
    // (history ng submissions) o sa value bago ito na-zero.
    document.querySelectorAll('#gradeMgmtEditorBody .grade-management-input').forEach(gradeInput => {
        const subjectId = gradeInput.dataset.subjectId;
        const unitsInput = document.querySelector(`#gradeMgmtEditorBody .grade-management-units-input[data-subject-id="${subjectId}"]`);
        if (!unitsInput) return;
        const g = gradeInput.value.trim();
        if (ascbGradeIsFailing(g)) {
            if (unitsInput.value.trim() !== '0') { unitsInput.dataset.prev = unitsInput.value.trim(); unitsInput.value = '0'; }
            unitsInput.dataset.auto = '1';
            return;
        }
        if (unitsInput.dataset.manual === '1') return;
        const restore = Number(unitsInput.dataset.restoreUnits || 0);
        const prev = Number(unitsInput.dataset.prev || 0);
        const target = prev > 0 ? prev : restore;
        const passingWithGrade = g !== '' && g !== '-';
        if (unitsInput.value.trim() === '0' && target > 0 && (unitsInput.dataset.auto === '1' || passingWithGrade)) {
            unitsInput.value = String(target);
            unitsInput.dataset.auto = '';
        }
    });
    ascbGradeManagementRecalcTotal();
    const btn = ascbGradeMgmtEl('gradeMgmtSaveBtn');
    if (!btn) return;
    let dirty = false;
    document.querySelectorAll('#gradeMgmtEditorBody .grade-management-input').forEach(i => {
        const base = ascbGradeMgmtBaseline.get(Number(i.dataset.subjectId)) || { grade: '' };
        if (i.value.trim() !== (base.grade || '')) dirty = true;
    });
    document.querySelectorAll('#gradeMgmtEditorBody .grade-management-units-input').forEach(i => {
        const base = ascbGradeMgmtBaseline.get(Number(i.dataset.subjectId)) || { units: '0' };
        if (i.value.trim() !== (base.units ?? '0')) dirty = true;
    });
    btn.disabled = !dirty;
}
let ascbGradeMgmtSaving=false;
async function ascbGradeManagementSave() {
    if(ascbGradeMgmtSaving) return; // iwas double-click / double-submit
    const s=ascbGradeMgmtCurrent; if(!s) return; const t=s.terms[s.activeTermIndex||0]; if(!t) return;
    const status=ascbGradeMgmtEl('gradeMgmtSaveStatus');
    const unitsBySubject=new Map([...document.querySelectorAll('#gradeMgmtEditorBody .grade-management-units-input')].map(i=>[Number(i.dataset.subjectId),i.value.trim()]));
    /* Ipadala LANG ang mga subject na talagang binago (grade o units) kumpara sa baseline,
       para ang Unit Head ay makakita lang ng ina-update ng Admin Staff — hindi ang buong term. */
    const grades=[...document.querySelectorAll('#gradeMgmtEditorBody .grade-management-input')].map(i=>{const subjectId=Number(i.dataset.subjectId);return {subjectId,grade:i.value.trim(),units:unitsBySubject.has(subjectId)?unitsBySubject.get(subjectId):undefined};}).filter(g=>{
        const base=ascbGradeMgmtBaseline.get(g.subjectId)||{grade:'',units:'0'};
        const gradeChanged=g.grade!==String(base.grade||'');
        const unitsChanged=g.units!==undefined && g.units!==String(base.units??'0');
        return gradeChanged||unitsChanged;
    });
    if(!grades.length){ if(status){status.style.display='block';status.textContent='No changes to save.';setTimeout(()=>status.style.display='none',4000);} return; }
    ascbGradeMgmtSaving=true;const saveBtn=ascbGradeMgmtEl('gradeMgmtSaveBtn');if(saveBtn)saveBtn.disabled=true;
    if(status){status.style.display='block';status.textContent='Saving grades…';}
    try{
        const response=await fetch('api/grades.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'save',enrollmentId:Number(t.enrollmentId),grades})});
        const data=await response.json(); if(!data||!data.ok) throw new Error(data?.error||'Unable to save.');
        if(status){status.textContent=data.message || (data.pending_approval ? 'Submitted for approval.' : `Saved. ${data.changed||0} grade(s) updated.`);setTimeout(()=>status.style.display='none',7000);}
        await ascbLoadGradeManagement();
        // Reload the modal's latest student data.
        const refreshed=ascbGradeMgmtStudents.find(x=>x.key===s.key); if(refreshed){ascbGradeMgmtCurrent=refreshed;ascbGradeManagementShowTerm(Math.min(s.activeTermIndex||0,refreshed.terms.length-1));}
    }catch(e){console.error(e);if(status){status.textContent=e.message||'Unable to save the grades.';}if(saveBtn)saveBtn.disabled=false;}finally{ascbGradeMgmtSaving=false;}
}
function ascbGradeManagementClose(){ const m=ascbGradeMgmtEl('gradeManagementModal'); if(m)m.classList.remove('active'); ascbGradeMgmtCurrent=null; }

/* =========================================================
   PREVIOUS TERM RECORD CORRECTION
   ---------------------------------------------------------
   Historical terms are read-only in Grade Management. Corrections
   are submitted as a request, then applied only after approval.
   ========================================================= */
let ascbCorrectionCurrent = null;
let ascbCorrectionRows = [];
function ascbCorrectionEl(id){return document.getElementById(id);}
function ascbCorrectionEsc(v){return escapeHTML(String(v??''));}
function ascbRecordCorrectionOpen(){
    const s=ascbGradeMgmtCurrent, idx=Number(s?.activeTermIndex ?? 0), t=s?.terms?.[idx];
    if(!s||!t){alert('Please select a term first.');return;}
    // Kung 'manage_grades' ang role (UNIT HEAD / SCHOOL REGISTRAR) at latest
    // term ito, direktang editable na — hindi na kailangan ng correction
    // request. Para sa ibang role na 'requestRecordCorrection' lang meron
    // (hal. ADMIN STAFF), pwede itong gamitin kahit sa latest term, dahil
    // wala silang direct-edit access dito.
    if(idx===0 && ASCB_PERMISSIONS?.manageGrades){alert('This latest term can be encoded and submitted for peer approval — use Submit Grades for Approval.');return;}
    if(!ASCB_PERMISSIONS?.requestRecordCorrection){alert("You don't have permission to request a correction.");return;}
    ascbCorrectionCurrent={student:s,term:t};
    ascbCorrectionRows=(t.rows||[]).map(r=>({id:Number(r.enrollment_subject_id),courseCode:r.course_code||'',description:r.description||'',units:r.units??0,grade:r.grade||'',remove:false}));

    // Huwag mag-stack ng dalawang fullscreen modal. Itago muna ang Grade Management
    // modal habang bukas ang correction modal; ibabalik ito kapag nag-Cancel/Close.
    const gradeModal=ascbGradeMgmtEl('gradeManagementModal');
    if(gradeModal) gradeModal.classList.remove('active');

    ascbCorrectionRender();
    const correctionModal=ascbCorrectionEl('recordCorrectionModal');
    if(correctionModal){
        correctionModal.style.zIndex='1300';
        correctionModal.classList.add('active');
    }
}
function ascbCorrectionRender(){
    const s=ascbCorrectionCurrent.student,t=ascbCorrectionCurrent.term,body=ascbCorrectionEl('recordCorrectionBody');
    ascbCorrectionEl('recordCorrectionSub').textContent=`${s.fullName} • ${s.studentId||'—'} • ${t.trimester||'Term'} / ${t.schoolYear||'—'}`;
    body.innerHTML=`<div class="record-correction-banner"><strong>Subject / Grade Correction</strong><br><span style="font-size:12px;">Original record is protected. I-submit ang requested changes; hindi pa ito magiging official hangga't hindi naa-approve.</span></div>
    <div class="record-correction-table-wrap"><table class="record-correction-table"><thead><tr><th>Course Code</th><th>Description</th><th>Units</th><th>Current Grade</th><th>New Grade</th><th>Remove</th></tr></thead><tbody id="recordCorrectionRows">${ascbCorrectionRows.map((r,i)=>`<tr data-i="${i}"><td><input class="rc-code" value="${ascbCorrectionEsc(r.courseCode)}"></td><td><input class="rc-desc" value="${ascbCorrectionEsc(r.description)}"></td><td><input type="text" inputmode="decimal" class="rc-units" value="${ascbCorrectionEsc(r.units)}" placeholder="3 / -" maxlength="6"></td><td>${ascbCorrectionEsc(r.grade||'—')}</td><td><input class="rc-grade" value="${ascbCorrectionEsc(r.grade)}" placeholder="1.75 / INC / Dr. / NG / P / -"></td><td style="text-align:center"><input type="checkbox" class="rc-remove" ${r.remove?'checked':''}></td></tr>`).join('')}</tbody></table></div>
    <div class="record-correction-actions" style="justify-content:flex-start"><button type="button" class="btn btn-outline" onclick="ascbRecordCorrectionAddSubject()">＋ Add Subject</button></div>
    <div class="f137-field" style="margin-top:12px"><label for="recordCorrectionReason">Reason <span style="color:#b91c1c">*</span></label><textarea id="recordCorrectionReason" rows="3" maxlength="500" placeholder="Hal. Incorrectly encoded grade / wrong subject enrolled"></textarea></div>
    <div class="record-correction-actions"><button type="button" class="btn btn-secondary" onclick="ascbRecordCorrectionClose()">Cancel</button><button type="button" class="btn btn-primary" onclick="ascbRecordCorrectionSubmit()">Submit Correction</button></div>`;
}
function ascbRecordCorrectionAddSubject(){
    const trs=[...document.querySelectorAll('#recordCorrectionRows tr')];
    trs.forEach(tr=>{const i=Number(tr.dataset.i),r=ascbCorrectionRows[i];if(!r)return;r.courseCode=(tr.querySelector('.rc-code')?.value||'').trim();r.description=(tr.querySelector('.rc-desc')?.value||'').trim();r.units=(tr.querySelector('.rc-units')?.value||'').trim();r.grade=(tr.querySelector('.rc-grade')?.value||'').trim();r.remove=!!tr.querySelector('.rc-remove')?.checked;});
    const reason=ascbCorrectionEl('recordCorrectionReason')?.value||'';
    ascbCorrectionRows.push({id:0,courseCode:'',description:'',units:0,grade:'',remove:false});
    ascbCorrectionRender();
    const reasonEl=ascbCorrectionEl('recordCorrectionReason');if(reasonEl)reasonEl.value=reason;
    const body=ascbCorrectionEl('recordCorrectionRows'); body?.lastElementChild?.scrollIntoView({block:'nearest'});
}
function ascbCorrectionCollect(){
    const rows=[...document.querySelectorAll('#recordCorrectionRows tr')];
    const out=[];
    for(const tr of rows){
        const i=Number(tr.dataset.i),base=ascbCorrectionRows[i];
        const code=(tr.querySelector('.rc-code')?.value||'').trim(),desc=(tr.querySelector('.rc-desc')?.value||'').trim();
        const units=(tr.querySelector('.rc-units')?.value||'').trim(),grade=(tr.querySelector('.rc-grade')?.value||'').trim();
        const remove=!!tr.querySelector('.rc-remove')?.checked;
        if(!base.id){
            if(remove) continue;
            if(!code&&!desc&&!units&&!grade) continue;
            out.push({type:'subject_add',courseCode:code,description:desc,units:units,grade:grade});
        }else{
            if(remove){out.push({type:'subject_remove',subjectId:base.id});continue;}
            if(code!==String(base.courseCode||'')||desc!==String(base.description||'')||Number(units)!==Number(base.units)) out.push({type:'subject_update',subjectId:base.id,courseCode:code,description:desc,units:units});
            if(grade!==String(base.grade||'')) out.push({type:'grade',subjectId:base.id,newGrade:grade});
        }
    }
    return out;
}
async function ascbRecordCorrectionSubmit(){
    const s=ascbCorrectionCurrent?.student,t=ascbCorrectionCurrent?.term;if(!s||!t)return;
    const reason=(ascbCorrectionEl('recordCorrectionReason')?.value||'').trim(),changes=ascbCorrectionCollect(),status=ascbCorrectionEl('recordCorrectionStatus');
    if(!reason){alert('Enter the reason for the correction.');return;} if(!changes.length){alert('No changes were selected.');return;}
    if(!(await ascbConfirm('Submit the correction request for approval?')))return;
    if(status){status.style.display='block';status.textContent='Submitting correction request…';}
    try{const res=await fetch('api/record_corrections.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'request',enrollmentId:Number(t.enrollmentId),reason,changes})});const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||'Unable to submit.');if(status)status.textContent=`Correction #${data.id} submitted — PENDING APPROVAL.`;setTimeout(()=>ascbRecordCorrectionClose(),1300);}
    catch(e){if(status){status.style.display='block';status.textContent=e.message||'Unable to submit the correction.';}}
}
function ascbRecordCorrectionClose(){
    const m=ascbCorrectionEl('recordCorrectionModal');
    if(m){m.classList.remove('active');m.style.zIndex='';}
    ascbCorrectionCurrent=null;
    ascbCorrectionRows=[];
    // Ibalik ang Grade Management modal kung galing tayo roon.
    if(ascbGradeMgmtCurrent){
        const gradeModal=ascbGradeMgmtEl('gradeManagementModal');
        if(gradeModal) gradeModal.classList.add('active');
    }
}

// ESC closes the top-most correction modal first, then leaves Grade Management intact.
document.addEventListener('keydown', function(e){
    if(e.key!=='Escape') return;
    const correction=ascbCorrectionEl('recordCorrectionModal');
    if(correction?.classList.contains('active')){ascbRecordCorrectionClose();return;}
    const review=ascbCorrectionEl('recordCorrectionReviewModal');
    if(review?.classList.contains('active')){ascbRecordCorrectionReviewClose();}
});
async function ascbRecordCorrectionReviewOpen(){
    if(!ASCB_PERMISSIONS?.approveRecordCorrection){alert("You don't have permission to review.");return;}
    const body=ascbCorrectionEl('recordCorrectionReviewBody'); if(!body)return; body.innerHTML='<div class="records-status">Loading pending corrections…</div>'; ascbCorrectionEl('recordCorrectionReviewModal')?.classList.add('active');
    try{const res=await fetch('api/record_corrections.php?status=PENDING');const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||'Unable to load.');if(!data.rows.length){body.innerHTML='<div class="records-empty">Walang pending correction requests.</div>';return;}try{if(typeof ascbMrInvalidateNames==='function')ascbMrInvalidateNames();const rcNames=await ascbMasterCurrentNames();data.rows.forEach(r=>{const n=rcNames&&rcNames[r.student_id];r._masterName=(n&&n.fullName)?n.fullName:'';});}catch(e){}body.innerHTML=data.rows.map(r=>{const changes=r.changes||[];const diff=changes.map(c=>{if(c.type==='grade')return `<div>Grade <strong>${ascbCorrectionEsc(c.courseCode)}</strong>: <del>${ascbCorrectionEsc(c.oldGrade||'blank')}</del> → <ins>${ascbCorrectionEsc(c.newGrade||'blank')}</ins></div>`;if(c.type==='subject_update')return `<div>Subject <strong>${ascbCorrectionEsc(c.oldCourseCode||'')}</strong>: ${ascbCorrectionEsc(c.oldDescription)} → <ins>${ascbCorrectionEsc(c.newDescription)}</ins></div>`;if(c.type==='subject_remove')return `<div>Remove: <strong>${ascbCorrectionEsc(c.courseCode)}</strong> — ${ascbCorrectionEsc(c.description)}</div>`;return `<div>Add: <strong>${ascbCorrectionEsc(c.courseCode)}</strong> — ${ascbCorrectionEsc(c.description)}</div>`;}).join('');return `<div class="record-correction-request"><strong>#${r.id} — ${ascbCorrectionEsc(r._masterName||r.name||(r.surname+', '+r.first_name))}</strong><div style="font-size:12px;margin-top:3px">${ascbCorrectionEsc(r.trimester)} / ${ascbCorrectionEsc(r.school_year)} • Requested by ${ascbCorrectionEsc(r.requested_by||'—')}</div><div style="margin-top:7px"><strong>Reason:</strong> ${ascbCorrectionEsc(r.reason)}</div><div class="record-correction-diff">${diff}</div><div class="record-correction-actions"><button class="btn btn-secondary" type="button" onclick="ascbRecordCorrectionReview(${Number(r.id)},'REJECT')">Reject</button><button class="btn btn-primary" type="button" onclick="ascbRecordCorrectionReview(${Number(r.id)},'APPROVE')">Approve & Apply</button></div></div>`;}).join('');}
    catch(e){body.innerHTML=`<div class="records-status">${ascbCorrectionEsc(e.message||'Unable to load.')}</div>`;}
}
async function ascbRecordCorrectionReview(id,decision){const remarks=(await ascbPrompt(decision==='APPROVE'?'Optional review remarks:':'Reason for rejection:',''))??'';if(decision==='REJECT'&&!remarks.trim()){alert('Enter a rejection reason.');return;}if(!(await ascbConfirm(decision==='APPROVE'?'I-approve at i-apply ang correction?':'I-reject ang correction request?')))return;try{const res=await fetch('api/record_corrections.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:decision==='APPROVE'?'approve':'reject',correctionId:id,remarks})});const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||'Action failed.');alert(decision==='APPROVE'?'Correction approved and applied.':'Correction rejected.');ascbRecordCorrectionReviewOpen();ascbRefreshCorrectionBadge();}catch(e){alert(e.message||'Unable to process the correction.');}}
function ascbRecordCorrectionReviewClose(){ascbCorrectionEl('recordCorrectionReviewModal')?.classList.remove('active');}

/* =========================================================
   GRADE EVALUATION
   ---------------------------------------------------------
   Read-only report — WALANG sariling database table ito.
   Binabasa lang nito ang existing na `enrollees` records
   (parehong data source ng Enrollment module) at pinagsasama
   ang lahat ng subjects/grades ng isang estudyante mula sa
   bawat naka-log na enrollment (bawat School Year / Year
   Level / Trimester) sa iisang report.

   Ang mga estudyante ay pinagsasama-sama (grouped) base sa
   Surname + Given Name + Middle Name (case-insensitive,
   trimmed) dahil walang hiwalay na "students" table ang
   system na ito — bawat row sa `enrollees` ay isang
   enrollment *event* (isang term), hindi isang permanenteng
   student ID.
   ========================================================= */

let ascbGradeEvalRows = []; let ascbGradeEvalTotal = 0;
let ascbGradeEvalStudents = [];
let ascbGradeEvalCurrentKey = "";
let ascbGradeEvalCurrentTerms = [];
let ascbGradeEvalPage = 1;

/* Huling na-build na buong HTML (kasama styles/markup) ng Grade
   Evaluation preview — ginagamit ng ascbGradeEvalPrintNow() para
   talagang mag-print gamit ang parehong pinagkakatiwalaang
   window.open()+print() na pattern ng Certificates (mas
   maaasahan kaysa iframe.contentWindow.print(), na pwedeng
   tumahimik/walang mangyari sa ilang browser kapag hindi pa
   tapos maka-load ang laman ng iframe). */
let ascbGradeEvalCurrentPrintHtml = "";


/* =========================================================
   LAKI NG WATERMARK — GRADE EVALUATION (SHORT BOND PAPER)
   ---------------------------------------------------------
   IISANG LUGAR LANG ITO BAGUHIN kung gusto pang palakihan o
   paliitin ang ASCB logo na watermark sa likod ng printed na
   Grade Evaluation.

     sizeIn  = laki ng logo sa INCHES (dating 4.35in).
               Mas malaki ang numero = mas malaki ang logo.
               Huwag lalagpas ng mga 6.5in para hindi maapektuhan
               ang gilid ng 8.5in na short bond paper.

     opacity = kadiliman ng watermark (0 = di makita,
               1 = solid). Panatilihin itong mababa para
               nababasa pa rin ang teksto sa ibabaw nito.

   Ginagamit ito sa SHORT at LONG print; ang logo ay naka-center
   sa bawat sheet, kabilang ang mga karagdagang pahina.
========================================================= */
const ASCB_GRADE_EVAL_WATERMARK = {
    sizeIn: 5.8,
    opacity: 0.07,
};


function ascbGradeEvalEl(id) {
    return document.getElementById(id);
}

/* Normalized grouping key para sa isang estudyante. */
function ascbGradeEvalStudentKey(row) {
    const sid = String(row.student_id || "")
        .trim()
        .replace(/\s+/g, " ")
        .toUpperCase();
    return sid || [row.surname, row.first_name, row.middle_name]
        .map(v => (v || "").trim().toLowerCase())
        .join("|");
}

function ascbGradeEvalEncodeBtnSync(){/* Encode by Subject button removed from Grade Evaluation. */}
async function ascbLoadGradeEvaluation(pageOverride = null) {
    if (pageOverride !== null) ascbGradeEvalPage = Math.max(1, Number(pageOverride) || 1);
    const status = ascbGradeEvalEl("gradeEvalListStatus");
    const wrapper = ascbGradeEvalEl("gradeEvalListWrapper");

    if (status) {
        status.style.display = "block";
        status.textContent = "Loading students…";
    }
    if (wrapper) wrapper.style.display = "none";

    ascbGradeEvalCloseReport();
    ascbGradeEvalCurrentKey = "";
    if (pageOverride === null) ascbGradeEvalPage = 1;

    try {
        // Read-only Grade Evaluation shows approved student records across ALL
        // departments for most roles (view=grade_evaluation flag). DEAN accounts
        // are the exception: the API limits them to their assigned Department(s)
        // (Staff Accounts > Assign), so a Dean only ever sees their own students.
        const response = await fetch("api/grades.php?view=grade_evaluation&group=student&page=" + encodeURIComponent(String(ascbGradeEvalPage)) + "&limit=25&q=" + encodeURIComponent((ascbGradeEvalEl("gradeEvalSearchInput")?.value||"").trim()));
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = "Unable to load the students. Please try again.";
            return;
        }

        const rawGradeRows = Array.isArray(data.rows) ? data.rows : [];
        ascbGradeEvalTotal = Number(data.total || 0);
        const termMap = new Map();
        rawGradeRows.forEach(r => {
            const key = String(r.enrollment_id);
            if (!termMap.has(key)) termMap.set(key, { ...r, subjects: [] });
            if (r.enrollment_subject_id) termMap.get(key).subjects.push({
                code: r.course_code,
                description: r.description,
                units: r.units,
                grade: r.grade || "",
                subjectId: r.enrollment_subject_id,
                _hiddenOnPrint: !!Number(r.hidden_on_print),
            });
        });
        ascbGradeEvalRows = [...termMap.values()];

        // I-group ang mga enrollment rows base sa estudyante, pagkatapos
        // pagbukud-bukurin ang mga term ng bawat estudyante base sa
        // created_at (pagkakasunod-sunod ng pagka-enroll).
        const groups = new Map();
        ascbGradeEvalRows.forEach(row => {
            const key = ascbGradeEvalStudentKey(row);
            if (!key) return;
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key).push(row);
        });

        ascbGradeEvalStudents = [...groups.entries()].map(([key, terms]) => {
            terms.sort((a, b) => new Date(a.created_at || 0) - new Date(b.created_at || 0));
            const latest = terms[terms.length - 1];
            return {
                key,
                fullName: ascbEnrollFullName(latest),
                studentId: latest.student_id || (terms.find(t => t.student_id) || {}).student_id || "",
                course: latest.program_code || latest.course || "",
                major: latest.major || "",
                terms,
            };
        }).sort((a, b) => a.fullName.localeCompare(b.fullName));

        /* Master Record: show the CURRENT name (old enrollment rows keep the old one). */
        await ascbMasterApplyCurrentNames(ascbGradeEvalStudents);
        ascbGradeEvalStudents.sort((a, b) => a.fullName.localeCompare(b.fullName));

        ascbGradeEvalRenderStudentList();

        if (status) status.style.display = "none";
        if (wrapper) wrapper.style.display = "block";

    } catch (error) {
        console.error("Grade Evaluation load failed:", error);
        if (status) status.textContent = "Unable to reach the server. Please check your connection or refresh the page.";
    }
}

let ascbGradeEvalSearchTimer = null;
function ascbGradeEvalFilterStudents() {
    ascbGradeEvalPage = 1;
    clearTimeout(ascbGradeEvalSearchTimer);
    ascbGradeEvalSearchTimer = setTimeout(() => ascbLoadGradeEvaluation(), 250);
}

function ascbGradeEvalGoToPage(page) { ascbLoadGradeEvaluation(page); }

function ascbGradeEvalRenderStudentList() {
    const body = ascbGradeEvalEl("gradeEvalStudentTableBody");
    if (!body) return;

    const term = (ascbGradeEvalEl("gradeEvalSearchInput") ? ascbGradeEvalEl("gradeEvalSearchInput").value : "").trim().toLowerCase();

    const filtered = ascbGradeEvalStudents.filter(student => {
        if (!term) return true;
        return ascbNameMatch(term, [student.fullName, student.studentId, student.course, student.major]);
    });

    if (!filtered.length) {
        body.innerHTML = `<tr><td colspan="6" class="records-empty">No student found.</td></tr>`;
        ascbRenderPagination("gradeEvalPagination", 1, 1, 0, ASCB_PAGE_SIZE, "ascbGradeEvalGoToPage");
        return;
    }

    const per = 25;
    const totalPages = Math.max(1, Math.ceil(ascbGradeEvalTotal / per));
    ascbGradeEvalPage = Math.min(ascbGradeEvalPage, totalPages);
    const pageRows = filtered;

    body.innerHTML = pageRows.map(student => `
        <tr>
            <td data-label="Student ID">${escapeHTML(student.studentId || "—")}</td>
            <td data-label="Name">${escapeHTML(student.fullName)}</td>
            <td data-label="Course">${escapeHTML(student.course || "—")}</td>
            <td data-label="Major">${escapeHTML(student.major || "—")}</td>
            <td data-label="Enrollment Records">${student.terms.length}</td>
            <td data-label="Actions">
                <button type="button" class="btn btn-outline approved-so-action-btn action-icon-btn" title="View Grades" aria-label="View Grades" onclick="ascbGradeEvalOpenByIndex(${ascbGradeEvalStudents.indexOf(student)})">${ascbIcon('viewGrades')}</button>
                <button type="button" class="btn btn-outline approved-so-action-btn action-icon-btn" title="Export to Excel" aria-label="Export to Excel" onclick="ascbGradeEvalExportExcel(${ascbGradeEvalStudents.indexOf(student)})">${ascbIcon('exportExcel')}</button>
            </td>
        </tr>
    `).join("");

    ascbRenderPagination("gradeEvalPagination", ascbGradeEvalPage, totalPages, ascbGradeEvalTotal, per, "ascbGradeEvalGoToPage");
}

/* GWA ng isang term (isang enrollment row) — parehong formula
   gaya ng ibang bahagi ng system: weighted average ng
   grade x units, hindi kasama ang blangko/hindi-numeric na grade. */
function ascbGradeEvalTermGWA(subjects) {
    let gradedUnits = 0;
    let weightedSum = 0;

    (subjects || []).forEach(subject => {
        const grade = parseFloat(subject.grade);
        const units = parseFloat(subject.units) || 0;
        if (isNaN(grade) || units <= 0) return;
        weightedSum += grade * units;
        gradedUnits += units;
    });

    return { gwa: gradedUnits > 0 ? (weightedSum / gradedUnits) : null, gradedUnits };
}

/* Export ng buong grade record ng isang estudyante (lahat ng term) bilang .xlsx. */
function ascbGradeEvalExportExcel(index) {
    const student = ascbGradeEvalStudents[Number(index)];
    if (!student || !student.studentId) {
        alert("This student has no Student ID, so the record cannot be exported.");
        return;
    }
    const q = new URLSearchParams({ csrf: ASCB_CSRF_TOKEN, student_id: student.studentId });
    window.location.href = "api/student_grades_export.php?" + q.toString();
}

function ascbGradeEvalOpenByIndex(index) {
    const student = ascbGradeEvalStudents[Number(index)];
    if (student) ascbGradeEvalOpen(student.key);
}

/* Kung ang laman ng grade ay INC o DROP (kasama ang mga variant na
   "INCOMPLETE" / "DRP" / "DROPPED"), ibinabalik ang CSS class na
   gagamitin para pulahin ito sa Grade Evaluation (parehong on-screen
   at print), para agad mapansin ng mag-e-enroll. */
function ascbGradeFlagClass(grade) {
    const g = String(grade || "").trim().toUpperCase();
    if (g === "INC" || g === "INCOMPLETE" || g === "NG") return "grade-flag-inc";
    if (g === "DR." || g === "DR" || g === "DRP" || g === "DROP" || g === "DROPPED") return "grade-flag-drop";
    return "";
}

/* Ang mga subject na may grade na INC o DRP ay dapat lumabas na
   "0" sa Units column (kasama na sa Total Units) — hindi dahil
   binago ang totoong naka-record na units ng subject (nananatili
   itong buo sa database), kundi para lang sa DISPLAY/print, dahil
   hindi pa naman "nabigay" ang units na iyon habang Incomplete o
   Dropped pa ang estudyante rito. */
/* (Dash) Kapag "-" ang grade (hal. Comprehensive Exam), "-" din ang
   ipinapakita sa Units column (0 pa rin ang bilang sa Total Units). */
function ascbGradeEvalUnitsText(subject) {
    if (String((subject && subject.grade) || "").trim() === "-") return "-";
    return String(ascbGradeEvalUnitsForDisplay(subject));
}
function ascbGradeEvalUnitsForDisplay(subject) {
    const flag = ascbGradeFlagClass(subject && subject.grade);
    if (flag === "grade-flag-inc" || flag === "grade-flag-drop") return 0;
    return parseFloat(subject && subject.units) || 0;
}

function ascbGradeEvalNormalizeTermLabel(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    // Legacy Summer records may be stored/displayed as:
    // "3rd | Summer", "3rd Semester | Summer", or
    // "3rd Trimester | Summer". Grade Evaluation and printing
    // must show the academic term simply as "Summer".
    const parts = raw.split("|").map(part => part.trim()).filter(Boolean);
    if (parts.length > 1 && parts[parts.length - 1].toLowerCase() === "summer") {
        return "Summer";
    }
    return raw;
}

/* Iisang function na gumagawa ng HTML block (heading + table) ng
   ISANG term — ginagamit pareho ng on-screen preview (lahat ng term)
   at ng print/PDF ng iisang trimester lang, para magkatugma laging
   ang datos/format ng dalawa. */
function ascbGradeEvalBuildTermBlockHtml(student, termRow, termIdx, courseChanged) {
    const subjects = Array.isArray(termRow.subjects) ? termRow.subjects : [];
    const { gwa, gradedUnits } = ascbGradeEvalTermGWA(subjects);

    let termTotalUnits = 0;
    subjects.forEach(s => { termTotalUnits += ascbGradeEvalUnitsForDisplay(s); });

    const academicYear = termRow.school_year || "—";
    const trimester = ascbGradeEvalNormalizeTermLabel(termRow.trimester || "—");
    const yearLevel = termRow.year_level || "";
    const termCourse = termRow.program_code || termRow.course || "";

    // Ipakita ang "Course: ..." (code lang, hindi na kasama ang major
    // — para hindi na-uulit ang "BSBA-MM — Marketing Management") sa
    // BAWAT term kapag alam nang nag-iiba-iba ang course ng estudyante
    // sa buong record niya (courseChanged) — kahit pareho ang term na
    // ito sa current/latest course, dapat malinaw pa rin kung anong
    // course siya noon. Kung hindi naman talaga nag-iiba ang course sa
    // buong record, hindi na ito uulitin dahil nasa itaas na ito.
    const showTermCourse = !!courseChanged && !!termCourse;

    const rowsHtml = subjects.length
        ? subjects.map((s, subjIdx) => {
            const flagClass = ascbGradeFlagClass(s.grade);
            const hidden = !!s._hiddenOnPrint;
            const canHide = (typeof ASCB_PERMISSIONS !== "undefined") && (ASCB_PERMISSIONS.manageGrades || ASCB_PERMISSIONS.hideGrades);
            const hideCellHtml = canHide
                ? `<label class="grade-eval-hide-toggle" title="Hide this subject's grade and units in the Student Portal; hide its grade on print">
                        <input type="checkbox" ${hidden ? "checked" : ""} onchange="ascbGradeEvalToggleHide(${termIdx}, ${subjIdx}, this.checked)">
                        Hide from Student / Print
                    </label>`
                : (hidden ? `<span class="grade-eval-hide-readonly">🙈 Hidden</span>` : "—");
            return `
            <tr data-term-idx="${termIdx}" data-subj-idx="${subjIdx}" class="${hidden ? "grade-eval-row-hidden" : ""}">
                <td class="ge-code" data-label="Course Code">${escapeHTML(s.code || "—")}</td>
                <td class="ge-desc" data-label="Description">${escapeHTML(s.description || "—")}</td>
                <td style="text-align:center;" class="ge-grade ${flagClass}" data-label="Grade">${escapeHTML(s.grade || "—")}</td>
                <td style="text-align:center;" class="ge-units" data-label="Units">${escapeHTML(ascbGradeEvalUnitsText(s))}</td>
                <td style="text-align:center;" class="grade-eval-hide-col ge-hide">${hideCellHtml}</td>
            </tr>
        `;
        }).join("")
        : `<tr><td colspan="5" class="records-empty">Walang subjects na naka-record para sa term na ito.</td></tr>`;

    const html = `
        <div class="grade-eval-term">
            <div class="grade-eval-term-heading">
                <strong>Student ID:</strong> ${escapeHTML(student.studentId || "—")} &nbsp;&nbsp;
                <strong>${escapeHTML(trimester)}</strong> &nbsp;&nbsp;
                <strong>Academic Year:</strong> ${escapeHTML(academicYear)}${yearLevel ? ` &nbsp;&nbsp;<strong>Year Level:</strong> ${escapeHTML(yearLevel)}` : ""}
                ${showTermCourse ? `<br><strong>Course:</strong> ${escapeHTML(termCourse)}` : ""}
            </div>
            <table class="grade-eval-print-table grade-eval-print-table--editable">
                <thead>
                    <tr><th>Course Code</th><th>Course Description</th><th>Grade</th><th>Units</th><th>Hide from Student / Print</th></tr>
                </thead>
                <tbody>${rowsHtml}</tbody>
                <tfoot>
                    <tr class="ge-foot-row"><td colspan="2" class="total-label ge-foot-label">TOTAL UNITS</td><td class="ge-foot-empty"></td><td style="text-align:center;" class="ge-foot-value">${termTotalUnits}</td><td class="ge-foot-empty"></td></tr>
                    <tr class="ge-foot-row"><td colspan="2" class="total-label ge-foot-label">GWA</td><td style="text-align:center;" class="ge-foot-value">${gwa !== null ? gwa.toFixed(2) : "—"}</td><td class="ge-foot-empty"></td><td class="ge-foot-empty"></td></tr>
                </tfoot>
            </table>
        </div>
    `;

    return { html, gwa, gradedUnits, termTotalUnits };
}

/* Tinatawag pag ni-click ang checkbox sa "Hide from Student / Print" column.
   Ise-save agad sa database (enrollment_subjects.hidden_on_print)
   kaya nananatili ang setting kahit mag-refresh o mag-logout —
   pero ang totoong grade mismo ay hindi ito dine-delete/binabago,
   kaya hindi rin naaapektuhan ang GWA computation. Ang effect nito
   sa Student Portal ay itinatago rin nito ang grade at units; sa print,
   grade lang ang papalitan ng star. */
async function ascbGradeEvalToggleHide(termIdx, subjIdx, checked) {
    const termRow = ascbGradeEvalCurrentTerms && ascbGradeEvalCurrentTerms[termIdx];
    const subject = termRow && Array.isArray(termRow.subjects) ? termRow.subjects[subjIdx] : null;
    if (!subject) return;

    const checkbox = document.querySelector(
        `#gradeEvalReportBody tr[data-term-idx="${termIdx}"][data-subj-idx="${subjIdx}"] .grade-eval-hide-toggle input[type="checkbox"]`
    );
    const row = document.querySelector(`#gradeEvalReportBody tr[data-term-idx="${termIdx}"][data-subj-idx="${subjIdx}"]`);

    // Optimistic update muna sa UI para agad ang response...
    const previous = !!subject._hiddenOnPrint;
    subject._hiddenOnPrint = !!checked;
    if (row) row.classList.toggle("grade-eval-row-hidden", !!checked);
    if (checkbox) checkbox.disabled = true;

    try {
        const response = await fetch("api/grades.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "set_hidden", subjectId: subject.subjectId, hidden: !!checked }),
        });
        const data = await response.json();
        if (!data || !data.ok) throw new Error(data && data.error ? data.error : "Save failed");
    } catch (error) {
        // ...pero i-revert kung na-fail ang pag-save sa server, para
        // hindi mag-akalang naka-save na ito gayong hindi pala.
        console.error("Grade visibility save failed:", error);
        subject._hiddenOnPrint = previous;
        if (row) row.classList.toggle("grade-eval-row-hidden", previous);
        if (checkbox) checkbox.checked = previous;
        alert("The 'Hide from Student / Print' setting was not saved. Please try again.");
    } finally {
        if (checkbox) checkbox.disabled = false;
    }
}

function ascbGradeEvalOpen(key) {
    const student = ascbGradeEvalStudents.find(s => s.key === key);
    if (!student) return;

    ascbGradeEvalCurrentKey = key;

    const modal = ascbGradeEvalEl("gradeEvalReportModal");
    const nameEl = ascbGradeEvalEl("gradeEvalReportName");
    const subEl = ascbGradeEvalEl("gradeEvalReportSub");
    const bodyEl = ascbGradeEvalEl("gradeEvalReportBody");

    nameEl.textContent = student.fullName;
    const distinctCourses = [...new Set(student.terms.map(t => (t.program_code || t.course || "").trim()).filter(Boolean))];
    const courseChanged = distinctCourses.length > 1;
    const courseLabel = (student.course || student.major)
        ? ascbGradeEvalFormatCourseMajor(student.course, student.major)
        : "";
    subEl.textContent = [
        student.studentId ? `Student ID: ${student.studentId}` : "",
        courseLabel ? `${courseChanged ? "Current Course" : "Course"}: ${courseLabel}` : "",
        courseChanged ? "⚠ Course varies per term — see each term below" : "",
    ].filter(Boolean).join(" | ") || "—";

    let overallGradedUnits = 0;
    let overallWeightedSum = 0;
    let overallTotalUnits = 0;

    /*
     * Academic-term ordering for Grade Evaluation.
     *
     * IMPORTANT: School Year is always the PRIMARY key. Within one
     * School Year, the order depends on the program's term system:
     *   Semester  : 1st Semester -> 2nd Semester -> Summer
     *   Trimester : 1st Trimester -> 2nd Trimester -> 3rd Trimester -> Summer
     *
     * Older records may contain shorthand values (1st/2nd/3rd) or the
     * legacy "3rd | Summer" label. Those are normalized for SORTING only;
     * the original database value is preserved for display/printing.
     */
    const ascbGradeEvalSchoolYearRank = (value) => {
        const text = String(value || "").trim();
        const match = text.match(/^(\d{4})/);
        return match ? Number(match[1]) : null;
    };

    const ascbGradeEvalTermRank = (termRow) => {
        const raw = String(termRow?.trimester || "").trim();
        const normalized = raw.toLowerCase().replace(/\s+/g, " ");
        const programCode = String(termRow?.program_code || "").trim();
        const termType = (typeof ascbGetProgramTermType === "function")
            ? ascbGetProgramTermType(programCode)
            : "Trimester";

        const isSummer = normalized === "summer" || /\|\s*summer$/i.test(raw);
        if (isSummer) {
            return termType === "Semester" ? 3 : 4;
        }

        if (termType === "Semester") {
            if (normalized === "1st semester" || normalized === "1st") return 1;
            if (normalized === "2nd semester" || normalized === "2nd") return 2;
            return 99;
        }

        if (normalized === "1st trimester" || normalized === "1st") return 1;
        if (normalized === "2nd trimester" || normalized === "2nd") return 2;
        if (normalized === "3rd trimester" || normalized === "3rd") return 3;
        return 99;
    };

    const sortedTerms = [...student.terms].sort((a,b) => {
        const aYear = ascbGradeEvalSchoolYearRank(a.school_year);
        const bYear = ascbGradeEvalSchoolYearRank(b.school_year);
        if (aYear !== null || bYear !== null) {
            if (aYear === null) return 1;
            if (bYear === null) return -1;
            if (aYear !== bYear) return aYear - bYear;
        } else {
            const ay = String(a.school_year || "").localeCompare(String(b.school_year || ""), undefined, {numeric:true});
            if (ay !== 0) return ay;
        }

        const ta = ascbGradeEvalTermRank(a);
        const tb = ascbGradeEvalTermRank(b);
        if (ta !== tb) return ta - tb;

        return new Date(a.created_at || 0) - new Date(b.created_at || 0);
    });

    ascbGradeEvalCurrentTerms = sortedTerms;

    const termsHtml = sortedTerms.map((termRow, termIdx) => {
        const block = ascbGradeEvalBuildTermBlockHtml(student, termRow, termIdx, courseChanged);
        overallTotalUnits += block.termTotalUnits;
        if (block.gwa !== null) {
            overallWeightedSum += block.gwa * block.gradedUnits;
            overallGradedUnits += block.gradedUnits;
        }
        return block.html;
    }).join("");

    const overallGwa = overallGradedUnits > 0 ? (overallWeightedSum / overallGradedUnits) : null;

    bodyEl.innerHTML = `
        ${termsHtml || '<p>No enrollment/grade records found.</p>'}
        <div class="grade-eval-summary">
            <p><strong>Overall Total Units:</strong> ${overallTotalUnits}</p>
            <p><strong>Overall GWA:</strong> ${overallGwa !== null ? overallGwa.toFixed(2) : "—"}</p>
        </div>
    `;

    const termSelect = ascbGradeEvalEl("gradeEvalTermSelect");
    if (termSelect) {
        termSelect.innerHTML = sortedTerms.map((termRow, idx) => {
            const displayTerm = ascbGradeEvalNormalizeTermLabel(termRow.trimester || "—");
            const label = `${termRow.school_year || "—"} — ${displayTerm}${termRow.year_level ? ` — ${termRow.year_level}` : ""}`;
            return `<option value="${idx}">${escapeHTML(label)}</option>`;
        }).join("") || `<option value="">Walang term</option>`;
        termSelect.selectedIndex = termSelect.options.length - 1; // default: pinaka-huling term
    }

    if (modal) {
        modal.classList.add("active");
        const scrollArea = modal.querySelector(".grade-eval-report-card");
        if (scrollArea) scrollArea.scrollTop = 0;
    }
}

function ascbGradeEvalCloseReport() {
    const modal = ascbGradeEvalEl("gradeEvalReportModal");
    if (modal) modal.classList.remove("active");
}

/* ---------------------------------------------------------
   PDF/PRINT — GAYANG-GAYA (exact copy) ng layout/format ng
   Certificates > Grade Evaluation: parehong letterhead,
   watermark, title, student details, certificate-table,
   at signature. Ginagamit dito ang MISMONG CSS classes ng
   certificate print-area (certificate-title, student-details,
   certificate-table, signature-area, atbp.) at ang mismong
   stylesheet ng site (style.css) para 100% magkatugma ang
   dalawa — hindi na hiwalay/bespoke na style.

   Nagbubukas ng PREVIEW muna sa bagong tab (hindi agad
   nagpo-print) — may button na "I-print / I-save bilang PDF"
   sa itaas na pipindutin ng user kapag handa na siya.

   - Per-trimester -> SHORT bond paper (8.5in x 11in / Letter),
     eksaktong kagaya ng isang Certificate (may Year Level at
     Semester/Trimester row, isang certificate-table lang).
   - Lahat ng trimester -> LONG bond paper (8.5in x 13in),
     isang certificate-table kada term + overall summary bago
     ang lagda.
   --------------------------------------------------------- */

/* Pinagsasama ang course/program code at ang major para sa
   "Course / Program" na row — PERO kung ang major mismo ay
   NASA LOOB NA ng course/program code (hal. "BSED-ENGLISH" na
   mismo ang naglalaman ng "ENGLISH" bilang major nito), hindi
   na ito uulitin pa bilang "BSED-ENGLISH — English" (doble/
   redundant). Ganito rin ang ginagawa kapag walang naka-record
   na major para sa specific na term/estudyanteng ito — course
   code na lang ang ipapakita, hindi na basta-basta hihiramin
   ang major ng ibang term. */
function ascbGradeEvalFormatCourseMajor(course, major) {
    const c = String(course || "").trim();
    const m = String(major || "").trim();

    // (fix) Gamitin ang buong/standard na pangalan ng programa mula sa
    // `programNames` (hal. "Bachelor of Secondary Education Major in
    // Social Studies" para sa "BSED-SOCIAL") kapag available — ito rin
    // ang parehong label na ginagamit sa Enrollment/Dashboard. Dati,
    // pag redundant ang major sa code (tingnan sa ibaba), raw code na
    // lang ang lumalabas sa print/certificate (hal. "BSED-SOCIAL"),
    // hindi ang buong pangalan ng major ("Social Studies").
    if (c && typeof programNames !== "undefined" && programNames[c]) {
        return programNames[c];
    }

    if (!m) return c || "—";
    if (!c) return m;

    const norm = v => v.toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (norm(c).includes(norm(m))) return c;

    // Minsan hindi buong salita ang nasa course code kundi acronym/
    // abbreviation ng major (hal. course "BSBA-MM" + major
    // "Marketing Management" -> ang "MM" segment ay acronym ng
    // "Marketing Management"). Kung tumutugma ang acronym ng major
    // sa isa sa mga segment ng course code, huwag nang ulitin pa
    // ang buong pangalan ng major — redundant na ito.
    const acronym = m
        .split(/\s+/)
        .filter(Boolean)
        .map(w => w[0])
        .join("")
        .toUpperCase();
    const codeSegments = c.toUpperCase().split(/[^A-Z0-9]+/).filter(Boolean);
    if (acronym.length > 1 && codeSegments.includes(acronym)) return c;

    // Minsan hindi acronym kundi ang literal na UNANG SALITA mismo ng
    // major ang lumalabas bilang segment ng course code (hal. course
    // "BSED-SOCIAL" + major "Social Studies" -> "SOCIAL" segment ay
    // talagang unang salita ng "Social Studies", "Studies" na lang ang
    // kulang). Ituring din itong redundant at ang code na lang ipakita.
    const majorFirstWord = (m.split(/\s+/).filter(Boolean)[0] || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (majorFirstWord.length >= 3 && codeSegments.some(seg =>
        seg === majorFirstWord ||
        (seg.length >= 3 && (majorFirstWord.startsWith(seg) || seg.startsWith(majorFirstWord)))
    )) return c;

    return `${c} — ${m}`;
}

/* Certificate-table markup (parehong classes/estructura gaya
   ng nasa Certificates modal) para sa ISANG term. */
function ascbGradeEvalBuildCertTableHtml(termRow) {
    const subjects = Array.isArray(termRow.subjects) ? termRow.subjects : [];
    const { gwa, gradedUnits } = ascbGradeEvalTermGWA(subjects);

    let termTotalUnits = 0;
    let anyHidden = false;
    subjects.forEach(s => { termTotalUnits += ascbGradeEvalUnitsForDisplay(s); });

    const rowsHtml = subjects.length
        ? subjects.map(s => {
            const hidden = !!s._hiddenOnPrint;
            if (hidden) anyHidden = true;
            // Kapag naka-mark na "Hide from Student / Print" ang subject na
            // ito, star (★) lang ang ilalagay sa grade cell sa print/PDF output;
            // mananatiling visible roon ang code/description/units. Sa Student
            // Portal, grade at units ay parehong nire-redact ng server.
            const flagClass = hidden ? "grade-hidden-cell" : ascbGradeFlagClass(s.grade);
            const gradeDisplay = hidden ? "★" : escapeHTML(s.grade || "—");
            return `
            <tr>
                <td>${escapeHTML(s.code || "—")}</td>
                <td>${escapeHTML(s.description || "—")}</td>
                <td class="${flagClass}">${gradeDisplay}</td>
                <td>${escapeHTML(ascbGradeEvalUnitsText(s))}</td>
            </tr>
        `;
        }).join("")
        : `<tr><td colspan="4">Walang subjects na naka-record para sa term na ito.</td></tr>`;

    const html = `
        <table class="certificate-table">
            <thead>
                <tr>
                    <th class="code-column">Course Code</th>
                    <th>Course Description</th>
                    <th class="grades-column">Grades</th>
                    <th class="units-column">Units</th>
                </tr>
            </thead>
            <tbody>${rowsHtml}</tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="cert-total-label">TOTAL UNITS</td>
                    <td>${termTotalUnits}</td>
                </tr>
                <tr>
                    <td colspan="3" class="cert-total-label">GENERAL WEIGHTED AVERAGE (GWA)</td>
                    <td>${gwa !== null ? gwa.toFixed(2) : "—"}</td>
                </tr>
            </tfoot>
        </table>
    `;

    return { html, gwa, gradedUnits, termTotalUnits, anyHidden };
}

function ascbGradeEvalTermLabel(termRow, courseChanged) {
    // Bagong format: "1st Trimester AY 2024-2025 (BSIT) (1st Year)"
    // Trimester + AY muna, tapos (course code) kung nag-iiba ang
    // course sa record ng estudyante, tapos (Year Level) sa dulo —
    // lahat plain lang (walang dash/"—" sa pagitan).
    const parts = [
        ascbGradeEvalNormalizeTermLabel(termRow.trimester || "—"),
        `AY ${termRow.school_year || "—"}`,
    ];
    let label = parts.map(escapeHTML).join(' ');

    // Ipakita ang course code (hindi na kasama ang major — para hindi
    // na-uulit ang "BSBA-MM — Marketing Management") kapag alam nang
    // nag-iiba-iba ang course ng estudyante sa buong record niya
    // (courseChanged) — kahit pareho ang term na ito sa current/latest
    // course sa itaas, dapat malinaw pa rin kung anong course siya noon.
    // Kung hindi naman talaga nag-iiba ang course, hindi na ito uulitin
    // dahil nasa itaas na ito.
    const termCourseCode = termRow.program_code || termRow.course || "";
    if (courseChanged && termCourseCode) {
        label += ` (${escapeHTML(termCourseCode)})`;
    }

    if (termRow.year_level) {
        label += ` (${escapeHTML(termRow.year_level)})`;
    }

    return label;
}

/* Bumubukas ng malaking PREVIEW MODAL (katulad-tulad ng
   Certificate Preview modal — .modal / .modal-window /
   .modal-toolbar / .modal-print-scroll) gamit ang MISMONG
   print-area markup at stylesheet ng Certificates, para
   gayang-gaya ang labas. Ang aktwal na laman ay ipina-render
   sa loob ng isang <iframe> (via srcdoc) para hindi masira
   ang layout/print-CSS ng buong app — walang bagong tab/window
   na bubukas, kaya wala nang isyu sa pop-up blocker. Ang
   totoong browser print dialog ay ipinapalabas na lang mamaya
   ng "Print" button sa toolbar ng modal (see
   ascbGradeEvalPrintNow()). */
function ascbGradeEvalOpenCertificateStylePreview(opts) {
    const {
        name, studentId, course, major,
        singleTerm, terms,
        showOverallSummary, overallTotalUnits, overallGwa,
        paperHeightIn,
        multiPage,
    } = opts;

    const modal = ascbGradeEvalEl("gradeEvalPrintPreviewModal");
    const frame = ascbGradeEvalEl("gradeEvalPrintFrame");
    const titleEl = ascbGradeEvalEl("gradeEvalPrintPreviewTitle");
    const subEl = ascbGradeEvalEl("gradeEvalPrintPreviewSub");

    if (!modal || !frame) {
        alert("Unable to open the Grade Evaluation print preview.");
        return;
    }

    const basePath = window.location.origin + window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/') + 1);

    // Kinokopya ang mismong stylesheet ng site (kasama ang lahat
    // ng .certificate-title / .student-details / .certificate-table /
    // .signature-area rules) — ito rin mismo ang ginagamit ng
    // printCertificate() para sa totoong Certificates.
    const styles = [...document.querySelectorAll("link[rel='stylesheet'], style")]
        .map(style => {
            if (style.tagName === "STYLE") {
                return `<style>${style.innerHTML}</style>`;
            }
            return `<link rel="stylesheet" href="${style.href}">`;
        })
        .join("");

    const studentDetailRows = [
        `<div class="detail-row"><span class="detail-label">Student Name</span><span class="colon">:</span><span class="detail-value">${escapeHTML(name)}</span></div>`,
        `<div class="detail-row"><span class="detail-label">Student ID</span><span class="colon">:</span><span class="detail-value">${escapeHTML(studentId || "—")}</span></div>`,
        `<div class="detail-row"><span class="detail-label">Course / Program</span><span class="colon">:</span><span class="detail-value">${escapeHTML(ascbGradeEvalFormatCourseMajor(course, major))}</span></div>`,
    ];

    let bodyBlocks;

    if (singleTerm) {
        const termRow = terms[0];
        studentDetailRows.push(
            `<div class="detail-row"><span class="detail-label">Year Level</span><span class="colon">:</span><span class="detail-value">${escapeHTML(termRow.year_level || "—")}</span></div>`,
            `<div class="detail-row"><span class="detail-label">Semester / Trimester</span><span class="colon">:</span><span class="detail-value">${escapeHTML(ascbGradeEvalNormalizeTermLabel(termRow.trimester || "—"))}, AY ${escapeHTML(termRow.school_year || "—")}</span></div>`
        );
        bodyBlocks = ascbGradeEvalBuildCertTableHtml(termRow).html;
    } else {
        const norm = v => String(v || "").trim().toUpperCase();
        const distinctCourseCodes = [...new Set(terms.map(t => norm(t.program_code || t.course)).filter(Boolean))];
        const termsCourseChanged = distinctCourseCodes.length > 1;
        bodyBlocks = terms.map(termRow => {
            const block = ascbGradeEvalBuildCertTableHtml(termRow);
            return `<div class="grade-eval-term-block"><p class="summary-title">${ascbGradeEvalTermLabel(termRow, termsCourseChanged)}</p>${block.html}</div>`;
        }).join("");
    }

    const overallSummaryHtml = showOverallSummary
        ? `<div class="student-details" style="margin-top:0.12in;">
               <div class="detail-row"><span class="detail-label">Overall Total Units</span><span class="colon">:</span><span class="detail-value">${overallTotalUnits}</span></div>
               <div class="detail-row"><span class="detail-label">Overall GWA</span><span class="colon">:</span><span class="detail-value">${overallGwa !== null && overallGwa !== undefined ? overallGwa.toFixed(2) : "—"}</span></div>
           </div>`
        : "";

    const documentHeaderHtml = `
    <div class="document-header">
        <img src="${basePath}Header_ASCB.png" class="letterhead-banner" alt="Andres Soriano Colleges of Bislig, Inc.">
        <div class="header-subtitle">
            <p class="header-office">Office of the Registrar</p>
            <p class="header-email">collegeregistrar.ascb@gmail.com &nbsp;|&nbsp; (086) 853-2306 (PhilCom)</p>
        </div>
    </div>`;

    /* ASCB logo watermark: ipinapakita sa gitna ng papel para sa
       parehong single-term at LONG bond paper / multi-page print.
       Presentation layer lang ito; walang binabago sa grades o records. */
    const watermarkHtml = `
    <div class="watermark-container" aria-hidden="true">
        <img src="${basePath}ASCB_LOGO.png" class="document-watermark" alt="">
    </div>`;

    /* Ang "Very truly yours" + pangalan ng pipirma + "School
       Registrar" na signature block, pati na rin ang "NOT VALID
       WITHOUT SCHOOL SEAL" na warning, ay lumalabas na rin ngayon
       sa LONG print (lahat ng trimester), hindi lang sa SHORT
       print (iisang trimester lang). Dahil isang beses lang
       lumalabas ang mainContentHtml (hindi paulit-ulit kada
       pahina), at ang .signature-area + .school-seal-warning ay
       may page-break-inside:avoid, natural itong dadapo sa
       HULING pahina ng multi-page sheet. */
    const signatureHtml = `
        <div class="signature-area signature-area--grade-eval">
            <div class="signature-box">
                <div class="signature-space">&nbsp;</div>
                <div class="signature-line">REBECCA P. CAPONONG, MAEd</div>
                <div class="signature-position">School Registrar</div>
            </div>
        </div>`;

    const schoolSealHtml = `
    <div class="school-seal-warning">
        <strong>NOT VALID WITHOUT</strong>
        <strong><span>SCHOOL SEAL</span></strong>
    </div>`;

    const mainContentHtml = `
    <div class="document-content">

        <h1 class="certificate-title">GRADE EVALUATION</h1>

        ${multiPage ? "" : `<p class="summary-title"><span>Below is the Summary of the Student's Grades${!singleTerm ? " (All Trimesters)" : ""}:</span></p>`}

        <div class="student-details">
            ${studentDetailRows.join("")}
        </div>

        ${bodyBlocks}

        ${overallSummaryHtml}

        ${signatureHtml}

    </div>

    ${schoolSealHtml}`;

    /* ===================================================================
       ONE-PAGE MODE (Print Term) — eksaktong kagaya ng printCertificate():
       fixed na 8.5 x paperHeightIn na sheet, overflow hidden, absolute
       watermark/footer. Palaging kasya sa isang term sa isang pahina.
       =================================================================== */
    const singlePageMarkup = `
<div class="print-area" id="printArea">
    ${documentHeaderHtml}
    ${watermarkHtml}
    ${mainContentHtml}
</div>`;

    const singlePageStyle = `
    @page { size: 8.5in ${paperHeightIn}in; margin: 0; }

    /* NOTE: mas mataas ang specificity dito (html body.ascb-grade-eval-preview)
       kaysa sa plain na "html, body" na mula sa GLOBAL na style.css (na kinokopya
       rin papasok sa iframe na ito) — dahil parehong "!important" ginagamit ng
       ibang print rules (Certificates / Form 137) para sa laki/padding ng
       html at body, kailangang tiyakin dito na palaging ang Grade Evaluation
       mismo ang mananalo sa cascade, kahit anong pagkakasunod-sunod pa ng
       stylesheets o anong bagong print rule pa ang idagdag balang araw sa
       ibang module. */
    html, body,
    html body.ascb-grade-eval-preview {
        width: 8.5in !important;
        height: ${paperHeightIn}in !important;
        margin: 0 !important;
        padding: 0 !important;
        padding-right: 0 !important;
        background: #ffffff !important;
        overflow: hidden !important;
    }

    .print-area,
    #printArea.print-area {
        width: 8.5in !important;
        height: ${paperHeightIn}in !important;
        min-height: ${paperHeightIn}in !important;
        max-height: ${paperHeightIn}in !important;
        margin: 0 !important;
        padding: 0 !important;
        overflow: hidden !important;
        box-shadow: none !important;
        background: #ffffff !important;
    }

    .watermark-container,
    #printArea.print-area .watermark-container {
        position: absolute !important;
        left: 0 !important;
        right: auto !important;
        top: 0 !important;
        bottom: auto !important;
        width: 8.5in !important;
        height: ${paperHeightIn}in !important;
        overflow: hidden !important;
        z-index: 1 !important;
        pointer-events: none !important;
    }`;

    /* ===================================================================
       MULTI-PAGE MODE (Print All) — long bond paper (8.5 x paperHeightIn),
       PERO kung mas mahaba pa sa isang sheet ang laman (maraming
       trimester), DUMADAGDAG na lang ito ng isa pang sheet (parehong
       laki) sa halip na putulin/i-clip ang laman. Ang letterhead
       (repeating table <thead>) at ang watermark (position: fixed, na
       inuulit sa bawat pahina sa print) ay lumalabas sa BAWAT dagdag na
       sheet, kaya pareho pa rin ang tingin kahit ilang pahina na.
       =================================================================== */
    const multiPageMarkup = `
<div class="print-area" id="printArea">
    <table class="grade-eval-page-table">
        <thead>
            <tr><td>${documentHeaderHtml}</td></tr>
        </thead>
        <tbody>
            <tr><td>
                ${watermarkHtml}
                ${mainContentHtml}
            </td></tr>
        </tbody>
    </table>
</div>`;

    const multiPageStyle = `
    @page { size: 8.5in ${paperHeightIn}in; margin: 0; }

    html, body {
        width: 8.5in;
        margin: 0;
        padding: 0;
        background: #ffffff;
        overflow: visible;
    }

    /* Sa print (Ctrl+P / physical printer), pinipilit ng GLOBAL na
       style.css (mismong Certificates print rule) na i-clip ang
       html/body sa eksaktong 11in kahit "!important" pa yun — kaya
       nawawala ang lagda/seal pag mahaba ang laman (maraming
       trimester). Hindi sapat ang pag-asa sa PAGKASUNOD-SUNOD ng
       stylesheets, kaya dito gumagamit tayo ng MAS SPECIFIC na
       class-based selector (".ascb-grade-eval-multipage") — mas
       mataas ang specificity nito kaysa sa plain na "html, body"
       kaya SIGURADONG mananalo ito sa cascade, kahit anong pagkasunod
       pa ang stylesheets. */
    @media print {
        html body.ascb-grade-eval-multipage,
        html body.ascb-grade-eval-multipage #printArea {
            height: auto !important;
            min-height: 0 !important;
            max-height: none !important;
            overflow: visible !important;
        }

        /* Parehong isyu gaya ng watermark sa ibaba: may GLOBAL na
           print rule (para sa Certificates) na naka-target din sa
           lahat ng "html, body" na may "padding-right: 14px !important"
           (para sa scrollbar allowance ng ibang doc type) — hindi ito
           kailangan (at sinisira ang alignment) dito sa Grade
           Evaluation, kaya tinatanggal ito gamit ang mas mataas na
           specificity na class-based selector. */
        html body.ascb-grade-eval-preview {
            padding-right: 0 !important;
        }
    }

    .print-area,
    #printArea.print-area {
        width: 8.5in !important;
        height: auto !important;
        min-height: 0 !important;
        max-height: none !important;
        margin: 0 !important;
        padding: 0 !important;
        overflow: visible !important;
        box-shadow: none !important;
        background: #ffffff !important;
    }

    .grade-eval-page-table {
        width: 100%;
        border-collapse: collapse;
    }

    .grade-eval-page-table > thead > tr > td,
    .grade-eval-page-table > tbody > tr > td {
        padding: 0;
    }

    /* Inuulit ng browser ang <thead> sa itaas ng BAWAT pahina —
       kaya lumalabas ang letterhead sa bawat karagdagang sheet. */
    .grade-eval-page-table thead {
        display: table-header-group;
    }

    /* Sa on-screen na preview at sa PDF download (html2canvas),
       "absolute" ito para tama ang pagka-center relative sa
       buong .print-area (na sumusukat ayon sa laman — "height:auto").
       "position:fixed" ay nagiging maling laki/posisyon sa
       html2canvas dahil relative ito sa viewport, hindi sa buong
       dokumento — kaya lumilihis sa gilid ang watermark pag PDF.
       Idinagdag ang "#printArea.print-area .watermark-container"
       bilang mas-specific na variant (ID + class) dahil may GLOBAL
       print rule (para sa Certificates) na naka-target din sa
       "#printArea .watermark-container" gamit ang "!important" —
       dahil may ID din ang selector na iyon, mas mataas ang
       specificity nito kaysa sa plain na ".watermark-container" sa
       ibaba, kaya nao-override/nagiging maling laki/posisyon ang
       watermark ng Grade Evaluation. Sa pagdagdag ng katumbas na
       mataas na specificity dito, palaging mananalo ang sariling
       setting ng Grade Evaluation. */
    .watermark-container,
    #printArea.print-area .watermark-container {
        position: absolute !important;
        left: 0 !important;
        right: auto !important;
        top: 0 !important;
        bottom: auto !important;
        width: 8.5in !important;
        height: ${paperHeightIn}in !important;
        overflow: hidden !important;
        z-index: 1 !important;
        pointer-events: none !important;
    }

    /* Sa Print All, ang fixed watermark ay isang buong sheet na
       inuulit ng browser sa bawat printed page. Ang logo ay naka-center
       sa buong 8.5 x 13in page, hindi sa content area o viewport. */
    @media print {
        body.ascb-grade-eval-multipage #printArea.print-area .watermark-container {
            position: fixed !important;
            left: 0 !important;
            right: auto !important;
            top: 0 !important;
            bottom: auto !important;
            width: 8.5in !important;
            height: ${paperHeightIn}in !important;
        }
    }

    .school-seal-warning,
    .transaction-notes {
        position: static !important;
        left: auto !important;
        bottom: auto !important;
        width: auto !important;
    }

    .school-seal-warning {
        margin: 0.35in 0 0 0.55in !important;
        text-align: left !important;
    }

    .school-seal-warning span {
        text-align: left !important;
    }

    /* ===============================================================
       LONG BOND PAPER ONLY — fixed bottom footer
       This block is inside multiPageStyle (Print All) only.
       SHORT / single-term print is intentionally left unchanged.
       Existing horizontal placement, typography and visual styling
       are preserved; only the vertical anchoring is changed.
       =============================================================== */
    /* LONG ONLY: the footer is anchored to the bottom of the long sheet.
       SHORT never reaches this block. Reserve enough space so the last
       grade rows cannot collide with the footer. */
    #printArea.print-area {
        position: relative !important;
        min-height: ${paperHeightIn}in !important;
    }

    #printArea.print-area .document-content {
        padding-bottom: 1.45in !important;
    }

    /* Signature: bottom-anchored but intentionally lifted above the
       absolute bottom so it sits visibly higher than the seal notice. */
    #printArea.print-area .signature-area.signature-area--grade-eval {
        position: absolute !important;
        right: 0.63in !important;
        bottom: 0.78in !important;
        left: auto !important;
        margin: 0 !important;
        padding-right: 0 !important;
        min-height: 0.90in !important;
        z-index: 10 !important;
    }

    /* School-seal warning stays closest to the physical bottom edge. */
    #printArea.print-area .school-seal-warning {
        position: absolute !important;
        left: 0.55in !important;
        right: auto !important;
        bottom: 0.24in !important;
        margin: 0 !important;
        padding: 0 !important;
        z-index: 10 !important;
        text-align: center !important;
    }

    #printArea.print-area .school-seal-warning span {
        text-align: center !important;
    }

    .transaction-notes {
        margin: 0.12in 0 0.3in 0.55in !important;
    }

    /* Huwag gawing indivisible ang buong trimester block. Kapag
       lumampas ang laman sa unang pahina, dapat ituloy ng browser
       ang content sa susunod na pahina sa halip na mag-overflow o
       mag-iwan ng puwang. Ang individual table at signature block
       lang ang pinananatiling magkakasama kung kaya. */
    .grade-eval-term-block,
    .document-content,
    .grade-eval-page-table > tbody,
    .grade-eval-page-table > tbody > tr,
    .grade-eval-page-table > tbody > tr > td {
        page-break-inside: auto !important;
        break-inside: auto !important;
    }

    .certificate-table,
    .signature-area {
        page-break-inside: avoid;
        break-inside: avoid;
    }

    /* SPACE SA PAGITAN NG "Course / Program" AT NG UNANG TERM
       ("1st Year — 1st Trimester — AY ..."), PATI NA RIN SA
       PAGITAN NG SUSUNOD PANG TERM BLOCKS — masyado kasi
       magkadikit dati dahil "margin-top: 0" ang default ng
       .summary-title (mula sa GLOBAL style.css, para sa ibang
       gamit nito). Dito lang ito pinapalakihan — hindi
       apektado ang Certificates o ibang module. */
    .grade-eval-term-block {
        margin-top: 0.28in;
    }

    /* Ang unang term block mismo ay hindi na kailangan ng
       extra top margin — ang student-details (Course/Program)
       sa itaas nito ang bibigyan ng bottom margin sa halip,
       para pantay ang laki ng puwang sa taas ng UNANG term
       kumpara sa mga susunod pa. */
    .grade-eval-term-block:first-of-type {
        margin-top: 0;
    }

    .student-details {
        margin-bottom: 0.28in !important;
    }

    .summary-title {
        page-break-after: avoid;
    }`;

    const sharedStyle = `

    body {
        font-family: "Poppins", Arial, sans-serif;
    }

    /* Direktang absolute + translate(-50%,-50%) ang paggamit dito
       para sa pag-center — mas reliable ito sa html2canvas (PDF
       download) kaysa sa flexbox na align-items/justify-content,
       na madalas hindi tama ang sukat/posisyon pag na-rasterize.
       Idinagdag ang "#printArea.print-area .document-watermark"
       bilang mas-specific na variant (ID + class) dahil may GLOBAL
       print rule (para sa Certificates) na naka-target din sa
       "#printArea .document-watermark" gamit ang "!important" na
       mas malaki (5.4in) at mas madilim (opacity 0.10) ang laki —
       dahil may ID din ang selector na iyon, mas mataas ang
       specificity nito kaysa sa plain na ".document-watermark" sa
       ibaba, kaya nao-override ang sarili nating laki/dilim ng
       watermark. Sa pagdagdag ng katumbas na mataas na specificity
       dito, palaging mananalo ang sariling setting ng Grade
       Evaluation. */
    .document-watermark,
    #printArea.print-area .document-watermark {
        position: absolute !important;
        left: 50% !important;
        top: 50% !important;
        width: ${ASCB_GRADE_EVAL_WATERMARK.sizeIn}in !important;
        height: ${ASCB_GRADE_EVAL_WATERMARK.sizeIn}in !important;
        max-width: ${ASCB_GRADE_EVAL_WATERMARK.sizeIn}in !important;
        max-height: ${ASCB_GRADE_EVAL_WATERMARK.sizeIn}in !important;
        transform: translate(-50%, -50%) !important;
        display: block !important;
        visibility: visible !important;
        object-fit: contain !important;
        opacity: ${ASCB_GRADE_EVAL_WATERMARK.opacity} !important;
        z-index: 1 !important;
        pointer-events: none !important;
    }

    .document-content {
        position: relative !important;
        z-index: 3 !important;
    }

    .document-header {
        position: relative !important;
        z-index: 5 !important;
    }

    .student-details,
    .certificate-title,
    .summary-title,
    .certificate-table,
    .signature-area {
        position: relative !important;
        z-index: 3 !important;
    }

    * {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }

    /* ===== toolbar ng preview (nawawala pag naka-print na) ===== */

    .preview-toolbar {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        padding: 12px;
        background: #eef5fa;
        border-bottom: 2px solid #17649a;
    }

    .preview-toolbar button {
        padding: 10px 20px;
        font-size: 13px;
        font-weight: 600;
        border: none;
        border-radius: 8px;
        background: #17649a;
        color: #fff;
        cursor: pointer;
    }

    .preview-toolbar button:hover {
        background: #123e67;
    }

    .preview-note {
        text-align: center;
        font-size: 11px;
        color: #667482;
        margin: 10px 0 0;
    }

    @media print {
        .preview-toolbar,
        .preview-note {
            display: none !important;
        }
    }`;

    const docHtml = `
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Grade Evaluation — ${escapeHTML(name)}</title>
${styles}
<style>
    /* ===== eksaktong parehong page setup ng printCertificate() ===== */
    ${multiPage ? multiPageStyle : singlePageStyle}
    ${sharedStyle}

    /* Grade Evaluation student information: match the Certificates layout.
       Keep the label / colon / value columns aligned and readable in print. */
    .document-content .student-details {
        display: block !important;
        width: 100% !important;
        box-sizing: border-box !important;
        margin: 0.12in 0 0.16in !important;
        padding: 0 !important;
        border: 0 !important;
        background: transparent !important;
        font-size: 10pt !important;
        line-height: 1.45 !important;
        color: #111 !important;
        position: relative !important;
        z-index: 3 !important;
    }
    .document-content .student-details .detail-row {
        display: grid !important;
        grid-template-columns: 1.65in 0.18in minmax(0, 1fr) !important;
        align-items: start !important;
        column-gap: 0.04in !important;
        width: 100% !important;
        margin: 0 !important;
        padding: 1.5pt 0 !important;
        break-inside: avoid !important;
        page-break-inside: avoid !important;
    }
    .document-content .student-details .detail-label {
        display: block !important;
        min-width: 0 !important;
        font-weight: 600 !important;
        white-space: normal !important;
    }
    .document-content .student-details .colon {
        display: block !important;
        text-align: center !important;
        font-weight: 600 !important;
    }
    .document-content .student-details .detail-value {
        display: block !important;
        min-width: 0 !important;
        font-weight: 400 !important;
        overflow-wrap: anywhere !important;
        white-space: normal !important;
    }
    .document-content .certificate-title {
        margin: 0.12in 0 0.10in !important;
        text-align: center !important;
        font-weight: 700 !important;
        letter-spacing: 0.04em !important;
    }
    .document-content .summary-title {
        margin: 0.08in 0 0.10in !important;
        line-height: 1.35 !important;
    }
    @media print {
        .document-content .student-details .detail-row { break-inside: avoid !important; page-break-inside: avoid !important; }
    }
    html, body { background: #ffffff; }
</style>
</head>
<body class="ascb-grade-eval-preview${multiPage ? " ascb-grade-eval-multipage" : ""}">

${multiPage ? multiPageMarkup : singlePageMarkup}

<script>
${multiPage ? `
/* Sigurado talagang hindi na ma-clip ang laman sa print (kahit
   ilang trimester/pages pa) — gumagamit ng INLINE style + "important"
   priority (via setProperty), na palaging mas matimbang kaysa sa
   anumang rule mula sa linked stylesheet (style.css), kasama na
   yung mga naunang "@media print" rule doon na nagpi-force ng
   11in / overflow:hidden sa html at body. */
function ascbForceNoClipForPrint() {
    [document.documentElement, document.body].forEach(function (el) {
        el.style.setProperty("height", "auto", "important");
        el.style.setProperty("min-height", "0", "important");
        el.style.setProperty("max-height", "none", "important");
        el.style.setProperty("overflow", "visible", "important");
    });
    var area = document.getElementById("printArea");
    if (area) {
        area.style.setProperty("height", "auto", "important");
        area.style.setProperty("min-height", "0", "important");
        area.style.setProperty("max-height", "none", "important");
        area.style.setProperty("overflow", "visible", "important");
    }
}
ascbForceNoClipForPrint();
window.addEventListener("beforeprint", ascbForceNoClipForPrint);
window.addEventListener("load", ascbForceNoClipForPrint);
` : ""}

/* =========================================================
   CTRL + P SA LOOB MISMO NG PREVIEW
   ---------------------------------------------------------
   Kapag na-click muna ng user ang preview bago pumindot ng
   Ctrl+P, ang keyboard focus ay nasa loob na ng <iframe> na
   ito — HINDI na umaabot sa main na dashboard page ang
   keydown event, kaya walang nakakasalo nito noon. Ang mas
   masama pa: ang default na Ctrl+P ng browser sa ganitong
   sitwasyon ay ang buong dashboard page ang pini-print
   (kung saan naka-clip sa 11in at nakatago ang laman), kaya
   blangko/mali ang lumalabas.

   Dito na natin sinasalo ang Ctrl+P at tinatawag ang
   window.print() ng iframe mismo — ang laman lang ng
   preview, kasama ang tamang @page size at print CSS nito,
   ang napupunta sa printer. Eksaktong-eksakto ito sa
   nakikita ng user sa preview.
========================================================= */
(function () {
    function ascbPrintThisPreview() {
        try { window.focus(); } catch (err) {}
        window.print();
    }

    /* Nagagamit ito ng parent page bilang fallback. */
    window.ascbPrintThisPreview = ascbPrintThisPreview;

    document.addEventListener("keydown", function (event) {
        var key = (event.key || "").toLowerCase();

        if (key !== "p") return;
        if (!(event.ctrlKey || event.metaKey)) return;
        if (event.altKey) return;

        /* Pigilan ang default na Ctrl+P ng browser (na maling
           page ang pini-print) bago tayo mag-print ng tama. */
        event.preventDefault();
        event.stopPropagation();

        ascbPrintThisPreview();
    }, true);
})();
<\/script>
</body>
</html>`;

    /* I-set ang title/subtitle ng toolbar bago ipakita ang modal. */
    if (titleEl) {
        titleEl.textContent = singleTerm
            ? "Grade Evaluation Preview (Selected Trimester)"
            : "Grade Evaluation Preview (All Trimester)";
    }
    if (subEl) {
        subEl.textContent = `${name}${studentId ? " — " + studentId : ""}`;
    }

    /* I-adjust ang taas ng iframe base sa aktwal na laman nito
       (para hindi nagdo-doble ang scrollbar — isa lang, yung sa
       .modal-print-scroll), tuwing ma-load ang bagong content. */
    frame.onload = function () {
        try {
            const frameDoc = frame.contentDocument || frame.contentWindow.document;
            const body = frameDoc.body;
            const html = frameDoc.documentElement;
            const h = Math.max(
                body ? body.scrollHeight : 0,
                body ? body.offsetHeight : 0,
                html ? html.scrollHeight : 0,
                html ? html.offsetHeight : 0
            );
            if (h > 0) frame.style.height = h + "px";
        } catch (e) {
            /* Hindi kritikal — mananatili na lang ang default na height. */
        }
        ascbGradeEvalFitPreview();
    };

    /* I-save ang buong docHtml na ito para magamit din ng totoong
       Print button (ascbGradeEvalPrintNow) sa pamamagitan ng
       window.open(), hindi lang sa loob ng preview iframe. */
    ascbGradeEvalCurrentPrintHtml = docHtml;

    frame.srcdoc = docHtml;

    modal.classList.add("active");
    ascbGradeEvalFitPreview();
}

/* =========================================================
   FIT PAPER PREVIEW TO ANY SCREEN
   Ang preview ay laging nire-render sa totoong lapad ng papel
   (8.5in = 816px) para eksaktong kapareho ng print — hindi na
   pinipiga ang iframe sa lapad ng phone (dating pumuputol sa
   kanan ang laman). Sa halip, i-s-scale ito pababa para magkasya
   sa lapad ng screen. Sa desktop na sapat ang lapad, scale = 1.
========================================================= */
function ascbGradeEvalFitPreview() {
    const frame = ascbGradeEvalEl("gradeEvalPrintFrame");
    if (!frame) return;
    const scroller = frame.closest(".modal-print-scroll");
    if (!scroller) return;

    const PAPER_W = 816; /* 8.5in @ 96dpi */
    const cs = window.getComputedStyle(scroller);
    const avail = scroller.clientWidth
        - (parseFloat(cs.paddingLeft) || 0)
        - (parseFloat(cs.paddingRight) || 0);
    if (!(avail > 0)) return;

    const scale = Math.max(0.2, Math.min(1, avail / PAPER_W));
    frame.style.setProperty("--ge-fit", String(scale));
    frame.style.setProperty("--ge-h", frame.offsetHeight + "px");
}

window.addEventListener("resize", function () {
    const m = document.getElementById("gradeEvalPrintPreviewModal");
    if (m && m.classList.contains("active")) ascbGradeEvalFitPreview();
});
window.addEventListener("orientationchange", function () {
    setTimeout(function () {
        const m = document.getElementById("gradeEvalPrintPreviewModal");
        if (m && m.classList.contains("active")) ascbGradeEvalFitPreview();
    }, 250);
});

/* =========================================================
   ISARA ANG GRADE EVALUATION PRINT PREVIEW MODAL
========================================================= */
function ascbGradeEvalClosePrintPreview() {
    const modal = ascbGradeEvalEl("gradeEvalPrintPreviewModal");
    if (modal) modal.classList.remove("active");

    ascbGradeEvalCurrentPrintHtml = "";

    const frame = ascbGradeEvalEl("gradeEvalPrintFrame");
    if (frame) {
        frame.onload = null;
        frame.srcdoc = "";
    }
}

/* =========================================================
   TOTOONG I-PRINT — pinipindot sa loob ng PREVIEW MODAL.
   Ipinapalabas nito ang aktwal na browser print dialog sa
   loob ng iframe (kung saan naka-set na ang wastong @page
   size at print CSS, eksaktong-eksakto sa nakita ng user
   sa preview).
========================================================= */
function ascbGradeEvalPrintNow() {
    if (!ascbGradeEvalCurrentPrintHtml) {
        alert("The preview isn't ready yet — please try again.");
        return;
    }

    /* Gamitin ang parehong pattern na ginagamit (at gumagana) ng
       Certificates print: buksan ang laman sa isang bagong window
       gamit ang window.open(), hintaying makumpleto ang pag-load
       ng mga larawan/font (setTimeout), saka lang tawagin ang
       print(). Mas maaasahan ito kaysa direktang pagtawag ng
       iframe.contentWindow.print() — na sa ilang browser ay
       pwedeng walang mangyari (lalo na kung hindi pa 100% tapos
       mag-load ang laman ng iframe, o naka-block ang printing
       ng frame content dahil sa timing). */
    const printWindow = window.open("", "_blank");

    if (!printWindow) {
        /* Naka-block ang popup — bumalik sa pag-print gamit ang
           preview iframe mismo bilang fallback, at balaan ang user. */
        const frame = ascbGradeEvalEl("gradeEvalPrintFrame");
        if (frame && frame.contentWindow) {
            frame.contentWindow.focus();
            frame.contentWindow.print();
        } else {
            alert("The browser blocked the print window. Please allow pop-ups for this site, then try again.");
        }
        return;
    }

    printWindow.document.open();
    printWindow.document.write(ascbGradeEvalCurrentPrintHtml);
    printWindow.document.close();
    printWindow.focus();

    setTimeout(() => {
        printWindow.print();
        setTimeout(() => {
            printWindow.close();
        }, 500);
    }, 400);
}


/* =========================================================
   CTRL + P — GLOBAL HANDLER
   ---------------------------------------------------------
   Dati, pag pinindot ang Ctrl+P habang bukas ang Grade
   Evaluation preview, ang pini-print ng browser ay ang
   BUONG dashboard page — hindi ang preview. At dahil ang
   global print CSS sa style.css ay nagkla-clip ng html/body
   sa 8.5 x 11in at nagtatago ng mga kontrol, ang lumalabas
   ay blangko o putol na papel. Mukhang "hindi nagpi-print".

   Sinasalo na natin dito ang Ctrl+P (at Cmd+P sa Mac).
   Kapag may bukas na preview modal, ipapasa natin ito sa
   parehong print routine na ginagamit ng "Print" button —
   kaya pareho na ang resulta kahit alin sa dalawa ang
   gamitin ng user. Kapag walang bukas na preview, hinahayaan
   lang natin ang normal na Ctrl+P ng browser.
========================================================= */
function ascbIsModalActive(id) {
    const modal = document.getElementById(id);
    return !!(modal && modal.classList.contains("active"));
}

document.addEventListener("keydown", function (event) {
    const key = (event.key || "").toLowerCase();

    if (key !== "p") return;
    if (!(event.ctrlKey || event.metaKey)) return;
    if (event.altKey) return;

    /* GRADE EVALUATION PREVIEW */
    if (ascbIsModalActive("gradeEvalPrintPreviewModal")) {
        event.preventDefault();

        if (ascbGradeEvalCurrentPrintHtml) {
            ascbGradeEvalPrintNow();
            return;
        }

        /* Hindi pa tapos mabuo ang HTML — i-print na lang
           direkta ang laman ng preview iframe. */
        const frame = ascbGradeEvalEl("gradeEvalPrintFrame");
        if (frame && frame.contentWindow) {
            frame.contentWindow.focus();
            frame.contentWindow.print();
        }
        return;
    }

    /* CERTIFICATE PREVIEW — parehong isyu, parehong ayos. */
    if (ascbIsModalActive("certificateModal")) {
        event.preventDefault();
        printCertificate();
        return;
    }

    /* FORM 137 PREVIEW */
    if (ascbIsModalActive("form137PreviewModal")) {
        event.preventDefault();
        printForm137();
    }
}, true);


function ascbGradeEvalPrintTerm() {
    const student = ascbGradeEvalStudents.find(s => s.key === ascbGradeEvalCurrentKey);
    const termSelect = ascbGradeEvalEl("gradeEvalTermSelect");

    if (!student || !ascbGradeEvalCurrentTerms.length) {
        alert("Please select a student first to view the Grade Evaluation PDF.");
        return;
    }

    const idx = termSelect ? Number(termSelect.value) : ascbGradeEvalCurrentTerms.length - 1;
    const termRow = ascbGradeEvalCurrentTerms[idx];
    if (!termRow) {
        alert("Please select the term to print first.");
        return;
    }

    // Ang major ay dapat lang mag-fallback sa "major" ng buong
    // estudyante (student.major) KAPAG ito talaga ang pinaka-
    // huling/kasalukuyang term niya — hindi dapat basta ipasok
    // ang kasalukuyang major sa MAS LUMANG term na wala pang
    // sariling major noon (hal. dati siyang ibang course pa
    // bago siya nagkaroon ng major sa 1st Trimester niya sa
    // kasalukuyang course) — dahil doon nagiging redundant/mali
    // ang lumalabas sa print.
    const isLatestTerm = idx === ascbGradeEvalCurrentTerms.length - 1;

    ascbGradeEvalOpenCertificateStylePreview({
        name: student.fullName,
        studentId: student.studentId,
        course: termRow.program_code || termRow.course || student.course,
        major: termRow.major || (isLatestTerm ? student.major : ""),
        singleTerm: true,
        terms: [termRow],
        showOverallSummary: false,
        paperHeightIn: 11, // Short bond paper (Letter) — kagaya ng Certificate
        multiPage: false,
    });
}

function ascbGradeEvalPrintAll() {
    const student = ascbGradeEvalStudents.find(s => s.key === ascbGradeEvalCurrentKey);

    if (!student || !ascbGradeEvalCurrentTerms.length) {
        alert("Please select a student first to view the Grade Evaluation PDF.");
        return;
    }

    let overallGradedUnits = 0;
    let overallWeightedSum = 0;
    let overallTotalUnits = 0;

    ascbGradeEvalCurrentTerms.forEach(termRow => {
        const subjects = Array.isArray(termRow.subjects) ? termRow.subjects : [];
        const { gwa, gradedUnits } = ascbGradeEvalTermGWA(subjects);
        subjects.forEach(s => { overallTotalUnits += ascbGradeEvalUnitsForDisplay(s); });
        if (gwa !== null) {
            overallWeightedSum += gwa * gradedUnits;
            overallGradedUnits += gradedUnits;
        }
    });

    const overallGwa = overallGradedUnits > 0 ? (overallWeightedSum / overallGradedUnits) : null;

    ascbGradeEvalOpenCertificateStylePreview({
        name: student.fullName,
        studentId: student.studentId,
        course: student.course,
        major: student.major,
        singleTerm: false,
        terms: ascbGradeEvalCurrentTerms,
        showOverallSummary: true,
        overallTotalUnits,
        overallGwa,
        paperHeightIn: 13, // Long bond paper — dadagdag ng sheet (parehong laki) kung kailangan
        multiPage: true,
    });
}



/* =========================================================
   APPROVED SO MODULE
   ---------------------------------------------------------
   Multi-PDF upload:
   - Walang fixed file-count limit.
   - Files are uploaded in small server-safe chunks.
   - The PDF filename is automatically used as the database name.
   - No browser PDF/OCR reading is performed.
   - Upload results are shown in a modal with total/success/failed.
   ========================================================= */
let ascbSoRows = [];
let ascbSoPage = 1;
let ascbSoTotal = 0, ascbSoTotalPages = 1;

function ascbSoEl(id) { return document.getElementById(id); }

function ascbUiDateTime(value) {
    if (!value) return "—";
    const raw = String(value).replace(" ", "T");
    const d = new Date(raw);
    return Number.isNaN(d.getTime())
        ? escapeHTML(value)
        : d.toLocaleString("en-PH", {
            year:"numeric", month:"short", day:"numeric",
            hour:"numeric", minute:"2-digit"
        });
}

async function ascbLoadApprovedSO(page = 1) {
    const status = ascbSoEl("soStatus"), wrap = ascbSoEl("soTableWrapper");
    const q = (ascbSoEl("soSearchInput")?.value || "").trim();

    if (status) { status.style.display = "block"; status.textContent = "Loading records…"; }
    if (wrap) wrap.style.display = "none";

    try {
        const qs = new URLSearchParams({
            page:String(page),
            limit:String(ASCB_PAGE_SIZE),
            q
        });
        const response = await fetch("api/approved_so.php?" + qs.toString());
        const data = await response.json();

        if (!response.ok || !data || !data.ok) {
            throw new Error(data?.error || "Unable to retrieve the records.");
        }

        ascbSoRows = Array.isArray(data.rows) ? data.rows : [];
        ascbSoPage = Number(data.page || page);
        ascbSoTotal = Number(data.total || 0);
        ascbSoTotalPages = Number(data.totalPages || 1);
        ascbSoRender();
    } catch (e) {
        if (status) status.textContent = e.message || "Unable to reach the server.";
    }
}

function ascbSoFilter() {
    ascbSoPage = 1;
    ascbLoadApprovedSO(1);
}

function ascbSoGoToPage(page) {
    ascbLoadApprovedSO(page);
}

function ascbSoRender() {
    const body = ascbSoEl("soTableBody");
    const status = ascbSoEl("soStatus");
    const wrap = ascbSoEl("soTableWrapper");

    if (!body || !status || !wrap) return;

    const rows = ascbSoRows;

    if (!rows.length) {
        body.innerHTML = `<tr><td colspan="5" class="records-empty">No Approved Special Order.</td></tr>`;
        status.style.display = "none";
        wrap.style.display = "block";
        ascbRenderPagination("soPagination", 1, 1, 0, ASCB_PAGE_SIZE, "ascbSoGoToPage");
        return;
    }

    body.innerHTML = rows.map(r => `
        <tr>
            <td data-label="Name">${escapeHTML(r.name || "—")}</td>
            <td data-label="File">
                <a class="docs-file-chip"
                   href="api/approved_so_file.php?id=${encodeURIComponent(r.id)}"
                   title="${escapeHTML(r.original_filename || 'View PDF')}"
                   target="_blank" rel="noopener">
                   📄 ${escapeHTML(r.original_filename || "View PDF")}
                </a>
            </td>
            <td data-label="Uploaded By">${escapeHTML(r.uploaded_by_name || "—")}</td>
            <td data-label="Date">${ascbUiDateTime(r.created_at)}</td>
            <td data-label="Actions">
                <button type="button" class="btn btn-outline btn-sm action-icon-btn"
                        title="Edit" aria-label="Edit"
                        onclick="ascbSoOpenEdit(${Number(r.id)})">${ascbIcon('edit')}</button>
                <button type="button" class="btn btn-danger btn-sm action-icon-btn"
                        title="Delete" aria-label="Delete"
                        onclick="ascbSoDelete(${Number(r.id)})">${ascbIcon('delete')}</button>
            </td>
        </tr>`).join("");

    status.style.display = "none";
    wrap.style.display = "block";
    ascbRenderPagination(
        "soPagination",
        ascbSoPage,
        ascbSoTotalPages,
        ascbSoTotal,
        ASCB_PAGE_SIZE,
        "ascbSoGoToPage"
    );
}

function ascbSoPreparePreview() {
    const input = ascbSoEl("so_file");
    const files = input && input.files ? Array.from(input.files) : [];
    const preview = ascbSoEl("soBatchPreview");

    if (!preview) return;

    if (!files.length) {
        preview.style.display = "none";
        preview.innerHTML = "";
        return;
    }

    preview.style.display = "block";
    preview.innerHTML = `
        <div class="so-batch-summary">
            <strong>${files.length}</strong> PDF file(s) selected.
            The PDF filename will automatically be saved as the Approved SO name.
        </div>
        ${files.map((f, i) => `
            <div class="so-batch-row" id="soBatchRow${i}">
                <span class="so-batch-file" title="${escapeHTML(f.name)}">
                    📄 ${escapeHTML(f.name)}
                </span>
                <span class="so-batch-state">Ready to upload</span>
            </div>
        `).join("")}
    `;
}

function ascbSoOpenResultModal(total, saved, failed, errors = []) {
    const modal = ascbSoEl("soResultModal");
    if (!modal) return;

    const title = ascbSoEl("soResultTitle");
    const message = ascbSoEl("soResultMessage");
    const icon = ascbSoEl("soResultIcon");
    const totalEl = ascbSoEl("soResultTotal");
    const savedEl = ascbSoEl("soResultSaved");
    const failedEl = ascbSoEl("soResultFailed");
    const errorsEl = ascbSoEl("soResultErrors");

    if (totalEl) totalEl.textContent = String(total);
    if (savedEl) savedEl.textContent = String(saved);
    if (failedEl) failedEl.textContent = String(failed);

    if (failed > 0) {
        if (icon) icon.textContent = "!";
        if (title) title.textContent = "Upload Completed with Errors";
        if (message) {
            message.textContent =
                `${saved} of ${total} PDF file(s) were uploaded successfully. ` +
                `${failed} file(s) failed.`;
        }
        if (errorsEl) {
            errorsEl.style.display = "block";
            errorsEl.innerHTML = `
                <strong>Files with errors:</strong>
                <ul>${errors.map(e => `<li>${escapeHTML(e)}</li>`).join("")}</ul>
            `;
        }
    } else {
        if (icon) icon.textContent = "✓";
        if (title) title.textContent = "Upload Successful";
        if (message) {
            message.textContent =
                `Successfully uploaded all ${total} Approved SO PDF file(s). ` +
                `The PDF filename was automatically saved as the Approved SO name.`;
        }
        if (errorsEl) {
            errorsEl.style.display = "none";
            errorsEl.innerHTML = "";
        }
    }

    modal.classList.add("active");
    modal.setAttribute("aria-hidden", "false");
}

function ascbSoCloseResultModal() {
    const modal = ascbSoEl("soResultModal");
    if (!modal) return;
    modal.classList.remove("active");
    modal.setAttribute("aria-hidden", "true");
}

async function ascbSoSubmit() {
    const input = ascbSoEl("so_file");
    const files = input && input.files ? Array.from(input.files) : [];
    const status = ascbSoEl("soFormStatus");
    const preview = ascbSoEl("soBatchPreview");

    if (!files.length) {
        ascbSoOpenResultModal(0, 0, 0, ["Please select at least one PDF file."]);
        return;
    }

    const invalid = files
        .map((f, i) => ({f, i}))
        .filter(x => !x.f.name.toLowerCase().endsWith(".pdf"));

    if (invalid.length) {
        ascbSoOpenResultModal(
            files.length,
            0,
            invalid.length,
            invalid.map(x => `${x.f.name}: PDF files only.`)
        );
        return;
    }

    if (status) {
        status.style.display = "block";
        status.textContent = `Uploading ${files.length} PDF file(s)…`;
    }

    if (preview && preview.querySelectorAll(".so-batch-row").length !== files.length) {
        ascbSoPreparePreview();
    }

    let saved = 0;
    let failed = 0;
    const errors = [];

    /*
     * No fixed application-level limit.
     * Send only 10 files per request so the system does not depend on
     * PHP's max_file_uploads for the total number selected.
     */
    const chunkSize = 10;

    try {
        for (let offset = 0; offset < files.length; offset += chunkSize) {
            const chunk = files.slice(offset, offset + chunkSize);
            const fd = new FormData();

            fd.append("action", "batch_create");

            chunk.forEach((file, localIndex) => {
                const absoluteIndex = offset + localIndex;

                fd.append("files[]", file);
                fd.append("file_indexes[]", String(absoluteIndex));
            });

            const res = await fetch("api/approved_so.php", {
                method: "POST",
                body: fd
            });

            let data = null;
            try {
                data = await res.json();
            } catch (jsonError) {
                throw new Error(
                    "Hindi mabasa ang server response. " +
                    "I-check ang PHP/server upload limits."
                );
            }

            if (!res.ok || !data || !data.ok) {
                throw new Error(data?.error || "Unable to process the PDF batch.");
            }

            (data.results || []).forEach(item => {
                const index = Number(item.index);
                const state = ascbSoEl("soBatchRow" + index)?.querySelector(".so-batch-state");

                if (item.saved) {
                    saved++;
                    if (state) {
                        state.textContent = "✓ Uploaded";
                        state.className = "so-batch-state is-ok";
                    }
                } else {
                    failed++;
                    const errorText = `${item.filename || "Unknown file"}: ${item.error || "Not saved"}`;
                    errors.push(errorText);

                    if (state) {
                        state.textContent = item.duplicate ? "⚠ Duplicate file name" : "⚠ Failed";
                        state.className = "so-batch-state is-error";
                    }
                }
            });

            const processed = Math.min(offset + chunk.length, files.length);
            if (status) {
                status.textContent = `Uploaded ${processed} of ${files.length} PDF file(s)…`;
            }
        }

        if (status) status.style.display = "none";

        input.value = "";
        if (preview) {
            preview.style.display = "none";
            preview.innerHTML = "";
        }

        ascbSoOpenResultModal(files.length, saved, failed, errors);
        await ascbLoadApprovedSO();
    } catch (e) {
        if (status) status.style.display = "none";

        /*
         * Show a modal instead of alert/status-only messaging.
         * If some files already succeeded, include that count.
         */
        const remaining = files.length - saved - failed;
        const allErrors = errors.slice();

        if (remaining > 0) {
            allErrors.push(
                `${remaining} file(s) were not processed because the upload request stopped.`
            );
        }

        ascbSoOpenResultModal(
            files.length,
            saved,
            failed + remaining,
            allErrors.length ? allErrors : [e.message || "Unable to reach the server."]
        );

        if (saved > 0) {
            await ascbLoadApprovedSO();
        }
    }
}

function ascbSoOpenEdit(id) {
    const r = ascbSoRows.find(x => Number(x.id) === Number(id));
    if (!r) return;

    ascbSoEl("so_edit_id").value = r.id;
    ascbSoEl("so_edit_name").value = r.name || "";
    ascbSoEl("so_edit_file").value = "";

    const st = ascbSoEl("soEditStatus");
    if (st) st.style.display = "none";

    ascbSoEl("soEditModal").classList.add("active");
}

function ascbSoCloseEdit() {
    const m = ascbSoEl("soEditModal");
    if (m) m.classList.remove("active");
}

async function ascbSoSubmitEdit() {
    const id = ascbSoEl("so_edit_id")?.value;
    const name = (ascbSoEl("so_edit_name")?.value || "").trim();
    const input = ascbSoEl("so_edit_file");
    const file = input?.files?.[0] || null;
    const st = ascbSoEl("soEditStatus");

    if (!id || !name) {
        alert("Name is required.");
        return;
    }

    if (file && !file.name.toLowerCase().endsWith(".pdf")) {
        alert("Only PDF files are accepted.");
        return;
    }

    const fd = new FormData();
    fd.append("action", "update");
    fd.append("id", id);
    fd.append("name", name);
    if (file) fd.append("file", file);

    if (st) {
        st.style.display = "block";
        st.textContent = "Saving…";
    }

    try {
        const res = await fetch("api/approved_so.php", {
            method: "POST",
            body: fd
        });
        const data = await res.json();

        if (!res.ok || !data.ok) {
            throw new Error(data.error || "Unable to save.");
        }

        ascbSoCloseEdit();
        await ascbLoadApprovedSO();
    } catch (e) {
        if (st) st.textContent = e.message || "Unable to reach the server.";
    }
}

async function ascbSoDelete(id) {
    if (!(await ascbConfirm("Delete this Approved SO entry and its PDF file?", { danger: true }))) {
        return;
    }

    const fd = new FormData();
    fd.append("action", "delete");
    fd.append("id", id);

    try {
        const res = await fetch("api/approved_so.php", {
            method: "POST",
            body: fd
        });
        const data = await res.json();

        if (!res.ok || !data.ok) {
            throw new Error(data.error || "Unable to delete.");
        }

        await ascbLoadApprovedSO();
    } catch (e) {
        alert(e.message || "Unable to delete.");
    }
}

/* =========================================================
   ADMIN MODULE
   ========================================================= */
let ascbUsersRows=[],ascbUsersPage=1,ascbAdmSchoolsRows=[],ascbAdmSchoolsPage=1,ascbAdmCoursesRows=[],ascbAdmCoursesPage=1,ascbLogRows=[],ascbLogPage=1;
let ascbAdmProgsRows=[],ascbAdmProgsPage=1,ascbAdmProgSubjRows=[],ascbAdmProgSubjCurrentProgram=null;
let ascbDepartmentsRows=[];
function ascbAdminEl(id){return document.getElementById(id);}
function ascbAdminShowPanels(ids){document.querySelectorAll('.admin-tab-panel').forEach(el=>el.style.display='none');ids.forEach(id=>{const el=ascbAdminEl(id);if(el)el.style.display='block';});}
function ascbAdminOpen(){ascbAdminSwitchTab('account');ascbLoadDepartments(true);
    const usersTab=ascbAdminEl('adminTabUsers'),logTab=ascbAdminEl('adminTabLog'),lookupsTab=ascbAdminEl('adminTabLookups');
    if(lookupsTab) lookupsTab.style.display=(ASCB_PERMISSIONS&&ASCB_PERMISSIONS.manageLookups)?'':'none';
    if(usersTab) usersTab.style.display=(ASCB_PERMISSIONS&&ASCB_PERMISSIONS.manageUsers)?'':'none';
    if(logTab) logTab.style.display=(ASCB_PERMISSIONS&&ASCB_PERMISSIONS.viewActivityLog)?'':'none';
}
function ascbAdminSwitchTab(tab){
    ['Account','Appearance','Users','Lookups','Departments','Programs','Log'].forEach(k=>{const b=ascbAdminEl('adminTab'+k);if(b)b.classList.remove('active');});
    if(tab==='appearance'){
        ascbAdminEl('adminTabAppearance')?.classList.add('active');ascbAdminShowPanels(['adminPanelAppearance']);ascbSyncThemeControls(ascbGetTheme()==='dark');return;
    }
    if(tab==='users'){
        if(!(ASCB_PERMISSIONS&&ASCB_PERMISSIONS.manageUsers)){ascbAdminShowPanels(['adminPanelNoAccess']);return;}
        ascbAdminEl('adminTabUsers')?.classList.add('active');ascbAdminShowPanels(['adminPanelUsers','adminPanelUsersList']);ascbLoadUsers();return;
    }
    if(tab==='lookups'){if(!(ASCB_PERMISSIONS&&ASCB_PERMISSIONS.manageLookups)){ascbAdminShowPanels(['adminPanelNoAccess']);return;}ascbAdminEl('adminTabLookups')?.classList.add('active');ascbAdminShowPanels(['adminPanelLookups','adminPanelLookupsCourses']);ascbAdminLoadSchools();ascbAdminLoadCourses();return;}
    if(tab==='departments'){if(!(ASCB_PERMISSIONS&&ASCB_PERMISSIONS.viewDepartmentsTab)){ascbAdminShowPanels(['adminPanelNoAccess']);return;}ascbAdminEl('adminTabDepartments')?.classList.add('active');ascbAdminShowPanels(['adminPanelDepartments']);ascbLoadDepartments();if(typeof ascbBackupScheduleLoad==='function')ascbBackupScheduleLoad();return;}
    if(tab==='programs'){ascbAdminEl('adminTabPrograms')?.classList.add('active');ascbAdminShowPanels(['adminPanelPrograms']);ascbAdminLoadPrograms();return;}
    if(tab==='log'){
        if(!(ASCB_PERMISSIONS&&ASCB_PERMISSIONS.viewActivityLog)){ascbAdminShowPanels(['adminPanelNoAccess']);return;}
        ascbAdminEl('adminTabLog')?.classList.add('active');ascbAdminShowPanels(['adminPanelLog']);ascbLoadActivityLog();return;
    }
    ascbAdminEl('adminTabAccount')?.classList.add('active');ascbAdminShowPanels(['adminPanelAccount']);
}
async function ascbChangeOwnPassword(){
    const cur=ascbAdminEl('acct_currentPassword')?.value||'',nw=ascbAdminEl('acct_newPassword')?.value||'',cf=ascbAdminEl('acct_confirmPassword')?.value||'',st=ascbAdminEl('acctStatus');
    if(!cur||!nw||!cf){alert('Please complete the password fields.');return;}if(nw.length<8){alert('The new password must be at least 8 characters.');return;}if(nw!==cf){alert('New Password and Confirm Password do not match.');return;}
    if(st){st.style.display='block';st.textContent='Saving…';}const data=await ascbApiPost('api/users.php',{action:'change_password',currentPassword:cur,newPassword:nw});if(!data.ok){if(st)st.textContent=data.error||'Unable to change the password.';return;}['acct_currentPassword','acct_newPassword','acct_confirmPassword'].forEach(id=>{const e=ascbAdminEl(id);if(e)e.value='';});if(st)st.textContent='Password successfully changed.';
}
function ascbOpenStaffAssignment(userId){
    const modal=document.getElementById('staffAssignmentModal'),frame=document.getElementById('staffAssignmentFrame');
    if(!modal||!frame)return;
    const row=(typeof ascbUsersRows!=='undefined'&&Array.isArray(ascbUsersRows))?ascbUsersRows.find(x=>Number(x.id)===Number(userId)):null;
    const sub=modal.querySelector('.staff-assignment-modal-subtitle');
    if(sub&&row&&row.display_name)sub.textContent='Piliin ang departments at courses na puwedeng ma-access ni '+row.display_name+'.';
    const theme=document.documentElement.getAttribute('data-theme')==='dark'?'dark':'light';
    modal.classList.add('loading');
    frame.onload=function(){modal.classList.remove('loading');};
    frame.src='staff_assignments?staff='+encodeURIComponent(Number(userId))+'&modal=1&theme='+theme;
    modal.classList.add('active');modal.setAttribute('aria-hidden','false');document.body.classList.add('modal-open');
}
function ascbCloseStaffAssignment(){
    const modal=document.getElementById('staffAssignmentModal'),frame=document.getElementById('staffAssignmentFrame');
    if(modal){modal.classList.remove('active','loading');modal.setAttribute('aria-hidden','true');}
    if(frame){frame.onload=null;frame.src='about:blank';}
    document.body.classList.remove('modal-open');
}
/* Success / Error result modal para sa Staff Assignment — may OK button,
   hindi auto-dismiss, at laging nasa ibabaw ng Assign modal. */
function ascbShowAssignResult(opts){
    opts=opts||{};
    const ok=!!opts.ok;
    let ov=document.getElementById('staffAssignResultModal');
    if(!ov){
        ov=document.createElement('div');
        ov.id='staffAssignResultModal';
        ov.className='sa-result-overlay';
        ov.setAttribute('role','alertdialog');
        ov.setAttribute('aria-modal','true');
        ov.innerHTML='<div class="sa-result-card"><div class="sa-result-icon" id="saResultIcon"></div><h4 class="sa-result-title" id="saResultTitle"></h4><p class="sa-result-message" id="saResultMessage"></p><div class="sa-result-actions"><button type="button" class="btn btn-primary" id="saResultOk">OK</button></div></div>';
        document.body.appendChild(ov);
    }
    ov.setAttribute('data-type',ok?'success':'error');
    document.getElementById('saResultIcon').innerHTML=ok
        ?'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>'
        :'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6L6 18"/><path d="M6 6l12 12"/></svg>';
    document.getElementById('saResultTitle').textContent=opts.title||(ok?'Assignments Saved':'Unable to Save');
    document.getElementById('saResultMessage').textContent=opts.message||(ok?'Matagumpay na na-save ang assignments.':'Nagka-problema. Subukan muli.');
    const okBtn=document.getElementById('saResultOk');
    okBtn.textContent=ok?'OK':'Try Again';
    const close=function(){
        ov.classList.remove('active');
        document.removeEventListener('keydown',onKey,true);
        if(ok){ascbCloseStaffAssignment();if(typeof ascbLoadUsers==='function')ascbLoadUsers();}
    };
    const onKey=function(e){if(e.key==='Escape'||e.key==='Enter'){e.preventDefault();e.stopPropagation();close();}};
    okBtn.onclick=close;
    ov.onclick=function(e){if(e.target===ov)close();};
    document.addEventListener('keydown',onKey,true);
    ov.classList.add('active');
    setTimeout(function(){okBtn.focus();},30);
}
window.addEventListener('message',function(event){
    if(event.origin!==window.location.origin||!event.data)return;
    const t=event.data.type;
    if(t==='ascb-staff-assignments-cancel'){ascbCloseStaffAssignment();return;}
    if(t==='ascb-staff-assignments-result'){ascbShowAssignResult({ok:!!event.data.ok,title:event.data.title,message:event.data.message});return;}
    if(t==='ascb-staff-assignments-saved'){ascbShowAssignResult({ok:true});return;}
});
async function ascbLoadUsers(){const st=ascbAdminEl('usersStatus'),wrap=ascbAdminEl('usersTableWrapper');if(st){st.style.display='block';st.textContent='Loading accounts…';}if(wrap)wrap.style.display='none';const data=await ascbApiPost('api/users.php',{action:'list'});if(!data.ok){if(st)st.textContent=data.error||'Unable to load the accounts.';return;}ascbUsersRows=Array.isArray(data.users)?data.users:[];ascbUsersPage=1;ascbUsersRender();}
function ascbUsersFiltered(){const q=(ascbAdminEl('userSearchInput')?.value||'').trim().toLowerCase();if(!q)return ascbUsersRows;return ascbUsersRows.filter(r=>[r.display_name,r.role,r.prepared_by_code,r.username,r.student_id].some(v=>String(v||'').toLowerCase().includes(q)));}
function ascbUsersFilter(){ascbUsersPage=1;ascbUsersRender();}function ascbUsersGoToPage(p){ascbUsersPage=p;ascbUsersRender();}
function ascbUsersRender(){const body=ascbAdminEl('usersTableBody'),st=ascbAdminEl('usersStatus'),wrap=ascbAdminEl('usersTableWrapper');if(!body||!st||!wrap)return;const rows=ascbUsersFiltered();if(!rows.length){body.innerHTML='<tr><td colspan="8" class="records-empty">Walang account.</td></tr>';st.style.display='none';wrap.style.display='block';ascbRenderPagination('usersPagination',1,1,0,ASCB_PAGE_SIZE,'ascbUsersGoToPage');return;}const p=ascbPaginate(rows,ascbUsersPage,ASCB_PAGE_SIZE);ascbUsersPage=p.page;body.innerHTML=p.pageRows.map(r=>{const active=Number(r.is_active);const toggleLabel=active?'Deactivate':'Activate';return `<tr><td>${escapeHTML(r.display_name||'—')}</td><td>${escapeHTML(r.role||'—')}</td><td>${escapeHTML(r.department_name||'—')}</td><td>${escapeHTML(r.student_id||'—')}</td><td>${escapeHTML(r.prepared_by_code||'—')}</td><td>${active?'Active':'Inactive'}</td><td>${ascbUiDateTime(r.created_at)}</td><td><button type="button" class="btn btn-outline btn-sm action-icon-btn" title="Edit" aria-label="Edit" onclick="ascbUserOpenEdit(${Number(r.id)})">${ascbIcon('edit')}</button> ${(r.role==='ADMIN STAFF'||r.role==='DEAN')?`<button type="button" class="btn btn-outline btn-sm staff-assign-btn" title="Department / Program Assignments" aria-label="Department / Program Assignments" onclick="ascbOpenStaffAssignment(${Number(r.id)})">${ascbIcon('assign')}<span>Assign</span></button> `:''}${r.role==='STUDENT'&&r.student_id?`<button type="button" class="btn btn-outline btn-sm action-icon-btn" title="Issue / reset temporary password" aria-label="Issue temporary password" onclick="ascbIssueStudentAccount(${ascbJsAttr(String(r.student_id))}, ${ascbJsAttr(String(r.display_name||''))})">${ascbIcon('key')}</button> `:''}<button type="button" class="btn btn-outline btn-sm action-icon-btn" title="${toggleLabel}" aria-label="${toggleLabel}" onclick="ascbUserToggle(${Number(r.id)})">${ascbIcon(active?'deactivate':'activate')}</button> <button type="button" class="btn btn-danger btn-sm action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbUserDelete(${Number(r.id)})">${ascbIcon('delete')}</button></td></tr>`;}).join('');st.style.display='none';wrap.style.display='block';ascbRenderPagination('usersPagination',p.page,p.totalPages,p.total,ASCB_PAGE_SIZE,'ascbUsersGoToPage');}
async function ascbUserAdd(){const displayName=(ascbAdminEl('user_displayName')?.value||'').trim(),role=ascbAdminEl('user_role')?.value||'',departmentId=Number(ascbAdminEl('user_departmentId')?.value||0),preparedByCode=(ascbAdminEl('user_preparedByCode')?.value||'').trim(),username=(ascbAdminEl('user_username')?.value||'').trim(),password=ascbAdminEl('user_password')?.value||'',studentId=(ascbAdminEl('user_studentId')?.value||'').trim(),st=ascbAdminEl('userFormStatus');if(!username||!displayName||!password){alert('Username, Full Name, and Password are required.');return;}if(role==='STUDENT'&&!studentId){alert('Student ID is required for a STUDENT account.');return;}if(password.length<8){alert('Password must be at least 8 characters.');return;}if(st){st.style.display='block';st.textContent='Saving…';}const data=await ascbApiPost('api/users.php',{action:'add',displayName,role,departmentId,studentId:role==='STUDENT'?studentId:'',preparedByCode,username,password});if(!data.ok){if(st)st.textContent=data.error||'Unable to save.';return;}['user_displayName','user_preparedByCode','user_password','user_studentId'].forEach(id=>{const e=ascbAdminEl(id);if(e)e.value='';});if(st)st.textContent='Account added.';await ascbLoadUsers();}
function ascbUserOpenEdit(id){const r=ascbUsersRows.find(x=>Number(x.id)===Number(id));if(!r)return;ascbAdminEl('user_edit_id').value=r.id;ascbAdminEl('user_edit_displayName').value=r.display_name||'';ascbAdminEl('user_edit_role').value=r.role||'ADMIN STAFF';ascbAdminEl('user_edit_departmentId').value=r.department_id||'';ascbAdminEl('user_edit_preparedByCode').value=r.prepared_by_code||'';ascbAdminEl('user_edit_username').value=r.username||'';ascbAdminEl('user_edit_studentId').value=r.student_id||'';ascbUserToggleStudentField('user_edit_role','user_edit_studentIdField');ascbAdminEl('user_edit_password').value='';const st=ascbAdminEl('userEditStatus');if(st)st.style.display='none';ascbAdminEl('userEditModal').classList.add('active');}
function ascbUserCloseEdit(){ascbAdminEl('userEditModal')?.classList.remove('active');}
function ascbUserToggleStudentField(roleSelId,fieldId){const rs=ascbAdminEl(roleSelId),f=ascbAdminEl(fieldId);if(f)f.style.display=(rs&&rs.value==='STUDENT')?'':'none';}
async function ascbUserSubmitEdit(){const id=Number(ascbAdminEl('user_edit_id')?.value||0),displayName=(ascbAdminEl('user_edit_displayName')?.value||'').trim(),role=ascbAdminEl('user_edit_role')?.value||'',departmentId=Number(ascbAdminEl('user_edit_departmentId')?.value||0),preparedByCode=(ascbAdminEl('user_edit_preparedByCode')?.value||'').trim(),username=(ascbAdminEl('user_edit_username')?.value||'').trim(),password=ascbAdminEl('user_edit_password')?.value||'',studentId=(ascbAdminEl('user_edit_studentId')?.value||'').trim(),st=ascbAdminEl('userEditStatus');if(!id||!displayName){alert('Full Name is required.');return;}if(role==='STUDENT'&&!studentId){alert('Student ID is required for a STUDENT account.');return;}if(password&&password.length<8){alert('New password must be at least 8 characters.');return;}if(st){st.style.display='block';st.textContent='Saving…';}const data=await ascbApiPost('api/users.php',{action:'update',id,displayName,role,departmentId,studentId:role==='STUDENT'?studentId:'',preparedByCode,username,password});if(!data.ok){if(st)st.textContent=data.error||'Unable to save.';return;}ascbUserCloseEdit();await ascbLoadUsers();}
async function ascbUserToggle(id){const r=ascbUsersRows.find(x=>Number(x.id)===Number(id));if(!r)return;if(!(await ascbConfirm(`${Number(r.is_active)?'Deactivate':'Activate'} the account of ${r.display_name}?`)))return;const data=await ascbApiPost('api/users.php',{action:'toggle_active',id});if(!data.ok){alert(data.error||'Unable to change the status.');return;}await ascbLoadUsers();}
async function ascbUserDelete(id){const r=ascbUsersRows.find(x=>Number(x.id)===Number(id));if(!r||!(await ascbConfirm(`Permanently delete the account of ${r.display_name}?`,{danger:true})))return;const data=await ascbApiPost('api/users.php',{action:'delete',id});if(!data.ok){alert(data.error||'Unable to delete.');return;}await ascbLoadUsers();}

async function ascbAdminLoadSchools(){const st=ascbAdminEl('admSchoolsStatus'),wrap=ascbAdminEl('admSchoolsTableWrapper');if(st){st.style.display='block';st.textContent='Loading…';}const data=await ascbApiPost('api/schools.php',{action:'list'});if(!data.ok){if(st)st.textContent=data.error||'Unable to load the schools.';return;}ascbAdmSchoolsRows=Array.isArray(data.schools)?data.schools:[];ascbAdmSchoolsPage=1;ascbAdminSchoolsRender();}
function ascbAdminSchoolsFiltered(){const q=(ascbAdminEl('admSchoolSearchInput')?.value||'').trim().toLowerCase();return q?ascbAdmSchoolsRows.filter(r=>[r.name,r.address].some(v=>String(v||'').toLowerCase().includes(q))):ascbAdmSchoolsRows;}
function ascbAdminSchoolsFilter(){ascbAdmSchoolsPage=1;ascbAdminSchoolsRender();}function ascbAdminSchoolsGoToPage(p){ascbAdmSchoolsPage=p;ascbAdminSchoolsRender();}
function ascbAdminSchoolsRender(){const b=ascbAdminEl('admSchoolsTableBody'),st=ascbAdminEl('admSchoolsStatus'),w=ascbAdminEl('admSchoolsTableWrapper');if(!b||!st||!w)return;const rows=ascbAdminSchoolsFiltered(),p=ascbPaginate(rows,ascbAdmSchoolsPage,ASCB_PAGE_SIZE);ascbAdmSchoolsPage=p.page;b.innerHTML=rows.length?p.pageRows.map(r=>`<tr><td>${escapeHTML(r.name||'—')}</td><td>${escapeHTML(r.address||'—')}</td><td>${ASCB_PERMISSIONS&&ASCB_PERMISSIONS.manageLookups?`<button type="button" class="btn btn-danger btn-sm action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbAdminDeleteSchoolById(${Number(r.id)})">${ascbIcon('delete')}</button>`:'—'}</td></tr>`).join(''):'<tr><td colspan="3" class="records-empty">Walang school.</td></tr>';st.style.display='none';w.style.display='block';ascbRenderPagination('admSchoolsPagination',p.page,p.totalPages,p.total,ASCB_PAGE_SIZE,'ascbAdminSchoolsGoToPage');}
async function ascbAdminAddSchool(){const name=(ascbAdminEl('admLookup_schoolName')?.value||'').trim(),address=(ascbAdminEl('admLookup_schoolAddress')?.value||'').trim(),st=ascbAdminEl('admSchoolFormStatus');if(!name){alert('Enter the school name.');return;}if(st){st.style.display='block';st.textContent='Saving…';}const data=await ascbApiPost('api/schools.php',{action:'add',name,address});if(!data.ok){if(st)st.textContent=data.error||'Unable to save.';return;}ascbAdminEl('admLookup_schoolName').value='';ascbAdminEl('admLookup_schoolAddress').value='';ascbSchoolsCache.push({name,address});f137LoadSchools();if(st)st.textContent='School added.';await ascbAdminLoadSchools();}
function ascbAdminDeleteSchoolById(id){const r=ascbAdmSchoolsRows.find(x=>Number(x.id)===Number(id));if(r)ascbAdminDeleteSchool(r.name);}
async function ascbAdminDeleteSchool(name){if(!(await ascbConfirm(`Delete school: ${name}?`,{danger:true})))return;const data=await ascbApiPost('api/schools.php',{action:'delete',name});if(!data.ok){alert(data.error||'Unable to delete.');return;}ascbSchoolsCache=ascbSchoolsCache.filter(s=>s.name!==name);f137LoadSchools();await ascbAdminLoadSchools();}

async function ascbAdminLoadCourses(){const st=ascbAdminEl('admCoursesStatus');const data=await ascbApiPost('api/courses.php',{action:'list'});if(!data.ok){if(st)st.textContent=data.error||'Unable to load the courses.';return;}ascbAdmCoursesRows=Array.isArray(data.courses)?data.courses:[];ascbAdmCoursesPage=1;ascbAdminCoursesRender();}
function ascbAdminCoursesFiltered(){const q=(ascbAdminEl('admCourseSearchInput')?.value||'').trim().toLowerCase();return q?ascbAdmCoursesRows.filter(r=>String(r.name||'').toLowerCase().includes(q)):ascbAdmCoursesRows;}
function ascbAdminCoursesFilter(){ascbAdmCoursesPage=1;ascbAdminCoursesRender();}function ascbAdminCoursesGoToPage(p){ascbAdmCoursesPage=p;ascbAdminCoursesRender();}
function ascbAdminCoursesRender(){const b=ascbAdminEl('admCoursesTableBody'),st=ascbAdminEl('admCoursesStatus'),w=ascbAdminEl('admCoursesTableWrapper');if(!b||!st||!w)return;const rows=ascbAdminCoursesFiltered(),p=ascbPaginate(rows,ascbAdmCoursesPage,ASCB_PAGE_SIZE);ascbAdmCoursesPage=p.page;b.innerHTML=rows.length?p.pageRows.map(r=>`<tr><td>${escapeHTML(r.name||'—')}</td><td>${ASCB_PERMISSIONS&&ASCB_PERMISSIONS.manageLookups?`<button type="button" class="btn btn-danger btn-sm action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbAdminDeleteCourseById(${Number(r.id)})">${ascbIcon('delete')}</button>`:'—'}</td></tr>`).join(''):'<tr><td colspan="2" class="records-empty">Walang course.</td></tr>';st.style.display='none';w.style.display='block';ascbRenderPagination('admCoursesPagination',p.page,p.totalPages,p.total,ASCB_PAGE_SIZE,'ascbAdminCoursesGoToPage');}
async function ascbAdminAddCourse(){const name=(ascbAdminEl('admLookup_courseName')?.value||'').trim(),st=ascbAdminEl('admCourseFormStatus');if(!name){alert('Enter the course name.');return;}if(st){st.style.display='block';st.textContent='Saving…';}const data=await ascbApiPost('api/courses.php',{action:'add',name});if(!data.ok){if(st)st.textContent=data.error||'Unable to save.';return;}ascbAdminEl('admLookup_courseName').value='';if(!ascbCoursesCache.includes(name))ascbCoursesCache.push(name);f137LoadCourses();ascbCfPopulateCourses();if(st)st.textContent='Course added.';await ascbAdminLoadCourses();}
function ascbAdminDeleteCourseById(id){const r=ascbAdmCoursesRows.find(x=>Number(x.id)===Number(id));if(r)ascbAdminDeleteCourse(r.name);}
async function ascbAdminDeleteCourse(name){if(!(await ascbConfirm(`Delete course: ${name}?`,{danger:true})))return;const data=await ascbApiPost('api/courses.php',{action:'delete',name});if(!data.ok){alert(data.error||'Unable to delete.');return;}ascbCoursesCache=ascbCoursesCache.filter(c=>c!==name);f137LoadCourses();ascbCfPopulateCourses();await ascbAdminLoadCourses();}


/* ---------- DEPARTMENTS / DEAN EXPORT ---------- */
function ascbPopulateDepartmentSelects(){
 const ids=['user_departmentId','user_edit_departmentId','admProg_departmentId','admProg_edit_departmentId','deptExport_department','deptAssign_department'];
 ids.forEach(id=>{const el=ascbAdminEl(id);if(!el)return;const cur=el.value;let options='<option value="">— Select Department —</option>';options+=ascbDepartmentsRows.filter(d=>Number(d.is_active)).map(d=>`<option value="${Number(d.id)}">${escapeHTML(d.code)} — ${escapeHTML(d.name)}</option>`).join('');el.innerHTML=options;if(cur)el.value=cur;});
 // Dashboard Summary Report's Department filter is OPTIONAL (blank = lahat
 // ng Department), kaya ibang default label at hiwalay sa loop sa itaas.
 const dashDeptEl=ascbAdminEl('dashboardReportDepartment');
 if(dashDeptEl){const cur=dashDeptEl.value;dashDeptEl.innerHTML='<option value="">— All Departments —</option>'+ascbDepartmentsRows.filter(d=>Number(d.is_active)).map(d=>`<option value="${Number(d.id)}">${escapeHTML(d.code)} — ${escapeHTML(d.name)}</option>`).join('');if(cur)dashDeptEl.value=cur;}
 if(ASCB_CURRENT_USER&&ASCB_CURRENT_USER.role==='DEAN'){const ex=ascbAdminEl('deptExport_department');if(ex){ex.value=String(ASCB_CURRENT_USER.departmentId||'');ex.disabled=true;ascbLoadDeptExportCourses();}if(dashDeptEl){dashDeptEl.value=String(ASCB_CURRENT_USER.departmentId||'');dashDeptEl.disabled=true;ascbLoadDashboardReportCourses();}const form=ascbAdminEl('deptManageForm'),btn=ascbAdminEl('deptAddBtn'),bak=ascbAdminEl('fullSqlBackupBtn');if(form)form.style.display='none';if(btn)btn.style.display='none';if(bak)bak.style.display='none';const pd=ascbAdminEl('admProg_departmentId');if(pd){pd.value=String(ASCB_CURRENT_USER.departmentId||'');pd.disabled=true;}}
}
async function ascbLoadDepartments(silent=false){const st=ascbAdminEl('deptStatus');if(st&&!silent){st.style.display='block';st.textContent='Loading departments…';}const data=await ascbApiPost('api/departments.php',{action:'list'});if(!data.ok){if(st&&!silent)st.textContent=data.error||'Unable to load the departments.';return;}ascbDepartmentsRows=Array.isArray(data.departments)?data.departments:[];ascbPopulateDepartmentSelects();const b=ascbAdminEl('deptTableBody');if(b)b.innerHTML=ascbDepartmentsRows.length?ascbDepartmentsRows.map(d=>`<tr><td>${escapeHTML(d.code)}</td><td>${escapeHTML(d.name)}</td><td>${Number(d.program_count||0)}</td><td>${Number(d.dean_count||0)}</td><td>${Number(d.is_active)?'Active':'Inactive'}</td><td>${ASCB_PERMISSIONS&&ASCB_PERMISSIONS.manageDepartments?`<button type="button" class="btn btn-secondary btn-sm" onclick="ascbDepartmentEdit(${Number(d.id)})">Update</button> <button type="button" class="btn btn-danger btn-sm" onclick="ascbDepartmentDelete(${Number(d.id)})">Delete</button>`:'—'}</td></tr>`).join(''):'<tr><td colspan="6" class="records-empty">No departments yet.</td></tr>';if(st&&!silent)st.style.display='none';}
async function ascbLoadDepartmentAssignablePrograms(){
    const dep=Number(ascbAdminEl('deptAssign_department')?.value||0);
    const st=ascbAdminEl('deptAssignStatus'), wrap=ascbAdminEl('deptAssignTableWrapper');
    if(!dep){ if(wrap)wrap.style.display='none'; ['deptAssignBtn','deptAssignSelectAllBtn','deptAssignClearBtn'].forEach(id=>{const e=ascbAdminEl(id);if(e)e.style.display='none';}); return; }
    if(st){st.style.display='block';st.textContent='Loading existing Programs…';}
    const data=await ascbApiPost('api/programs.php',{action:'list'});
    if(!data.ok){if(st)st.textContent=data.error||'Unable to load the Programs.';return;}
    ascbAdmProgsRows=Array.isArray(data.programs)?data.programs:[];
    ascbRenderDepartmentAssignablePrograms();
}
function ascbRenderDepartmentAssignablePrograms(){
    const dep=Number(ascbAdminEl('deptAssign_department')?.value||0), b=ascbAdminEl('deptAssignTableBody'), wrap=ascbAdminEl('deptAssignTableWrapper'), st=ascbAdminEl('deptAssignStatus');
    if(!dep||!b||!wrap)return;
    const q=(ascbAdminEl('deptAssign_search')?.value||'').trim().toLowerCase();
    const rows=ascbAdmProgsRows.filter(r=>!q || [r.code,r.course_name,r.major,r.department_name].some(v=>String(v||'').toLowerCase().includes(q)));
    const unassigned=rows.filter(r=>!Number(r.department_id));
    const assignedElsewhere=rows.filter(r=>Number(r.department_id) && Number(r.department_id)!==dep);
    const same=rows.filter(r=>Number(r.department_id)===dep);
    const selectable=rows.filter(r=>Number(r.department_id)!==dep);
    b.innerHTML=rows.length?rows.map(r=>{
        const current=Number(r.department_id)===dep;
        const currentName=r.department_name||'No Department';
        return `<tr><td><input type="checkbox" class="dept-assign-program" value="${Number(r.id)}" ${current?'disabled checked':''}></td><td>${escapeHTML(r.code||'—')}</td><td>${escapeHTML(r.course_name||'—')}</td><td>${escapeHTML(r.major||'—')}</td><td>${escapeHTML(currentName)}${(!current&&Number(r.department_id))?' <strong>(will move)</strong>':''}</td></tr>`;
    }).join(''):'<tr><td colspan="5" class="records-empty">Walang matching Program.</td></tr>';
    wrap.style.display='block';
    const btn=ascbAdminEl('deptAssignBtn'), all=ascbAdminEl('deptAssignSelectAllBtn'), clear=ascbAdminEl('deptAssignClearBtn');
    [btn,all,clear].forEach(e=>{if(e)e.style.display=rows.length?'inline-block':'none';});
    if(st){st.style.display='block';st.textContent=`${rows.length} matching program(s). ${unassigned.length} unassigned; ${assignedElsewhere.length} currently under another Department; ${same.length} already assigned here.`;}
}
function ascbToggleDepartmentAssignablePrograms(select){
    document.querySelectorAll('#deptAssignTableBody .dept-assign-program:not(:disabled)').forEach(cb=>cb.checked=!!select);
}
async function ascbAssignSelectedPrograms(){
    const dep=Number(ascbAdminEl('deptAssign_department')?.value||0);
    const selected=Array.from(document.querySelectorAll('#deptAssignTableBody .dept-assign-program:checked:not(:disabled)')).map(cb=>Number(cb.value)).filter(Boolean);
    const st=ascbAdminEl('deptAssignStatus');
    if(!dep){alert('Please select a Target Department first.');return;}
    if(!selected.length){alert('Please select at least one existing Program/Course.');return;}
    const moving=selected.map(id=>ascbAdmProgsRows.find(r=>Number(r.id)===id)).filter(r=>r&&Number(r.department_id)&&Number(r.department_id)!==dep);
    if(moving.length && !(await ascbConfirm(`${moving.length} Program(s) are currently assigned to a different Department. They will be moved to the selected Department. Continue?`)))return;
    if(st){st.style.display='block';st.textContent='Saving Department assignments…';}
    const data=await ascbApiPost('api/programs.php',{action:'assign_department_bulk',departmentId:dep,programIds:selected});
    if(!data.ok){if(st)st.textContent=data.error||'Unable to save the assignments.';return;}
    if(st)st.textContent=`Success: ${Number(data.assigned_count||selected.length)} Program(s) assigned sa ${data.department?.code||'Department'}.`;
    await ascbLoadDepartments(true);
    await ascbLoadDepartmentAssignablePrograms();
    await ascbAdminLoadPrograms();
    await ascbRefreshCustomPrograms();
}

async function ascbDepartmentAdd(){
  const idEl=ascbAdminEl('dept_id');
  const id=idEl&&idEl.value?parseInt(idEl.value,10):0;
  const code=(ascbAdminEl('dept_code')?.value||'').trim().toUpperCase();
  const name=(ascbAdminEl('dept_name')?.value||'').trim();
  const st=ascbAdminEl('deptStatus');
  if(!code||!name){alert('Department Code and Name are required.');return;}
  const payload=id?{action:'update',id,code,name,isActive:parseInt(ascbAdminEl('dept_isActive')?.value||'1',10)}:{action:'add',code,name};
  const data=await ascbApiPost('api/departments.php',payload);
  if(!data.ok){if(st){st.style.display='block';st.textContent=data.error||'Unable to save.';}return;}
  ascbDepartmentCancelEdit();
  await ascbLoadDepartments();
}
function ascbDepartmentEdit(id){
  const d=ascbDepartmentsRows.find(r=>Number(r.id)===Number(id));
  if(!d)return;
  const idEl=ascbAdminEl('dept_id');if(idEl)idEl.value=String(d.id);
  const codeEl=ascbAdminEl('dept_code');if(codeEl)codeEl.value=d.code||'';
  const nameEl=ascbAdminEl('dept_name');if(nameEl)nameEl.value=d.name||'';
  const activeSel=ascbAdminEl('dept_isActive');if(activeSel)activeSel.value=Number(d.is_active)?'1':'0';
  const activeField=ascbAdminEl('dept_active_field');if(activeField)activeField.style.display='';
  const addBtn=ascbAdminEl('deptAddBtn');if(addBtn)addBtn.innerHTML='<span class="app-nav-icon">✔</span> UPDATE DEPARTMENT';
  const cancelBtn=ascbAdminEl('deptCancelEditBtn');if(cancelBtn)cancelBtn.style.display='';
  const st=ascbAdminEl('deptStatus');if(st)st.style.display='none';
  codeEl?.scrollIntoView({behavior:'smooth',block:'center'});
}
function ascbDepartmentCancelEdit(){
  const idEl=ascbAdminEl('dept_id');if(idEl)idEl.value='';
  const codeEl=ascbAdminEl('dept_code');if(codeEl)codeEl.value='';
  const nameEl=ascbAdminEl('dept_name');if(nameEl)nameEl.value='';
  const activeField=ascbAdminEl('dept_active_field');if(activeField)activeField.style.display='none';
  const addBtn=ascbAdminEl('deptAddBtn');if(addBtn)addBtn.innerHTML='<span class="app-nav-icon">✔</span> ADD DEPARTMENT';
  const cancelBtn=ascbAdminEl('deptCancelEditBtn');if(cancelBtn)cancelBtn.style.display='none';
}
async function ascbDepartmentDelete(id){if(!(await ascbConfirm('Delete this Department?',{danger:true})))return;const data=await ascbApiPost('api/departments.php',{action:'delete',id});if(!data.ok){alert(data.error||'Unable to delete.');return;}await ascbLoadDepartments();}
async function ascbLoadDeptExportCourses(){
    const dep=Number(ascbAdminEl('deptExport_department')?.value||ASCB_CURRENT_USER?.departmentId||0);
    const sel=ascbAdminEl('deptExport_course');
    if(!sel)return;
    const cur=sel.value;
    sel.innerHTML='<option value="">— All Courses —</option>';
    window.ASCB_DEPT_EXPORT_TERM_TYPES={};
    if(!dep){ascbUpdateDeptExportTerms();return;}
    const data=await ascbApiPost('api/programs.php',{action:'list'});
    if(!data.ok)return;
    const rows=(Array.isArray(data.programs)?data.programs:[]).filter(r=>Number(r.department_id)===dep);
    rows.forEach(r=>{window.ASCB_DEPT_EXPORT_TERM_TYPES[String(r.id)]=(r.term_type==='Semester'?'Semester':'Trimester');});
    sel.innerHTML='<option value="">— All Courses —</option>'+rows.map(r=>`<option value="${Number(r.id)}">${escapeHTML(r.code||'')} — ${escapeHTML(r.course_name||'')}${r.major?(' — '+escapeHTML(r.major)):''}</option>`).join('');
    if(cur)sel.value=cur;
    ascbUpdateDeptExportTerms();
}
/* (fix Semester) Ang Term dropdown ng Department Export ay sumusunod sa term
   system ng napiling Course: Semester-based (hal. MAED) -> 1st/2nd Semester +
   Summer; Trimester-based -> 1st/2nd/3rd Trimester + Summer. Kapag "All
   Courses", lahat ng pagpipilian ang ipinapakita. */
function ascbUpdateDeptExportTerms(){
    const sel=ascbAdminEl('deptExport_term');
    if(!sel)return;
    const courseId=ascbAdminEl('deptExport_course')?.value||'';
    const tt=(window.ASCB_DEPT_EXPORT_TERM_TYPES||{})[courseId]||'';
    let opts;
    if(tt==='Semester')opts=['1st Semester','2nd Semester','Summer'];
    else if(tt==='Trimester')opts=['1st Trimester','2nd Trimester','3rd Trimester','Summer'];
    else opts=['1st Trimester','2nd Trimester','3rd Trimester','1st Semester','2nd Semester','Summer'];
    const cur=sel.value;
    sel.innerHTML='<option value="">All Terms</option>'+opts.map(o=>`<option>${o}</option>`).join('');
    if(opts.indexOf(cur)!==-1)sel.value=cur;
    const lbl=document.querySelector('label[for="deptExport_term"]');
    if(lbl)lbl.textContent=(tt||'Term')+' (optional)';
}
function ascbDepartmentExport(){const dep=Number(ascbAdminEl('deptExport_department')?.value||ASCB_CURRENT_USER?.departmentId||0),course=ascbAdminEl('deptExport_course')?.value||'',sy=(ascbAdminEl('deptExport_sy')?.value||'').trim(),term=ascbAdminEl('deptExport_term')?.value||'';if(!dep){alert('Please select a Department.');return;}const q=new URLSearchParams({department_id:String(dep),csrf:ASCB_CSRF_TOKEN});if(course)q.set('program_id',course);if(sy)q.set('school_year',sy);if(term)q.set('term',term);window.location.href='api/department_export.php?'+q.toString();}
function ascbPromotionalReportExport(){const dep=Number(ascbAdminEl('deptExport_department')?.value||ASCB_CURRENT_USER?.departmentId||0),course=ascbAdminEl('deptExport_course')?.value||'',sy=(ascbAdminEl('deptExport_sy')?.value||'').trim(),term=ascbAdminEl('deptExport_term')?.value||'';if(!dep){alert('Please select a Department.');return;}if(!course){alert('Please select a Course — isang Program lang bawat Promotional Report.');return;}const q=new URLSearchParams({department_id:String(dep),program_id:course,csrf:ASCB_CSRF_TOKEN});if(sy)q.set('school_year',sy);if(term)q.set('term',term);window.location.href='api/promotional_report_export.php?'+q.toString();}
function ascbFullSqlBackup(){const q=new URLSearchParams({csrf:ASCB_CSRF_TOKEN});window.location.href='api/database_backup.php?'+q.toString();}

/* ---------- PROGRAMS & SUBJECTS ---------- */
async function ascbAdminLoadPrograms(){const st=ascbAdminEl('admProgsStatus'),wrap=ascbAdminEl('admProgsTableWrapper');if(st){st.style.display='block';st.textContent='Loading…';}const data=await ascbApiPost('api/programs.php',{action:'list'});if(!data.ok){if(st)st.textContent=data.error||'Unable to load the programs.';return;}ascbAdmProgsRows=Array.isArray(data.programs)?data.programs:[];ascbAdmProgsPage=1;ascbAdminProgramsRender();}
function ascbAdminProgramsFiltered(){const q=(ascbAdminEl('admProgSearchInput')?.value||'').trim().toLowerCase();return q?ascbAdmProgsRows.filter(r=>[r.code,r.course_name,r.major].some(v=>String(v||'').toLowerCase().includes(q))):ascbAdmProgsRows;}
function ascbAdminProgramsFilter(){ascbAdmProgsPage=1;ascbAdminProgramsRender();}function ascbAdminProgramsGoToPage(p){ascbAdmProgsPage=p;ascbAdminProgramsRender();}
function ascbAdminProgramsRender(){
    const b=ascbAdminEl('admProgsTableBody'),st=ascbAdminEl('admProgsStatus'),w=ascbAdminEl('admProgsTableWrapper');
    if(!b||!st||!w)return;
    const rows=ascbAdminProgramsFiltered(),p=ascbPaginate(rows,ascbAdmProgsPage,ASCB_PAGE_SIZE);
    ascbAdmProgsPage=p.page;
    b.innerHTML=rows.length?p.pageRows.map(r=>{
        const active=Number(r.is_active);
        const delBtn=ASCB_PERMISSIONS&&ASCB_PERMISSIONS.deleteLookups?`<button type="button" class="btn btn-danger btn-sm action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbAdminDeleteProgram(${Number(r.id)})">${ascbIcon('delete')}</button>`:'';
        return `<tr>
            <td>${escapeHTML(r.department_name||'—')}</td>
            <td>${escapeHTML(r.code||'—')}</td>
            <td>${escapeHTML(r.course_name||'—')}</td>
            <td>${escapeHTML(r.major||'—')}</td>
            <td>${escapeHTML(r.term_type||'Trimester')}</td>
            <td>${Number(r.subject_count||0)}</td>
            <td>${active?'Active':'Inactive'}</td>
            <td>
                <button type="button" class="btn btn-outline btn-sm" onclick="ascbAdminProgManageSubjects(${Number(r.id)})">Manage Subjects</button>
                <button type="button" class="btn btn-outline btn-sm action-icon-btn" title="Edit" aria-label="Edit" onclick="ascbAdminProgOpenEdit(${Number(r.id)})">${ascbIcon('edit')}</button>
                ${delBtn}
            </td>
        </tr>`;
    }).join(''):'<tr><td colspan="8" class="records-empty">Wala pang idinagdag na program.</td></tr>';
    st.style.display='none';w.style.display='block';
    ascbRenderPagination('admProgsPagination',p.page,p.totalPages,p.total,ASCB_PAGE_SIZE,'ascbAdminProgramsGoToPage');
}
async function ascbAdminAddProgram(){
    const departmentId=Number(ascbAdminEl('admProg_departmentId')?.value||0);
    const code=(ascbAdminEl('admProg_code')?.value||'').trim().toUpperCase();
    const courseName=(ascbAdminEl('admProg_courseName')?.value||'').trim();
    const major=(ascbAdminEl('admProg_major')?.value||'').trim();
    const termType=ascbAdminEl('admProg_termType')?.value||'Trimester';
    const st=ascbAdminEl('admProgFormStatus');
    if(!code||!courseName){alert('Course Code and Course Name are required.');return;}
    if(st){st.style.display='block';st.textContent='Saving…';}
    const data=await ascbApiPost('api/programs.php',{action:'add',departmentId,code,courseName,major,termType});
    if(!data.ok){if(st)st.textContent=data.error||'Unable to save.';return;}
    ['admProg_code','admProg_courseName','admProg_major'].forEach(id=>{const e=ascbAdminEl(id);if(e)e.value='';});
    if(st)st.textContent='Program added. Now available in the Enrollment Course dropdown.';
    await ascbAdminLoadPrograms();
    await ascbRefreshCustomPrograms();
}
function ascbAdminProgOpenEdit(id){
    const r=ascbAdmProgsRows.find(x=>Number(x.id)===Number(id));
    if(!r)return;
    ascbAdminEl('admProg_edit_id').value=r.id;
    ascbAdminEl('admProg_edit_departmentId').value=r.department_id||'';
    ascbAdminEl('admProg_edit_departmentId').disabled=!!(ASCB_CURRENT_USER&&ASCB_CURRENT_USER.role==='DEAN');
    ascbAdminEl('admProg_edit_code').value=r.code||'';
    ascbAdminEl('admProg_edit_courseName').value=r.course_name||'';
    ascbAdminEl('admProg_edit_major').value=r.major||'';
    ascbAdminEl('admProg_edit_termType').value=r.term_type||'Trimester';
    ascbAdminEl('admProg_edit_isActive').checked=!!Number(r.is_active);
    const st=ascbAdminEl('admProgEditStatus');if(st)st.style.display='none';
    ascbAdminEl('progEditModal')?.classList.add('active');
}
function ascbAdminProgCloseEdit(){ascbAdminEl('progEditModal')?.classList.remove('active');}
async function ascbAdminProgSubmitEdit(){
    const id=Number(ascbAdminEl('admProg_edit_id')?.value||0);
    const departmentId=Number(ascbAdminEl('admProg_edit_departmentId')?.value||0);
    const code=(ascbAdminEl('admProg_edit_code')?.value||'').trim().toUpperCase();
    const courseName=(ascbAdminEl('admProg_edit_courseName')?.value||'').trim();
    const major=(ascbAdminEl('admProg_edit_major')?.value||'').trim();
    const termType=ascbAdminEl('admProg_edit_termType')?.value||'Trimester';
    const isActive=ascbAdminEl('admProg_edit_isActive')?.checked?1:0;
    const st=ascbAdminEl('admProgEditStatus');
    if(!id||!code||!courseName){alert('Course Code and Course Name are required.');return;}
    if(st){st.style.display='block';st.textContent='Saving…';}
    const data=await ascbApiPost('api/programs.php',{action:'update',id,departmentId,code,courseName,major,termType,isActive});
    if(!data.ok){if(st)st.textContent=data.error||'Unable to save.';return;}
    ascbAdminProgCloseEdit();
    await ascbAdminLoadPrograms();
    await ascbRefreshCustomPrograms();
}
async function ascbAdminDeleteProgram(id){
    const r=ascbAdmProgsRows.find(x=>Number(x.id)===Number(id));
    if(!r||!(await ascbConfirm(`Delete program: ${r.code} — ${r.course_name}? This will also delete all its subjects.`,{danger:true})))return;
    const data=await ascbApiPost('api/programs.php',{action:'delete',id});
    if(!data.ok){alert(data.error||'Unable to delete.');return;}
    await ascbAdminLoadPrograms();
    await ascbRefreshCustomPrograms();
}

/* ---- Manage Subjects modal (isang program) ---- */
function ascbAdminProgManageSubjects(programId){
    const r=ascbAdmProgsRows.find(x=>Number(x.id)===Number(programId));
    if(!r)return;
    ascbAdmProgSubjCurrentProgram=r;
    ascbAdminEl('progSubjModalTitle').textContent=`Manage Subjects — ${r.code}`;
    ascbAdminEl('progSubjModalSubtitle').textContent=`${r.course_name}${r.major?(' Major in '+r.major):''} · ${r.term_type||'Trimester'} system`;
    ascbAdminEl('admProgSubj_termLabelLabel').textContent=r.term_type==='Semester'?'Semester':'Trimester';
    const termSelect=ascbAdminEl('admProgSubj_termLabel');
    if(termSelect){
        const opts=r.term_type==='Semester'?['1st Semester','2nd Semester','Summer']:['1st Trimester','2nd Trimester','3rd Trimester','Summer'];
        termSelect.innerHTML=`<option value="">Select ${r.term_type==='Semester'?'Semester':'Trimester'}</option>`+opts.map(o=>`<option>${o}</option>`).join('');
    }
    ascbAdminProgSubjectCancelEdit();
    ascbAdminEl('progSubjectsModal')?.classList.add('active');
    ascbAdminProgSubjLoad(r.id);
}
function ascbAdminProgSubjClose(){ascbAdminEl('progSubjectsModal')?.classList.remove('active');}
async function ascbAdminProgSubjLoad(programId){
    const st=ascbAdminEl('admProgSubjListStatus');
    if(st){st.style.display='block';st.textContent='Loading…';}
    const data=await ascbApiPost('api/programs.php',{action:'list_subjects',programId});
    if(!data.ok){if(st)st.textContent=data.error||'Unable to load the subjects.';return;}
    ascbAdmProgSubjRows=Array.isArray(data.subjects)?data.subjects:[];
    ascbAdminProgSubjRender();
}
function ascbAdminProgSubjRender(){
    const b=ascbAdminEl('admProgSubjTableBody'),st=ascbAdminEl('admProgSubjListStatus');
    if(!b)return;
    b.innerHTML=ascbAdmProgSubjRows.length?ascbAdmProgSubjRows.map(s=>{
        const delBtn=ASCB_PERMISSIONS&&ASCB_PERMISSIONS.deleteLookups?`<button type="button" class="btn btn-danger btn-sm action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbAdminProgSubjectDelete(${Number(s.id)})">${ascbIcon('delete')}</button>`:'';
        return `<tr>
            <td>${escapeHTML(s.year_level||'—')}</td>
            <td>${escapeHTML(s.term_label||'—')}</td>
            <td>${escapeHTML(s.subject_code||'—')}</td>
            <td>${escapeHTML(s.description||'—')}</td>
            <td>${Number(s.units||0)}</td>
            <td>
                <button type="button" class="btn btn-outline btn-sm action-icon-btn" title="Edit" aria-label="Edit" onclick="ascbAdminProgSubjectEdit(${Number(s.id)})">${ascbIcon('edit')}</button>
                ${delBtn}
            </td>
        </tr>`;
    }).join(''):'<tr><td colspan="7" class="records-empty">Wala pang subject.</td></tr>';
    if(st)st.style.display='none';
}
async function ascbAdminProgSubjectSave(){
    if(!ascbAdmProgSubjCurrentProgram)return;
    const editId=Number(ascbAdminEl('admProgSubj_editId')?.value||0);
    const yearLevel=ascbAdminEl('admProgSubj_yearLevel')?.value||'';
    const termLabel=ascbAdminEl('admProgSubj_termLabel')?.value||'';
    const subjectCode=(ascbAdminEl('admProgSubj_code')?.value||'').trim();
    const description=(ascbAdminEl('admProgSubj_description')?.value||'').trim();
    const units=Number(ascbAdminEl('admProgSubj_units')?.value||0);
    const st=ascbAdminEl('admProgSubjFormStatus');
    if(!yearLevel||!termLabel||!subjectCode||!description){alert('Please complete Year Level, Term, Subject Code, and Description.');return;}
    if(st){st.style.display='block';st.textContent='Saving…';}
    const payload=editId
        ?{action:'update_subject',id:editId,yearLevel,termLabel,subjectCode,description,units}
        :{action:'add_subject',programId:ascbAdmProgSubjCurrentProgram.id,yearLevel,termLabel,subjectCode,description,units};
    const data=await ascbApiPost('api/programs.php',payload);
    if(!data.ok){if(st)st.textContent=data.error||'Unable to save.';return;}
    ascbAdminProgSubjectCancelEdit();
    ['admProgSubj_code','admProgSubj_description','admProgSubj_units'].forEach(id=>{const e=ascbAdminEl(id);if(e)e.value='';});
    if(st)st.textContent='Subject saved.';
    await ascbAdminProgSubjLoad(ascbAdmProgSubjCurrentProgram.id);
    await ascbAdminLoadPrograms();
    await ascbRefreshCustomPrograms();
}
function ascbAdminProgSubjectEdit(id){
    const s=ascbAdmProgSubjRows.find(x=>Number(x.id)===Number(id));
    if(!s)return;
    ascbAdminEl('admProgSubj_editId').value=s.id;
    ascbAdminEl('admProgSubj_yearLevel').value=s.year_level||'';
    ascbAdminEl('admProgSubj_termLabel').value=s.term_label||'';
    ascbAdminEl('admProgSubj_code').value=s.subject_code||'';
    ascbAdminEl('admProgSubj_description').value=s.description||'';
    ascbAdminEl('admProgSubj_units').value=s.units||'';
    ascbAdminEl('admProgSubjAddBtn').innerHTML='<span class="btn-icon">✔</span> Save Changes';
    const cancelBtn=ascbAdminEl('admProgSubjCancelEditBtn');if(cancelBtn)cancelBtn.style.display='';
}
function ascbAdminProgSubjectCancelEdit(){
    const idField=ascbAdminEl('admProgSubj_editId');if(idField)idField.value='';
    ['admProgSubj_yearLevel','admProgSubj_termLabel','admProgSubj_code','admProgSubj_description','admProgSubj_units'].forEach(id=>{const e=ascbAdminEl(id);if(e)e.value='';});
    const addBtn=ascbAdminEl('admProgSubjAddBtn');if(addBtn)addBtn.innerHTML='<span class="btn-icon">+</span> Add Subject';
    const cancelBtn=ascbAdminEl('admProgSubjCancelEditBtn');if(cancelBtn)cancelBtn.style.display='none';
    const st=ascbAdminEl('admProgSubjFormStatus');if(st)st.style.display='none';
}
async function ascbAdminProgSubjectDelete(id){
    const s=ascbAdmProgSubjRows.find(x=>Number(x.id)===Number(id));
    if(!s||!(await ascbConfirm(`Delete subject: ${s.subject_code} — ${s.description}?`,{danger:true})))return;
    const data=await ascbApiPost('api/programs.php',{action:'delete_subject',id});
    if(!data.ok){alert(data.error||'Unable to delete.');return;}
    await ascbAdminProgSubjLoad(ascbAdmProgSubjCurrentProgram.id);
    await ascbAdminLoadPrograms();
    await ascbRefreshCustomPrograms();
}

async function ascbLoadActivityLog(){const st=ascbAdminEl('logStatus'),wrap=ascbAdminEl('logTableWrapper');if(st){st.style.display='block';st.textContent='Loading…';}if(wrap)wrap.style.display='none';const data=await ascbApiPost('api/activity_log.php',{action:'list',limit:1000});if(!data.ok){if(st)st.textContent=data.error||'Unable to load the Activity Log.';return;}ascbLogRows=Array.isArray(data.rows)?data.rows:[];ascbLogPage=1;ascbActivityLogRender();}
function ascbActivityLogFiltered(){const q=(ascbAdminEl('logSearchInput')?.value||'').trim().toLowerCase();return q?ascbLogRows.filter(r=>[r.display_name,r.role,r.action,r.entity_label,r.details].some(v=>String(v||'').toLowerCase().includes(q))):ascbLogRows;}
function ascbActivityLogFilter(){ascbLogPage=1;ascbActivityLogRender();}function ascbActivityLogGoToPage(p){ascbLogPage=p;ascbActivityLogRender();}
function ascbActivityLogRender(){
    const b=ascbAdminEl('logTableBody'),st=ascbAdminEl('logStatus'),w=ascbAdminEl('logTableWrapper');
    if(!b||!st||!w)return;
    const rows=ascbActivityLogFiltered(),p=ascbPaginate(rows,ascbLogPage,ASCB_PAGE_SIZE);
    ascbLogPage=p.page;
    const actionMeta=(action)=>{
        const a=String(action||'').toLowerCase();
        if(a.includes('delete')||a.includes('reject')||a.includes('remove'))return {icon:'✕',cls:'is-danger',verb:'Removed / Rejected'};
        if(a.includes('update')||a.includes('edit')||a.includes('correct'))return {icon:'✎',cls:'is-warning',verb:'Updated'};
        if(a.includes('approve'))return {icon:'✓',cls:'is-success',verb:'Approved'};
        if(a.includes('login'))return {icon:'↪',cls:'is-info',verb:'Logged In'};
        if(a.includes('logout'))return {icon:'↩',cls:'is-info',verb:'Logged Out'};
        if(a.includes('create')||a.includes('add')||a.includes('enroll')||a.includes('upload'))return {icon:'+',cls:'is-primary',verb:'Created / Added'};
        return {icon:'•',cls:'is-primary',verb:'Activity'};
    };
    b.innerHTML=rows.length?p.pageRows.map((r)=>{
        const action=String(r.action||'Activity').trim();
        const entity=String(r.entity_label||'').trim();
        const details=String(r.details||'').trim();
        const name=String(r.display_name||'Unknown user').trim();
        const role=String(r.role||'—').trim();
        const meta=actionMeta(action);
        const initials=name.split(/\s+/).filter(Boolean).slice(0,2).map(x=>x.charAt(0).toUpperCase()).join('')||'U';
        const dateText=ascbUiDateTime(r.created_at);
        return `<article class="activity-card ${meta.cls}">
            <div class="activity-card-head">
                <div class="activity-action-wrap">
                    <span class="activity-card-icon ${meta.cls}">${meta.icon}</span>
                    <div class="activity-action-copy">
                        <span class="activity-action ${meta.cls}">${escapeHTML(action)}</span>
                        <span class="activity-verb">${escapeHTML(meta.verb)}</span>
                    </div>
                </div>
                <time class="activity-time" datetime="${escapeHTML(r.created_at||'')}">${escapeHTML(dateText)}</time>
            </div>
            <div class="activity-card-record">
                <span class="activity-label">TRANSACTION RECORD</span>
                <strong>${escapeHTML(entity||'System Activity')}</strong>
            </div>
            <div class="activity-card-info">
                <div class="activity-user">
                    <span class="activity-avatar">${escapeHTML(initials)}</span>
                    <span class="activity-user-copy"><small>PERFORMED BY</small><strong>${escapeHTML(name)}</strong><em>${escapeHTML(role)}</em></span>
                </div>
                <div class="activity-details-box">
                    <span class="activity-label">DETAILS</span>
                    <p>${escapeHTML(details||'No additional details recorded.')}</p>
                </div>
            </div>
        </article>`;
    }).join(''):`<div class="activity-empty"><span>◷</span><strong>Walang activity record</strong><small>Walang history na tumutugma sa iyong search.</small></div>`;
    st.style.display='none';w.style.display='block';
    ascbRenderPagination('logPagination',p.page,p.totalPages,p.total,ASCB_PAGE_SIZE,'ascbActivityLogGoToPage');
}

/* =========================================================
   HONORS — President's Lister / Dean's Lister
   Read-only report mula sa api/honors.php. Per Term ang bawat
   row (isang enrollment record); DEAN accounts ay sariling
   Department na lang ang nakikita (backend-side na ang filter).
   ========================================================= */
let ascbHonorsRows = [];
let ascbHonorsActiveTab = 'PRESIDENT';
let ascbHonorsPage = 1;
let ascbHonorsSort = { key: 'gwa', dir: 'asc' };
let ascbHonorsLoadTimer = null;
let ascbHonorsReqId = 0;
let ascbHonorsLoaded = false;

function ascbHonorsEl(id) { return document.getElementById(id); }

/* Add all trimester/semester periods to the existing honors filter. */
function ascbHonorsInitTermFilter() {
    const select = ascbHonorsEl('honorsTrimesterFilter');
    if (!select || select.dataset.periodOptionsReady === '1') return;
    const previous = select.value || '';
    const options = [
        ['', 'ALL — All Terms'],
        ['1st Trimester', '1st Trimester'],
        ['2nd Trimester', '2nd Trimester'],
        ['3rd Trimester', '3rd Trimester'],
        ['1st Semester', '1st Semester'],
        ['2nd Semester', '2nd Semester'],
        ['Summer', 'Summer']
    ];
    select.replaceChildren(...options.map(([value, label]) => {
        const option = document.createElement('option');
        option.value = value;
        option.textContent = label;
        return option;
    }));
    select.value = options.some(([value]) => value === previous) ? previous : '';
    select.dataset.periodOptionsReady = '1';
}

/* School Year: accept "2025-2026", "2025 – 2026", etc. Returns '' when blank,
   null when the text is not a valid school year yet (so we don't query the server). */
function ascbHonorsSchoolYearValue() {
    const raw = (ascbHonorsEl('honorsSchoolYearFilter')?.value || '').trim();
    if (!raw) return '';
    const norm = raw.replace(/[\u2013\u2014]/g, '-').replace(/\s+/g, '');
    return /^\d{4}-\d{4}$/.test(norm) ? norm : null;
}

function ascbHonorsSetStatus(kind, html) {
    const st = ascbHonorsEl('honorsStatus');
    if (!st) return;
    st.className = 'records-status honors-status is-' + kind;
    st.innerHTML = html;
    st.style.display = 'block';
}

function ascbHonorsSkeleton() {
    return '<div class="honors-skel" aria-hidden="true">' + '<span></span>'.repeat(5) + '</div><span class="honors-sr">Loading honor lists…</span>';
}

/* Debounced reload while typing the School Year (no more waiting for blur). */
function ascbHonorsQueueLoad() {
    clearTimeout(ascbHonorsLoadTimer);
    const hint = ascbHonorsEl('honorsSchoolYearHint');
    const input = ascbHonorsEl('honorsSchoolYearFilter');
    const value = ascbHonorsSchoolYearValue();
    const invalid = value === null;
    if (hint) hint.hidden = !invalid;
    if (input) input.classList.toggle('is-invalid', invalid);
    if (invalid) return;
    ascbHonorsLoadTimer = setTimeout(ascbLoadHonors, 450);
}

function ascbHonorsReset() {
    const t = ascbHonorsEl('honorsTrimesterFilter'); if (t) t.value = '';
    const s = ascbHonorsEl('honorsSchoolYearFilter'); if (s) { s.value = ''; s.classList.remove('is-invalid'); }
    const q = ascbHonorsEl('honorsSearchInput'); if (q) { q.value = ''; q.dataset.ascbUserTyped = '1'; }
    const h = ascbHonorsEl('honorsSchoolYearHint'); if (h) h.hidden = true;
    ascbLoadHonors();
}

async function ascbLoadHonors() {
    clearTimeout(ascbHonorsLoadTimer);
    ascbHonorsInitTermFilter();
    const wrap = ascbHonorsEl('honorsTableWrapper');
    const pager = ascbHonorsEl('honorsPagination');
    const trimester = ascbHonorsEl('honorsTrimesterFilter')?.value || '';
    const schoolYear = ascbHonorsSchoolYearValue();
    if (schoolYear === null) { ascbHonorsQueueLoad(); return; }

    const reqId = ++ascbHonorsReqId;
    ascbHonorsSetStatus('loading', ascbHonorsSkeleton());
    if (wrap) wrap.style.display = 'none';
    if (pager) pager.innerHTML = '';

    const q = new URLSearchParams();
    if (trimester) q.set('trimester', trimester);
    if (schoolYear) q.set('school_year', schoolYear);
    const retry = '<button type="button" class="btn btn-secondary btn-sm honors-retry" onclick="ascbLoadHonors()">Try again</button>';

    try {
        const response = await fetch('api/honors.php' + (q.toString() ? ('?' + q.toString()) : ''), { cache: 'no-store', credentials: 'same-origin', headers: { 'Accept': 'application/json' } });
        let data = null;
        try { data = await response.json(); } catch (parseErr) { console.error('Honors API returned a non-JSON response:', response.status, parseErr); }
        if (reqId !== ascbHonorsReqId) return; // a newer request replaced this one

        if (response.status === 401) {
            ascbHonorsSetStatus('error', '<strong>Your session has expired.</strong> Redirecting to the login page…');
            setTimeout(() => { window.location.href = './'; }, 1800);
            return;
        }
        if (!response.ok || !data || !data.ok) {
            let reason;
            if (data && data.error) reason = data.error;
            else if (response.status >= 500) reason = 'The server reported an error (HTTP ' + response.status + '). Check the PHP error log or contact IT/Admin.';
            else reason = 'The server returned an unexpected response (HTTP ' + response.status + ').';
            console.error('Honors load failed:', response.status, data);
            ascbHonorsSetStatus('error', '<strong>Unable to load the honor lists.</strong><span>' + escapeHTML(reason) + '</span>' + retry);
            return;
        }
        ascbHonorsRows = Array.isArray(data.rows) ? data.rows : [];
        ascbHonorsLoaded = true;
        ascbHonorsPage = 1;
        ascbHonorsRender();
    } catch (e) {
        if (reqId !== ascbHonorsReqId) return;
        console.error('Honors load failed:', e);
        ascbHonorsSetStatus('error', '<strong>Unable to reach the server.</strong><span>Check your internet connection, then try again.</span>' + retry);
    }
}

function ascbHonorsSwitchTab(tab) {
    ascbHonorsActiveTab = tab;
    [['honorsTabPresident', 'PRESIDENT'], ['honorsTabDean', 'DEAN']].forEach(([id, key]) => {
        const el = ascbHonorsEl(id);
        if (!el) return;
        el.classList.toggle('active', tab === key);
        el.setAttribute('aria-selected', tab === key ? 'true' : 'false');
    });
    ascbHonorsPage = 1;
    if (ascbHonorsLoaded) ascbHonorsRender();
}

function ascbHonorsQuery() { return (ascbHonorsEl('honorsSearchInput')?.value || '').trim().toLowerCase(); }

function ascbHonorsMatches(r, q) {
    return !q || ascbNameMatch(q, [r.student_id, r.student_name, r.course, r.major, r.department_name]);
}

function ascbHonorsSortRows(rows) {
    const { key, dir } = ascbHonorsSort;
    const m = dir === 'asc' ? 1 : -1;
    const text = (v) => String(v == null ? '' : v);
    const cmp = (a, b) => text(a).localeCompare(text(b), undefined, { numeric: true, sensitivity: 'base' });
    return rows.slice().sort((a, b) => {
        let c = key === 'gwa'
            ? ((Number.isFinite(Number(a.gwa)) ? Number(a.gwa) : 99) - (Number.isFinite(Number(b.gwa)) ? Number(b.gwa) : 99))
            : cmp(a[key], b[key]);
        if (!c) c = cmp(a.student_name, b.student_name);
        return c * m;
    });
}

function ascbHonorsFiltered() {
    const q = ascbHonorsQuery();
    return ascbHonorsSortRows(ascbHonorsRows.filter(r => r.list_type === ascbHonorsActiveTab && ascbHonorsMatches(r, q)));
}

function ascbHonorsFilter() { ascbHonorsPage = 1; if (ascbHonorsLoaded) ascbHonorsRender(); }
function ascbHonorsGoToPage(p) { ascbHonorsPage = p; ascbHonorsRender(); }

function ascbHonorsSortBy(key) {
    ascbHonorsSort = (ascbHonorsSort.key === key)
        ? { key, dir: ascbHonorsSort.dir === 'asc' ? 'desc' : 'asc' }
        : { key, dir: 'asc' };
    ascbHonorsPage = 1;
    if (ascbHonorsLoaded) ascbHonorsRender();
}

function ascbHonorsExport() {
    const trimester = ascbHonorsEl('honorsTrimesterFilter')?.value || '';
    const schoolYear = ascbHonorsSchoolYearValue();
    if (schoolYear === null) { ascbHonorsQueueLoad(); ascbHonorsEl('honorsSchoolYearFilter')?.focus(); return; }
    const q = new URLSearchParams({ csrf: ASCB_CSRF_TOKEN });
    if (trimester) q.set('trimester', trimester);
    if (schoolYear) q.set('school_year', schoolYear);
    window.location.href = 'api/honors_export.php?' + q.toString();
}

/* Tab badges: entry count (respecting the search box) + best GWA per list. */
function ascbHonorsUpdateTabs() {
    const q = ascbHonorsQuery();
    const stat = { PRESIDENT: { n: 0, best: null }, DEAN: { n: 0, best: null } };
    ascbHonorsRows.forEach(r => {
        const s = stat[r.list_type];
        if (!s || !ascbHonorsMatches(r, q)) return;
        s.n++;
        const g = Number(r.gwa);
        if (Number.isFinite(g) && (s.best === null || g < s.best)) s.best = g;
    });
    [['PRESIDENT', 'President'], ['DEAN', 'Dean']].forEach(([k, name]) => {
        const c = ascbHonorsEl('honorsCount' + name), b = ascbHonorsEl('honorsBest' + name);
        if (c) c.textContent = stat[k].n.toLocaleString();
        if (b) b.textContent = stat[k].best === null ? 'No entries' : 'Best GWA ' + stat[k].best.toFixed(2);
    });
}

function ascbHonorsUpdateSortHeaders() {
    document.querySelectorAll('#honorsTable thead th[data-sort]').forEach(th => {
        const active = th.dataset.sort === ascbHonorsSort.key;
        th.setAttribute('aria-sort', active ? (ascbHonorsSort.dir === 'asc' ? 'ascending' : 'descending') : 'none');
    });
}

function ascbHonorsRender() {
    const b = ascbHonorsEl('honorsTableBody'), st = ascbHonorsEl('honorsStatus'), w = ascbHonorsEl('honorsTableWrapper'), meta = ascbHonorsEl('honorsMeta');
    if (!b || !st || !w) return;
    ascbHonorsUpdateTabs();
    ascbHonorsUpdateSortHeaders();

    const rows = ascbHonorsFiltered();
    const p = ascbPaginate(rows, ascbHonorsPage, ASCB_PAGE_SIZE);
    ascbHonorsPage = p.page;
    const label = ascbHonorsActiveTab === 'PRESIDENT' ? "President's Lister" : "Dean's Lister";
    const term = ascbHonorsEl('honorsTrimesterFilter')?.value || 'All terms';
    const sy = ascbHonorsSchoolYearValue();
    const q = (ascbHonorsEl('honorsSearchInput')?.value || '').trim();

    if (meta) {
        const from = rows.length ? ((p.page - 1) * ASCB_PAGE_SIZE + 1) : 0;
        const to = rows.length ? Math.min(rows.length, p.page * ASCB_PAGE_SIZE) : 0;
        const sortName = { gwa: 'GWA', student_name: 'student name', course: 'course', department_name: 'department', year_level: 'year level', school_year: 'school year' }[ascbHonorsSort.key] || ascbHonorsSort.key;
        meta.innerHTML = `<span><strong>${from.toLocaleString()}–${to.toLocaleString()}</strong> of <strong>${rows.length.toLocaleString()}</strong> ${escapeHTML(label)} entries</span>`
            + `<span class="honors-chip">${escapeHTML(term)}</span>`
            + (sy ? `<span class="honors-chip">SY ${escapeHTML(sy)}</span>` : '')
            + (q ? `<span class="honors-chip">Search: “${escapeHTML(q)}”</span>` : '')
            + `<span class="honors-meta-sort">Sorted by ${escapeHTML(sortName)} (${ascbHonorsSort.dir === 'asc' ? (ascbHonorsSort.key === 'gwa' ? 'best first' : 'A–Z') : (ascbHonorsSort.key === 'gwa' ? 'lowest first' : 'Z–A')})</span>`;
    }

    if (!rows.length) {
        b.innerHTML = '';
        w.style.display = 'none';
        const pager = ascbHonorsEl('honorsPagination'); if (pager) pager.innerHTML = '';
        const hasAny = ascbHonorsRows.some(r => r.list_type === ascbHonorsActiveTab);
        ascbHonorsSetStatus('empty', hasAny
            ? `<strong>No ${escapeHTML(label)} matches “${escapeHTML(q)}”.</strong><span>Check the spelling or clear the search box.</span><button type="button" class="btn btn-secondary btn-sm honors-retry" onclick="(function(){const s=document.getElementById('honorsSearchInput'); if(s){s.value='';} ascbHonorsFilter(); })()">Clear search</button>`
            : `<strong>No qualified ${escapeHTML(label)} for this selection.</strong><span>Try “ALL — All Terms”, another academic period, or another school year.</span>`);
        return;
    }

    b.innerHTML = p.pageRows.map(r => {
        const gwa = Number(r.gwa);
        const gwaText = Number.isFinite(gwa) ? gwa.toFixed(2) : '—';
        const tone = r.list_type === 'PRESIDENT' ? 'is-president' : 'is-dean';
        return `<tr>
        <td data-label="Student"><div class="honors-student"><strong>${escapeHTML(r.student_name || '—')}</strong><span>${escapeHTML(r.student_id || '—')}</span></div></td>
        <td data-label="Course / Major"><div class="honors-stack"><strong>${escapeHTML(r.course || '—')}</strong>${r.major ? `<span>${escapeHTML(r.major)}</span>` : ''}</div></td>
        <td data-label="Department">${escapeHTML(r.department_name || '—')}</td>
        <td data-label="Year Level">${escapeHTML(r.year_level || '—')}</td>
        <td data-label="Period"><div class="honors-stack"><strong>${escapeHTML(r.trimester || '—')}</strong><span>${escapeHTML(r.school_year || '—')}</span></div></td>
        <td data-label="GWA" class="honors-col-gwa"><span class="honors-gwa ${tone}">${escapeHTML(gwaText)}</span></td>
    </tr>`;
    }).join('');
    st.style.display = 'none';
    w.style.display = 'block';
    ascbRenderPagination('honorsPagination', p.page, p.totalPages, p.total, ASCB_PAGE_SIZE, 'ascbHonorsGoToPage');
}


/* =========================================================
   STUDENT 360
   Search -> pumili ng estudyante -> ipinapakita ang Student
   Information, Enrollment History, Grade Evaluation,
   Certificates, at Audit Timeline mula sa api/student_360.php.
   Read-only lang ito — walang add/edit/delete dito.
   ========================================================= */

let ascbStudent360SearchTimer = null;
let ascbStudent360CurrentId = null;

function ascbStudent360El(id) { return document.getElementById(id); }

/* ---------------------------------------------------------
   GRADE EVALUATION (Student 360) — button na lang kada term
   (hindi na naka-expand lahat agad) para hindi bumababa/humaba
   nang sobra ang page kapag maraming term na ang estudyante.
   --------------------------------------------------------- */
let ascbStudent360GradeTerms = [];
let ascbStudent360OpenTermIdx = null;

function ascbStudent360RenderGradeTerms() {
    const gradesContainer = ascbStudent360El('student360GradesContainer');
    if (!gradesContainer) return;
    const terms = ascbStudent360GradeTerms;
    if (!terms.length) {
        gradesContainer.innerHTML = `<p class="records-empty">No Grade Record.</p>`;
        return;
    }
    gradesContainer.innerHTML = terms.map((t, idx) => {
        const isOpen = ascbStudent360OpenTermIdx === idx;
        const label = escapeHTML([t.schoolYear, t.trimester, t.yearLevel].filter(Boolean).join(' · ') || 'Term');
        const totalUnitsVal = escapeHTML(String(t.totalUnits || 0));
        const gwaVal = escapeHTML(t.gwa === null || t.gwa === undefined ? '—' : String(t.gwa));
        const table = isOpen ? `
                <table class="records-table">
                    <thead><tr><th>Code</th><th>Description</th><th>Grade</th><th>Units</th></tr></thead>
                    <tbody>
                        ${t.subjects.length ? t.subjects.map(s => `<tr>
                            <td>${escapeHTML(s.code || '—')}</td>
                            <td>${escapeHTML(s.description || '—')}</td>
                            <td>${escapeHTML(s.hiddenOnPrint ? 'Hidden on Print' : (s.grade || '—'))}</td>
                            <td>${escapeHTML(String(s.units ?? '—'))}</td>
                        </tr>`).join('') : `<tr><td colspan="4" class="records-empty">Walang subjects.</td></tr>`}
                    </tbody>
                    <tfoot>
                        <tr class="student360-term-total-row">
                            <td></td>
                            <td></td>
                            <td><strong>GWA: ${gwaVal}</strong></td>
                            <td><strong>Total Units: ${totalUnitsVal}</strong></td>
                        </tr>
                    </tfoot>
                </table>` : '';
        return `
            <div class="student360-term-block">
                <div class="student360-term-heading">
                    <strong>${label}</strong>
                    <button type="button" class="btn btn-outline student360-term-toggle-btn" onclick="ascbStudent360ToggleTerm(${idx})">${isOpen ? 'Hide Grades' : 'View Grades'}</button>
                </div>
                ${table}
            </div>
        `;
    }).join('');
}

function ascbStudent360ToggleTerm(idx) {
    ascbStudent360OpenTermIdx = (ascbStudent360OpenTermIdx === idx) ? null : idx;
    ascbStudent360RenderGradeTerms();
}

function ascbLoadStudent360() {
    // Walang kailangang i-fetch agad pagbukas ng view — maghihintay
    // lang ng paghahanap. Kung may bukas nang profile, panatilihin ito.
    const input = ascbStudent360El('student360SearchInput');
    if (input) input.focus();
}

const ascbStudent360RequestGuard = ascbMakeRequestGuard();
function ascbStudent360Search() {
    clearTimeout(ascbStudent360SearchTimer);
    const q = (ascbStudent360El('student360SearchInput')?.value || '').trim();
    const status = ascbStudent360El('student360SearchStatus');
    const wrap = ascbStudent360El('student360ResultsWrapper');

    if (q.length < 2) {
        if (status) { status.style.display = 'none'; }
        if (wrap) wrap.style.display = 'none';
        return;
    }

    if (status) { status.style.display = 'block'; status.textContent = 'Searching…'; }
    if (wrap) wrap.style.display = 'none';

    ascbStudent360SearchTimer = setTimeout(async () => {
        const ascbStudent360Token = ascbStudent360RequestGuard.start();
        try {
            const response = await fetch('api/student_360.php?action=search&q=' + encodeURIComponent(q));
            const data = await response.json();
            // May mas bago nang search na pinaandar habang naghihintay dito
            // (hal. mas mabagal ang network sa mas lumang keystroke) —
            // laktawan ang lumang resultang ito, hindi na dapat ipakita.
            if (!ascbStudent360RequestGuard.isCurrent(ascbStudent360Token)) return;
            if (!data || !data.ok) {
                if (status) status.textContent = (data && data.error) || 'Unable to load the results.';
                return;
            }
            const rows = Array.isArray(data.rows) ? data.rows : [];
            const body = ascbStudent360El('student360ResultsTableBody');
            if (!body) return;

            if (!rows.length) {
                if (status) { status.style.display = 'block'; status.textContent = 'No student found.'; }
                if (wrap) wrap.style.display = 'none';
                return;
            }

            body.innerHTML = rows.map(r => `<tr>
                <td>${escapeHTML(r.studentId || '—')}</td>
                <td>${escapeHTML(r.name || '—')}</td>
                <td>${escapeHTML(r.course || '—')}</td>
                <td>${escapeHTML(r.major || '—')}</td>
                <td>${escapeHTML([r.yearLevel, r.trimester].filter(Boolean).join(' / ') || '—')}</td>
                <td>${escapeHTML(r.departmentName || '—')}</td>
                <td><button type="button" class="btn btn-secondary" onclick="ascbStudent360SelectStudent('${encodeURIComponent(r.studentId)}')">Buksan ➜</button></td>
            </tr>`).join('');

            if (status) status.style.display = 'none';
            if (wrap) wrap.style.display = 'block';
        } catch (e) {
            if (!ascbStudent360RequestGuard.isCurrent(ascbStudent360Token)) return;
            if (status) { status.style.display = 'block'; status.textContent = 'Unable to load the results. Please try again.'; }
        }
    }, 300);
}

function ascbStudent360ClosePofile() {
    ascbStudent360CurrentId = null;
    const wrap = ascbStudent360El('student360ProfileWrapper');
    if (wrap) wrap.style.display = 'none';
}

async function ascbStudent360SelectStudent(encodedStudentId) {
    const studentId = decodeURIComponent(encodedStudentId);
    ascbStudent360CurrentId = studentId;

    const wrap = ascbStudent360El('student360ProfileWrapper');
    if (wrap) { wrap.style.display = 'block'; wrap.scrollIntoView({ behavior: 'smooth', block: 'start' }); }

    const nameEl = ascbStudent360El('student360ProfileName');
    const subEl = ascbStudent360El('student360ProfileSub');
    if (nameEl) nameEl.textContent = 'Loading…';
    if (subEl) subEl.textContent = studentId;

    try {
        const response = await fetch('api/student_360.php?action=profile&studentId=' + encodeURIComponent(studentId));
        const data = await response.json();
        if (!data || !data.ok) {
            if (nameEl) nameEl.textContent = (data && data.error) || 'Unable to load the student.';
            if (subEl) subEl.textContent = '';
            return;
        }
        ascbStudent360Render(data);
    } catch (e) {
        if (nameEl) nameEl.textContent = 'Unable to load the student. Please try again.';
        if (subEl) subEl.textContent = '';
    }
}

/* Ginagamit para sa Student 360 view — dapat "Enrolled" ang lumalabas
   sa student data kapag "approved" ang status sa database, kaugnay
   ng parehong label na ginagamit ng ascbEnrollStatusBadge(). */
function ascbStudent360StatusLabel(status) {
    const map = { approved: 'Enrolled', pending: 'Pending', rejected: 'Rejected' };
    const key = String(status || '').toLowerCase();
    return map[key] || (status || '—');
}

function ascbStudent360Render(data) {
    const p = data.profile || {};

    const nameEl = ascbStudent360El('student360ProfileName');
    const subEl = ascbStudent360El('student360ProfileSub');
    if (nameEl) nameEl.textContent = p.fullName || '—';
    if (subEl) {
        // Ginagamit ang parehong helper na ginagamit na sa Grade
        // Evaluation/Certificate (ascbGradeEvalFormatCourseMajor) para
        // konsistent din dito — kasi kapag hinati-hati/raw-joined lang
        // ang currentCourse + currentMajor (dating ginagawa dito), ang
        // lumalabas para sa mga BSED/BSBA na program ay ang mismong
        // raw code (hal. "BSED-SOCIAL") na parang major ang "SOCIAL"
        // ay bahagi ng course, imbes na "Bachelor of Secondary
        // Education Major in Social Studies".
        const courseLabel = ascbGradeEvalFormatCourseMajor(p.currentCourse, p.currentMajor);
        subEl.textContent = `${p.studentId || '—'} · ${courseLabel} · ${p.departmentName || 'No Department'}`;
    }

    const infoGrid = ascbStudent360El('student360InfoGrid');
    if (infoGrid) {
        const fields = [
            ['Student ID', p.studentId],
            ['Sex', p.sex],
            ['Civil Status', p.civilStatus],
            ['Student Type', p.studentType],
            ['Birth Date', ascbEnrollFormatDateLong(p.birthDate)],
            ['Birth Place', p.birthPlace],
            ['Address', p.address],
            ['Mobile Number', p.mobileNumber],
            ['Guardian Name', p.guardianName],
            ['Email', p.email],
            ['Previous School (JHS)', p.prevSchoolJuniorHs],
            ['Previous School (SHS)', p.prevSchoolSeniorHs],
            ['Junior High School Graduated', p.juniorHsGraduated],
            ['Senior High School Graduated', p.seniorHsGraduated],
            ['Current Program', ascbGradeEvalFormatCourseMajor(p.currentProgramCode, p.currentMajor)],
            ['Current Year / Term', [p.currentYearLevel, p.currentTrimester].filter(Boolean).join(' / ')],
            ['Current School Year', p.currentSchoolYear],
            ['Current Status', ascbStudent360StatusLabel(p.currentStatus)],
        ];
        infoGrid.innerHTML = fields.map(([label, value]) => `
            <div class="student360-info-item">
                <span class="student360-info-label">${escapeHTML(label)}</span>
                <span class="student360-info-value">${escapeHTML(value || '—')}</span>
            </div>
        `).join('');
    }

    const historyBody = ascbStudent360El('student360HistoryTableBody');
    if (historyBody) {
        const rows = Array.isArray(data.enrollmentHistory) ? data.enrollmentHistory.slice().reverse() : [];
        historyBody.innerHTML = rows.length ? rows.map(r => `<tr${r.archived ? ' style="opacity:.6;"' : ''}>
            <td>${escapeHTML(r.schoolYear || '—')}</td>
            <td>${escapeHTML(r.trimester || '—')}</td>
            <td>${escapeHTML(r.yearLevel || '—')}</td>
            <td>${escapeHTML(ascbGradeEvalFormatCourseMajor(r.course, r.major))}</td>
            <td>${escapeHTML((r.archived ? 'Archived / ' : '') + ascbStudent360StatusLabel(r.status))}</td>
            <td>${escapeHTML(r.enrolledByName || '—')}</td>
            <td>${escapeHTML((r.createdAt || '').slice(0, 10) || '—')}</td>
        </tr>`).join('') : `<tr><td colspan="7" class="records-empty">Walang enrollment history.</td></tr>`;
    }

    ascbStudent360GradeTerms = Array.isArray(data.gradeEvaluation) ? data.gradeEvaluation.slice().reverse() : [];
    ascbStudent360OpenTermIdx = null;
    ascbStudent360RenderGradeTerms();

    const certCard = ascbStudent360El('student360CertificatesCard');
    const certBody = ascbStudent360El('student360CertificatesTableBody');
    if (certCard && certBody) {
        if (Array.isArray(data.certificates)) {
            certCard.style.display = 'block';
            certBody.innerHTML = data.certificates.length ? data.certificates.map(c => `<tr>
                <td>${escapeHTML(ascbRecordsCertLabel ? ascbRecordsCertLabel(c.certificateType) : (c.certificateType || '—'))}</td>
                <td>${escapeHTML(c.orNumber || '—')}</td>
                <td>${escapeHTML(c.academicYear || '—')}</td>
                <td>${escapeHTML(c.trimester || '—')}</td>
                <td>${escapeHTML(c.gwa === null || c.gwa === undefined ? '—' : String(c.gwa))}</td>
                <td>${escapeHTML((c.createdAt || '').slice(0, 10) || '—')}</td>
            </tr>`).join('') : `<tr><td colspan="6" class="records-empty">Wala pang na-generate na certificate.</td></tr>`;
        } else {
            certCard.style.display = 'none';
        }
    }

    const auditCard = ascbStudent360El('student360AuditCard');
    const timelineList = ascbStudent360El('student360TimelineList');
    if (auditCard && timelineList) {
        if (Array.isArray(data.auditTimeline)) {
            auditCard.style.display = 'block';
            ascbStudent360AuditEntries = data.auditTimeline;
            ascbStudent360AuditShown = ASCB_STUDENT360_AUDIT_PAGE_SIZE;
            ascbStudent360RenderAuditTimeline();
        } else {
            auditCard.style.display = 'none';
        }
    }
}

const ASCB_STUDENT360_AUDIT_PAGE_SIZE = 8;
let ascbStudent360AuditEntries = [];
let ascbStudent360AuditShown = ASCB_STUDENT360_AUDIT_PAGE_SIZE;

function ascbStudent360RenderAuditTimeline() {
    const timelineList = ascbStudent360El('student360TimelineList');
    if (!timelineList) return;
    const entries = ascbStudent360AuditEntries;
    const visible = entries.slice(0, ascbStudent360AuditShown);
    timelineList.innerHTML = visible.length ? visible.map(a => `
                <li class="student360-timeline-item">
                    <div class="student360-timeline-dot"></div>
                    <div class="student360-timeline-body">
                        <strong>${escapeHTML(a.action || '—')}</strong>
                        <span class="student360-timeline-meta">${escapeHTML(a.byName || 'System')} (${escapeHTML(a.byRole || '—')}) · ${escapeHTML((a.createdAt || '').slice(0, 16).replace('T', ' '))}</span>
                        ${a.details ? `<p>${escapeHTML(a.details)}</p>` : ''}
                    </div>
                </li>
            `).join('') : `<li class="records-empty">Walang naitalang aktibidad.</li>`;

    const moreWrap = ascbStudent360El('student360TimelineMore');
    if (moreWrap) {
        const remaining = entries.length - visible.length;
        moreWrap.innerHTML = remaining > 0
            ? `<button type="button" class="btn btn-outline" onclick="ascbStudent360LoadMoreAudit()">Show More (${remaining} more)</button>`
            : '';
    }
}

function ascbStudent360LoadMoreAudit() {
    ascbStudent360AuditShown += ASCB_STUDENT360_AUDIT_PAGE_SIZE;
    ascbStudent360RenderAuditTimeline();
}

function ascbGradebookToggleLock(){/* lock/unlock feature removed */}


/* =========================================================
   MASTER RECORD MODULE  (api/master_record.php)
   The permanent, current profile of each student. Historical
   enrollment / grade / certificate rows are never edited here.
   ========================================================= */

const ASCB_MR_API = 'api/master_record.php';
const ASCB_MR_FIELDS = [
    { group: 'Name', items: [
        { key: 'surname', label: 'Surname', required: true, max: 100 },
        { key: 'firstName', label: 'First name', required: true, max: 100 },
        { key: 'middleName', label: 'Middle name', max: 100 },
        { key: 'suffix', label: 'Suffix', max: 20, placeholder: 'Jr., Sr., III' },
        { key: 'suffixPosition', label: 'Suffix placement (per PSA)', type: 'select', options: [
            { value: 'separate', label: '(Standard Suffix)' },
            { value: 'first_name', label: 'Suffix on Firstname (Base on PSA)' },
            { value: 'surname', label: 'Suffix on Lastname (Base on PSA' },
        ] },
        { key: 'reason', label: 'Reason for name change', span: 2, max: 255, virtual: true, placeholder: 'e.g. Marriage, correction of spelling' },
    ] },
    { group: 'Personal details', items: [
        { key: 'civilStatus', label: 'Civil status', type: 'select', options: ['', 'Single', 'Married', 'Widowed', 'Separated'] },
        { key: 'sex', label: 'Sex', type: 'select', options: ['', 'Male', 'Female'] },
        { key: 'birthDate', label: 'Birth date', type: 'date' },
        { key: 'birthplace', label: 'Birthplace', max: 255 },
        { key: 'nationality', label: 'Nationality', max: 80 },
    ] },
    { group: 'Contact', items: [
        { key: 'address', label: 'Address', span: 2, max: 255 },
        { key: 'mobileNumber', label: 'Mobile number', type: 'tel', max: 20 },
        { key: 'email', label: 'Email', type: 'email', max: 254 },
    ] },
    { group: 'Guardian and emergency contact', items: [
        { key: 'guardianName', label: 'Guardian', max: 150 },
        { key: 'guardianContact', label: 'Guardian contact', type: 'tel', max: 50 },
        { key: 'emergencyContact', label: 'Emergency contact', span: 2, max: 150 },
    ] },
];
const ASCB_MR_NAME_KEYS = ['surname', 'firstName', 'middleName', 'suffix', 'suffixPosition'];

let ascbMrData = null;
let ascbMrFormBuilt = false;
let ascbMrSearchTimer = null;
let ascbMrFirstResultId = null;
let ascbMrNamesCache = null;
let ascbMrNamesAt = 0;
const ascbMrSearchGuard = ascbMakeRequestGuard();

function ascbMrEl(id) { return document.getElementById(id); }
function ascbMrText(v) { return (v === null || v === undefined || String(v).trim() === '') ? '—' : String(v); }
function ascbMrDate(v, withTime) {
    if (!v) return '—';
    const d = new Date(String(v).replace(' ', 'T'));
    if (Number.isNaN(d.getTime())) return String(v);
    const opts = { month: 'short', day: 'numeric', year: 'numeric' };
    if (withTime) { opts.hour = 'numeric'; opts.minute = '2-digit'; }
    return d.toLocaleString('en-US', opts);
}
function ascbMrProgram(e) {
    const base = e.programCode || e.course || '';
    return [base, e.major].filter(Boolean).join(' - ') || '—';
}
function ascbMrFieldInput(key) { return ascbMrEl('mrf_' + key); }

async function ascbMrRequest(url, options) {
    try {
        const res = await fetch(url, options);
        let data = null;
        try { data = await res.json(); } catch (e) { data = null; }
        return { res, data };
    } catch (e) {
        return { res: null, data: null };
    }
}

/* ---------- current-name overlay for other modules ---------- */
async function ascbMasterCurrentNames() {
    const now = Date.now();
    if (ascbMrNamesCache && now - ascbMrNamesAt < 60000) return ascbMrNamesCache;
    const { data } = await ascbMrRequest(ASCB_MR_API + '?action=current_names', { headers: { Accept: 'application/json' }, credentials: 'same-origin' });
    ascbMrNamesCache = (data && data.ok && data.names) ? data.names : (ascbMrNamesCache || {});
    ascbMrNamesAt = now;
    return ascbMrNamesCache;
}
function ascbMrInvalidateNames() { ascbMrNamesCache = null; }
async function ascbMasterApplyCurrentNames(students, sep) {
    try {
        const names = await ascbMasterCurrentNames();
        (students || []).forEach(s => {
            const n = names[s.studentId];
            if (!n) return;
            if (sep) {
                const p = ascbNamePrintParts(n.surname, n.firstName, n.middleName, n.suffix, n.suffixPosition);
                s.fullName = [p.surname, p.first, [p.middle, p.tail].filter(Boolean).join(' ')].filter(Boolean).join(sep);
            } else {
                s.fullName = n.fullName || s.fullName;
            }
        });
    } catch (e) { /* never block the calling module */ }
    return students;
}

/* ---------- page load / search ---------- */
function ascbLoadMasterRecord() {
    const input = ascbMrEl('mrSearchInput');
    if (input && !input.dataset.bound) {
        input.dataset.bound = '1';
        input.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter' && ascbMrFirstResultId) { ev.preventDefault(); ascbMasterOpen(encodeURIComponent(ascbMrFirstResultId)); }
        });
    }
    if (input) input.focus();
}

function ascbMasterSearch() {
    clearTimeout(ascbMrSearchTimer);
    const q = (ascbMrEl('mrSearchInput')?.value || '').trim();
    const status = ascbMrEl('mrSearchStatus');
    const wrap = ascbMrEl('mrResultsWrapper');
    ascbMrFirstResultId = null;
    if (q.replace(/[\s,]/g, '').length < 2) {
        if (status) status.style.display = 'none';
        if (wrap) wrap.style.display = 'none';
        return;
    }
    if (status) { status.style.display = 'block'; status.textContent = 'Searching…'; }
    ascbMrSearchTimer = setTimeout(async () => {
        const token = ascbMrSearchGuard.start();
        const { res, data } = await ascbMrRequest(ASCB_MR_API + '?action=search&q=' + encodeURIComponent(q));
        if (!ascbMrSearchGuard.isCurrent(token)) return;
        if (!data || !data.ok) {
            if (status) { status.style.display = 'block'; status.textContent = (data && data.error) || 'Unable to search. Please try again.'; }
            if (wrap) wrap.style.display = 'none';
            return;
        }
        const rows = Array.isArray(data.rows) ? data.rows : [];
        if (!rows.length) {
            if (status) { status.style.display = 'block'; status.textContent = 'No student found.'; }
            if (wrap) wrap.style.display = 'none';
            return;
        }
        ascbMrFirstResultId = rows[0].studentId;
        ascbMrEl('mrResultsBody').innerHTML = rows.map(r => `<tr class="mr-row-link" onclick="ascbMasterOpen('${encodeURIComponent(r.studentId)}')">
            <td data-label="Student ID">${escapeHTML(r.studentId)}</td>
            <td data-label="Name">${escapeHTML(r.fullName)}${r.nameChanges ? `<span class="mr-formerly">Name changed ${r.nameChanges}×</span>` : ''}${r.active ? '' : '<span class="mr-formerly">Inactive</span>'}</td>
            <td data-label="Course">${escapeHTML(ascbMrText(r.course))}</td>
            <td data-label="Year / Term">${escapeHTML([r.yearLevel, r.trimester].filter(Boolean).join(' / ') || '—')}</td>
            <td data-label="Civil status">${escapeHTML(ascbMrText(r.civilStatus))}</td>
            <td><button type="button" class="btn btn-secondary" onclick="event.stopPropagation(); ascbMasterOpen('${encodeURIComponent(r.studentId)}')">Open</button></td>
        </tr>`).join('');
        if (status) status.style.display = 'none';
        if (wrap) wrap.style.display = 'block';
    }, 220);
}

async function ascbMasterSync() {
    const btn = ascbMrEl('mrSyncBtn');
    const status = ascbMrEl('mrSearchStatus');
    if (btn) btn.disabled = true;
    const { data } = await ascbMrRequest(ASCB_MR_API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'sync' }) });
    if (btn) btn.disabled = false;
    if (data && data.ok && status) {
        status.style.display = 'block';
        status.textContent = `Sync complete: ${data.added} student(s) added. ${data.total} in the Master Record.`;
    }
}

/* ---------- open / close a student ---------- */
async function ascbMasterOpen(encodedId) {
    const studentId = decodeURIComponent(encodedId);
    if (ascbMrIsDirty() && !confirm('You have unsaved changes for the open student. Discard them?')) return;
    const wrap = ascbMrEl('mrProfileWrapper');
    if (wrap) wrap.style.display = 'block';
    ascbMrEl('mrProfileName').textContent = 'Loading…';
    ascbMrEl('mrProfileId').textContent = studentId;
    wrap.scrollIntoView({ behavior: 'smooth', block: 'start' });
    const { data } = await ascbMrRequest(ASCB_MR_API + '?action=get&studentId=' + encodeURIComponent(studentId));
    if (!data || !data.ok) {
        ascbMrEl('mrProfileName').textContent = (data && data.error) || 'Unable to load the student.';
        return;
    }
    ascbMrRender(data);
    ascbMasterSwitchTab('personal');
}

function ascbMasterCloseProfile() {
    if (ascbMrIsDirty() && !confirm('You have unsaved changes. Close without saving?')) return;
    ascbMrData = null;
    const wrap = ascbMrEl('mrProfileWrapper');
    if (wrap) wrap.style.display = 'none';
}

/* ---------- rendering ---------- */
function ascbMrBuildForm() {
    if (ascbMrFormBuilt) return;
    const form = ascbMrEl('mrForm');
    if (!form) return;
    form.innerHTML = ASCB_MR_FIELDS.map(g => `
        <h4 class="mr-group-title">${escapeHTML(g.group)}</h4>
        <div class="mr-form-grid">${g.items.map(f => {
            const id = 'mrf_' + f.key;
            const span = f.span === 2 ? ' mr-span-2' : '';
            let control;
            if (f.type === 'select') {
                control = `<select id="${id}">${f.options.map(o => {
                    const ov = (o && typeof o === 'object') ? o.value : o;
                    const ol = (o && typeof o === 'object') ? o.label : (o || 'Not set');
                    return `<option value="${escapeHTML(ov)}">${escapeHTML(ol)}</option>`;
                }).join('')}</select>`;
            } else {
                control = `<input id="${id}" type="${f.type || 'text'}" ${f.max ? `maxlength="${f.max}"` : ''} ${f.placeholder ? `placeholder="${escapeHTML(f.placeholder)}"` : ''} autocomplete="off">`;
            }
            const hint = f.virtual ? `<small class="mr-field-hint" id="mrReasonHint">Only needed when the name changes.</small>` : '';
            return `<div class="f137-field${span}" id="mrw_${f.key}"><label for="${id}">${escapeHTML(f.label)}${f.required ? ' *' : ''}</label>${control}${hint}<small class="mr-field-error" id="mre_${f.key}"></small></div>`;
        }).join('')}</div>`).join('');
    form.addEventListener('input', ascbMrOnFormInput);
    form.addEventListener('change', ascbMrOnFormInput);
    ascbMrFormBuilt = true;
}

function ascbMrAllFields() { return ASCB_MR_FIELDS.reduce((a, g) => a.concat(g.items), []); }

function ascbMrFillForm() {
    const s = ascbMrData.student;
    ascbMrAllFields().forEach(f => {
        const el = ascbMrFieldInput(f.key);
        if (el) el.value = f.virtual ? '' : (s[f.key] === null || s[f.key] === undefined ? (f.key === 'suffixPosition' ? 'separate' : '') : s[f.key]);
    });
    ascbMrClearErrors();
    ascbMrOnFormInput();
}

function ascbMrFormValue(key) { return (ascbMrFieldInput(key)?.value || '').replace(/\s+/g, ' ').trim(); }

function ascbMrNameChanged() {
    if (!ascbMrData) return false;
    const s = ascbMrData.student;
    return ASCB_MR_NAME_KEYS.some(k => ascbMrFormValue(k) !== String(s[k] || '').trim());
}

function ascbMrIsDirty() {
    if (!ascbMrData || !ascbMrFormBuilt) return false;
    const wrap = ascbMrEl('mrProfileWrapper');
    if (!wrap || wrap.style.display === 'none') return false;
    const s = ascbMrData.student;
    return ascbMrAllFields().some(f => f.virtual ? ascbMrFormValue(f.key) !== '' : ascbMrFormValue(f.key) !== String(s[f.key] || '').trim());
}

function ascbMrOnFormInput() {
    const dirty = ascbMrIsDirty();
    const note = ascbMrEl('mrDirtyNote');
    if (note) note.style.display = dirty ? 'inline' : 'none';
    const changed = ascbMrNameChanged();
    const w = ascbMrEl('mrw_reason');
    if (w) w.classList.toggle('mr-reason-needed', changed);
    const hint = ascbMrEl('mrReasonHint');
    if (hint) hint.textContent = changed ? 'Required: the name is being changed. The old name is saved to Name history.' : 'Only needed when the name changes.';
}

function ascbMrClearErrors() {
    document.querySelectorAll('#mrForm .mr-field-error').forEach(e => { e.textContent = ''; });
    document.querySelectorAll('#mrForm .mr-invalid').forEach(e => e.classList.remove('mr-invalid'));
}
function ascbMrShowErrors(fields) {
    let first = null;
    Object.keys(fields || {}).forEach(k => {
        const err = ascbMrEl('mre_' + k);
        if (err) err.textContent = fields[k];
        const input = ascbMrFieldInput(k);
        if (input) { input.classList.add('mr-invalid'); if (!first) first = input; }
    });
    if (first) first.focus();
}

function ascbMrRender(data) {
    ascbMrData = data;
    ascbMrBuildForm();
    const s = data.student, c = data.card, st = data.stats;

    ascbMrEl('mrProfileName').textContent = s.fullName;
    ascbMrEl('mrProfileId').textContent = 'Student ID ' + s.studentId;

    const chips = [];
    const okStatus = c.statusLabel === 'Enrolled';
    chips.push(`<span class="mr-chip ${okStatus ? 'mr-chip-ok' : ''}">${escapeHTML(c.statusLabel)}</span>`);
    if (s.civilStatus) chips.push(`<span class="mr-chip">${escapeHTML(s.civilStatus)}</span>`);
    if (!s.active) chips.push('<span class="mr-chip mr-chip-warn">Inactive</span>');
    ascbMrEl('mrProfileChips').innerHTML = chips.join('');

    const initials = ((s.firstName || '?').charAt(0) + (s.surname || '').charAt(0)).toUpperCase();
    ascbMrEl('mrPhoto').innerHTML = `<span>${escapeHTML(initials)}</span>` + (s.hasPhoto
        ? `<img alt="" src="api/master_record_photo.php?studentId=${encodeURIComponent(s.studentId)}&v=${encodeURIComponent(s.photoVersion)}" onerror="this.remove()">` : '');
    const rm = ascbMrEl('mrPhotoRemoveBtn');
    if (rm) rm.style.display = s.hasPhoto ? '' : 'none';

    const item = (label, value) => `<div class="student360-info-item"><span class="student360-info-label">${escapeHTML(label)}</span><span class="student360-info-value">${escapeHTML(ascbMrText(value))}</span></div>`;
    ascbMrEl('mrCardGrid').innerHTML = [
        item('Course', [c.course, c.major].filter(Boolean).join(' - ')),
        item('Department', c.department),
        item('Current year', c.yearLevel),
        item('Current trimester', c.trimester),
        item('Current school year', c.schoolYear),
        item('Status', c.statusLabel),
    ].join('');
    ascbMrEl('mrReadonlyGrid').innerHTML = [
        item('Student ID', s.studentId),
        item('First enrollment', ascbMrDate(st.firstEnrollmentDate)),
        item('Total enrollments', st.totalEnrollments),
        item('Certificates issued', st.totalCertificates),
        item('Last updated', ascbMrDate(s.updatedAt, true) + (s.updatedByName ? ' by ' + s.updatedByName : '')),
    ].join('');

    ascbMrFillForm();
    ascbMrRenderEnrollments();
    ascbMrRenderGrades();
    ascbMrRenderCertificates();
    ascbMrRenderNames();
}

function ascbMrRenderEnrollments() {
    const rows = ascbMrData.enrollments;
    const badge = (e) => {
        const cls = e.archived ? '' : (e.status === 'approved' ? 'status-badge-approved' : (e.status === 'pending' ? 'status-badge-pending' : 'status-badge-rejected'));
        return `<span class="status-badge ${cls}" ${e.archiveReason ? `title="${escapeHTML(e.archiveReason)}"` : ''}>${escapeHTML(e.statusLabel)}</span>`;
    };
    ascbMrEl('mrEnrollmentsBody').innerHTML = rows.length ? rows.map(e => `<tr>
        <td data-label="School year">${escapeHTML(ascbMrText(e.schoolYear))}</td>
        <td data-label="Trimester">${escapeHTML(ascbMrText(e.trimester))}</td>
        <td data-label="Year level">${escapeHTML(ascbMrText(e.yearLevel))}</td>
        <td data-label="Program">${escapeHTML(ascbMrProgram(e))}</td>
        <td data-label="Type">${escapeHTML(ascbMrText(e.studentType))}</td>
        <td data-label="Department">${escapeHTML(ascbMrText(e.departmentName))}</td>
        <td data-label="Status">${badge(e)}</td>
        <td data-label="Recorded">${escapeHTML(ascbMrDate(e.createdAt))}</td></tr>`).join('')
        : '<tr><td colspan="8" class="mr-empty">No enrollment records.</td></tr>';
}

function ascbMrRenderGrades() {
    const terms = ascbMrData.grades;
    const box = ascbMrEl('mrGradesContainer');
    if (!terms.length) { box.innerHTML = '<div class="mr-empty">No grades recorded.</div>'; return; }
    box.innerHTML = terms.map((t, i) => {
        const title = ['SY ' + ascbMrText(t.schoolYear), t.trimester, t.yearLevel].filter(Boolean).join(' · ');
        const body = t.subjects.length ? `<div class="table-wrapper records-table-wrapper"><table class="records-table"><thead><tr><th>Code</th><th>Subject</th><th>Grade</th><th>Units</th></tr></thead><tbody>${
            t.subjects.map(s => `<tr><td data-label="Code">${escapeHTML(ascbMrText(s.code))}</td><td data-label="Subject">${escapeHTML(ascbMrText(s.description))}</td><td data-label="Grade">${escapeHTML(ascbMrText(s.grade))}</td><td data-label="Units">${escapeHTML(ascbMrText(s.units))}</td></tr>`).join('')
        }</tbody></table></div>` : '<div class="mr-empty">No subjects recorded for this term.</div>';
        return `<details class="mr-term" ${i === 0 ? 'open' : ''}><summary>${escapeHTML(title)}${t.archived ? ' (archived)' : ''}<small>${escapeHTML(String(t.totalUnits))} units</small></summary><div class="mr-term-body">${body}</div></details>`;
    }).join('');
}

function ascbMrRenderCertificates() {
    const rows = ascbMrData.certificates;
    ascbMrEl('mrCertificatesBody').innerHTML = rows.length ? rows.map(c => `<tr>
        <td data-label="Type">${escapeHTML(ascbMrText(c.type))}</td>
        <td data-label="Issued under name">${escapeHTML(ascbMrText(c.issuedName))}</td>
        <td data-label="OR #">${escapeHTML(ascbMrText(c.orNumber))}</td>
        <td data-label="School year">${escapeHTML(ascbMrText(c.academicYear))}</td>
        <td data-label="Term">${escapeHTML(ascbMrText(c.trimester))}</td>
        <td data-label="GWA">${escapeHTML(ascbMrText(c.gwa))}</td>
        <td data-label="Date issued">${escapeHTML(ascbMrDate(c.createdAt))}</td></tr>`).join('')
        : '<tr><td colspan="7" class="mr-empty">No certificates issued.</td></tr>';
}

function ascbMrRenderNames() {
    const s = ascbMrData.student, hist = ascbMrData.nameHistory;
    const now = `<p class="mr-name-now">Current name: <strong>${escapeHTML(s.fullName)}</strong></p>`;
    if (!hist.length) {
        ascbMrEl('mrNamesContainer').innerHTML = now + '<div class="mr-empty">No name changes yet.</div>';
        return;
    }
    ascbMrEl('mrNamesContainer').innerHTML = now + '<ul class="student360-timeline">' + hist.map(h => `
        <li class="student360-timeline-item"><div class="student360-timeline-dot"></div>
        <div class="student360-timeline-body">
            <strong>${escapeHTML(h.previous)}<span class="mr-name-arrow">→</span>${escapeHTML(h.current)}</strong>
            <span class="student360-timeline-meta">${escapeHTML(ascbMrDate(h.updatedAt, true))}${h.byName ? ' · ' + escapeHTML(h.byName) : ''}</span>
            <p>Reason: ${escapeHTML(ascbMrText(h.reason))}</p>
        </div></li>`).join('') + '</ul>';
}

function ascbMasterSwitchTab(tab) {
    document.querySelectorAll('#mrTabs .records-tab').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
    ['personal', 'enrollments', 'grades', 'certificates', 'names'].forEach(t => {
        const p = ascbMrEl('mrPanel-' + t);
        if (p) p.style.display = (t === tab) ? '' : 'none';
    });
}

/* ---------- save ---------- */
function ascbMasterDiscard() {
    if (!ascbMrData) return;
    ascbMrFillForm();
}

async function ascbMasterSave() {
    if (!ascbMrData) return;
    ascbMrClearErrors();
    const s = ascbMrData.student;
    const errs = {};
    if (!ascbMrFormValue('surname')) errs.surname = 'Surname is required.';
    if (!ascbMrFormValue('firstName')) errs.firstName = 'First name is required.';
    if (ascbMrNameChanged() && !ascbMrFormValue('reason')) errs.reason = 'Enter the reason for the name change.';
    if (Object.keys(errs).length) { ascbMrShowErrors(errs); return; }

    const payload = { action: 'save', studentId: s.studentId, version: s.version };
    ascbMrAllFields().forEach(f => { payload[f.key] = ascbMrFormValue(f.key); });

    const btn = ascbMrEl('mrSaveBtn');
    if (btn) btn.disabled = true;
    const { res, data } = await ascbMrRequest(ASCB_MR_API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (btn) btn.disabled = false;

    if (!data || !data.ok) {
        if (data && data.fields) ascbMrShowErrors(data.fields);
        if (res && res.status === 409 && confirm('Someone else changed this record. Reload the latest version? Your unsaved edits will be lost.')) {
            const dirtyOff = ascbMrData; ascbMrData = null; // skip the discard prompt
            await ascbMasterOpen(encodeURIComponent(dirtyOff.student.studentId));
        }
        return;
    }
    ascbMrInvalidateNames();
    ascbMrRender(data);
    if (data.nameChanged) ascbMasterSwitchTab('names');
}

/* ---------- update after marriage ---------- */
function ascbMasterOpenMarriage() {
    if (!ascbMrData) return;
    if (ascbMrIsDirty() && !confirm('Unsaved changes on the form will be lost. Continue?')) return;
    ascbMrFillForm();
    ascbMrEl('mrMarriageCurrent').value = ascbMrData.student.fullName;
    ascbMrEl('mrMarriageSurname').value = '';
    ascbMrEl('mrMarriageReason').value = 'Marriage';
    ascbMrEl('mrMarriageConfirm').checked = false;
    ascbMrEl('mrMarriageSurnameError').textContent = '';
    ascbMrEl('mrMarriageReasonError').textContent = '';
    ascbMasterMarriagePreview();
    ascbMrEl('mrMarriageModal').classList.add('active');
    setTimeout(() => ascbMrEl('mrMarriageSurname').focus(), 30);
}
function ascbMasterCloseMarriage() {
    const m = ascbMrEl('mrMarriageModal');
    if (m) m.classList.remove('active');
}
function ascbMasterMarriagePreview() {
    if (!ascbMrData) return;
    const s = ascbMrData.student;
    const ns = (ascbMrEl('mrMarriageSurname').value || '').replace(/\s+/g, ' ').trim();
    const nat = (surname) => { const p = ascbNamePrintParts(surname, s.firstName, s.middleName, s.suffix, s.suffixPosition); return [p.first, p.middle, p.surname, p.tail].filter(Boolean).join(' '); };
    ascbMrEl('mrMarriagePreview').textContent = ns ? `${nat(s.surname)}  →  ${nat(ns)}` : '';
    const ok = ns !== '' && ns !== s.surname && ascbMrEl('mrMarriageConfirm').checked;
    ascbMrEl('mrMarriageSubmit').disabled = !ok;
}
async function ascbMasterSubmitMarriage() {
    if (!ascbMrData) return;
    ascbMrEl('mrMarriageSurnameError').textContent = '';
    ascbMrEl('mrMarriageReasonError').textContent = '';
    const s = ascbMrData.student;
    const payload = {
        action: 'marriage', studentId: s.studentId, version: s.version,
        newSurname: ascbMrEl('mrMarriageSurname').value, reason: ascbMrEl('mrMarriageReason').value,
    };
    const btn = ascbMrEl('mrMarriageSubmit');
    btn.disabled = true;
    const { data } = await ascbMrRequest(ASCB_MR_API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (!data || !data.ok) {
        btn.disabled = false;
        if (data && data.fields) {
            if (data.fields.newSurname) ascbMrEl('mrMarriageSurnameError').textContent = data.fields.newSurname;
            if (data.fields.reason) ascbMrEl('mrMarriageReasonError').textContent = data.fields.reason;
        }
        return;
    }
    ascbMasterCloseMarriage();
    ascbMrInvalidateNames();
    ascbMrRender(data);
    ascbMasterSwitchTab('names');
}

/* ---------- photo ---------- */
async function ascbMasterUploadPhoto(input) {
    const file = input && input.files && input.files[0];
    if (!file || !ascbMrData) return;
    const okType = ['image/jpeg', 'image/png', 'image/webp'].includes(file.type);
    if (!okType) { alert('Only JPG, PNG or WebP photos are allowed.'); input.value = ''; return; }
    if (file.size > 2 * 1024 * 1024) { alert('The photo is too large. Maximum size is 2 MB.'); input.value = ''; return; }
    const fd = new FormData();
    fd.append('action', 'photo');
    fd.append('studentId', ascbMrData.student.studentId);
    fd.append('photo', file);
    const { data } = await ascbMrRequest(ASCB_MR_API, { method: 'POST', body: fd });
    input.value = '';
    if (data && data.ok) {
        const wasDirty = ascbMrIsDirty();
        if (wasDirty) { /* keep the person's typing: only refresh the header + version */ ascbMrData = Object.assign({}, data, { student: data.student }); ascbMrRenderHeaderOnly(); }
        else ascbMrRender(data);
    }
}
function ascbMrRenderHeaderOnly() {
    const s = ascbMrData.student;
    const initials = ((s.firstName || '?').charAt(0) + (s.surname || '').charAt(0)).toUpperCase();
    ascbMrEl('mrPhoto').innerHTML = `<span>${escapeHTML(initials)}</span>` + (s.hasPhoto
        ? `<img alt="" src="api/master_record_photo.php?studentId=${encodeURIComponent(s.studentId)}&v=${encodeURIComponent(s.photoVersion)}" onerror="this.remove()">` : '');
    const rm = ascbMrEl('mrPhotoRemoveBtn');
    if (rm) rm.style.display = s.hasPhoto ? '' : 'none';
}
async function ascbMasterRemovePhoto() {
    if (!ascbMrData || !confirm('Remove this student\'s photo?')) return;
    const { data } = await ascbMrRequest(ASCB_MR_API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'remove_photo', studentId: ascbMrData.student.studentId }) });
    if (data && data.ok) {
        if (ascbMrIsDirty()) { ascbMrData = data; ascbMrRenderHeaderOnly(); } else ascbMrRender(data);
    }
}

/* ---------- Certificates form: fill the CURRENT name for renamed students ---------- */
(function () {
    const idEl = document.getElementById('studentId');
    if (!idEl) return;
    idEl.addEventListener('change', async () => {
        const nameEl = document.getElementById('studentName');
        if (!nameEl || nameEl.value.trim() !== '' || !idEl.value.trim()) return;
        const names = await ascbMasterCurrentNames();
        const n = names[idEl.value.trim()];
        if (n && n.fullName) {
            nameEl.value = n.fullName;
            if (typeof window.ascbNotify === 'function') window.ascbNotify('Name filled from the Master Record.', 'success');
        }
    });
})();


/* =========================================================
   SUBJECT GRADEBOOK — ENCODING HISTORY
   ========================================================= */
let ascbGradebookHistoryPage = 1;
function ascbGradebookHistoryOpen(){
    const m=ascbGradebookEl('gradebookHistoryModal'); if(!m)return;
    const s=ascbGradebookCurrent;
    const sub=ascbGradebookEl('gradebookHistorySubtitle');
    if(sub){
        sub.textContent=s
            ? `Recent encoding history • ${s.course_code||'Subject'} — ${s.description||''} • ${s.trimester||''} / ${s.school_year||''}`
            : 'Recent grades encoded in Subject Gradebook.';
    }
    const q=ascbGradebookEl('gradebookHistorySearch'); if(q)q.value='';
    m.classList.add('active');
    ascbGradebookHistoryLoad(1);
}
function ascbGradebookHistoryClose(){const m=ascbGradebookEl('gradebookHistoryModal');if(m)m.classList.remove('active');}
function ascbGradebookHistoryView(id){
    const r=(window.ascbGradebookHistoryRows||[]).find(x=>Number(x.id)===Number(id));
    if(!r)return;
    alert([
        'GRADE ENCODING DETAILS',
        '',
        'Student ID: '+(r.student_id||'—'),
        'Student: '+(r.student_name||'—'),
        'Subject: '+[(r.course_code||'—'),(r.description||'—')].join(' — '),
        'School Year: '+(r.school_year||'—'),
        'Term: '+(r.trimester||'—'),
        'Previous Grade: '+(r.old_grade||'—'),
        'New Grade: '+(r.new_grade||'—'),
        'Encoded By: '+(r.encoded_by_name||'—'),
        'Date/Time: '+(r.encoded_at||'—')
    ].join('\n'));
}
async function ascbGradebookHistoryLoad(page=1){
    const body=ascbGradebookEl('gradebookHistoryBody'),status=ascbGradebookEl('gradebookHistoryStatus');
    ascbGradebookHistoryPage=Math.max(1,Number(page)||1);
    const s=ascbGradebookCurrent;
    const q=String(ascbGradebookEl('gradebookHistorySearch')?.value||'').trim();
    if(body)body.innerHTML='<tr><td colspan="9" class="records-empty">Loading history…</td></tr>';
    try{
        const p=new URLSearchParams({action:'history',page:String(ascbGradebookHistoryPage),limit:'30',q});
        if(s){p.set('school_year',s.school_year||'');p.set('trimester',s.trimester||'');p.set('course_code',s.course_code||'');p.set('description',s.description||'');}
        const res=await fetch('api/professor_gradebook.php?'+p.toString());
        const data=await res.json(); if(!data?.ok)throw new Error(data?.error||'Unable to load grade history.');
        window.ascbGradebookHistoryRows=Array.isArray(data.rows)?data.rows:[];
        if(body)body.innerHTML=window.ascbGradebookHistoryRows.length?window.ascbGradebookHistoryRows.map(r=>`<tr>
            <td data-label="Date / Time">${escapeHTML(r.encoded_at||'—')}</td>
            <td data-label="Student ID">${escapeHTML(r.student_id||'—')}</td>
            <td data-label="Student Name">${escapeHTML(r.student_name||'—')}</td>
            <td data-label="Subject"><strong>${escapeHTML(r.course_code||'—')}</strong><br><small>${escapeHTML(r.description||'—')}</small></td>
            <td data-label="Term">${escapeHTML((r.school_year||'—')+' / '+(r.trimester||'—'))}</td>
            <td data-label="Previous" class="gradebook-history-old">${escapeHTML(r.old_grade||'—')}</td>
            <td data-label="New Grade" class="gradebook-history-new">${escapeHTML(r.new_grade||'—')}</td>
            <td data-label="Encoded By">${escapeHTML(r.encoded_by_name||'—')}</td>
            <td data-label="View"><button type="button" class="btn btn-secondary btn-sm" onclick="ascbGradebookHistoryView(${Number(r.id)})">View</button></td>
        </tr>`).join(''):'<tr><td colspan="9" class="records-empty">No newly encoded grades found for this selection.</td></tr>';
        if(typeof ascbRenderPagination==='function')ascbRenderPagination('gradebookHistoryPagination',Number(data.page||1),Math.max(1,Number(data.pages||1)),Number(data.total||0),Number(data.limit||30),'ascbGradebookHistoryLoad');
        if(status)status.style.display='none';
    }catch(e){
        if(status){status.style.display='block';status.textContent=e.message||'Unable to load grade history.';}
        if(body)body.innerHTML='<tr><td colspan="9" class="records-empty">Unable to load grade history.</td></tr>';
    }
}

/* =========================================================
   AUTOMATIC BACKUP SCHEDULE (Departments & Backup tab)
   ========================================================= */
var ASCB_BACKUP_TICK_TIMER = null;
var ASCB_BACKUP_PAGE = 1;      /* kasalukuyang page ng listahan ng backup files */
var ASCB_BACKUP_PER_PAGE = 10; /* ilang file bawat page (5/10/20/50) */
function ascbBackupPageParams(){return {page:ASCB_BACKUP_PAGE,perPage:ASCB_BACKUP_PER_PAGE};}
function ascbBackupEl(id){return document.getElementById(id);}
function ascbBackupMsg(text,isErr){const st=ascbBackupEl('abk_status');if(!st)return;if(!text){st.style.display='none';return;}st.style.display='block';st.textContent=text;st.style.color=isErr?'#b42318':'';}
function ascbBackupToggleWeekday(){const f=ascbBackupEl('abk_frequency'),w=ascbBackupEl('abk_weekday_field');if(f&&w)w.style.display=f.value==='weekly'?'block':'none';}
function ascbBackupFmtSize(n){if(n===null||n===undefined)return '—';n=Number(n);if(n<1024)return n+' B';if(n<1048576)return (n/1024).toFixed(1)+' KB';return (n/1048576).toFixed(1)+' MB';}
function ascbBackupFmtDate(s){if(!s)return '—';const d=new Date(String(s).replace(' ','T'));if(isNaN(d.getTime()))return escapeHTML(String(s));return d.toLocaleString('en-PH',{year:'numeric',month:'short',day:'numeric',hour:'numeric',minute:'2-digit',hour12:true});}
function ascbBackupRender(data,fillForm){
  if(!data||!data.settings)return;
  const s=data.settings;
  if(fillForm){
    ascbBackupEl('abk_enabled').value=String(s.enabled?1:0);
    ascbBackupEl('abk_frequency').value=s.frequency==='weekly'?'weekly':'daily';
    ascbBackupEl('abk_weekday').value=String(s.weekday);
    ascbBackupEl('abk_time').value=s.time||'02:00';
    ascbBackupEl('abk_keep').value=String(s.keep||7);
    ascbBackupEl('abk_sql').checked=!!s.includeSql;
    ascbBackupEl('abk_dept').checked=!!s.includeDepartments;
    ascbBackupToggleWeekday();
  }
  const sum=ascbBackupEl('abk_summary');
  if(sum){
    let h='';
    h+='<div><strong>Status:</strong> '+(s.enabled?'<span style="color:#067647;">ON</span>':'OFF')+(s.running?' — <em>may tumatakbong backup…</em>':'')+'</div>';
    if(s.enabled)h+='<div><strong>Next backup:</strong> '+ascbBackupFmtDate(s.nextRunAt)+'</div>';
    if(s.lastRunAt)h+='<div><strong>Last run:</strong> '+ascbBackupFmtDate(s.lastRunAt)+' — '+escapeHTML(s.lastStatus||'')+(s.lastMessage?' ('+escapeHTML(s.lastMessage)+')':'')+'</div>';
    sum.innerHTML=h;
  }
  const url=ascbBackupEl('abk_cron_url');
  if(url&&s.cronToken){url.value=new URL('api/backup_cron.php?token='+encodeURIComponent(s.cronToken),window.location.href).href;}
  const body=ascbBackupEl('abk_filesBody');
  if(body){
    const files=Array.isArray(data.files)?data.files:[];
    body.innerHTML=files.length?files.map(f=>'<tr><td>'+ascbBackupFmtDate(f.createdAt)+'</td><td>'+escapeHTML(f.type)+((f.schoolYear||f.term)?'<div style="font-size:.85em;opacity:.75;">'+escapeHTML([f.schoolYear,f.term].filter(Boolean).join(' • '))+'</div>':'')+'</td><td style="word-break:break-all;">'+escapeHTML(f.filename)+'</td><td>'+ascbBackupFmtSize(f.size)+'</td><td>'+(f.available?'<button type="button" class="btn btn-secondary btn-sm" onclick="ascbBackupDownload('+Number(f.id)+')">Download</button>':'<span style="opacity:.6;">Removed</span>')+'</td></tr>').join(''):'<tr><td colspan="5" class="records-empty">Wala pang automatic backup.</td></tr>';
  }
  /* Pagination (server-side) — sinusunod ang page/perPage na ibinalik ng server (na-clamp na). */
  const pg=data.pagination;
  if(pg){
    ASCB_BACKUP_PAGE=Number(pg.page)||1;
    ASCB_BACKUP_PER_PAGE=Number(pg.perPage)||10;
    const sel=ascbBackupEl('abk_perPage');if(sel)sel.value=String(ASCB_BACKUP_PER_PAGE);
    ascbRenderPagination('abk_pagination',ASCB_BACKUP_PAGE,Math.max(1,Number(pg.totalPages)||1),Number(pg.total)||0,ASCB_BACKUP_PER_PAGE,'ascbBackupGoToPage');
  }
}
async function ascbBackupGoToPage(page){
  ascbBackupMsg('',false);
  const data=await ascbApiPost('api/backup_schedule.php',Object.assign({action:'list'},ascbBackupPageParams(),{page:Number(page)||1}));
  if(!data||!data.ok){ascbBackupMsg((data&&data.error)||'Unable to load the backup list.',true);return;}
  ascbBackupRender(data,false);
}
function ascbBackupSetPerPage(n){
  ASCB_BACKUP_PER_PAGE=Number(n)||10;
  ASCB_BACKUP_PAGE=1; /* balik sa page 1 kapag nag-iba ang laki ng page */
  ascbBackupGoToPage(1);
}
async function ascbBackupScheduleLoad(){
  if(!ascbBackupEl('abk_enabled'))return;
  ascbBackupMsg('Loading backup schedule…',false);
  const data=await ascbApiPost('api/backup_schedule.php',Object.assign({action:'list'},ascbBackupPageParams()));
  if(!data.ok){ascbBackupMsg(data.error||'Unable to load the backup schedule.',true);return;}
  ascbBackupMsg('',false);
  ascbBackupRender(data,true);
}
async function ascbBackupScheduleSave(){
  const payload={action:'save',enabled:ascbBackupEl('abk_enabled').value==='1'?1:0,frequency:ascbBackupEl('abk_frequency').value,weekday:Number(ascbBackupEl('abk_weekday').value),time:ascbBackupEl('abk_time').value,keep:Number(ascbBackupEl('abk_keep').value||7),includeSql:ascbBackupEl('abk_sql').checked?1:0,includeDepartments:ascbBackupEl('abk_dept').checked?1:0,page:ASCB_BACKUP_PAGE,perPage:ASCB_BACKUP_PER_PAGE};
  if(!payload.time){ascbBackupMsg('Pumili ng oras ng backup.',true);return;}
  const btn=ascbBackupEl('abk_saveBtn');if(btn)btn.disabled=true;
  const data=await ascbApiPost('api/backup_schedule.php',payload);
  if(btn)btn.disabled=false;
  if(!data.ok){ascbBackupMsg(data.error||'Unable to save the schedule.',true);return;}
  ascbBackupMsg(payload.enabled?'Na-save ang schedule. Susunod na backup: '+ascbBackupFmtDate(data.settings.nextRunAt).replace(/<[^>]*>/g,''):'Na-save. Naka-OFF ang automatic backup.',false);
  ascbBackupRender(data,true);
}
async function ascbBackupRunNow(){
  if(!confirm('Gumawa ng backup ngayon? Maaaring tumagal ito depende sa laki ng database.'))return;
  const btn=ascbBackupEl('abk_runBtn');if(btn){btn.disabled=true;btn.textContent='Backing up…';}
  ascbBackupMsg('Gumagawa ng backup… huwag isara ang page.',false);
  ASCB_BACKUP_PAGE=1;
  const data=await ascbApiPost('api/backup_schedule.php',Object.assign({action:'run_now'},ascbBackupPageParams()));
  if(btn){btn.disabled=false;btn.textContent='Run Backup Now';}
  if(data&&data.settings)ascbBackupRender(data,false);
  if(!data.ok){ascbBackupMsg(data.error||'Backup failed.',true);return;}
  ascbBackupMsg('Tapos na ang backup: '+(data.run&&data.run.message?data.run.message:'OK'),false);
}
async function ascbBackupRegenToken(){
  if(!confirm('Gumawa ng bagong token? Hindi na gagana ang lumang URL — kailangang i-update sa pinger mo.'))return;
  const data=await ascbApiPost('api/backup_schedule.php',Object.assign({action:'regen_token'},ascbBackupPageParams()));
  if(!data.ok){ascbBackupMsg(data.error||'Unable to create a new token.',true);return;}
  ascbBackupRender(data,false);ascbBackupMsg('Bagong cron URL na ang ipinapakita.',false);
}
function ascbBackupCopyCron(){
  const el=ascbBackupEl('abk_cron_url');if(!el||!el.value)return;
  el.select();
  if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(el.value).then(()=>ascbBackupMsg('Na-copy ang URL.',false),()=>{document.execCommand('copy');ascbBackupMsg('Na-copy ang URL.',false);});}
  else{document.execCommand('copy');ascbBackupMsg('Na-copy ang URL.',false);}
}
function ascbBackupDownload(id){window.location.href='api/backup_download.php?id='+encodeURIComponent(id)+'&csrf='+encodeURIComponent(ASCB_CSRF_TOKEN);}
/* Pseudo-cron: habang bukas ang dashboard ng may permission, tinatawag bawat minuto ang "tick"
   (gagawa lang ng backup kung due na ang oras). */
async function ascbBackupTick(){
  if(typeof ASCB_PERMISSIONS==='undefined'||!ASCB_PERMISSIONS||!ASCB_PERMISSIONS.fullBackup)return;
  try{
    const r=await fetch('api/backup_schedule.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'tick',page:1,perPage:ASCB_BACKUP_PER_PAGE})});
    if(r.status===401||r.status===403){if(ASCB_BACKUP_TICK_TIMER){clearInterval(ASCB_BACKUP_TICK_TIMER);ASCB_BACKUP_TICK_TIMER=null;}return;}
    const data=await r.json();
    if(data&&data.ok&&data.ran&&ascbBackupEl('abk_summary'))ascbBackupRender(data,false);
  }catch(e){/* silent */}
}
if(!ASCB_BACKUP_TICK_TIMER){ASCB_BACKUP_TICK_TIMER=setInterval(ascbBackupTick,60000);setTimeout(ascbBackupTick,8000);}

/* Grade approval workflow: department/course/subject filters and consolidated registrar queue. */
let ASCB_GRADE_APPROVAL_ROWS=[];
let ASCB_GBA_TOTAL=null;
function ascbGradebookApprovalsClose(){const m=document.getElementById('gradebookApprovalsModal');if(m)m.classList.remove('active');}
async function ascbGradebookApprovalsOpen(){const m=document.getElementById('gradebookApprovalsModal');if(m)m.classList.add('active');await ascbGradebookApprovalsLoad();}
/* Ang subject ay nasa ITEM level (isang submission = lahat ng binago sa isang student, maraming subject).
   Kaya ang filter at display ay dapat per item, hindi per submission. */
function ascbGbaSubj(it,x){return [it&&it.subject_code||x&&x.subject_code,it&&it.subject_description||x&&x.subject_description].filter(Boolean).join(' — ');}
function ascbGbaSubjHead(x){const its=x.items||[],codes=[...new Set(its.map(i=>String(i.subject_code||'').trim()).filter(Boolean))];if(codes.length<=1)return ascbGbaSubj(its[0],x)||'—';return codes.length+' subjects: '+codes.slice(0,3).join(', ')+(codes.length>3?' …':'');}
function ascbGbaSubjItems(x,subject){return subject?(x.items||[]).filter(it=>ascbGbaSubj(it,x)===subject):(x.items||[]);}
function ascbGbaVisibleItems(x,subject,search){let its=ascbGbaSubjItems(x,subject);if(search){const head=[x.id,x.department_name,x.course_name,x.subject_code,x.subject_description,x.school_year,x.term,x.submitted_by_name,x.unit_head_name].join(' ').toLowerCase().includes(search);if(!head)its=its.filter(i=>[i.student_id,i.student_name,i.new_grade,i.course_name].join(' ').toLowerCase().includes(search));}return its;}
function ascbGbaSelItems(st,x){const ids=st&&st.sel&&st.sel[x.id];return ids?(x.items||[]).filter(it=>ids.indexOf(Number(it.id))>-1):(x.items||[]);}
function ascbGbaEsc(v){return typeof escapeHTML==='function'?escapeHTML(String(v??'')):String(v??'').replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]));}
function ascbGbaDepartmentChanged(){ascbGradebookApprovalsLoad();}
function ascbGbaFillSelect(id,values,label){const el=document.getElementById(id);if(!el)return;const old=el.value;el.innerHTML='<option value="">'+label+'</option>'+values.map(v=>'<option value="'+ascbGbaEsc(v)+'">'+ascbGbaEsc(v)+'</option>').join('');if(values.includes(old))el.value=old;}
async function ascbGradebookApprovalsLoad(){const deptSel=ascbGbaRole()==='ADMIN STAFF'?'':(document.getElementById('gbaDepartmentFilter')?.value||'').trim();const box=document.getElementById('gradebookApprovalsList'),status=document.getElementById('gradebookApprovalsStatus');if(box)box.innerHTML='<div class="gradebook-approvals-state"><span class="gradebook-approval-spinner"></span>Loading grade submissions…</div>';if(status){status.textContent='';status.style.display='none';}try{const r=await fetch('api/gradebook_approvals.php?action=list'+(deptSel?'&department='+encodeURIComponent(deptSel):''),{cache:'no-store'}),d=await ascbReadJson(r);if(!r.ok||!d.ok)throw new Error(d.error||'Unable to load approvals.');ASCB_GRADE_APPROVAL_ROWS=d.rows||[];ASCB_GBA_TOTAL=(typeof d.total==='number')?d.total:null;const uniq=k=>[...new Set(ASCB_GRADE_APPROVAL_ROWS.map(x=>String(x[k]||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b));ascbGbaFillSelect('gbaDepartmentFilter',[...new Set([...(d.departments||[]),...uniq('department_name')])].sort((a,b)=>a.localeCompare(b)),'All departments');ascbGbaFillSelect('gbaCourseFilter',uniq('course_name'),'All courses');ascbGbaFillSelect('gbaSubjectFilter',[...new Set(ASCB_GRADE_APPROVAL_ROWS.flatMap(x=>(x.items||[]).map(it=>ascbGbaSubj(it,x))).filter(Boolean))].sort((a,b)=>a.localeCompare(b)),'All subjects');ascbGbaFillSelect('gbaTermFilter',[...new Set(ASCB_GRADE_APPROVAL_ROWS.map(x=>(x.school_year||'—')+' / '+(x.term||'—')))].sort((a,b)=>a.localeCompare(b)),'All school years / terms');if(ascbGbaRole()==='ADMIN STAFF')ascbGbaSyncRejected(ASCB_GRADE_APPROVAL_ROWS.filter(x=>x.status==='REJECTED'));ascbGradebookApprovalsRender();}catch(e){if(status){status.textContent=e.message||'Unable to load approvals.';status.style.display='block';}if(box)box.innerHTML='<div class="gradebook-approvals-state gradebook-approvals-error">Could not load grade submissions. Use Refresh to try again.</div>';}}
function ascbGradebookApprovalsRender(){const box=document.getElementById('gradebookApprovalsList');if(!box)return;const val=id=>(document.getElementById(id)?.value||'').trim(),dept=val('gbaDepartmentFilter'),course=val('gbaCourseFilter'),subject=val('gbaSubjectFilter'),schoolTerm=val('gbaTermFilter'),search=val('gbaSearchFilter').toLowerCase();const rows=ASCB_GRADE_APPROVAL_ROWS.filter(x=>(!dept||String(x.department_name||'')===dept)&&(!course||String(x.course_name||'')===course)&&(!subject||(x.items||[]).some(it=>ascbGbaSubj(it,x)===subject))&&(!schoolTerm||((x.school_year||'—')+' / '+(x.term||'—'))===schoolTerm)&&(!search||[x.id,x.department_name,x.course_name,x.subject_code,x.subject_description,x.school_year,x.term,x.submitted_by_name,...(x.items||[]).flatMap(i=>[i.student_id,i.student_name,i.new_grade])].join(' ').toLowerCase().includes(search)));const currentRole=String(ASCB_CURRENT_USER?.role||'').toUpperCase(),registrar=currentRole==='SCHOOL REGISTRAR',unitHead=currentRole==='UNIT HEAD',adminStaff=currentRole==='ADMIN STAFF',bulk=document.getElementById('gbaBulkApproveBtn');if(bulk){bulk.style.display=(registrar||unitHead)?'inline-flex':'none';bulk.textContent=unitHead?'Verify all filtered':'Approve all filtered';bulk.disabled=!rows.some(x=>x.status===(unitHead?'PENDING_UNIT_HEAD':'PENDING_REGISTRAR'));}const bulkRej=document.getElementById('gbaBulkRejectBtn');if(bulkRej){bulkRej.style.display=(registrar||unitHead)?'inline-flex':'none';bulkRej.disabled=!rows.some(x=>x.status===(unitHead?'PENDING_UNIT_HEAD':'PENDING_REGISTRAR'));}const esc=ascbGbaEsc,sl={PENDING_UNIT_HEAD:'Pending Unit Head',PENDING_REGISTRAR:'Pending School Registrar',APPROVED:'Approved',REJECTED:'Rejected'};{const sm=document.getElementById('gbaSummary');if(sm){const gc=rows.reduce((n,x)=>n+ascbGbaSubjItems(x,subject).length,0);sm.innerHTML='<span class="gba-chip"><b>'+rows.length+'</b> submission'+(rows.length===1?'':'s')+'</span><span class="gba-chip"><b>'+gc+'</b> grade'+(gc===1?'':'s')+'</span>'+(rows.length!==ASCB_GRADE_APPROVAL_ROWS.length?'<span class="gba-chip gba-chip-muted">filtered from '+ASCB_GRADE_APPROVAL_ROWS.length+'</span>':'')+((ASCB_GBA_TOTAL!==null&&ASCB_GBA_TOTAL>ASCB_GRADE_APPROVAL_ROWS.length)?'<span class="gba-chip gba-chip-muted" title="Only the oldest 300 are loaded at a time. Approve or reject some, or pick a department.">showing oldest '+ASCB_GRADE_APPROVAL_ROWS.length+' of '+ASCB_GBA_TOTAL+' pending</span>':'');}}if(!rows.length){box.innerHTML='<div class="gradebook-approvals-state"><strong>No submissions match these filters</strong><span>Try clearing a filter or refresh the queue.</span></div>';return;}if(registrar||unitHead){const flat=[];rows.forEach(x=>{const its=ascbGbaVisibleItems(x,subject,search);its.forEach(it=>flat.push({x,it}));});if(!flat.length){box.innerHTML='<div class="gradebook-approvals-state"><strong>No grades match these filters</strong><span>Try clearing a filter or refresh the queue.</span></div>';return;}const fmtU=v=>(v===null||v===undefined||v==='')?'—':String(Number(v));box.innerHTML='<div class="gradebook-approval-table-wrap"><table class="records-table gradebook-approval-table gba-final-table"><thead><tr><th>Student ID</th><th>Student Name</th><th>Course/Program</th><th>Course Code</th><th>Course Description</th><th>School Year</th><th>Grades</th><th>Units</th><th>Submitted By</th><th>Verify By</th><th>Action</th></tr></thead><tbody>'+flat.map(({x,it})=>{const ng=String(it.new_grade||'').trim(),og=String(it.old_grade||'').trim(),changed=og!==''&&og!==ng;return '<tr><td data-label="Student ID">'+esc(it.student_id||'—')+'</td><td data-label="Student Name">'+esc(it.student_name||'—')+'</td><td data-label="Course/Program">'+esc(it.course_name||x.course_name||'—')+'</td><td data-label="Course Code">'+esc(it.subject_code||x.subject_code||'—')+'</td><td data-label="Course Description">'+esc(it.subject_description||x.subject_description||'—')+'</td><td data-label="School Year">'+esc(x.school_year||'—')+'<small style="display:block;color:var(--muted)">'+esc(x.term||'—')+'</small></td><td data-label="Grades"><strong>'+esc(ng||'—')+'</strong>'+(changed?'<small style="display:block;color:var(--muted)">prev: '+esc(og)+'</small>':'')+'</td><td data-label="Units">'+esc(fmtU(it.new_units))+'</td><td data-label="Submitted By">'+esc(x.submitted_by_name||'—')+(Number(x.resubmit_count||0)>0?'<small class="gba-resub-chip" style="display:inline-block;margin-top:3px" title="'+esc('Re-submitted after rejection'+(x.last_rejection_reason?'. Previous reason: '+x.last_rejection_reason:'')+(x.resubmit_note?'. Encoder note: '+x.resubmit_note:''))+'">Re-submitted ×'+Number(x.resubmit_count)+'</small>':'')+(x.resubmit_note?'<small style="display:block;color:var(--muted)" title="Encoder note">“'+esc(x.resubmit_note)+'”</small>':'')+'</td><td data-label="Verify By">'+esc(x.unit_head_name||(unitHead?'Pending':'—'))+'</td><td data-label="Action"><div style="display:flex;gap:6px;flex-wrap:wrap">'+((unitHead||registrar)?'<button type="button" class="btn btn-add gba-row-approve" title="Approve this grade only (submission #'+Number(x.id)+')" onclick="ascbGradebookApprovalAction('+Number(x.id)+',\'approve\','+Number(it.id)+')">'+(unitHead?(x.submitted_by_role==='SCHOOL REGISTRAR'?'Approve & Finalize':'Verify'):'Approve & Finalize')+'</button>':'')+'<button type="button" class="btn btn-secondary gba-row-reject" title="Reject this grade only (submission #'+Number(x.id)+')" onclick="ascbGradebookApprovalAction('+Number(x.id)+',\'reject\','+Number(it.id)+')">Reject</button></div></td></tr>';}).join('')+'</tbody></table></div>'; }else{box.innerHTML=rows.map(x=>'<article class="gradebook-approval-submission"><div class="gradebook-approval-submission-head"><div class="gradebook-approval-heading"><span class="gradebook-approval-id">Submission #'+Number(x.id)+'</span><h4>'+esc(x.department_name||'Department')+' · '+esc(x.course_name||'Course')+' · '+esc(ascbGbaSubjHead(x))+'</h4><p>'+esc((x.school_year||'—')+' / '+(x.term||'—'))+(Number(x.resubmit_count||0)>0?' <span class="gba-resub-chip" title="This submission was rejected and re-submitted">Re-submitted ×'+Number(x.resubmit_count)+'</span>':'')+'</p></div><span class="gradebook-approval-status status-'+esc(String(x.status||'').toLowerCase())+'">'+esc(sl[x.status]||x.status||'Unknown')+'</span></div><div class="gradebook-approval-table-wrap"><table class="records-table gradebook-approval-table"><thead><tr><th>Student ID</th><th>Student Name</th><th>Subject</th><th>Previous Grade</th><th>Proposed Grade</th><th>Previous Units</th><th>Proposed Units</th></tr></thead><tbody>'+(ascbGbaSubjItems(x,subject).map(it=>'<tr><td data-label="Student ID">'+esc(it.student_id||'—')+'</td><td data-label="Student Name">'+esc(it.student_name||'—')+'</td><td data-label="Subject">'+esc(ascbGbaSubj(it,x)||'—')+'</td><td data-label="Previous Grade">'+esc(it.old_grade||'—')+'</td><td data-label="Proposed Grade"><strong>'+esc(it.new_grade||'—')+'</strong></td><td data-label="Previous Units">'+esc(it.old_units??'—')+'</td><td data-label="Proposed Units"><strong>'+esc(it.new_units??'—')+'</strong></td></tr>').join(''))+'</tbody></table></div>'+(unitHead&&x.status==='PENDING_UNIT_HEAD'?'<div class="gradebook-approval-actions"><button type="button" class="btn btn-secondary" onclick="ascbGradebookApprovalAction('+Number(x.id)+',\'reject\')">Reject</button><button type="button" class="btn btn-add" onclick="ascbGradebookApprovalAction('+Number(x.id)+',\'approve\')">Verify & Forward to Registrar</button></div>':(adminStaff&&x.status==='PENDING_UNIT_HEAD'?'<p class="gradebook-approval-note">Submitted successfully. Waiting for Unit Head verification.</p>':''))+(x.status==='REJECTED'?'<div class="gradebook-approval-rejection"><strong>Rejected'+esc(ascbGbaRejectedBy(x))+'</strong>'+(x.rejection_reason?'<div class="gba-rej-reason"><strong>Reason:</strong> '+esc(x.rejection_reason)+'</div>':'')+'</div>':'')+(adminStaff&&x.status==='REJECTED'?'<div class="gradebook-approval-actions"><button type="button" class="btn btn-add gba-resubmit-btn" onclick="ascbGbaResubmit('+Number(x.id)+')">↻ Re-submit</button></div>':'')+(adminStaff&&x.status!=='REJECTED'&&Number(x.resubmit_count||0)>0&&x.last_rejection_reason?'<div class="gba-resub-history"><strong>Previously rejected:</strong> '+esc(x.last_rejection_reason)+'</div>':'')+'</article>').join('');}}
/* =========================================================
   GRADE APPROVAL — DECISION MODAL (Reject / Approve)
   Pinapalitan ang native prompt()/confirm()/alert() ng isang
   modal na may summary ng submission, required na reason sa
   Reject, loading state, inline error, at success/result view.
   Modes: 'reject' | 'approve' (Unit Head verify) |
          'final' (Registrar final approval) | 'bulk' (Registrar, filtered)
   ========================================================= */
let ASCB_GBA_DECISION=null;
const ASCB_GBA_REASONS=['Incorrect grade entered','Missing grades','Wrong subject or term','Units do not match','Needs supporting documents'];
function ascbGbaRole(){return String(ASCB_CURRENT_USER?.role||'').toUpperCase();}
function ascbGbaDecisionEnsure(){
 let o=document.getElementById('gbaDecisionModal');if(o)return o;
 o=document.createElement('div');o.id='gbaDecisionModal';o.className='gba-decision-overlay';
 o.innerHTML='<section class="gba-decision-card" role="dialog" aria-modal="true" aria-labelledby="gbaDecisionTitle" aria-describedby="gbaDecisionSub"></section>';
 o.addEventListener('mousedown',e=>{if(e.target===o&&!(ASCB_GBA_DECISION&&ASCB_GBA_DECISION.busy))ascbGbaDecisionClose();});
 document.addEventListener('keydown',e=>{
  if(!o.classList.contains('active'))return;
  if(e.key==='Escape'&&!(ASCB_GBA_DECISION&&ASCB_GBA_DECISION.busy)){e.preventDefault();e.stopPropagation();ascbGbaDecisionClose();return;}
  if(e.key==='Tab'){const f=[...o.querySelectorAll('button:not([disabled]),textarea,input,[tabindex]:not([tabindex="-1"])')].filter(x=>x.offsetParent!==null);if(!f.length)return;const a=f[0],z=f[f.length-1];if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus();}else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus();}}
 },true);
 document.body.appendChild(o);return o;
}
function ascbGbaDecisionCfg(st){
 const role=ascbGbaRole(),n=st.rows.length;
 if(st.mode==='resubmit')return{tone:'verify',icon:'↻',title:'Re-submit these grades?',sub:'They go back to the Unit Head for verification, then to the School Registrar for final approval. Official grades do not change yet.',ok:'Re-submit',busy:'Re-submitting…'};
 const grades=st.rows.reduce((t,x)=>t+ascbGbaSelItems(st,x).length,0);
 if(st.mode==='reject'){const one=grades===1&&st.sel;return{tone:'reject',icon:'✕',title:one?'Reject this grade?':(st.sel?'Reject '+grades+' selected grades?':'Reject this grade submission?'),sub:'Only the grade'+(grades===1?'':'s')+' shown here will be rejected. The encoder will see your reason and can correct and resubmit just '+(grades===1?'it':'those')+'. Your other pending grades are not affected.',ok:st.sel?'Reject '+grades+' grade'+(grades===1?'':'s'):'Reject submission',busy:'Rejecting…'};}
 if(st.mode==='rejectfiltered')return{tone:'reject',icon:'✕',title:'Reject '+grades+' filtered grade'+(grades===1?'':'s')+'?',sub:'Only the grades matching your current filters will be rejected and returned to the encoder. All other pending grades stay in the queue.',ok:'Reject '+grades+' grade'+(grades===1?'':'s'),busy:'Rejecting…'};
 if(st.mode==='peerfinal')return{tone:'final',icon:'✓',title:'Approve and finalize these grades?',sub:'The School Registrar encoded these grades. Your Unit Head approval completes the peer review and writes the grades to the official records.',ok:'Approve & finalize',busy:'Finalizing grades…'};
 if(st.mode==='bulkpeerfinal')return{tone:'final',icon:'✓',title:'Approve and finalize '+n+' submission'+(n===1?'':'s')+'?',sub:grades+' grade'+(grades===1?'':'s')+' encoded by the School Registrar will be written to the official records after your approval.',ok:'Approve & finalize '+n,busy:'Finalizing grades…'};
 if(st.mode==='bulkmixed')return{tone:'verify',icon:'✓',title:'Review '+n+' submission'+(n===1?'':'s')+'?',sub:grades+' grades will be processed according to the encoder: Admin Staff submissions will be forwarded to the School Registrar, while School Registrar submissions will be finalized after your peer approval.',ok:'Review '+n+' submission'+(n===1?'':'s'),busy:'Processing approvals…'};
 if(st.mode==='approve'){const one=st.sel&&grades===1;return{tone:'verify',icon:'✓',title:one?'Verify this grade and forward to Registrar?':(st.sel?'Verify '+grades+' selected grades?':'Verify and forward to Registrar?'),sub:'You are confirming that '+(st.sel?(grades===1?'this grade is':'these grades are'):'these grades are')+' correct. Only '+(st.sel?'the selected grade'+(grades===1?'':'s'):'this submission')+' will be forwarded; your other pending grades are not affected. Official grades do not change yet.',ok:'Verify & forward',busy:'Forwarding…'};}
 if(st.mode==='final')return{tone:'final',icon:'✓',title:st.sel&&grades===1?'Give final approval to this grade?':'Give final approval?',sub:'These grades will be written to the official records.',ok:'Approve & update grades',busy:'Updating grades…'};
 if(st.mode==='bulkverify')return{tone:'verify',icon:'✓',title:'Verify and forward '+n+' submission'+(n===1?'':'s')+'?',sub:grades+' grade'+(grades===1?'':'s')+' will be sent to the School Registrar for final approval. Official grades do not change yet.',ok:'Verify & forward '+n,busy:'Forwarding…'};
 return{tone:'final',icon:'✓',title:'Final-approve '+n+' submission'+(n===1?'':'s')+'?',sub:grades+' grade'+(grades===1?'':'s')+' will be written to the official records.',ok:'Approve '+n+' submission'+(n===1?'':'s'),busy:'Approving…'};
}
function ascbGbaDecisionRender(){
 const o=ascbGbaDecisionEnsure(),card=o.firstElementChild,st=ASCB_GBA_DECISION,esc=ascbGbaEsc,cfg=ascbGbaDecisionCfg(st);
 card.className='gba-decision-card tone-'+cfg.tone+(st.mode==='resubmit'?' is-resubmit':'');
 const rows=st.rows,one=rows[0]||{};
 const flat=[];rows.forEach(x=>ascbGbaSelItems(st,x).forEach(it=>flat.push(it)));
 const show=flat.slice(0,5),more=flat.length-show.length;
 const uq=a=>[...new Set(a.map(v=>String(v==null?'':v).trim()).filter(Boolean))];
 const lst=a=>{const u=uq(a);return u.length?esc(u.slice(0,4).join(', ')+(u.length>4?' … +'+(u.length-4)+' more':'')):'—';};
 const bulkMode=st.mode.indexOf('bulk')===0||st.mode==='rejectfiltered';
 const students=new Set(flat.map(it=>String(it.student_id||it.student_name||'').trim()).filter(Boolean)).size;
 const meta=!bulkMode&&rows.length===1
  ?'<dl class="gba-dec-meta"><div><dt>Submission</dt><dd>#'+Number(one.id)+'</dd></div><div><dt>Subject</dt><dd>'+lst(flat.map(it=>ascbGbaSubj(it,one)))+'</dd></div><div><dt>Program</dt><dd>'+esc(one.course_name||'—')+'</dd></div><div><dt>Term</dt><dd>'+esc((one.school_year||'—')+' / '+(one.term||'—'))+'</dd></div><div><dt>Submitted by</dt><dd>'+esc(one.submitted_by_name||'—')+'</dd></div><div><dt>Grades</dt><dd>'+flat.length+'</dd></div></dl>'
  :'<dl class="gba-dec-meta"><div><dt>Total Students</dt><dd>'+students+'</dd></div><div><dt>School Year</dt><dd>'+lst(rows.map(x=>(x.school_year||'—')+' / '+(x.term||'—')))+'</dd></div>'
   +'<div class="wide"><dt>Course/Program</dt><dd>'+lst(rows.flatMap(x=>ascbGbaSelItems(st,x).map(it=>it.course_name||x.course_name)))+'</dd></div>'
   +'<div class="wide"><dt>Course Code</dt><dd>'+lst(rows.flatMap(x=>ascbGbaSelItems(st,x).map(it=>it.subject_code||x.subject_code)))+'</dd></div>'
   +'<div class="wide"><dt>Course Description</dt><dd>'+lst(rows.flatMap(x=>ascbGbaSelItems(st,x).map(it=>it.subject_description||x.subject_description)))+'</dd></div>'
   +'<div><dt>Submitted By</dt><dd>'+lst(rows.map(x=>x.submitted_by_name))+'</dd></div>'
   +'<div><dt>Verify By</dt><dd>'+(st.mode==='bulkverify'?esc(ASCB_CURRENT_USER?.displayName||'You'):lst(rows.map(x=>x.unit_head_name)))+'</dd></div></dl>';
 const preview=st.mode==='resubmit'?ascbGbaResubmitTable(one):(st.mode.indexOf('bulk')===0||st.mode==='rejectfiltered')?'':'<div class="gba-dec-preview"><table><thead><tr><th>Student</th><th>Previous</th><th>Proposed</th></tr></thead><tbody>'+show.map(it=>'<tr><td><strong>'+esc(it.student_name||'—')+'</strong><small>'+esc([it.student_id,it.subject_code].filter(Boolean).join(' · '))+'</small></td><td>'+esc(it.old_grade||'—')+'</td><td><strong>'+esc(it.new_grade||'—')+'</strong></td></tr>').join('')+'</tbody></table>'+(more>0?'<p class="gba-dec-more">+ '+more+' more grade'+(more===1?'':'s')+' in this submission</p>':'')+'</div>';
 const heldBack=rows.reduce((n,x)=>n+(x.items||[]).length,0)-flat.length;
 const warn=(bulkMode&&heldBack>0)?'<p class="gba-dec-note">Only the <b>'+flat.length+'</b> filtered grade'+(flat.length===1?'':'s')+' will be '+(st.mode==='rejectfiltered'?'rejected':(st.mode==='bulkverify'?'verified':'approved'))+'. The other <b>'+heldBack+'</b> grade'+(heldBack===1?'':'s')+' stay in the queue.</p>':'';
 let field='';
 if(st.mode==='reject'||st.mode==='rejectfiltered'){
  field='<label class="gba-dec-label" for="gbaDecReason">Reason for rejection <span class="gba-dec-req">required</span></label>'
   +'<div class="gba-dec-chips" role="group" aria-label="Quick reasons">'+ASCB_GBA_REASONS.map(r=>'<button type="button" class="gba-dec-chip" data-reason="'+esc(r)+'">'+esc(r)+'</button>').join('')+'</div>'
   +'<textarea id="gbaDecReason" class="gba-dec-textarea" rows="3" maxlength="500" placeholder="Tell the encoder what to fix, e.g. which student or subject." aria-describedby="gbaDecErr gbaDecCount">'+esc(st.reason||'')+'</textarea>'
   +'<div class="gba-dec-foot"><span id="gbaDecErr" class="gba-dec-err" role="alert"></span><span id="gbaDecCount" class="gba-dec-count">0 / 500</span></div>';
 }else if(st.mode==='resubmit'){
  field=(one.rejection_reason?'<div class="gba-dec-warn"><strong>'+esc('Rejected'+ascbGbaRejectedBy(one))+'.</strong> '+esc(one.rejection_reason)+'</div>':'')
   +'<label class="gba-dec-label" for="gbaDecNote">Note to reviewer <span class="gba-dec-opt">optional</span></label>'
   +'<textarea id="gbaDecNote" class="gba-dec-textarea" rows="2" maxlength="500" placeholder="e.g. Corrected the grade as requested.">'+esc(st.note||'')+'</textarea>'
   +'<div class="gba-dec-foot"><span id="gbaDecErr" class="gba-dec-err" role="alert"></span><span id="gbaDecNoteCount" class="gba-dec-count">0 / 500</span></div>';
 }else if(st.mode==='approve'){
  field='<p class="gba-dec-note">After you verify, this goes to the School Registrar for final approval. If something is wrong, use Reject instead.</p>';
 }else{
  field='<label class="gba-dec-check"><input type="checkbox" id="gbaDecAck"><span>'+(st.mode==='bulkverify'?'I have reviewed these grades and units. I understand they will be forwarded to the School Registrar.':'I have reviewed these grades and units. I understand official records will be updated.')+'</span></label><div id="gbaDecErr" class="gba-dec-err" role="alert"></div>';
 }
 card.innerHTML='<header class="gba-dec-head"><span class="gba-dec-icon" aria-hidden="true">'+cfg.icon+'</span><div><h3 id="gbaDecisionTitle">'+esc(cfg.title)+'</h3><p id="gbaDecisionSub">'+esc(cfg.sub)+'</p></div></header>'
  +'<div class="gba-dec-body">'+meta+preview+warn+field+'</div>'
  +'<footer class="gba-dec-actions"><button type="button" class="btn btn-secondary" id="gbaDecCancel">Cancel</button><button type="button" class="btn gba-dec-ok" id="gbaDecOk">'+esc(cfg.ok)+'</button></footer>';
 const ta=card.querySelector('#gbaDecReason'),cnt=card.querySelector('#gbaDecCount'),err=card.querySelector('#gbaDecErr');
 const sync=()=>{if(ta&&cnt){cnt.textContent=ta.value.length+' / 500';st.reason=ta.value;}if(err&&err.textContent){err.textContent='';ta&&ta.classList.remove('is-invalid');}};
 if(ta){ta.addEventListener('input',sync);sync();card.querySelectorAll('.gba-dec-chip').forEach(b=>b.addEventListener('click',()=>{ta.value=b.dataset.reason;sync();ta.focus();ta.setSelectionRange(ta.value.length,ta.value.length);}));}
 const ack=card.querySelector('#gbaDecAck');if(ack)ack.addEventListener('change',()=>{if(err)err.textContent='';});
 const noteEl=card.querySelector('#gbaDecNote'),noteCnt=card.querySelector('#gbaDecNoteCount');
 if(noteEl){const ns=()=>{if(noteCnt)noteCnt.textContent=noteEl.value.length+' / 500';st.note=noteEl.value;};noteEl.addEventListener('input',ns);ns();}
 card.querySelectorAll('.gba-resub-input').forEach(i=>i.addEventListener('input',()=>{i.classList.remove('is-invalid');if(err)err.textContent='';}));
 card.querySelector('#gbaDecCancel').addEventListener('click',ascbGbaDecisionClose);
 card.querySelector('#gbaDecOk').addEventListener('click',ascbGbaDecisionSubmit);
 setTimeout(()=>{(ta||ack||(st.mode==='resubmit'&&card.querySelector('.gba-resub-input'))||card.querySelector('#gbaDecOk')).focus();},30);
}
function ascbGbaDecisionOpen(mode,rows,sel){
 if(!rows||!rows.length)return;
 ASCB_GBA_DECISION={mode,rows,sel:sel||null,reason:'',busy:false,lastFocus:document.activeElement};
 const o=ascbGbaDecisionEnsure();ascbGbaDecisionRender();o.classList.add('active');
}
function ascbGbaDecisionClose(){
 const o=document.getElementById('gbaDecisionModal');if(!o)return;
 o.classList.remove('active');const lf=ASCB_GBA_DECISION&&ASCB_GBA_DECISION.lastFocus;ASCB_GBA_DECISION=null;
 if(lf&&typeof lf.focus==='function'&&document.contains(lf))lf.focus();
}
function ascbGbaDecisionError(msg,focusEl){
 const card=document.querySelector('#gbaDecisionModal .gba-decision-card'),err=card&&card.querySelector('#gbaDecErr');
 if(err)err.textContent=msg;if(focusEl){focusEl.classList.add('is-invalid');focusEl.focus();}
}
function ascbGbaDecisionBusy(on,label){
 const st=ASCB_GBA_DECISION;if(!st)return;st.busy=on;
 const card=document.querySelector('#gbaDecisionModal .gba-decision-card');if(!card)return;
 const ok=card.querySelector('#gbaDecOk'),cancel=card.querySelector('#gbaDecCancel');
 card.classList.toggle('is-busy',on);if(cancel)cancel.disabled=on;
 if(ok){ok.disabled=on;if(on){ok.dataset.label=ok.textContent;ok.innerHTML='<span class="gradebook-approval-spinner"></span>'+ascbGbaEsc(label||'Working…');}else if(ok.dataset.label){ok.textContent=ok.dataset.label;}}
 card.querySelectorAll('textarea,input,.gba-dec-chip').forEach(x=>x.disabled=on);
}
async function ascbGbaPost(action,id,reason,itemIds,extra){
 const fd=new FormData();fd.append('action',action);fd.append('submission_id',String(id));if(reason)fd.append('reason',reason);if(extra)Object.keys(extra).forEach(k=>fd.append(k,extra[k]));if(itemIds&&itemIds.length)itemIds.forEach(v=>fd.append('item_ids[]',String(v)));
 const r=await fetch('api/gradebook_approvals.php',{method:'POST',body:fd});let d=null;
 d=await ascbReadJson(r);
 if(!d||!d.ok)throw new Error((d&&d.error)||'The action could not be completed.');return d;
}
async function ascbGbaRefreshAll(){
 try{await ascbGradebookApprovalsLoad();}catch(e){}
 try{if(typeof ascbGradebookLoad==='function')await ascbGradebookLoad();}catch(e){}
 try{await ascbGradeMgmtRejectedLoad();}catch(e){}
 try{if(typeof ascbLoadGradeEvaluation==='function')ascbLoadGradeEvaluation();}catch(e){}
}
function ascbGbaDecisionResult(kind,title,text,failed){
 const card=document.querySelector('#gbaDecisionModal .gba-decision-card');if(!card)return;
 const esc=ascbGbaEsc;card.classList.remove('is-busy');card.classList.add('is-result');
 card.innerHTML='<div class="gba-dec-result '+kind+'"><span class="gba-dec-result-icon" aria-hidden="true">'+(kind==='ok'?'✓':'!')+'</span><h3 id="gbaDecisionTitle">'+esc(title)+'</h3><p id="gbaDecisionSub">'+esc(text)+'</p>'
  +(failed&&failed.length?'<ul class="gba-dec-failed">'+failed.slice(0,5).map(f=>'<li>'+esc(f)+'</li>').join('')+(failed.length>5?'<li>+ '+(failed.length-5)+' more</li>':'')+'</ul>':'')
  +'<button type="button" class="btn gba-dec-ok" id="gbaDecDone">Done</button></div>';
 const b=card.querySelector('#gbaDecDone');b.addEventListener('click',ascbGbaDecisionClose);setTimeout(()=>b.focus(),30);
}
async function ascbGbaDecisionSubmit(){
 const st=ASCB_GBA_DECISION;if(!st||st.busy)return;
 const card=document.querySelector('#gbaDecisionModal .gba-decision-card'),cfg=ascbGbaDecisionCfg(st);
 let reason='';
 if(st.mode==='reject'||st.mode==='rejectfiltered'){
  const ta=card.querySelector('#gbaDecReason');reason=(ta.value||'').trim();
  if(reason.length<5){ascbGbaDecisionError(reason?'Add a bit more detail so the encoder knows what to fix.':'Enter a reason for rejecting this submission.',ta);return;}
 }else if(st.mode==='resubmit'){
  const chk=ascbGbaResubmitCollect(card);if(chk.error){ascbGbaDecisionError(chk.error,chk.el);return;}
  st.edits=chk.edits;
 }else if(st.mode!=='approve'){
  const ack=card.querySelector('#gbaDecAck');if(ack&&!ack.checked){ascbGbaDecisionError('Tick the box to confirm you reviewed the grades.');ack.focus();return;}
 }
 ascbGbaDecisionBusy(true,cfg.busy);
 try{
  if(st.mode==='rejectfiltered'){
   const failed=[];let ok=0,grades=0;
   for(let i=0;i<st.rows.length;i++){
    const b=card.querySelector('#gbaDecOk');if(b&&b.lastChild)b.lastChild.textContent=' Rejecting '+(i+1)+' of '+st.rows.length+'…';
    try{const d=await ascbGbaPost('reject',st.rows[i].id,reason,st.sel?st.sel[st.rows[i].id]:null);ok++;grades+=Number(d.rejected||0);}catch(e){failed.push('#'+st.rows[i].id+': '+e.message);}
   }
   await ascbGbaRefreshAll();st.busy=false;
   ascbGbaDecisionResult(failed.length?'warn':'ok',failed.length?(ok+' rejected, '+failed.length+' failed'):'Grades rejected',failed.length?'The failed ones stay in the queue so you can check them.':grades+' grade'+(grades===1?'':'s')+' rejected and returned to the encoder. All other pending grades stay in the queue.',failed);
   return;
  }
  if(st.mode.indexOf('bulk')===0){
   const failed=[];let ok=0;
   for(let i=0;i<st.rows.length;i++){
    const b=card.querySelector('#gbaDecOk');if(b)b.lastChild.textContent=(st.mode==='bulkverify'?' Verifying ':' Approving ')+(i+1)+' of '+st.rows.length+'…';
    try{await ascbGbaPost('approve',st.rows[i].id,'',st.sel?st.sel[st.rows[i].id]:null);ok++;}catch(e){failed.push('#'+st.rows[i].id+': '+e.message);}
   }
   await ascbGbaRefreshAll();st.busy=false;
   const verifyOnly=st.mode==='bulkverify',peerOnly=st.mode==='bulkpeerfinal';
   const verb=verifyOnly?' verified':(peerOnly?' peer-approved':' processed');
   ascbGbaDecisionResult(failed.length?'warn':'ok',failed.length?(ok+verb+', '+failed.length+' failed'):(verifyOnly?'Forwarded to School Registrar':(peerOnly?'Peer approval complete':'Approvals processed')),failed.length?'The failed submissions stay in the queue so you can check them.':ok+' submission'+(ok===1?'':'s')+(verifyOnly?' verified and forwarded to the School Registrar.':(peerOnly?' peer-approved and finalized. Official grades have been updated.':' processed according to the encoder role. Official grades have been updated where peer/final approval was due.')),failed);
   return;
  }
  if(st.mode==='resubmit'){
   const d=await ascbGbaPost('resubmit',st.rows[0].id,'',null,{edits:JSON.stringify(st.edits||[]),note:(st.note||'').trim()});
   await ascbGbaRefreshAll();st.busy=false;
   const dr=d.dropped_reasons||[];
   ascbGbaDecisionResult((d.closed||dr.length)?'warn':'ok',d.closed?'Submission closed':'Re-submitted',d.message||'Re-submitted.',dr);
   return;
  }
  const action=st.mode==='reject'?'reject':'approve';
  const d=await ascbGbaPost(action,st.rows[0].id,reason,st.sel?st.sel[st.rows[0].id]:null);
  await ascbGbaRefreshAll();st.busy=false;
  const t=st.mode==='reject'?(d.partial?'Grade rejected':'Submission rejected'):(st.mode==='approve'?'Forwarded to School Registrar':'Final approval complete');
  ascbGbaDecisionResult('ok',t,d.message||'Updated.');
  setTimeout(()=>{const o=document.getElementById('gbaDecisionModal');if(o&&o.classList.contains('active')&&ASCB_GBA_DECISION&&ASCB_GBA_DECISION.rows[0]===st.rows[0])ascbGbaDecisionClose();},2200);
 }catch(e){
  ascbGbaDecisionBusy(false);
  ascbGbaDecisionError(e.message||'The action could not be completed.',(st.mode==='reject'||st.mode==='rejectfiltered')?card.querySelector('#gbaDecReason'):null);
 }
}
/* =========================================================
   RE-SUBMIT NG NA-REJECT NA GRADES (Admin Staff)
   - Lumalabas sa Grade Management (panel sa taas) at sa Grade Approval Workflow.
   - Mawawala kapag nag-re-submit na (pending na ulit) o kapag final approved na.
   ========================================================= */
let ASCB_GBA_REJECTED_ROWS=[];
function ascbGbaRejectedBy(x){
 const role=String(x&&x.rejected_by_role||'').toUpperCase(),who=role==='SCHOOL REGISTRAR'?'School Registrar':'Unit Head',nm=String(x&&x.rejected_by_name||'').trim(),at=String(x&&x.rejected_at||'').slice(0,16);
 return ' by '+who+(nm?' ('+nm+')':'')+(at?' · '+at:'');
}
function ascbGbaResubmitTable(x){
 const esc=ascbGbaEsc,its=(x&&x.items)||[];
 return '<div class="gba-dec-preview gba-resub-wrap"><table class="gba-resub-table"><thead><tr><th>Student</th><th>Previous</th><th>Grade</th><th>Units</th></tr></thead><tbody>'
  +its.map(it=>{const g=String(it.new_grade||'').trim(),u=(it.new_units===null||it.new_units===undefined||it.new_units==='')?'':String(Number(it.new_units));
   return '<tr><td><strong>'+esc(it.student_name||'—')+'</strong><small>'+esc([it.student_id,it.subject_code].filter(Boolean).join(' · '))+'</small></td><td>'+esc(it.old_grade||'—')+'</td>'
    +'<td><input type="text" class="gba-resub-input" data-item="'+Number(it.id)+'" data-kind="grade" data-orig="'+esc(g)+'" value="'+esc(g)+'" maxlength="10" inputmode="decimal" aria-label="Grade for '+esc(it.student_name||'student')+'"></td>'
    +'<td><input type="text" class="gba-resub-input gba-resub-units" data-item="'+Number(it.id)+'" data-kind="units" data-orig="'+esc(u)+'" value="'+esc(u)+'" maxlength="5" inputmode="decimal" aria-label="Units for '+esc(it.student_name||'student')+'"></td></tr>';}).join('')
  +'</tbody></table></div>';
}
function ascbGbaResubmitCollect(card){
 const byItem={};let bad=null;
 card.querySelectorAll('.gba-resub-input').forEach(inp=>{
  if(bad)return;
  const id=Number(inp.dataset.item),kind=inp.dataset.kind,val=String(inp.value||'').trim(),orig=String(inp.dataset.orig||'').trim();
  if(kind==='grade'&&!/^(INC|DRP|DR\.?|NG|P|PASSED|C|COMPETENT|[-–—])?$/i.test(val)&&!(val!==''&&!isNaN(Number(val))&&ascbGradeScaleOk(Number(val)))){bad={error:'Invalid grade "'+val+'". Use 0.00–5.00, INC, DRP, NG, P or a dash.',el:inp};return;}
  if(kind==='units'&&val!==''&&!/^[-–—]$/.test(val)&&(isNaN(Number(val))||Number(val)<0||Number(val)>99)){bad={error:'Invalid units "'+val+'". Use a number from 0 to 99.',el:inp};return;}
  if(val!==orig){byItem[id]=byItem[id]||{id};byItem[id][kind]=val;}
 });
 return bad||{edits:Object.keys(byItem).map(k=>byItem[k])};
}
function ascbGbaResubmit(id){
 if(ascbGbaRole()!=='ADMIN STAFF')return;
 const row=ASCB_GRADE_APPROVAL_ROWS.concat(ASCB_GBA_REJECTED_ROWS).find(x=>Number(x.id)===Number(id)&&x.status==='REJECTED');
 if(!row){ascbConfirm('This submission can no longer be re-submitted. It may already be waiting for review or approved. Refresh the list.',{title:'Cannot re-submit',hideCancel:true,okLabel:'Got it'});return;}
 ascbGbaDecisionOpen('resubmit',[row]);
}
/* Badge lang ng Grade Approval Workflow button (Admin Staff): bilang ng na-reject na kailangang i-re-submit.
   Ang mismong Re-submit ay nasa loob ng Grade Approval Workflow modal. */
function ascbGbaSyncRejected(rows){
 ASCB_GBA_REJECTED_ROWS=Array.isArray(rows)?rows.filter(x=>x.status==='REJECTED'):[];
 const badge=document.getElementById('gradebookApprovalWorkflowBadge'),n=ASCB_GBA_REJECTED_ROWS.length;
 if(badge&&ascbGbaRole()==='ADMIN STAFF'){badge.textContent=String(n);badge.style.display=(ascbGbaRole()==='ADMIN STAFF'&&n>0)?'inline-flex':'none';badge.title=n+' rejected submission'+(n===1?'':'s')+' need re-submit';}
}
async function ascbGradeMgmtRejectedLoad(){
 if(ascbGbaRole()!=='ADMIN STAFF'){ascbGbaSyncRejected([]);return;}
 try{const r=await fetch('api/gradebook_approvals.php?action=list&only=rejected',{cache:'no-store'}),d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||'Unable to load rejected submissions.');ascbGbaSyncRejected(d.rows||[]);}catch(e){/* tahimik: hindi dapat masira ang Grade Management kung pumalya ito */}
}
function ascbGbaFilteredPending(){
 const val=id=>(document.getElementById(id)?.value||'').trim(),dept=val('gbaDepartmentFilter'),course=val('gbaCourseFilter'),subject=val('gbaSubjectFilter'),schoolTerm=val('gbaTermFilter'),search=val('gbaSearchFilter').toLowerCase();
 const want=ascbGbaRole()==='UNIT HEAD'?'PENDING_UNIT_HEAD':'PENDING_REGISTRAR',rows=[],sel={};
 ASCB_GRADE_APPROVAL_ROWS.forEach(x=>{
  if(x.status!==want)return;
  if(dept&&String(x.department_name||'')!==dept)return;
  if(course&&String(x.course_name||'')!==course)return;
  if(schoolTerm&&((x.school_year||'—')+' / '+(x.term||'—'))!==schoolTerm)return;
  const vis=ascbGbaVisibleItems(x,subject,search);if(!vis.length)return;
  rows.push(x);sel[x.id]=vis.map(i=>Number(i.id));
 });
 return {rows,sel};
}
async function ascbGradebookApprovalsBulkApprove(){
 const role=ascbGbaRole();if(role!=='SCHOOL REGISTRAR'&&role!=='UNIT HEAD')return;
 const fp=ascbGbaFilteredPending(),rows=fp.rows;
 if(!rows.length){await ascbConfirm('There are no pending submissions in the current filtered view.',{title:'Nothing to '+(role==='UNIT HEAD'?'verify':'approve'),hideCancel:true,okLabel:'Got it'});return;}
 let mode='bulk';
 if(role==='UNIT HEAD'){
  const registrarOnly=rows.length>0&&rows.every(x=>String(x.submitted_by_role||'').toUpperCase()==='SCHOOL REGISTRAR');
  const hasRegistrar=rows.some(x=>String(x.submitted_by_role||'').toUpperCase()==='SCHOOL REGISTRAR');
  mode=registrarOnly?'bulkpeerfinal':(hasRegistrar?'bulkmixed':'bulkverify');
 }
 ascbGbaDecisionOpen(mode,rows,fp.sel);
}
async function ascbGradebookApprovalsBulkReject(){
 const role=ascbGbaRole();if(role!=='SCHOOL REGISTRAR'&&role!=='UNIT HEAD')return;
 const fp=ascbGbaFilteredPending(),rows=fp.rows;
 if(!rows.length){await ascbConfirm('There are no pending grades in the current filtered view.',{title:'Nothing to reject',hideCancel:true,okLabel:'Got it'});return;}
 ascbGbaDecisionOpen('rejectfiltered',rows,fp.sel);
}
async function ascbGradebookApprovalAction(id,action,itemId){
 const role=ascbGbaRole();
 if(role==='ADMIN STAFF'||!['UNIT HEAD','SCHOOL REGISTRAR'].includes(role)){await ascbConfirm('Admin Staff can encode and submit grades only. Approval and rejection are restricted to the Unit Head and School Registrar.',{title:'Action not allowed',hideCancel:true,okLabel:'Got it'});return;}
 const row=ASCB_GRADE_APPROVAL_ROWS.find(x=>Number(x.id)===Number(id));
 if(!row){await ascbConfirm('This submission is no longer in your queue. Refresh the list and try again.',{title:'Submission not found',hideCancel:true,okLabel:'Got it'});return;}
 const sel=itemId?{[row.id]:[Number(itemId)]}:null;
 const peerFinal=role==='UNIT HEAD'&&String(row.submitted_by_role||'').toUpperCase()==='SCHOOL REGISTRAR';
 ascbGbaDecisionOpen(action==='reject'?'reject':(peerFinal?'peerfinal':(role==='SCHOOL REGISTRAR'?'final':'approve')),[row],sel);
}
