<?php
/* =========================================================
   API: GRADE / STUDENT INFO BULK IMPORT (.xlsx o .csv)
   ---------------------------------------------------------
   UNIT HEAD lang — pinakamataas na role — dahil malaking
   epekto ito sa maraming Enrollment + Grade record nang sabay,
   at diretso itong "approved" nang walang hiwalay na approval
   step pa (permission: import_grades).

   DALAWANG format ang tinatanggap — awtomatikong nade-detect
   base sa header row ng na-upload na file:

   (A) "Department Export" layout (api/department_export.php):

     Student ID | Surname | Given Name | Middle Name | Birthdate |
     Student Type | Program Code | Program | Major | Year Level |
     Term | School Year | Subject Code | Subject Description |
     Grade | Units

     Isang estudyante = isa o higit pang row: unang row ng bawat
     estudyante ay may laman ang Student ID (at lahat ng info
     columns); ang mga susunod na row (dagdag na subject lang ng
     PAREHONG estudyante) ay may BLANGKONG Student ID — ito ang
     senyales na "same student pa rin, bagong subject lang".

     Ang "Term" column ay tumatanggap ng KAHIT ALIN sa DALAWANG
     term system — parehong format ang tinatanggap, walang
     karagdagang hakbang: Trimester-based ("1st Trimester", "2nd
     Trimester", "3rd Trimester", "Summer") o Semester-based
     ("1st Semester", "2nd Semester", "Summer").

   (B) "Promotional Report" layout (api/promotional_report_export.php —
       ito rin ang eksaktong layout ng orihinal na Excel template ng
       paaralan, "Promotional Report"):

     Row 1: "Promotional Report" (title)
     Row 2: SCHOOL:         <pangalan ng paaralan>
     Row 3: Program:        <pangalan ng kurso, hal. "... major in ...">
     Row 4: Academic Year:  <hal. "AY 2025-2026">
     Row 5: Trimester: / Semester:  <hal. "2ND", "1st Semester", o "Summer">
            ("Semester:" ang label para sa Semester-based na Program
             tulad ng MAED; "Trimester:" para sa Trimester-based)
     Row 7 (o kahit saang row): header — No | Student Number | Last Name |
       First Name | Middle Name | Date of Birth | Gender | Home Address |
       Year | Course Code | Course Description | Grades | Units

     Ang Program/Academic Year/Trimester ay kinukuha mula sa mga
     meta-row na ito (isang Program/Term/School Year lang bawat file);
     kagaya ng (A), blangkong "Student Number" sa isang row = dagdag
     na subject lang ng parehong estudyante sa naunang row. Tulad ng
     (A), Trimester-based ("1st"/"2nd"/"3rd Trimester" + "Summer") o
     Semester-based ("1st"/"2nd Semester" + "Summer") na halaga ay
     pareho lang na tinatanggap sa Row 5 na ito. Ang label ng row ay
     "Trimester:" o "Semester:" (parehong binabasa), at ang VALUE nito
     ang tumutukoy sa aktwal na term. Para sa Semester-based na Program
     (hal. MAED), Semester ang binabasa kahit "2ND" lang o "Trimester"
     ang nakasulat (ginagamit ang term system ng Program).

   POST multipart/form-data:
     action=preview : i-parse + i-validate lang, WALANG isusulat
                       sa database. Ibinabalik ang buod (bilang
                       ng estudyante/subject, mga error kung
                       meron) para ma-review muna ng UNIT HEAD.
     action=commit  : muling i-parse + i-validate, tapos isulat
                       na sa database sa loob ng isang transaction.
                       Kung may kahit isang FATAL error, walang
                       maisusulat (all-or-nothing).

     field: file (1 .xlsx o .csv file, required)

   Pagtugma sa existing record: Student ID + School Year + Term.
   Kung tugma sa existing Enrollment, doon idadagdag/ia-update
   ang mga subject/grade nito (hindi gagawa ng duplicate
   enrollment). Kung wala pang tugma, gagawa ng BAGONG Enrollment
   record nang direktang "approved" status.

   (FIX) DUPLICATE GRADE RECORD: Student/Enrollment + Subject +
   Term + School Year ang identity ng isang grade record (HINDI
   kasama ang Grade value). Kung may row — sa loob mismo ng file,
   o naka-save na sa database — na kaparehong identity, ito ay
   DUPLICATE at haharangin ang BUONG import (0 record ang
   maisusulat), kahit isa lang ang duplicate row. Ang parehong
   Subject ay puwedeng ulitin ng parehong estudyante kung IBA ang
   Term at/o School Year (retake). Tingnan ang seksyong
   "DUPLICATE DETECTION" sa ibaba para sa detalye. */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/gradebook_lock.php';
require_once __DIR__ . '/../includes/xlsx_reader.php';
require_once __DIR__ . '/../includes/xlsx_writer.php';
require_once __DIR__ . '/../includes/csv_reader.php';
require_once __DIR__ . '/../includes/cache.php';
require_once __DIR__ . '/../includes/programs_helper.php';
require_once __DIR__ . '/../includes/master_record_helper.php';
require_once __DIR__ . '/../includes/student_account_helper.php';
require_once __DIR__ . '/../config/db.php';

$role = ascb_get($ascbUser, 'role', '');
if (!ascb_can($role, 'import_grades')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'You do not have access to this Bulk Import module. UNIT HEAD only.'));
    exit;
}

$action = ascb_get($_POST, 'action', '');
if (!in_array($action, array('preview', 'commit', 'export_normalized', 'create_accounts'), true)) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Invalid action.'));
    exit;
}

/* ---------- create_accounts: gumawa ng STUDENT account sa maliliit na batch ----------
   (fix) Dati, ang commit ay gumagawa ng account (bcrypt ~50-150 ms bawat isa) para sa LAHAT ng estudyante bago
   sumagot — ang 336 na estudyante ay umaabot ng 20-50+ segundo, kaya pinuputol ng hosting/proxy ang koneksyon at
   lumalabas ang "Unable to reach the server" kahit TULOY PA at tapos naman ang import sa server.
   Ngayon: mabilis na sumasagot ang commit (defer_accounts=1), at ang browser ang tumatawag ng action na ito
   nang 20 estudyante bawat request, may progress bar. Parehong helper (ascb_sa_ensure_account): isa lang ang account
   bawat estudyante at hindi ginagalaw ang mga existing. UNIT HEAD lang ang may access (gate sa itaas). */
if ($action === 'create_accounts') {
    @set_time_limit(120);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    $ids = json_decode((string) ascb_get($_POST, 'studentIds', '[]'), true);
    if (!is_array($ids)) $ids = array();
    $clean = array();
    foreach ($ids as $sid) {
        $sid = trim((string) $sid);
        if ($sid !== '' && strlen($sid) <= 40 && preg_match('/^[A-Za-z0-9._\-\/ ]+$/', $sid)) $clean[$sid] = true;
    }
    $clean = array_slice(array_keys($clean), 0, 40);
    if (!$clean) { echo json_encode(array('ok' => true, 'created' => 0, 'existing' => 0, 'failed' => 0, 'credentials' => array())); exit; }
    $creds = array(); $existing = 0; $failed = 0;
    try {
        foreach ($clean as $sid) {
            $nm = ascb_sa_name_for_student($pdo, $sid);
            $res = ascb_sa_ensure_account($pdo, $sid, (array) $nm, $ascbUser);
            if ($res['status'] === 'created') {
                $creds[] = array(
                    'studentId' => $sid,
                    'name' => $nm ? trim($nm['surname'] . ', ' . $nm['first_name']) : '',
                    'username' => $res['username'],
                    'tempPassword' => $res['tempPassword'],
                );
            } elseif ($res['status'] === 'exists') { $existing++; } else { $failed++; }
        }
    } catch (Throwable $e) {
        error_log('ASCB create_accounts failed: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode(array('ok' => false, 'error' => ASCB_DEBUG ? $e->getMessage() : 'Unable to create student accounts for this batch.'));
        exit;
    }
    echo json_encode(array('ok' => true, 'created' => count($creds), 'existing' => $existing, 'failed' => $failed, 'credentials' => $creds));
    exit;
}

/* ---------- 1. i-validate + i-save muna ang na-upload na file sa isang temp path ---------- */

if (empty($_FILES['file']) || $_FILES['file']['error'] === UPLOAD_ERR_NO_FILE) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'No file was uploaded (.xlsx or .csv).'));
    exit;
}
if ($_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'There was a problem uploading the file (code ' . $_FILES['file']['error'] . ').'));
    exit;
}
$origName = (string) $_FILES['file']['name'];
$ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
$ALLOWED_EXTS = array('xlsx', 'csv');
if (!in_array($ext, $ALLOWED_EXTS, true)) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Only .xlsx or .csv files may be uploaded. (If your file is still .xls, please "Save As" .xlsx or .csv first in Excel/Google Sheets.)'));
    exit;
}
$maxSizeBytes = ASCB_MAX_UPLOAD_MB * 1024 * 1024;
if ((int) $_FILES['file']['size'] > $maxSizeBytes) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'The file exceeds the ' . ASCB_MAX_UPLOAD_MB . 'MB limit.'));
    exit;
}

/* ---------- 2. i-parse ang .xlsx papunta sa mga row ---------- */

function ascb_gi_grade_valid($grade) {
    $grade = trim((string) $grade);
    if ($grade === '') return true;
    if (preg_match('/^(INC|DRP|DR\.?|NG|P|PASSED|[-–—])$/iu', $grade)) return true;
    if (is_numeric($grade)) { $n = (float) $grade; return $n >= 0 && $n <= 5; }
    return false;
}

/* =========================================================
   DUPLICATE DETECTION (FIX) — GRADE/ENROLLMENT IDENTITY,
   HINDI "student_id + subject" LANG, AT HINDI RIN DEPENDE SA GRADE
   ---------------------------------------------------------
   Ang identity ng isang grade record ay:

       Student/Enrollment + Subject + Term + School Year

   (HINDI kasama ang Grade value sa identity na ito.) Kung
   may row — sa loob mismo ng na-upload na file, O naka-save
   na sa database para sa parehong Enrollment (Student ID +
   School Year + Term) — na may KAPAREHONG Subject Description,
   ito ay DUPLICATE, KAHIT MAGKAIBA ang Grade nila.

   Dahil dito, ang isang duplicate ay hindi na basta "nilalaktawan"
   nang tahimik: HAHARANGIN na ang BUONG IMPORT (walang isusulat
   kahit isa) hangga't hindi pa naitatama ang file — walang partial
   import (tingnan ang seksyong "NO PARTIAL IMPORT" sa PREVIEW/COMMIT
   sa ibaba). Ito ang naghaharang sa root cause ng bug: dati, dalawang
   row sa loob ng iisang file na magkaparehong Student+Subject+Term+
   School Year pero MAGKAIBA ang Grade ay hindi nade-detect bilang
   duplicate — parehong naisusulat sa commit loop, kaya nagkakaroon
   ng DALAWANG hiwalay na `enrollment_subjects` row (di-sinasadyang
   duplicate) para sa iisang subject.

   RETAKE (hindi duplicate): OKAY lang ulitin ang parehong Subject
   ng parehong estudyante kung IBA ang Term at/o School Year —
   hal. bumagsak sa "1st Trimester" tapos inulit sa "2nd Trimester"
   ng parehong School Year, o sa susunod na School Year — dahil iba
   na ang Enrollment/Term context nito (student_id+school_year+term
   ang batayan ng pagtugma sa Enrollment, tingnan sa ibaba), kaya
   hindi ito tinuturing na parehong "Enrollment" kung kaya't hindi
   rin ito nakikita bilang duplicate ng identity check sa itaas. */

/* Description comparison: hindi case-sensitive, at pare-pareho
   ang trato sa sobra-sobrang espasyo ("MATH  101 " = "math 101"). */
function ascb_gi_norm_desc($v) {
    $v = trim((string) $v);
    $v = preg_replace('/\s+/u', ' ', $v);
    return function_exists('mb_strtoupper') ? mb_strtoupper($v, 'UTF-8') : strtoupper($v);
}

/* Grade comparison: blangko at NULL ay iisa; "INC" = "inc". */
function ascb_gi_norm_grade($v) {
    $g = strtoupper(trim((string) $v));
    if ($g === 'DRP' || $g === 'DR') $g = 'DR.';   // (Dr.) iisa lang ang "Dropped"
    return $g;
}

/* Lahat ng naka-save nang subject + grade ng isang Enrollment,
   naka-index ayon sa normalized na description. */
function ascb_gi_existing_subject_map($pdo, $enrollmentId) {
    $q = $pdo->prepare(
        "SELECT es.id, es.description, g.grade
           FROM enrollment_subjects es
           LEFT JOIN grades g ON g.enrollment_subject_id = es.id
          WHERE es.enrollment_id = ?"
    );
    $q->execute(array($enrollmentId));

    $map = array();
    foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $key = ascb_gi_norm_desc(ascb_get($r, 'description', ''));
        if ($key === '') continue;
        if (!isset($map[$key])) $map[$key] = array();
        $map[$key][] = ascb_gi_norm_grade(ascb_get($r, 'grade', ''));
    }
    return $map;
}

/* TRUE kung ang Subject na ito ay NASA DATABASE NA para sa
   Enrollment na iyon (Student+Term+School Year) — ANUMANG grade
   value, kasama ang blangko. (FIX) Hindi na kailangang magkatugma
   pa ang Grade — ang Subject Description + Enrollment context na
   lang ang tunay na "identity" ng isang grade record; kung existing
   na ang Subject na ito sa Enrollment, duplicate ito, kahit magkaiba
   ang laman ng Grade column. Ang $grade param ay hindi na ginagamit
   dito — naiwan lang ito para hindi na kailangang baguhin ang mga
   existing call site. */
function ascb_gi_is_duplicate($map, $desc, $grade = null) {
    $key = ascb_gi_norm_desc($desc);
    return $key !== '' && !empty($map[$key]);
}

/* Idinadagdag sa map ang bagong naisulat na subject+grade para
   masalo rin ang mga sumunod pang ulit sa loob ng parehong file. */
function ascb_gi_remember_subject(&$map, $desc, $grade) {
    $key = ascb_gi_norm_desc($desc);
    if ($key === '') return;
    if (!isset($map[$key])) $map[$key] = array();
    $map[$key][] = ascb_gi_norm_grade($grade);
}

/* =========================================================
   N+1 QUERY PREVENTION — batch lookup ng LAHAT ng estudyante sa
   buong file sa loob lang ng 2 query (sa halip na 1-2 query PER
   ESTUDYANTE, na noon ay pwedeng umabot ng libo-libong query sa
   isang malaking file):

     1) Isang query gamit ang tuple-IN
        "(student_id, school_year, trimester) IN ((?,?,?),...)"
        para hanapin kaagad ang lahat ng existing enrollee row na
        tumutugma sa bawat block ng file.
     2) Isang query gamit ang "enrollment_id IN (...)" para kunin
        LAHAT ng existing subject+grade ng lahat ng nahanap na
        enrollment sa #1, sabay-sabay.

   Ginagamit ito ng PREVIEW, ng "buong file = duplicate" guard, AT
   ng COMMIT loop — iisang batch lookup na lang bawat request, sa
   halip na 3 magkakahiwalay na N+1 pass gaya noon. ========================================================= */
function ascb_gi_batch_lookup($pdo, $blocks) {
    $lookup = array('enrollmentIds' => array(), 'subjectRows' => array());
    if (!$blocks) return $lookup;

    /* (fix) Dating eksaktong (student_id, school_year, trimester) IN (...)
       tuple-match ito sa SQL mismo — kaya kahit na-normalize na natin ang
       Term/School Year mula sa file, kung ANG NAKA-SAVE NA SA DATABASE
       (mula sa mga dating import bago itong fix, o mula sa ibang paraan
       ng pagpasok) ay may bahagyang ibang casing/spacing (hal. "2nd
       trimester" sa halip na "2nd Trimester"), hindi pa rin ito
       magtutugma — magpapatuloy pa ring gumawa ng duplicate Enrollment.

       Ngayon: student_id na lang ang tuop match sa SQL (mas malawak,
       pero bounded pa rin sa mga estudyanteng nasa file lang), tapos
       ang aktwal na pagtugma ng School Year + Term ay ginagawa sa
       PHP gamit ang case/whitespace-insensitive na ascb_gi_norm_match_key()
       — kaya nahahanap pa rin ang tamang existing Enrollment kahit
       papaano man na-type/na-save dati ang term nito. */
    $studentIds = array();
    $seenSid = array();
    foreach ($blocks as $b) {
        $sid = ascb_gi_student_id_key($b['studentId']);
        if ($sid === '' || isset($seenSid[$sid])) continue;
        $seenSid[$sid] = true;
        $studentIds[] = $sid;
    }
    if ($studentIds) {
        $in = implode(',', array_fill(0, count($studentIds), '?'));
        /* Match canonical Student IDs instead of raw strings. This prevents
           an imported ID from creating a second enrollment merely because an
           old record contains different casing or accidental outer spaces. */
        $sql = "SELECT id, student_id, school_year, trimester FROM enrollees WHERE UPPER(TRIM(student_id)) IN ($in)";
        $st = $pdo->prepare($sql);
        $st->execute($studentIds);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $key = ascb_gi_tuple_key($row['student_id'], $row['school_year'], $row['trimester']);
            /* Kung sakaling may dalawa nang magkatugmang row (matanda nang
               duplicate bago itong fix), ang pinakabago (pinakamalaking id)
               ang gamitin — ito rin ang "Latest Term" na makikita sa Grade
               Management, kaya doon dapat idinidikit ang mga bagong subject. */
            if (!isset($lookup['enrollmentIds'][$key]) || (int) $row['id'] > $lookup['enrollmentIds'][$key]) {
                $lookup['enrollmentIds'][$key] = (int) $row['id'];
            }
        }
    }

    $enrollmentIds = array_values(array_unique($lookup['enrollmentIds']));
    if ($enrollmentIds) {
        $in = implode(',', array_fill(0, count($enrollmentIds), '?'));
        $sq = $pdo->prepare(
            "SELECT es.enrollment_id, es.id AS subject_id, es.description, es.course_code, g.id AS grade_id, g.grade
               FROM enrollment_subjects es
               LEFT JOIN grades g ON g.enrollment_subject_id = es.id
              WHERE es.enrollment_id IN ($in)"
        );
        $sq->execute($enrollmentIds);
        foreach ($sq->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $lookup['subjectRows'][(int) $row['enrollment_id']][] = $row;
        }
    }

    return $lookup;
}

/* In-memory na bersyon ng dating ascb_gi_existing_subject_map(),
   pero mula sa resulta na ng batch query (walang bagong query). */
function ascb_gi_subject_map_from_rows($rows) {
    $map = array();
    foreach ($rows as $r) {
        $key = ascb_gi_norm_desc(ascb_get($r, 'description', ''));
        if ($key === '') continue;
        if (!isset($map[$key])) $map[$key] = array();
        $map[$key][] = ascb_gi_norm_grade(ascb_get($r, 'grade', ''));
    }
    return $map;
}

/* =========================================================
   (FIX) IISANG LUGAR LANG — ginagamit ng PAREHONG Preview AT
   Commit — para tukuyin kung aling mga row sa file ang DUPLICATE
   laban sa naka-save na sa database (Student+Term+School Year na
   Enrollment + parehong Subject, ANUMANG Grade). Isang batch
   lookup lang (2 query) para sa BUONG file — ginagamit pa rin ang
   parehong lookup pagkatapos nito (commit loop) kaya walang
   double query. Ibinabalik ang bilang ng duplicate row AT isang
   listahan ng malinaw na error message per duplicate (Student ID,
   Subject, Term, School Year) — ito ang ipinapakita sa UNIT HEAD
   bago pa man payagan ang Import (Preview), at muling siniguro
   bago talaga isulat sa database (Commit) kung sakaling nagbago
   ang database sa pagitan ng Preview at Commit. ========================================================= */
function ascb_gi_detect_existing_duplicates($pdo, $blocks) {
    $lookup = ascb_gi_batch_lookup($pdo, $blocks);
    $dupExisting = 0;
    $dupErrors = array();
    $perBlockDup = array();
    $existingUpdates = array();

    foreach ($blocks as $idx => $b) {
        $tupleKey = ascb_gi_tuple_key($b['studentId'], $b['schoolYear'], $b['term']);
        $foundId = isset($lookup['enrollmentIds'][$tupleKey]) ? $lookup['enrollmentIds'][$tupleKey] : null;
        if ($foundId === null) continue;

        $rows = isset($lookup['subjectRows'][$foundId]) ? $lookup['subjectRows'][$foundId] : array();
        $map = ascb_gi_subject_map_from_rows($rows);
        $updates = 0;
        foreach ($b['subjects'] as $s) {
            $existing = ascb_gi_find_subject_row($rows, $s['description'], $s['code']);
            if ($existing) {
                $updates++;
                $existingUpdates[] = array(
                    'block'=>$idx, 'enrollment_id'=>(int)$foundId,
                    'subject_id'=>(int)$existing['subject_id'],
                    'grade_id'=>$existing['grade_id']!==null?(int)$existing['grade_id']:null,
                    'description'=>$s['description'],
                    'oldGrade'=>$existing['grade'],
                    'newGrade'=>$s['grade']
                );
            }
        }
        if ($updates > 0) $perBlockDup[$idx] = $updates;
    }

    return array(
        'lookup'=>$lookup,
        'dupExisting'=>$dupExisting,
        'dupErrors'=>$dupErrors,
        'perBlockDup'=>$perBlockDup,
        'existingUpdates'=>$existingUpdates
    );
}

/* Hinahanap sa in-memory na subject rows (mula sa batch lookup) ang
   eksaktong tumutugmang subject — kapalit ng dating per-subject
   "SELECT id FROM enrollment_subjects WHERE ..." query. */
/* =========================================================
   SMART SUBJECT IDENTITY (FIX: A1 vs A1A, BAa/BAb, A&B1, PATH Fit 1...)
   ---------------------------------------------------------
   Ang Subject CODE ang pangunahing identity ng isang subject. Ang code
   ay inihahambing sa EKSAKTONG anyo nito (uppercase, walang espasyo/
   simbolo): "A1" at "A1a"/"A1A" ay DALAWANG magkaibang subject — hindi
   kailanman prefix/fuzzy match ang code.

   Mga patakaran sa pagtutugma ng isang imported subject sa isang
   naka-save nang subject ng parehong Enrollment:
     1) Parehong code            -> parehong subject (UPDATE, hindi bago)
     2) Magkaibang code          -> MAGKAIBANG subject, kahit magkahawig
     3) Walang code sa isang panig -> pareho ang description
     4) "Placeholder" na description (ang description ay code lang,
        hal. "A1A", galing sa lumang import na hindi nakilala ang code)
        -> itinuturing na kapareho ng subject na may ganoong code, at
        INAAYOS ang description/code nito sa commit sa halip na
        gumawa pa ng panibagong (duplicate) row.
   ========================================================= */
function ascb_gi_code_key($v) {
    return strtoupper(preg_replace('/[^A-Za-z0-9]+/', '', trim((string) $v)));
}

function ascb_gi_find_subject_row($rows, $description, $code) {
    $wCode    = ascb_gi_code_key($code);
    $wDescKey = ascb_gi_code_key(ascb_gi_norm_desc($description));
    $best = null; $bestScore = 0;
    foreach ($rows as $r) {
        $rCode    = ascb_gi_code_key(isset($r['course_code']) ? $r['course_code'] : '');
        $rDescKey = ascb_gi_code_key(ascb_gi_norm_desc(isset($r['description']) ? $r['description'] : ''));
        $score = 0;
        if ($wCode !== '' && $rCode !== '') {
            if ($wCode !== $rCode) continue;                 /* A1 != A1A : magkaibang subject */
            $score = ($rDescKey === $wDescKey) ? 100 : 90;
        } else {
            if ($wDescKey !== '' && $rDescKey === $wDescKey)        $score = 70;  /* parehong description */
            elseif ($wCode !== '' && $rDescKey === $wCode)          $score = 60;  /* existing description = code lang */
            elseif ($rCode !== '' && $wDescKey === $rCode)          $score = 60;  /* incoming description = code lang */
        }
        if ($score > $bestScore) { $best = $r; $bestScore = $score; }
    }
    return $best;
}

/* Ibinabalik ang "Nth Trimester" / "Nth Semester" / "Summer" mula sa
   halagang tulad ng "2ND", "2nd trimester", "2ND TRIMESTER",
   "1st Semester", "SUMMER", "summer", atbp. — kaya tumutugma pa rin
   ito sa eksaktong string na naka-save sa database (na galing sa
   dropdown ng site, hal. "2nd Trimester", "1st Semester", "Summer")
   kahit anong casing/spacing ang laman ng na-type o na-encode na
   Excel file. Kung walang leading number, ibinabalik na lang ang
   orihinal (naka-trim). NOTE: dating "Trimester" lang ang laging
   idinidikit dito kahit ano pa ang orihinal na salita — na mali
   para sa mga Semester-based na term (hal. bali-baliktad na
   "1st Semester" -> "1st Trimester"). Ngayon, kinikilala/pinapanatili
   ang aktwal na salita (Trimester/Semester) mula sa input, at
   "Trimester" na lang ang default kung wala talagang nabanggit.
   (fix) "Summer" ay walang leading number sa alinmang term system
   (Trimester-based: 1st/2nd/3rd Trimester -> Summer; Semester-based:
   1st/2nd Semester -> Summer) — kinikilala ito bilang sarili nitong
   espesyal na termino, case/whitespace-insensitive, bago pa man
   subukan ang "Nth ..." na pattern sa ibaba. */
/* (fix Semester) $termType ("Trimester" / "Semester" / "" = hindi alam)
   ay ang term system ng PROGRAM ng estudyante (galing sa programs.term_type).
   - Kung walang nakasulat na "Trimester"/"Semester" sa halaga (hal. "2ND"),
     ang term system ng Program ang ginagamit — dati laging "Trimester" ang
     default kaya ang MAED (Semester-based) ay nagiging "2nd Trimester".
   - Kung Semester-based ang Program, ang nakasulat na "Trimester" (hal.
     mula sa lumang export na mali ang label) ay binabasa bilang "Semester". */
function ascb_gi_normalize_term($v, $termType = '') {
    $v = trim((string) $v);
    if ($v === '') return '';
    if (preg_match('/^summer$/i', $v)) return 'Summer';
    if (preg_match('/^(\d+)\s*(?:st|nd|rd|th)?\.?\s*(trimester|semester)?/i', $v, $m)) {
        $n = (int) $m[1];
        $defaultWord = ($termType === 'Semester') ? 'Semester' : 'Trimester';
        $unitWord = (isset($m[2]) && $m[2] !== '') ? ucfirst(strtolower($m[2])) : $defaultWord;
        if ($termType === 'Semester') $unitWord = 'Semester';
        $mod100 = $n % 100;
        if ($mod100 >= 11 && $mod100 <= 13) {
            $suffix = 'th';
        } else {
            $suffixByLastDigit = array(1 => 'st', 2 => 'nd', 3 => 'rd');
            $suffix = isset($suffixByLastDigit[$n % 10]) ? $suffixByLastDigit[$n % 10] : 'th';
        }
        return $n . $suffix . ' ' . $unitWord;
    }
    return $v;
}

/* Puwede ba ang Term na ito sa term system ng Program? Ang Semester-based
   na Program (hal. MAED) ay may 1st/2nd Semester + Summer lang — walang 3rd. */
function ascb_gi_term_fits_program($term, $termType) {
    if ($termType !== 'Semester') return true;
    if (preg_match('/^(\d+)(?:st|nd|rd|th) /', (string) $term, $m)) return ((int) $m[1]) <= 2;
    return true;
}

/* Case/whitespace-insensitive na "susi" para sa pagtutugma ng Term
   at School Year laban sa naka-save na sa database — hindi dapat
   umasa ang pagtutugma sa EKSAKTONG parehong casing, dahil iba-iba
   ang puwedeng i-type ng tao sa Excel ("2ND", "2nd trimester",
   "2nd Trimester"). Ginagamit LANG ito para sa PAGTUTUGMA (matching);
   ang aktwal na isusulat sa database ay nanggagaling pa rin sa
   ascb_gi_normalize_term()/ascb_gi_normalize_school_year() para
   laging pare-pareho/"canonical" ang casing ng BAGONG record. */
function ascb_gi_norm_match_key($v) {
    $v = trim((string) $v);
    $v = preg_replace('/\s+/u', ' ', $v);
    return function_exists('mb_strtoupper') ? mb_strtoupper($v, 'UTF-8') : strtoupper($v);
}

/* Iisang lugar lang ang gumagawa ng "susi" para sa pagtutugma ng
   isang block (Student ID + School Year + Term) laban sa existing
   Enrollment — para hindi na kailangang ulit-ulitin (at posibleng
   magkaiba-iba) ang paggawa nito sa iba't ibang parte ng file na ito. */
/* (suffix) Walang Suffix column ang import file. Kapag ang Student ID ay may
   Master Record na may Suffix (Jr., III...) at ang pangalan sa file ay kapareho
   ng sa Master, dalhin ang Suffix + PSA placement ng Master sa bagong
   enrollment row. Kung magkaiba ang pangalan, iwanan ito ayon sa file. */
function ascb_gi_master_suffix($pdo, $b) {
    $none = array('', 'separate');
    if (!ascb_column_exists($pdo, 'enrollees', 'suffix') || !ascb_column_exists($pdo, 'enrollees', 'suffix_position')) return $none;
    $m = ascb_master_current($pdo, $b['studentId']);
    if (!$m) return $none;
    $sfx = trim((string) (isset($m['suffix']) ? $m['suffix'] : ''));
    if ($sfx === '') return $none;
    if (strcasecmp(trim((string) $m['surname']), trim((string) $b['surname'])) !== 0
        || strcasecmp(trim((string) $m['first_name']), trim((string) $b['firstName'])) !== 0
        || strcasecmp(trim((string) $m['middle_name']), trim((string) $b['middleName'])) !== 0) return $none;
    return array($sfx, ascb_normalize_suffix_position(isset($m['suffix_position']) ? $m['suffix_position'] : ''));
}

function ascb_gi_tuple_key($studentId, $schoolYear, $term) {
    return ascb_gi_student_id_key($studentId) . '|' . ascb_gi_norm_match_key($schoolYear) . '|' . ascb_gi_norm_match_key($term);
}

/* "AY 2025-2026" / "2025 - 2026" -> "2025-2026" */
function ascb_gi_normalize_school_year($v) {
    $v = trim((string) $v);
    if ($v === '') return '';
    if (preg_match('/(\d{4})\s*-\s*(\d{4})/', $v, $m)) {
        return $m[1] . '-' . $m[2];
    }
    return $v;
}

/* Year Level -> "1st Year" / "2nd Year" / "3rd Year" / "4th Year" ...
   (fix) Dati, "1st year" lang ang naa-normalize — kapag "1", "1.0",
   "1st", "First Year", "Year 1", "I" ang nasa Year column ng Excel,
   iyon mismo ang nase-save (hal. year_level = "1"), kaya sa Grade
   Management ay lumalabas ito bilang hiwalay na grupong "1" sa halip
   na nasa "1ST YEAR". Ngayon lahat ng iyon ay ginagawang "1st Year". */
function ascb_gi_normalize_year_level($v) {
    $v = trim(preg_replace('/\s+/u', ' ', (string) $v));
    if ($v === '') return '';
    $words = array('first' => 1, 'second' => 2, 'third' => 3, 'fourth' => 4, 'fifth' => 5, 'sixth' => 6);
    $roman = array('i' => 1, 'ii' => 2, 'iii' => 3, 'iv' => 4, 'v' => 5, 'vi' => 6);
    $n = 0;
    $lv = strtolower($v);
    if (preg_match('/^(?:year\s*)?(\d+)(?:\.0+)?(?:\s*(?:st|nd|rd|th))?(?:\s*(?:year|yr)\.?)?$/i', $v, $m)) {
        $n = (int) $m[1];
    } elseif (preg_match('/^(first|second|third|fourth|fifth|sixth)(?:\s*(?:year|yr)\.?)?$/i', $v, $m)) {
        $n = $words[strtolower($m[1])];
    } elseif (isset($roman[$lv])) {
        $n = $roman[$lv];
    } elseif (preg_match('/^year\s+(i{1,3}|iv|vi?)$/i', $v, $m)) {
        $n = $roman[strtolower($m[1])];
    }
    if ($n < 1 || $n > 6) return $v;
    $mod100 = $n % 100;
    if ($mod100 >= 11 && $mod100 <= 13) $suffix = 'th';
    else { $sfx = array(1 => 'st', 2 => 'nd', 3 => 'rd'); $suffix = isset($sfx[$n % 10]) ? $sfx[$n % 10] : 'th'; }
    return $n . $suffix . ' Year';
}

/* Pinakamalapit na Program batay sa pagkakahawig ng text (kapag may typo).
   Tumatanggap lang kung ≥ 90% ang pagkakahawig AT walang halos kasing-lapit
   na ibang Program (para hindi magkamali ng Program). */
function ascb_gi_fuzzy_program_pick($label, $programs) {
    $lk = ascb_program_match_key($label);
    if ($lk === '') return null;
    $best = null; $bestPct = 0.0; $second = 0.0;
    foreach ($programs as $p) {
        $pk = ascb_program_match_key($p['course_name'] . ' ' . trim((string) $p['major']));
        if ($pk === '') continue;
        similar_text($lk, $pk, $pct);
        if ($pct > $bestPct) { $second = $bestPct; $bestPct = $pct; $best = $p; }
        elseif ($pct > $second) { $second = $pct; }
    }
    if ($best && $bestPct >= 90.0 && ($bestPct - $second) >= 3.0) return $best;
    return null;
}

/* Ang buong "Program:" na text (hal. "Bachelor of Secondary Education
   major in Social Studies") -> tugmang row sa programs table, para
   makuha ang Program Code + Department. Kung walang tugma, null lang
   ang ibabalik (hindi ito FATAL error — mananatili lang blangko ang
   Program Code ng bagong Enrollment). */
function ascb_gi_lookup_program($pdo, $label) {
    $label = trim((string) $label);
    if ($label === '') return null;
    $courseName = $label;
    $major = null;
    if (preg_match('/^(.*?)\s+major\s+in\s+(.*)$/i', $label, $m)) {
        $courseName = trim($m[1]);
        $major = trim($m[2]);
    }
    $sql = "SELECT code, department_id, course_name, major, term_type FROM programs WHERE UPPER(TRIM(course_name))=UPPER(TRIM(?))";
    $params = array($courseName);
    if ($major !== null) {
        $sql .= " AND (UPPER(TRIM(COALESCE(major,'')))=UPPER(TRIM(?)))";
        $params[] = $major;
    }
    $sql .= " LIMIT 1";
    $st = $pdo->prepare($sql);
    $st->execute($params);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if ($row) return $row;
    /* (fix BSIS) Kapag hindi eksakto ang spelling ng Program sa Excel
       (hal. "Information System" na walang "s", may "(BSIS)", "BS ...")
       gamitin ang fingerprint resolver para makuha pa rin ang tamang
       Program Code + Department. */
    $hit = ascb_resolve_program($pdo, '', $label);
    if (!$hit) {
        /* (fix) May typo sa Program text ng Excel (hal. "Supevision" sa halip
           na "Supervision") — hanapin ang pinakamalapit na Program. */
        try {
            $all = $pdo->query("SELECT code, department_id, course_name, major, term_type FROM programs ORDER BY is_active DESC, id ASC")->fetchAll(PDO::FETCH_ASSOC);
            $hit = ascb_gi_fuzzy_program_pick($label, $all);
        } catch (Throwable $e) { $hit = null; }
    }
    return $hit ? array('code' => $hit['code'], 'department_id' => $hit['department_id'], 'course_name' => $hit['course_name'], 'major' => $hit['major'], 'term_type' => isset($hit['term_type']) ? $hit['term_type'] : 'Trimester') : null;
}

/* (fix) Mas maluwag na pagbasa ng meta-row ng Promotional Report
   (Program / Academic Year / Trimester o Semester). Dati, kailangang
   EKSAKTONG "Trimester:" sa unang column at ang value ay nasa
   kasunod na column — kaya kapag "Semester" na walang colon, may
   dagdag na espasyo ("Semester :"), nasa ibang column, o nakasulat
   sa isang cell lang ("Semester: 1st Semester"), "Missing or
   unreadable meta-row" ang lumalabas. Ibinabalik ang array(key, value)
   kung meta-row ito (key = program | school_year | term), o null. */
function ascb_gi_parse_meta_row($r) {
    if (!is_array($r)) return null;
    $cells = array();
    foreach ($r as $c) {
        $t = trim(preg_replace('/\s+/u', ' ', str_replace("\xC2\xA0", ' ', (string) $c)));
        if ($t !== '') $cells[] = $t;
    }
    if (!$cells) return null;
    if (!preg_match('/^(program|course|academic year|school year|s\.?y\.?|trimester|semester|term)\s*:?\s*(.*)$/iu', $cells[0], $m)) return null;
    $label = strtolower(preg_replace('/[^a-z ]/i', '', $m[1]));
    $value = trim($m[2]);
    if ($value === '' && isset($cells[1])) $value = $cells[1];
    if ($label === 'program' || $label === 'course') $key = 'program';
    elseif ($label === 'academic year' || $label === 'school year' || $label === 'sy') $key = 'school_year';
    else $key = 'term';
    /* Ang mismong label (Semester/Trimester) ay palatandaan ng term system
       kapag walang nakasulat na salita sa value (hal. "2ND"). */
    $labelWord = ($label === 'semester') ? 'Semester' : (($label === 'trimester') ? 'Trimester' : '');
    return array($key, $value, $labelWord);
}

/* =========================================================
   3. INTELLIGENT FORMAT DETECTION / NORMALIZATION
   ---------------------------------------------------------
   Hindi na umaasa sa fixed column positions. Sinusuri ang bawat
   worksheet, hinahanap ang pinaka-malamang na header row, ina-alias
   ang labels, at kino-convert ang iba't ibang row layouts sa iisang
   internal block shape na ginagamit ng existing commit code.

   Supported patterns:
     - one subject per row
     - repeated student rows / merged-cell exports
     - student-per-row gradebook
     - subject code + description in one cell
     - multiple worksheets
     - metadata rows (Program/SY/Term)
     - extra/unrecognized columns
   ========================================================= */

$format = 'intelligent';
$blocks = array();
$errors = array();
$warnings = array();
$mapping = array();
$unrecognizedColumns = array();
$sheetRows = array();

function ascb_gi_label_norm($v) {
    $v = trim((string)$v);
    if ($v === '') return '';
    if (function_exists('iconv')) {
        $x = @iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$v);
        if ($x !== false) $v = $x;
    }
    $v = strtolower($v);
    $v = preg_replace('/[\r\n\t]+/', ' ', $v);
    $v = preg_replace('/[^a-z0-9]+/', ' ', $v);
    return trim(preg_replace('/\s+/', ' ', $v));
}

function ascb_gi_value_norm($v) {
    $v = trim((string)$v);
    $v = preg_replace('/\s+/u', ' ', $v);
    return trim($v);
}

function ascb_gi_field_from_label($label) {
    $n = ascb_gi_label_norm($label);
    if ($n === '') return null;

    $aliases = array(
        'studentId' => array('student id','student no','student number','student num','id number','id no','studentid','studentnumber','id'),
        'surname' => array('last name','lastname','surname','family name','familyname'),
        'firstName' => array('first name','firstname','given name','givenname','first'),
        'middleName' => array('middle name','middlename','middle initial','mi','m i'),
        'suffix' => array('suffix','name suffix'),
        'birthdate' => array('birth date','birthdate','date of birth','dob','birthday'),
        'sex' => array('sex','gender'),
        'studentType' => array('student type','type','classification'),
        'address' => array('address','home address','complete address','residential address'),
        'mobileNumber' => array('mobile','mobile number','contact number','phone','phone number'),
        'email' => array('email','email address'),
        'programCode' => array('program code','degree code','program id'),
        'program' => array('program','course','degree','program name','degree program'),
        'major' => array('major','major field','specialization'),
        'yearLevel' => array('year','year level','level','grade level','yr','yr level'),
        'term' => array('term','trimester','trimester term','semester','sem','period'),
        'schoolYear' => array('school year','academic year','academic yr','schoolyear','sy','ay'),
        'subjectCode' => array('subject code','course code','subject no','subject number','course no','course number'),
        'subjectDescription' => array('subject description','subject name','description','course description','course name','subject'),
        'units' => array('units','unit','credit','credits','credit units'),
        'grade' => array('grade','grades','final grade','final grades','rating','mark','score'),
    );
    foreach ($aliases as $field => $list) {
        foreach ($list as $a) {
            if ($n === $a) return $field;
        }
    }

    /* Labels with qualifiers: "Student ID No.", "Final Grade 1", etc. */
    if (preg_match('/\b(student\s*(id|no|number)|id\s*(number|no))\b/i',$n)) return 'studentId';
    if (preg_match('/\b(last|family)\s*name\b/i',$n)) return 'surname';
    if (preg_match('/\b(first|given)\s*name\b/i',$n)) return 'firstName';
    if (preg_match('/\bmiddle\b/i',$n) && preg_match('/\b(name|initial|mi)\b/i',$n)) return 'middleName';
    if (preg_match('/\b(date\s*of\s*birth|birth\s*date|dob)\b/i',$n)) return 'birthdate';
    if (preg_match('/\b(student\s*)?type\b/i',$n)) return 'studentType';
    if (preg_match('/\bprogram\b|\bdegree\b|\bcourse\b/i',$n)) {
        if (preg_match('/\b(code|no|number)\b/i',$n)) return 'programCode';
        return 'program';
    }
    if (preg_match('/\byear\b|\blevel\b/i',$n) && !preg_match('/school|academic/i',$n)) return 'yearLevel';
    if (preg_match('/\btrimester\b|\bsemester\b|\bterm\b/i',$n)) return 'term';
    if (preg_match('/\bschool\s*year\b|\bacademic\s*year\b|\bsy\b|\bay\b/i',$n)) return 'schoolYear';
    if (preg_match('/\bsubject\b|\bcourse\b/i',$n)) {
        if (preg_match('/\b(code|no|number)\b/i',$n)) return 'subjectCode';
        if (preg_match('/\b(description|name)\b/i',$n)) return 'subjectDescription';
        return 'subjectDescription';
    }
    if (preg_match('/\bunit|credit\b/i',$n)) return 'units';
    if (preg_match('/\bgrade|rating|mark|score\b/i',$n)) return 'grade';
    return null;
}


/*
 * Context-aware semantic mapping.
 *
 * "Course" / "Course Code" is inherently ambiguous in school exports:
 * some files use it for the student's PROGRAM, while others use it for a
 * SUBJECT CODE. Never decide from the header alone. We inspect representative
 * values and, when possible, compare them against the actual programs table.
 * Explicit Subject/Program labels always win.
 */
function ascb_gi_program_catalog($pdo) {
    static $catalog = null;
    if ($catalog !== null) return $catalog;
    $catalog = array('codes'=>array(), 'names'=>array());
    try {
        $q=$pdo->query("SELECT code, course_name, major FROM programs WHERE is_active=1 OR is_active IS NULL");
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $code=ascb_gi_label_norm($r['code']??'');
            $name=ascb_gi_label_norm(trim(($r['course_name']??'').' '.($r['major']??'')));
            if ($code!=='') $catalog['codes'][$code]=true;
            if ($name!=='') $catalog['names'][$name]=true;
            $base=ascb_gi_label_norm($r['course_name']??'');
            if ($base!=='') $catalog['names'][$base]=true;
        }
    } catch (Throwable $e) {
        /* Detection must still work when the optional catalog query fails. */
    }
    return $catalog;
}

function ascb_gi_value_looks_program($value, $catalog) {
    $n=ascb_gi_label_norm($value);
    if ($n==='') return false;
    if (isset($catalog['codes'][$n]) || isset($catalog['names'][$n])) return true;
    /* Common Philippine program-code shape: BSIT, BSCS, BSA, BSED, MM, etc. */
    $compact=strtoupper(preg_replace('/[^A-Z0-9]/','',$n));
    if (preg_match('/^(BS|AB|BA|BSE|BSED|BEED|BSA|BSBA|BSCRIM|BSIS|BSCS|BSIT|MA|MS|MM|MBA|MEd|MED|JD|LLB)[A-Z0-9]{1,8}$/i',$compact)) return true;
    return false;
}

function ascb_gi_value_looks_subject_code($value) {
    $v=trim((string)$value);
    if ($v==='') return false;
    $n=strtoupper(preg_replace('/\s+/','', $v));
    /* GE1, GE-1, IT101, IT-101, ENG 101, MATH1, etc. */
    return (bool)preg_match('/^[A-Z]{1,10}[-.]?\d{1,5}[A-Z0-9-]*$/', $n);
}

function ascb_gi_nonempty_column_values($rows, $headerRow, $col, $limit=12) {
    $out=array();
    for($i=$headerRow+1;$i<count($rows)&&count($out)<$limit;$i++) {
        $v=trim((string)($rows[$i][$col]??''));
        if($v!=='') $out[]=$v;
    }
    return $out;
}

function ascb_gi_contextualize_fields($pdo, $rows, $headerRow, $fields) {
    $catalog=ascb_gi_program_catalog($pdo);
    $hasExplicitProgram=false; $hasExplicitSubject=false;
    foreach($fields as $c=>$f) {
        $raw=ascb_gi_label_norm($rows[$headerRow][$c]??'');
        if($f==='program' || $f==='programCode') $hasExplicitProgram=true;
        if($f==='subjectCode' || $f==='subjectDescription') $hasExplicitSubject=true;
        /* Force explicit semantic labels before any heuristic. */
        if(in_array($raw,array('program code','degree code','program id'),true)) $fields[$c]='programCode';
        elseif(in_array($raw,array('program','program name','degree','degree program'),true)) $fields[$c]='program';
        elseif(in_array($raw,array('subject code','subject no','subject number'),true)) $fields[$c]='subjectCode';
        elseif(in_array($raw,array('subject','subject name','subject description'),true)) $fields[$c]='subjectDescription';
    }
    foreach($fields as $c=>$f) {
        $raw=ascb_gi_label_norm($rows[$headerRow][$c]??'');
        if(!in_array($raw,array('course','course code','course no','course number','course name','course description'),true)) continue;
        $vals=ascb_gi_nonempty_column_values($rows,$headerRow,$c);
        $programHits=0; $subjectHits=0;
        foreach($vals as $v) {
            if(ascb_gi_value_looks_program($v,$catalog)) $programHits++;
            if(ascb_gi_value_looks_subject_code($v)) $subjectHits++;
        }
        if($raw==='course') {
            /* A plain Course column in registrar exports is the student's
               program. If its values are not program-like, do not silently
               call it a subject; flag it as program only when plausible. */
            if($programHits>0 || !$hasExplicitSubject) $fields[$c]='program';
            else $fields[$c]='program';
        } elseif($raw==='course code' || $raw==='course no' || $raw==='course number') {
            if($programHits>$subjectHits && $programHits>0 && !$hasExplicitProgram) $fields[$c]='programCode';
            else $fields[$c]='subjectCode';
        } elseif($raw==='course name' || $raw==='course description') {
            if($programHits>$subjectHits && !$hasExplicitProgram) $fields[$c]='program';
            else $fields[$c]='subjectDescription';
        }
    }
    return $fields;
}

function ascb_gi_header_score($row) {
    $recognized = 0; $fields = array(); $unknown = 0;
    foreach ((array)$row as $i=>$v) {
        $f = ascb_gi_field_from_label($v);
        if ($f) { $recognized++; $fields[$i] = $f; }
        elseif (trim((string)$v) !== '') $unknown++;
    }
    $score = $recognized * 4;
    foreach (array('studentId','surname','firstName','subjectCode','subjectDescription','grade','units','schoolYear','term','program') as $f) {
        if (in_array($f,$fields,true)) $score += 2;
    }
    if ($recognized >= 3) $score += 3;
    return array($score,$fields,$unknown);
}

function ascb_gi_find_header($rows, $maxScan = 60) {
    $best = null;
    $limit = min(count($rows), $maxScan);
    for ($i=0; $i<$limit; $i++) {
        $r = isset($rows[$i]) ? $rows[$i] : array();
        if (!$r) continue;
        list($score,$fields,$unknown) = ascb_gi_header_score($r);
        if ($score < 10) continue;
        if ($best === null || $score > $best['score']) {
            $best = array('row'=>$i,'fields'=>$fields,'score'=>$score,'unknown'=>$unknown);
        }
    }
    return $best;
}

function ascb_gi_meta_value($rows, $labels) {
    foreach ((array)$rows as $r) {
        if (!$r) continue;
        $joined = '';
        foreach ($r as $v) if (trim((string)$v)!=='') $joined .= ' '.trim((string)$v);
        $n = ascb_gi_label_norm($joined);
        foreach ($labels as $label) {
            $labelNorm = ascb_gi_label_norm($label);
            /* Whole-token match: short alias "sy" must not match
               the "sy" at the start of "systems" in a Program row. */
            if ($labelNorm === '' || !preg_match('/(?<![a-z0-9])'.preg_quote($labelNorm,'/').'(?![a-z0-9])/i', $n)) {
                continue;
            }
            /* Keep the original punctuation in inline values (e.g.
               "Academic Year: AY 2025-2026") instead of returning the
               punctuation-stripped normalized row. */
            $rawLabelPattern = '/^\s*'.preg_quote($label,'/').'(?:\s*[:=]\s*|\s+)(.+)$/iu';
            foreach ($r as $v) {
                if (preg_match($rawLabelPattern, trim((string)$v), $m)) return trim($m[1]);
            }
            foreach ($r as $idx=>$v) {
                if ($idx === 0) continue;
                $v = trim((string)$v);
                if ($v !== '' && !preg_match('/^'.preg_quote($label,'/').'\s*:?\s*$/i',$v)) return $v;
            }
            /* "Program: BSIT" may have been flattened into one cell. */
            if (preg_match('/(?<![a-z0-9])'.preg_quote($labelNorm,'/').'(?![a-z0-9])\s*:?\s*(.+)$/i',$n,$m)) return trim($m[1]);
        }
    }
    return '';
}

function ascb_gi_parse_subject_cell($value) {
    $v = ascb_gi_value_norm($value);
    if ($v === '') return array('code'=>'','description'=>'','units'=>'');
    /* code | description | units */
    if (substr_count($v,'|') >= 1) {
        $p = array_map('trim', explode('|',$v));
        return array('code'=>$p[0]??'','description'=>$p[1]??'','units'=>$p[2]??'');
    }
    /* GE1 - Understanding the Self (3) */
    if (preg_match('/^\s*([A-Za-z]{1,8}\s*[- ]?\s*\d{1,4}[A-Za-z0-9-]*)\s*[-:]\s*(.+?)(?:\s*\((\d+(?:\.\d+)?)\s*(?:units?|u)?\))?\s*$/u',$v,$m)) {
        return array('code'=>preg_replace('/\s+/','',trim($m[1])),'description'=>trim($m[2]),'units'=>isset($m[3])?$m[3]:'');
    }
    return array('code'=>'','description'=>$v,'units'=>'');
}

function ascb_gi_excel_date_to_iso($v) {
    $v = trim((string)$v);
    if ($v === '') return '';
    if (is_numeric($v) && (float)$v > 1000 && (float)$v < 100000) {
        return gmdate('Y-m-d',(int)round(((float)$v-25569)*86400));
    }
    $ts = strtotime($v);
    return $ts !== false ? date('Y-m-d',$ts) : '';
}

function ascb_gi_normalize_student_id($v) {
    $v = ascb_gi_value_norm($v);
    if ($v === '') return '';

    /* Excel/CSV can carry a Student ID as text with a leading apostrophe
       ('2026-00001), non-breaking/zero-width characters, or a Unicode
       dash. Those characters are not part of the permanent Student ID and
       caused the imported value to differ from the value users type in
       Grade Management. */
    $v = preg_replace('/[\\x{200B}-\\x{200D}\\x{FEFF}]/u', '', $v);
    $v = trim($v, " \\t\\r\\n\\0\\x0B\\'");
    $v = str_replace(array('–','—','−','‑','‐'), '-', $v);

    /* Excel may turn numeric IDs into "2026.0". */
    if (preg_match('/^\\d+\\.0+$/',$v)) $v = preg_replace('/\\.0+$/','',$v);

    /* Standard ASCB Student ID: YYYY-NNNNN. If Excel removed the dash
       and the value is exactly 9 digits, restore the canonical form. */
    if (preg_match('/^(\\d{4})(\\d{5})$/', $v, $m)) {
        $v = $m[1] . '-' . $m[2];
    }

    /* Also normalize harmless spacing around the separator. */
    if (preg_match('/^(\\d{4})\\s*-\\s*(\\d{1,})$/', $v, $m)) {
        $v = $m[1] . '-' . $m[2];
    }

    return $v;
}

/* Canonical identity key used ONLY for matching/grouping. The original
   Student ID value is preserved for display/storage, but matching must not
   split one student because of casing or accidental outer whitespace. */
function ascb_gi_student_id_key($v) {
    $v = ascb_gi_normalize_student_id($v);
    $v = preg_replace('/\s+/u', ' ', trim($v));
    return function_exists('mb_strtoupper') ? mb_strtoupper($v, 'UTF-8') : strtoupper($v);
}

function ascb_gi_subject_key($code,$desc) {
    /* (fix) Dati: strtoupper(preg_replace('/[^A-Z0-9]+/', ...)) — nabubura muna ang
       lowercase letters bago pa mag-uppercase, kaya ang \"A1a\" ay naging \"A1\" at
       napagkamalang iisang subject ang A1 at A1a (BSA). Ngayon: uppercase muna / case-safe
       ang pag-strip (ascb_gi_code_key), kaya A1 != A1A. */
    $code = ascb_gi_code_key(ascb_gi_value_norm($code));
    $desc = ascb_gi_norm_desc($desc);
    return $code !== '' ? 'C:'.$code : 'D:'.$desc;
}

/* (fix: doble ang Major) Ang "Program:" sa Excel ay madalas buo na ang label
   (hal. "Bachelor of Secondary Education major in Social Studies"). Dati,
   iyon mismo ang na-save sa `course`, tapos idinagdag pa ang `major`
   ("Social Studies") mula sa Programs table — kaya lumalabas na doble ang
   Major sa Course/Major display. Ang tamang anyo (kapareho ng manual
   Enrollment): `course` = pangalan ng kurso LANG, `major` = major LANG.
   Binabalik true kung may binago. */
function ascb_gi_split_course_major(&$b) {
    $prog  = trim((string) $b['program']);
    $major = trim((string) $b['major']);
    if ($prog === '') return false;
    $changed = false;

    /* 1) "<course> major in <major>" -> hatiin. */
    if (preg_match('/^(.*?)[\s,\-–—]*\bmajor(?:ing)?\s+in\s+(.+)$/iu', $prog, $m) && trim($m[1]) !== '') {
        $prog = trim($m[1]);
        if ($major === '') $major = trim($m[2]);
        $changed = true;
    }

    /* 2) Nakadikit ang major sa dulo ng course (hal. "BSBA - Marketing") at
          pareho sa laman ng Major column -> alisin sa course. */
    if ($major !== '') {
        $q = preg_quote($major, '/');
        if (preg_match('/^(.*?)[\s,:\-–—]+' . $q . '\s*$/iu', $prog, $m) && trim($m[1]) !== '') {
            $prog = trim($m[1]);
            $changed = true;
        }
    }

    if ($changed) { $b['program'] = $prog; $b['major'] = $major; }
    return $changed;
}

function ascb_gi_resolve_program_block($pdo, &$b) {
    $p = null;
    if (trim((string)$b['programCode']) !== '' || trim((string)$b['program']) !== '') {
        $p = ascb_gi_lookup_program($pdo, trim((string)$b['programCode']) !== '' ? $b['programCode'] : $b['program']);
    }
    /* Hatiin ang course/major BAGO punan mula sa Programs table. */
    $split = ascb_gi_split_course_major($b);
    if ($p) {
        $b['programCode'] = $p['code'];
        if ($b['program'] === '') $b['program'] = $p['course_name'];
        elseif ($split && trim((string)$p['course_name']) !== '') $b['program'] = $p['course_name']; /* standard na pangalan */
        if (trim((string)$p['major']) !== '' && ($b['major'] === '' || $split)) $b['major'] = $p['major'];
        $b['_termType'] = $p['term_type'];
    } else $b['_termType'] = '';
    if ($b['term'] !== '') $b['term'] = ascb_gi_normalize_term($b['term'],$b['_termType']);
    if ($b['schoolYear'] !== '') $b['schoolYear'] = ascb_gi_normalize_school_year($b['schoolYear']);
}


/* =========================================================
   CANONICAL DATA REPAIR / ENRICHMENT
   ---------------------------------------------------------
   The source workbook is allowed to be incomplete. Once a Student ID is
   known, the ASCB database is the authoritative source for fields that are
   simply missing from the export. We fill missing values only; we never
   invent a value and we never overwrite a non-empty source value silently.

   The same rule applies to subjects: program_subjects is used to complete a
   missing code/description/units when the available part uniquely identifies
   the curriculum subject. If more than one subject is possible, it stays
   Needs Review instead of guessing.
   ========================================================= */
function ascb_gi_fill_from_existing_profile($pdo, &$b) {
    if (trim((string)$b['studentId']) === '') return;
    $id = ascb_gi_normalize_student_id($b['studentId']);

    $master = null;
    try {
        $q=$pdo->prepare("SELECT student_id,surname,first_name,middle_name,suffix,sex,birth_date,address,mobile_number,email FROM student_master WHERE UPPER(TRIM(student_id))=UPPER(TRIM(?)) LIMIT 1");
        $q->execute(array($id));
        $master=$q->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {}

    if ($master) {
        $copy=array(
            'surname'=>'surname','firstName'=>'first_name','middleName'=>'middle_name',
            'birthdate'=>'birth_date','sex'=>'sex','address'=>'address',
            'mobileNumber'=>'mobile_number','email'=>'email'
        );
        foreach($copy as $dst=>$src) {
            if ((string)($b[$dst]??'')==='') {
                $v=trim((string)($master[$src]??''));
                if ($v!=='') $b[$dst]=$v;
            }
        }
    }

    /* If the export omitted term/SY/program/year, use the matching
       enrollment when exactly one enrollment fits the available context. */
    $where=array('UPPER(TRIM(e.student_id))=UPPER(TRIM(?))','e.archived_at IS NULL'); $args=array($id);
    if (($b['schoolYear']??'')!=='') { $where[]='e.school_year=?'; $args[]=$b['schoolYear']; }
    if (($b['term']??'')!=='') { $where[]='e.trimester=?'; $args[]=$b['term']; }
    try {
        $q=$pdo->prepare("SELECT e.* FROM enrollees e WHERE ".implode(' AND ',$where)." ORDER BY e.id DESC LIMIT 25");
        $q->execute($args); $ers=$q->fetchAll(PDO::FETCH_ASSOC);
        $chosen=null;
        if (count($ers)===1) $chosen=$ers[0];
        elseif (($b['schoolYear']??'')!=='' && ($b['term']??'')!=='' && count($ers)>0) $chosen=$ers[0];
        if ($chosen) {
            $map=array(
                'programCode'=>'program_code','program'=>'course','major'=>'major',
                'yearLevel'=>'year_level','term'=>'trimester','schoolYear'=>'school_year',
                'studentType'=>'student_type','sex'=>'sex','birthdate'=>'birth_date','address'=>'address'
            );
            foreach($map as $dst=>$src) if ((string)($b[$dst]??'')==='') {
                $v=trim((string)($chosen[$src]??'')); if($v!=='') $b[$dst]=$v;
            }
            $b['_repairReason'][]='Missing fields completed from the existing ASCB enrollment.';
        } elseif (count($ers)>1 && (($b['schoolYear']??'')==='' || ($b['term']??'')==='')) {
            $b['_repairAmbiguous'][]='Multiple ASCB enrollments exist; School Year/Term cannot be safely inferred.';
        }
    } catch (Throwable $e) {}
}

/* =========================================================
   SMART CURRICULUM ANALYZER (FIX: duplicate A1 / A1A sa BSA import)
   ---------------------------------------------------------
   Ang ugat ng bug: ang mga code ng BSA ay hindi sumusunod sa karaniwang
   anyo (A1a, BAa, BAb, A&B1, A12*, PATH Fit 1, PA Elec1). Hindi ito
   nakilala ng parser bilang "code", kaya ang buong header/cell (hal. "A1A")
   ang nai-save bilang DESCRIPTION — at dahil iba iyon sa tunay na
   description ("Fundamentals of Accounting") na nasa database na, nagkaroon
   ng bagong subject row (duplicate).

   Ngayon, bago ihambing sa database, ang bawat subject ay "inaanalisa"
   laban sa kurikulum ng PROGRAM ng estudyante (program_subjects):
     - Kinikilala ang code kahit anong anyo (case/espasyo/simbolo), at
       EKSAKTO lang ang tugmaan: A1 != A1a.
     - Kung ang description ay code lang, o nagsisimula sa code
       ("A1a - Fundamentals of Accounting", "BAa Principles of Marketing"),
       hinihiwalay at pinupunan ng tamang description/units mula sa
       kurikulum.
     - Kung walang code, hinahanap sa kurikulum gamit ang description
       (eksakto muna, tapos malapit na tugma kung iisa lang ang kandidato).
     - Kung ang code at description ay magkasalungat (code ng subject X pero
       description ng subject Y), sinusunod ang description at may babala.
     - Ang mga subject na wala sa kurikulum ay iniiwan kung ano ang nasa file.
   Pagkatapos, ang mga subject sa loob ng iisang block ay in-dedupe ulit
   gamit ang canonical code. ========================================================= */
/* TRUE kung ang label ay mukhang SUBJECT CODE (hal. "NSTP 1", "A1a", "PE2") at hindi
   pangalan ng subject (hal. "THESIS WRITING 2"). Ginagamit para hindi maling ituring na
   code ang isang buong description na nasa Code column (o inulit sa dalawang column). */
function ascb_gi_label_looks_like_code($v) {
    $v = trim((string) $v);
    if ($v === '') return false;
    $words = preg_split('/\s+/u', $v, -1, PREG_SPLIT_NO_EMPTY);
    if (count($words) === 1) return strlen($v) <= 12;
    return count($words) <= 2 && strlen($v) <= 15 && preg_match('/\d/', $v) === 1;
}

function ascb_gi_desc_similarity($a, $b) {
    $a = ascb_gi_label_norm($a); $b = ascb_gi_label_norm($b);
    if ($a === '' || $b === '') return 0.0;
    if ($a === $b) return 1.0;
    similar_text($a, $b, $pct);
    return $pct / 100;
}

function ascb_gi_curriculum_index($pdo, $programCode) {
    static $cache = array();
    $pc = strtoupper(trim((string) $programCode));
    if (isset($cache[$pc])) return $cache[$pc];
    $idx = array('entries'=>array(), 'byCode'=>array(), 'byDesc'=>array(), 'codeRegex'=>array());
    try {
        $sql = "SELECT ps.subject_code, ps.description, ps.units, ps.year_level, ps.term_label
                  FROM program_subjects ps JOIN programs p ON p.id = ps.program_id";
        $args = array();
        if ($pc !== '') { $sql .= " WHERE UPPER(TRIM(p.code)) = ?"; $args[] = $pc; }
        $q = $pdo->prepare($sql); $q->execute($args);
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $ck = ascb_gi_code_key($r['subject_code']);
            $dk = ascb_gi_code_key(ascb_gi_norm_desc($r['description']));
            if ($ck === '' && $dk === '') continue;
            $idx['entries'][] = array(
                'code' => trim((string) $r['subject_code']), 'codeKey' => $ck,
                'description' => trim((string) $r['description']), 'descKey' => $dk,
                'units' => $r['units'], 'year' => (string) $r['year_level'], 'term' => (string) $r['term_label'],
            );
        }
    } catch (Throwable $e) { /* walang kurikulum -> walang canonicalization, hindi fatal */ }
    foreach ($idx['entries'] as $i => $e) {
        if ($e['codeKey'] !== '') $idx['byCode'][$e['codeKey']][] = $i;
        if ($e['descKey'] !== '') $idx['byDesc'][$e['descKey']][] = $i;
    }
    /* Regex ng bawat code (pinakamahaba muna) para mahiwalay ang code na nakadikit
       sa description. Ang lookahead ay pumipigil sa "A1" na tumugma sa "A1a ...". */
    $seen = array();
    foreach ($idx['entries'] as $e) {
        if ($e['codeKey'] === '' || isset($seen[$e['codeKey']])) continue;
        $seen[$e['codeKey']] = true;
        $chars = preg_split('//u', $e['codeKey'], -1, PREG_SPLIT_NO_EMPTY);
        $re = '/^' . implode('[\s\-\.&*]*', array_map(function ($c) { return preg_quote($c, '/'); }, $chars)) . '(?![A-Za-z0-9])/iu';
        $idx['codeRegex'][] = array('codeKey'=>$e['codeKey'], 're'=>$re, 'len'=>strlen($e['codeKey']));
    }
    usort($idx['codeRegex'], function ($x, $y) { return $y['len'] - $x['len']; });
    return $cache[$pc] = $idx;
}

/* Pumipili ng iisang curriculum entry mula sa listahan ng kandidato (ayon sa Year/Term kung marami). */
function ascb_gi_curriculum_pick($idx, $list, $yearN, $termN) {
    if (!$list) return null;
    $cands = array();
    foreach ($list as $i) $cands[] = $idx['entries'][$i];
    if (count($cands) > 1) {
        $f = array();
        foreach ($cands as $e) {
            if (($yearN === '' || ascb_gi_label_norm($e['year']) === $yearN) &&
                ($termN === '' || ascb_gi_label_norm($e['term']) === $termN)) $f[] = $e;
        }
        if ($f) $cands = $f;
    }
    $keys = array();
    foreach ($cands as $e) $keys[$e['descKey']] = true;
    return count($keys) === 1 ? $cands[0] : null;
}

/* "A1a - Fundamentals of Accounting" -> array(codeKey=>'A1A', rest=>'Fundamentals of Accounting') */
function ascb_gi_split_embedded_code($idx, $text) {
    $text = trim((string) $text);
    if ($text === '') return null;
    foreach ($idx['codeRegex'] as $cr) {
        if (preg_match($cr['re'], $text, $m)) {
            $rest = preg_replace('/^[\s\-:|\x{2013}\x{2014}\.*&]+/u', '', substr($text, strlen($m[0])));
            return array('codeKey' => $cr['codeKey'], 'rest' => trim((string) $rest));
        }
    }
    return null;
}

function ascb_gi_repair_subjects_from_curriculum($pdo, &$b) {
    $out = array('warnings' => array(), 'errors' => array());
    if (empty($b['subjects'])) return $out;

    $programCode = trim((string) ($b['programCode'] ?? ''));
    $idx   = ascb_gi_curriculum_index($pdo, $programCode);
    $yearN = ascb_gi_label_norm($b['yearLevel'] ?? '');
    $termN = ascb_gi_label_norm($b['term'] ?? '');

    /* (smart) Mga code na EKSPLISITONG nakasulat sa file para sa estudyanteng ito.
       Kapag magkaibang code (A1 at A1a) ang nasa file, hindi sila pagsasamahin kahit
       magkapareho ang description — code ang identity ng subject. */
    $explicitCodes = array();
    foreach ($b['subjects'] as $__s) {
        $__ck = ascb_gi_code_key($__s['code'] ?? '');
        if ($__ck !== '') $explicitCodes[$__ck] = true;
    }

    foreach ($b['subjects'] as $i => &$s) {
        $code = trim((string) ($s['code'] ?? ''));
        $desc = trim((string) ($s['description'] ?? ''));
        if ($code === '' && $desc === '') continue;
        $origLabel = $code !== '' ? $code : $desc;

        /* (1) Hiwalayin ang code na nakadikit sa description / code-lang na description. */
        if ($code === '' && $desc !== '') {
            $sp = ascb_gi_split_embedded_code($idx, $desc);
            if ($sp) {
                $entry = ascb_gi_curriculum_pick($idx, isset($idx['byCode'][$sp['codeKey']]) ? $idx['byCode'][$sp['codeKey']] : array(), $yearN, $termN);
                if ($entry) { $code = $entry['code']; $desc = $sp['rest']; }
            }
        } elseif ($code !== '' && $desc !== '') {
            if (ascb_gi_code_key($desc) === ascb_gi_code_key($code)) {
                if (ascb_gi_label_looks_like_code($code)) {
                    $desc = '';                               /* description = code lang */
                } else {
                    $code = '';                               /* pangalan ng subject ang inulit; hindi code */
                }
            } else {
                $sp = ascb_gi_split_embedded_code($idx, $desc);
                if ($sp && $sp['codeKey'] === ascb_gi_code_key($code)) $desc = $sp['rest'];
            }
        }

        /* Pangalan ng subject ang nasa Code column at walang description: ilipat sa description. */
        if ($code !== '' && $desc === '' && !ascb_gi_label_looks_like_code($code)
            && !isset($idx['byCode'][ascb_gi_code_key($code)])) {
            $desc = $code; $code = '';
        }

        /* (2) Hanapin sa kurikulum. */
        $entry = null;
        $codeKey = ascb_gi_code_key($code);
        if ($codeKey !== '') {
            $entry = ascb_gi_curriculum_pick($idx, isset($idx['byCode'][$codeKey]) ? $idx['byCode'][$codeKey] : array(), $yearN, $termN);
            if (!$entry && $desc === '' && $programCode !== '') {
                /* Walang tugma sa program: ligtas pa rin kung ang code ay natatangi sa buong kurikulum. */
                $gidx = ascb_gi_curriculum_index($pdo, '');
                $entry = ascb_gi_curriculum_pick($gidx, isset($gidx['byCode'][$codeKey]) ? $gidx['byCode'][$codeKey] : array(), $yearN, $termN);
            }
            /* Magkasalungat na code at description: description ang may mas matibay na ebidensya. */
            if ($entry && $desc !== '' && ascb_gi_desc_similarity($desc, $entry['description']) < 0.80) {
                $dk = ascb_gi_code_key(ascb_gi_norm_desc($desc));
                $alt = ascb_gi_curriculum_pick($idx, isset($idx['byDesc'][$dk]) ? $idx['byDesc'][$dk] : array(), $yearN, $termN);
                if ($alt && $alt['codeKey'] !== '' && $alt['codeKey'] !== $entry['codeKey']
                    && !isset($explicitCodes[$alt['codeKey']])) {   /* (smart) may sariling row na ang code na iyon -> huwag i-remap */
                    $out['warnings'][] = "Subject code \"{$code}\" does not match its description \"{$desc}\"; treated as {$alt['code']} - {$alt['description']} (matched by description).";
                    $entry = $alt;
                }
            }
        } elseif ($desc !== '') {
            $dk = ascb_gi_code_key(ascb_gi_norm_desc($desc));
            $entry = ascb_gi_curriculum_pick($idx, isset($idx['byDesc'][$dk]) ? $idx['byDesc'][$dk] : array(), $yearN, $termN);
            if (!$entry && $idx['entries']) {
                /* Malapit na description (typo/ibang baybay) — tatanggapin lang kung iisa ang malinaw na panalo. */
                $best = null; $bestSim = 0; $second = 0;
                foreach ($idx['entries'] as $e) {
                    $sim = ascb_gi_desc_similarity($desc, $e['description']);
                    if ($sim > $bestSim) { $second = $bestSim; $bestSim = $sim; $best = $e; }
                    elseif ($sim > $second && ($best === null || $e['descKey'] !== $best['descKey'])) $second = $sim;
                }
                if ($best && $bestSim >= 0.88 && ($bestSim - $second) >= 0.05) $entry = $best;
            }
        }

        /* (3) Ilapat ang canonical na code/description/units. */
        if ($entry) {
            $s['code'] = $entry['code'] !== '' ? $entry['code'] : $code;
            if ($desc === '' || ascb_gi_desc_similarity($desc, $entry['description']) >= 0.80
                || ascb_gi_code_key(ascb_gi_norm_desc($desc)) === $entry['descKey']) {
                $s['description'] = $entry['description'];
            } else {
                $s['description'] = $desc;   /* ibang wording sa file: iniiwan, code pa rin ang identity */
            }
            if ((string) ($s['units'] ?? '') === '' || (float) $s['units'] <= 0) $s['units'] = $entry['units'];
            $s['_repaired'] = true;
        } else {
            $s['code'] = trim($code);
            if ($desc === '') {
                /* Code lang ang alam at wala sa kurikulum: ang code ang ilalagay na description
                   (pansamantala). Kikilalanin ito ng matcher bilang parehong subject sa susunod na import. */
                $desc = $origLabel;
                $out['warnings'][] = "Subject code \"{$origLabel}\" was not found in the program curriculum and has no description; imported using the code as its description.";
            }
            $s['description'] = $desc;
        }
    }
    unset($s);

    /* (4) I-dedupe ulit ang mga subject sa block gamit ang canonical na code. */
    $seen = array(); $clean = array();
    foreach ($b['subjects'] as $s) {
        $ck = ascb_gi_code_key($s['code'] ?? '');
        $key = $ck !== '' ? 'C:' . $ck : 'D:' . ascb_gi_code_key(ascb_gi_norm_desc($s['description'] ?? ''));
        if (isset($seen[$key])) {
            $prev = $clean[$seen[$key]];
            if ((string) $prev['grade'] === (string) $s['grade'] && (float) $prev['units'] === (float) $s['units']) {
                $out['warnings'][] = "Repeated identical subject \"" . (trim((string) ($s['code'] ?? '')) !== '' ? $s['code'] . ' - ' : '') . "{$s['description']}\" was collapsed.";
            } else {
                $out['errors'][] = "conflicting duplicate for {$b['studentId']} / \"{$s['description']}\". Multiple different grades/values for the same student, term and school year require review.";
            }
            continue;
        }
        $seen[$key] = count($clean);
        $clean[] = $s;
    }
    $b['subjects'] = $clean;
    return $out;
}

function ascb_gi_match_existing_student($pdo, $b) {
    $id = ascb_gi_normalize_student_id($b['studentId']);
    if ($id !== '') return array('studentId'=>$id,'confidence'=>'high','reason'=>'Student ID');
    $sn = ascb_gi_norm_desc($b['surname']);
    $fn = ascb_gi_norm_desc($b['firstName']);
    $mn = ascb_gi_norm_desc($b['middleName']);
    if ($sn === '' || $fn === '') return array('studentId'=>'','confidence'=>'needs_review','reason'=>'Missing Student ID and complete name');

    $sql = "SELECT DISTINCT student_id, surname, first_name, middle_name, birth_date, program_code
              FROM enrollees WHERE UPPER(TRIM(surname))=? AND UPPER(TRIM(first_name))=?";
    $args = array($sn,$fn);
    if ($mn !== '') { $sql .= " AND UPPER(TRIM(COALESCE(middle_name,'')))=?"; $args[]=$mn; }
    $sql .= " LIMIT 20";
    $q=$pdo->prepare($sql); $q->execute($args); $rows=$q->fetchAll(PDO::FETCH_ASSOC);
    /* student_master is the permanent identity source. If the historical
       enrollment table does not contain the name (or the student has no
       enrollment yet), use the master record as the controlled matcher. */
    if (count($rows) === 0) {
        try {
            $msql="SELECT student_id,surname,first_name,middle_name,birth_date FROM student_master WHERE UPPER(TRIM(surname))=? AND UPPER(TRIM(first_name))=?";
            $margs=array($sn,$fn);
            if ($mn !== '') { $msql .= " AND UPPER(TRIM(COALESCE(middle_name,'')))=?"; $margs[]=$mn; }
            $msql .= " LIMIT 20";
            $mq=$pdo->prepare($msql); $mq->execute($margs); $rows=$mq->fetchAll(PDO::FETCH_ASSOC);
        } catch(Throwable $e) {}
    }
    if (count($rows) === 1) return array('studentId'=>$rows[0]['student_id'],'confidence'=>'high','reason'=>'Unique normalized name match');
    if (count($rows) > 1 && $b['birthdate'] !== '') {
        $bd=ascb_gi_excel_date_to_iso($b['birthdate']);
        $hits=array_values(array_filter($rows,function($r)use($bd){return $bd!=='' && (string)$r['birth_date']===$bd;}));
        if (count($hits)===1) return array('studentId'=>$hits[0]['student_id'],'confidence'=>'high','reason'=>'Name + birth date match');
    }
    if (count($rows) > 1) return array('studentId'=>'','confidence'=>'needs_review','reason'=>'Multiple existing students match the normalized name');
    return array('studentId'=>'','confidence'=>'needs_review','reason'=>'No Student ID and no unique existing student match');
}

foreach ($sheetRows as $sheetInfo) { /* populated below; keeps static analyzers happy */ }

try {
    if ($ext === 'csv') {
        $sheetRows[] = array('name'=>'CSV','rows'=>ascb_csv_read($_FILES['file']['tmp_name']));
    } else {
        $sheetRows = ascb_xlsx_read_all_sheets($_FILES['file']['tmp_name']);
    }
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(array('ok'=>false,'error'=>$e->getMessage()));
    exit;
}


/* =========================================================
   CANONICAL / WIDE-GRADE DETECTION
   ---------------------------------------------------------
   Source exports are not required to be row-oriented. Some gradebooks put
   subjects in the COLUMN HEADERS and grades in the cells. Convert those
   layouts into the same canonical subject rows used by the normal parser.
   This is deliberately conservative: a column becomes a subject only when
   most of its non-empty sample values are valid grade values and its header
   is not an obvious administrative field.
   ========================================================= */
function ascb_gi_wide_subject_columns($rows, $headerRow, $fields) {
    $known = array();
    foreach ($fields as $c => $f) $known[(int)$c] = true;
    $blocked = array('remarks','remark','status','student status','address','home address','gender','sex','birthdate','date of birth','student type','school year','academic year','term','semester','trimester','year','year level','program','course','major','student id','student number','surname','last name','first name','given name','middle name','mi','units','unit','credits','credit','grade','grades','final grade','rating');
    $out = array();
    $max = count($rows);
    for ($c=0; $c<count($rows[$headerRow]); $c++) {
        if (isset($known[$c])) continue;
        $label = trim((string)($rows[$headerRow][$c] ?? ''));
        if ($label === '') continue;
        $ln = ascb_gi_label_norm($label);
        if (in_array($ln, $blocked, true)) continue;
        $vals = array(); $valid = 0;
        for ($r=$headerRow+1; $r<$max && count($vals)<20; $r++) {
            $v = trim((string)($rows[$r][$c] ?? ''));
            if ($v==='') continue;
            $vals[]=$v;
            if (ascb_gi_grade_valid($v)) $valid++;
        }
        if (!$vals || $valid===0) continue;
        $ratio=$valid/count($vals);
        if ($ratio < 0.60) continue;
        $parsed=ascb_gi_parse_subject_cell($label);
        if ($parsed['code']==='' && !ascb_gi_value_looks_subject_code($label)) {
            /* A plain descriptive header is acceptable only when it contains
               enough subject-like words and not a generic administrative term. */
            if (strlen($label)<3) continue;
        }
        $out[$c]=array('label'=>$label,'parsed'=>$parsed);
    }
    return $out;
}

foreach ($sheetRows as $sheet) {
    $rows = $sheet['rows'];
    $sheetName = $sheet['name'];
    $header = ascb_gi_find_header($rows);
    if (!$header) {
        /* A sheet with no recognizable header is not fatal if another sheet
           has usable data; report it as an ignored/unrecognized sheet. */
        if (count($sheetRows) === 1) $errors[] = "Sheet \"$sheetName\": no recognizable header row was found.";
        else $warnings[] = "Sheet \"$sheetName\" was skipped because no recognizable header row was found.";
        continue;
    }

    $fields = ascb_gi_contextualize_fields($pdo, $rows, $header['row'], $header['fields']);
    $mapping[$sheetName] = array();
    foreach ($fields as $col=>$field) $mapping[$sheetName][] = array('column'=>$col+1,'field'=>$field,'header'=>$rows[$header['row']][$col]??'', 'semantic'=>($field==='program'||$field==='programCode'?'PROGRAM':($field==='subjectCode'||$field==='subjectDescription'?'SUBJECT':strtoupper($field))));
    foreach ($rows[$header['row']] as $col=>$label) {
        if (trim((string)$label)!=='' && !isset($fields[$col])) $unrecognizedColumns[] = $sheetName.'!'.($col+1).' "'.trim((string)$label).'"';
    }

    $wideSubjectCols = ascb_gi_wide_subject_columns($rows, $header['row'], $fields);
    if ($wideSubjectCols) {
        $mapping[$sheetName][] = array('column'=>'—','field'=>'wide_gradebook','header'=>count($wideSubjectCols).' subject columns detected','semantic'=>'WIDE GRADEBOOK');
    }

    $metaProgram = ascb_gi_meta_value(array_slice($rows,0,$header['row']),array('program','course','degree'));
    $metaSY = ascb_gi_meta_value(array_slice($rows,0,$header['row']),array('school year','academic year','sy','ay'));
    $metaTerm = ascb_gi_meta_value(array_slice($rows,0,$header['row']),array('term','trimester','semester'));

    $current = null;
    $seenByBlock = array();

    for ($ri=$header['row']+1; $ri<count($rows); $ri++) {
        $r=$rows[$ri]??array();
        if (!$r || !array_filter($r,function($v){return trim((string)$v)!=='';})) continue;
        /* Repeated header row inside an exported workbook. */
        list($repeatScore,$repeatFields,$repeatUnknown)=ascb_gi_header_score($r);
        if ($repeatScore >= $header['score']*0.75 && isset($repeatFields[array_key_first($repeatFields)])) continue;

        $get=function($field)use($r,$fields){
            foreach($fields as $c=>$f) if($f===$field) return trim((string)($r[$c]??''));
            return '';
        };

        $sid=ascb_gi_normalize_student_id($get('studentId'));
        $surname=ascb_gi_value_norm($get('surname'));
        $first=ascb_gi_value_norm($get('firstName'));
        $middle=ascb_gi_value_norm($get('middleName'));

        $hasStudentIdentity = ($sid!=='' || ($surname!=='' && $first!==''));
        $hasSubjectSignal = ($get('subjectCode')!=='' || $get('subjectDescription')!=='' || $get('grade')!=='' || $get('units')!=='');
        $sameCurrent = $current && (
            ($sid!=='' && $sid===ascb_gi_student_id_key($current['studentId']??'')) ||
            ($sid==='' && $surname!=='' && $first!=='' &&
             ascb_gi_norm_desc($surname)===ascb_gi_norm_desc($current['surname']) &&
             ascb_gi_norm_desc($first)===ascb_gi_norm_desc($current['firstName']))
        );

        if ($hasStudentIdentity && !$sameCurrent) {
            if ($current) $blocks[]=$current;
            $current=array(
                'line'=>$ri+1,'sheet'=>$sheetName,'studentId'=>$sid,'surname'=>$surname,'firstName'=>$first,'middleName'=>$middle,
                'suffix'=>ascb_gi_value_norm($get('suffix')),'birthdate'=>ascb_gi_value_norm($get('birthdate')),
                'studentType'=>ascb_gi_value_norm($get('studentType')),'sex'=>ascb_gi_value_norm($get('sex')),
                'address'=>ascb_gi_value_norm($get('address')),'mobileNumber'=>ascb_gi_value_norm($get('mobileNumber')),
                'email'=>ascb_gi_value_norm($get('email')),
                'programCode'=>ascb_gi_value_norm($get('programCode')),'program'=>ascb_gi_value_norm($get('program')),
                'major'=>ascb_gi_value_norm($get('major')),'yearLevel'=>ascb_gi_value_norm($get('yearLevel')),
                'term'=>ascb_gi_value_norm($get('term')),'schoolYear'=>ascb_gi_value_norm($get('schoolYear')),
                'subjects'=>array(),'seen'=>array(),'_confidence'=>'high','_confidenceReasons'=>array()
            );
            if ($current['program']==='' && $metaProgram!=='') $current['program']=$metaProgram;
            if ($current['schoolYear']==='' && $metaSY!=='') $current['schoolYear']=$metaSY;
            if ($current['term']==='' && $metaTerm!=='') $current['term']=$metaTerm;
        } elseif (!$current && ($hasSubjectSignal || $hasStudentIdentity)) {
            $errors[]="Sheet \"$sheetName\", row ".($ri+1).": subject/grade data appears before a student record.";
            continue;
        }

        if (!$current) continue;

        /* Carry-forward values from merged cells. */
        foreach (array('birthdate','studentType','sex','address','mobileNumber','email','programCode','program','major','yearLevel','term','schoolYear') as $f) {
            $v=$get($f); if ($current[$f]==='' && $v!=='') $current[$f]=$v;
        }

        /* IMPORTANT: Year Level is normalized ONLY for the Year Level field.
           Never run this against Grade: a Grade value of 1 means 1.0, not 1st Year.
           This also makes Preview/Normalized Export/Commit use the same canonical value. */
        if ($current['yearLevel'] !== '') {
            $current['yearLevel'] = ascb_gi_normalize_year_level($current['yearLevel']);
        }

        ascb_gi_resolve_program_block($pdo,$current);
        if ($current['schoolYear']==='' && $metaSY!=='') $current['schoolYear']=ascb_gi_normalize_school_year($metaSY);
        if ($current['term']==='' && $metaTerm!=='') $current['term']=ascb_gi_normalize_term($metaTerm,$current['_termType']??'');

        $subjCode=ascb_gi_value_norm($get('subjectCode'));
        $subjDesc=ascb_gi_value_norm($get('subjectDescription'));
        $units=ascb_gi_value_norm($get('units'));
        $grade=ascb_gi_value_norm($get('grade'));

        /* If a single "Subject" column contains code + description, split it. */
        if ($subjDesc!=='' && $subjCode==='' && preg_match('/\s[-:|]\s/',$subjDesc)) {
            $parsed=ascb_gi_parse_subject_cell($subjDesc);
            if ($parsed['description']!==$subjDesc || $parsed['code']!=='') {
                $subjCode=$parsed['code']; $subjDesc=$parsed['description'];
                if ($units==='' && $parsed['units']!=='') $units=$parsed['units'];
            }
        }
        if ($units!=='' && preg_match('/^[-–—]$/u',$units)) $units='0';

        /* Gradebook/wide layout: no explicit Subject/Description column.
           Every safe wide subject column is converted to one canonical
           subject row. This also supports headers that are plain descriptions
           (for example "Understanding the Self") rather than code+description. */
        if ($subjCode==='' && $subjDesc==='' && !empty($wideSubjectCols)) {
            $wideAdded=false;
            foreach ($wideSubjectCols as $wc=>$wi) {
                $cell=trim((string)($r[$wc]??''));
                if ($cell==='') continue;
                if (!ascb_gi_grade_valid($cell)) continue;
                $parsed=$wi['parsed'];
                $wcode=$parsed['code']!=='' ? $parsed['code'] : (ascb_gi_value_looks_subject_code($wi['label']) ? $wi['label'] : '');
                $wdesc=$parsed['description']!=='' ? $parsed['description'] : preg_replace('/\s*(grade|mark|rating)\s*$/i','',$wi['label']);
                $wunits=$parsed['units']!=='' ? $parsed['units'] : '';
                if ($wdesc==='') continue;
                $wk=ascb_gi_subject_key($wcode,$wdesc);
                if (isset($current['seen'][$wk])) continue;
                $current['seen'][$wk]=array('grade'=>ascb_normalize_grade($cell),'units'=>($wunits!==''?(float)$wunits:0));
                $current['subjects'][]=array('code'=>$wcode,'description'=>$wdesc,'grade'=>ascb_normalize_grade($cell),'units'=>($wunits!==''?(float)$wunits:0));
                $wideAdded=true;
            }
            if ($wideAdded) continue;
        }

        if ($subjCode==='' && $subjDesc==='') continue;
        if ($subjDesc==='') {
            $parsed=ascb_gi_parse_subject_cell($subjCode);
            if ($parsed['description']!=='') { $subjCode=$parsed['code']; $subjDesc=$parsed['description']; if($units===''&&$parsed['units']!=='')$units=$parsed['units']; }
        }
        if ($subjDesc==='') {
            $errors[]="Sheet \"$sheetName\", row ".($ri+1).": Subject Description could not be identified.";
            continue;
        }
        if ($units!=='' && (!is_numeric($units)||(float)$units<0||(float)$units>99)) {
            $errors[]="Sheet \"$sheetName\", row ".($ri+1).": invalid Units \"$units\".";
            continue;
        }
        if (!ascb_gi_grade_valid($grade)) {
            $errors[]="Sheet \"$sheetName\", row ".($ri+1).": invalid Grade \"$grade\" for \"$subjDesc\".";
            continue;
        }
        $grade=ascb_normalize_grade($grade);
        $key=ascb_gi_subject_key($subjCode,$subjDesc);
        if (isset($current['seen'][$key])) {
            $prev=$current['seen'][$key];
            /* Exact repeat = safe duplicate in the same file; conflicting
               values = Needs Review. */
            if ((string)$prev['grade']===(string)$grade && (float)$prev['units']===(float)($units!==''?$units:0)) {
                $warnings[]="Sheet \"$sheetName\", row ".($ri+1).": repeated identical subject \"".($subjCode!==''?$subjCode.' - ':'')."$subjDesc\" for {$current['studentId']} was collapsed.";
                continue;
            }
            $dupInFile++;
            $errors[]="Sheet \"$sheetName\", row ".($ri+1).": conflicting duplicate for {$current['studentId']} / \"$subjDesc\". Multiple different grades/values for the same student, term and school year require review.";
            continue;
        }
        $current['seen'][$key]=array('grade'=>$grade,'units'=>($units!==''?(float)$units:0));
        $current['subjects'][]=array('code'=>$subjCode,'description'=>$subjDesc,'grade'=>$grade,'units'=>($units!==''?(float)$units:0));

        /* Row-oriented format handled above. Wide gradebook subjects are
           added independently below, using the same canonical subject key. */
        if (!empty($wideSubjectCols)) {
            foreach ($wideSubjectCols as $wc=>$wi) {
                $wv=trim((string)($r[$wc]??''));
                if ($wv==='') continue;
                if (!ascb_gi_grade_valid($wv)) continue;
                $pc=$wi['parsed'];
                $wcode=$pc['code']!=='' ? $pc['code'] : (ascb_gi_value_looks_subject_code($wi['label']) ? $wi['label'] : '');
                $wdesc=$pc['description']!=='' ? $pc['description'] : $wi['label'];
                $wunits=$pc['units']!=='' ? $pc['units'] : '';
                $wk=ascb_gi_subject_key($wcode,$wdesc);
                if (isset($current['seen'][$wk])) continue;
                $current['seen'][$wk]=array('grade'=>ascb_normalize_grade($wv),'units'=>($wunits!==''?(float)$wunits:0));
                $current['subjects'][]=array('code'=>$wcode,'description'=>$wdesc,'grade'=>ascb_normalize_grade($wv),'units'=>($wunits!==''?(float)$wunits:0));
            }
        }
    }
    if ($current) $blocks[]=$current;
}

/* Resolve missing Student IDs only when the existing database has a unique
   controlled match. Ambiguous/no-match records are never guessed. */
foreach ($blocks as $bi=>&$b) {
    ascb_gi_resolve_program_block($pdo,$b);
    $match=ascb_gi_match_existing_student($pdo,$b);
    if ($b['studentId']==='' && $match['studentId']!=='') {
        $b['studentId']=$match['studentId'];
        $b['_confidence']=$match['confidence'];
        $b['_confidenceReasons'][]=$match['reason'];
    } elseif ($b['studentId']==='') {
        $b['_confidence']='needs_review';
        $errors[]="Sheet \"{$b['sheet']}\", row {$b['line']}: {$match['reason']}. The system will not invent a Student ID.";
    }
    if ($b['studentId']==='') continue;

    /* Repair incomplete exports from authoritative ASCB records before
       validating the block. This is what allows a file with only Student ID
       + Subject + Grade to be reconstructed safely. */
    ascb_gi_fill_from_existing_profile($pdo,$b);
    ascb_gi_resolve_program_block($pdo,$b);
    $smartSubj = ascb_gi_repair_subjects_from_curriculum($pdo,$b);
    foreach ($smartSubj['warnings'] as $sw) $warnings[] = "Sheet \"{$b['sheet']}\", row {$b['line']}: ".$sw;
    foreach ($smartSubj['errors'] as $se) { $errors[] = "Sheet \"{$b['sheet']}\", row {$b['line']}: ".$se; $dupInFile++; }

    if ($b['surname']==='' || $b['firstName']==='') $errors[]="Sheet \"{$b['sheet']}\", row {$b['line']}: complete student name is required.";
    if ($b['schoolYear']==='') $errors[]="Sheet \"{$b['sheet']}\", row {$b['line']}: School Year could not be identified.";
    if ($b['term']==='') $errors[]="Sheet \"{$b['sheet']}\", row {$b['line']}: Term/Trimester/Semester could not be identified.";
    if ($b['programCode']==='' && $b['program']==='') {
        /* Existing enrollment can supply the historical program; new enrollment cannot. */
        $q=$pdo->prepare("SELECT program_code,course,major FROM enrollees WHERE UPPER(TRIM(student_id))=UPPER(TRIM(?)) AND UPPER(TRIM(school_year))=UPPER(TRIM(?)) AND UPPER(TRIM(trimester))=UPPER(TRIM(?)) LIMIT 1");
        $q->execute(array($b['studentId'],$b['schoolYear'],$b['term']));
        $existing=$q->fetch(PDO::FETCH_ASSOC);
        if ($existing) {
            $b['programCode']=$existing['program_code']; $b['program']=$existing['course']; $b['major']=$existing['major'];
            ascb_gi_split_course_major($b); /* (fix) iwas doble ang Major sa lumang record */
        } else $errors[]="Sheet \"{$b['sheet']}\", row {$b['line']}: Program/Course could not be identified for a new enrollment.";
    }
    if ($b['programCode']!=='' && !$b['_termType']) {
        ascb_gi_resolve_program_block($pdo,$b);
    }
    if ($b['term']!=='' && $b['_termType']!=='' && !ascb_gi_term_fits_program($b['term'],$b['_termType'])) {
        $errors[]="Sheet \"{$b['sheet']}\", row {$b['line']}: Term \"{$b['term']}\" does not match the program's {$b['_termType']} term system.";
    }
}
unset($b);

/* Merge blocks that refer to the same Student + School Year + Term.
   This is essential for multi-sheet workbooks and exports that repeat the
   student header on separate sections: only ONE enrollment is ever created
   for a tuple. Conflicting subject values are escalated to Needs Review. */
if ($blocks) {
    $merged = array();
    $index = array();
    foreach ($blocks as $b) {
        $key = ascb_gi_tuple_key($b['studentId'],$b['schoolYear'],$b['term']);
        if ($b['studentId']==='' || $b['schoolYear']==='' || $b['term']==='') {
            $merged[]=$b; continue;
        }
        if (!isset($index[$key])) {
            $index[$key]=count($merged);
            $merged[]=$b;
            continue;
        }
        $mi=$index[$key];
        foreach ($b['subjects'] as $s) {
            $sk=ascb_gi_subject_key($s['code'],$s['description']);
            $found=null;
            foreach ($merged[$mi]['subjects'] as $existingIndex=>$es) {
                if (ascb_gi_subject_key($es['code'],$es['description'])===$sk) { $found=$existingIndex; break; }
            }
            if ($found===null) $merged[$mi]['subjects'][]=$s;
            else {
                $es=$merged[$mi]['subjects'][$found];
                if ((string)$es['grade']!==(string)$s['grade'] || (float)$es['units']!==(float)$s['units']) {
                    $errors[]="Conflicting duplicate across sheets/sections: Student ID {$b['studentId']}, {$b['term']}, {$b['schoolYear']}, Subject \"{$s['description']}\" has different values.";
                    $dupInFile++;
                }
            }
        }
    }
    $blocks=$merged;
}

if (!$blocks && !$errors) $errors[]='No student/subject records could be identified in the workbook.';

/* Confidence is intentionally conservative: any unresolved mapping/error is
   Needs Review; explicit ID + recognized subject/term/SY is High. */
foreach ($blocks as $bi=>$b) {
    $confidence='high';
    if (($b['_confidence']??'high')!=='high' || count($b['subjects'])===0) $confidence='medium';
    $blocks[$bi]['_confidence']=$confidence;
}


/* ---------- 4. CANONICAL ASCB EXPORT: source workbook -> ASCB Department Export ----------
   IMPORTANT: this action never writes to the database. It exports the same
   semantic shape used by the existing ASCB Department Export, so a registrar
   can visually verify the normalized result before migration. */
if ($action === 'export_normalized') {
    if ($errors) {
        http_response_code(422);
        echo json_encode(array(
            'ok'=>false,
            'error'=>'The workbook cannot be normalized yet. Resolve the Needs Review items first.',
            'errors'=>$errors,
            'warnings'=>$warnings,
            'mapping'=>$mapping,
            'unrecognizedColumns'=>$unrecognizedColumns
        ));
        exit;
    }
    $rows=array();
    $rows[]=array(array('v'=>'ASCB Department Student Data Export'));
    $rows[]=array(array('v'=>'Source File'),array('v'=>$origName));
    $rows[]=array(array('v'=>'Normalized By'),array('v'=>'ASCB Intelligent Excel Import'));
    $rows[]=array();
    $rows[]=array(
        array('v'=>'Student ID','style'=>1),array('v'=>'Surname','style'=>1),array('v'=>'Given Name','style'=>1),array('v'=>'Middle Name','style'=>1),
        array('v'=>'Birthdate','style'=>1),array('v'=>'Student Type','style'=>1),array('v'=>'Program Code','style'=>1),array('v'=>'Program','style'=>1),
        array('v'=>'Major','style'=>1),array('v'=>'Year Level','style'=>1),array('v'=>'Term','style'=>1),array('v'=>'School Year','style'=>1),
        array('v'=>'Subject Code','style'=>1),array('v'=>'Subject Description','style'=>1),array('v'=>'Grade','style'=>1),array('v'=>'Units','style'=>1)
    );
    foreach($blocks as $b){
        $birth=ascb_gi_excel_date_to_iso($b['birthdate']);
        $base=array(
            (string)$b['studentId'], $b['surname'], $b['firstName'], $b['middleName'], $birth,
            $b['studentType'], $b['programCode'], $b['program'], $b['major'], $b['yearLevel'], $b['term'], $b['schoolYear']
        );
        $first=true;
        foreach($b['subjects'] as $sub){
            $prefix=$first?$base:array_fill(0,12,'');
            $rows[]=array_merge(
                array_map(function($v){return array('v'=>(string)$v,'style'=>2);},$prefix),
                array(
                    array('v'=>(string)$sub['code'],'style'=>2),array('v'=>(string)$sub['description'],'style'=>2),
                    array('v'=>(string)$sub['grade'],'style'=>3,'type'=>'s'),array('v'=>(string)$sub['units'],'style'=>3)
                )
            );
            $first=false;
        }
    }
    try{$bytes=ascb_xlsx_build('ASCB Import Normalized',$rows,array(),array('A'=>18,'B'=>18,'C'=>18,'D'=>16,'E'=>16,'F'=>14,'G'=>16,'H'=>34,'I'=>24,'J'=>12,'K'=>18,'L'=>16,'M'=>18,'N'=>44,'O'=>10,'P'=>9));}
    catch(Throwable $e){http_response_code(500);echo json_encode(array('ok'=>false,'error'=>ASCB_DEBUG?$e->getMessage():'Unable to create normalized Excel.'));exit;}
    $safe=preg_replace('/[^A-Za-z0-9_-]+/','_',pathinfo($origName,PATHINFO_FILENAME));
    $filename='ASCB_Normalized_'.$safe.'_'.date('Ymd_His').'.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="'.$filename.'"');
    header('Content-Length: '.strlen($bytes)); header('Cache-Control: no-store, no-cache, must-revalidate'); header('Pragma: no-cache');
    echo $bytes; exit;
}

/* ---------- 5. PREVIEW: ibalik lang ang buod, walang isusulat sa DB ---------- */

if ($action === 'preview') {
    $subjectCount = 0;
    $newCount = 0;
    $existingCount = 0;

    /* (FIX) Iisang shared function na lang ang gumagawa ng batch
       lookup AT ng duplicate-vs-database detection — kaparehong
       function na ginagamit din sa COMMIT sa ibaba, para hindi na
       magkaiba/mag-out-of-sync ang dalawang pass. Kahit ISANG
       duplicate lang (hindi na kailangang LAHAT) ay idinadagdag na
       agad sa $errors — kaya awtomatikong naka-hide ang Commit
       button sa frontend (walang partial import). */
    $ascbGiDupInfo = ascb_gi_detect_existing_duplicates($pdo, $blocks);
    $ascbGiLookup = $ascbGiDupInfo['lookup'];
    $dupExisting = $ascbGiDupInfo['dupExisting'];   // nasa database na (parehong Subject, anumang grade)
    if ($ascbGiDupInfo['dupErrors']) $errors = array_merge($errors, $ascbGiDupInfo['dupErrors']);

    $sample = array();
    $existingStudentIds = array();
    foreach ($blocks as $b) if ($b['studentId'] !== '') $existingStudentIds[$b['studentId']] = true;
    $knownStudents = 0;
    if ($existingStudentIds) {
        $ids=array_keys($existingStudentIds);
        $in=implode(',',array_fill(0,count($ids),'?'));
        $q=$pdo->prepare("SELECT DISTINCT student_id FROM enrollees WHERE UPPER(TRIM(student_id)) IN ($in)");
        $q->execute($ids);
        $knownStudents=$q->rowCount();
    }
    $newSubjects=0; $existingSubjects=0; $updateRows=0;
    foreach ($blocks as $idx => $b) {
        $subjectCount += count($b['subjects']);

        $tupleKey = ascb_gi_tuple_key($b['studentId'], $b['schoolYear'], $b['term']);
        $foundId = isset($ascbGiLookup['enrollmentIds'][$tupleKey]) ? $ascbGiLookup['enrollmentIds'][$tupleKey] : null;
        if ($foundId !== null) $existingCount++; else $newCount++;

        $blockDup = isset($ascbGiDupInfo['perBlockDup'][$idx]) ? $ascbGiDupInfo['perBlockDup'][$idx] : 0;
        $rowsForEnrollment = $foundId !== null && isset($ascbGiLookup['subjectRows'][$foundId]) ? $ascbGiLookup['subjectRows'][$foundId] : array();
        foreach ($b['subjects'] as $ss) {
            $ex=ascb_gi_find_subject_row($rowsForEnrollment,$ss['description'],$ss['code']);
            if ($ex) { $existingSubjects++; $updateRows++; } else $newSubjects++;
        }
        if (count($sample) < 20) {
            $sample[] = array(
                'studentId' => $b['studentId'],
                'name' => (function ($b, $pdo) { list($x, $pos) = ascb_gi_master_suffix($pdo, $b); return ascb_name_print($b['surname'], $b['firstName'], $b['middleName'], $x, $pos); })($b, $pdo),
                'term' => $b['term'],
                'schoolYear' => $b['schoolYear'],
                'subjectCount' => count($b['subjects']),
                'duplicateCount' => $blockDup,
                'importCount' => max(0, count($b['subjects']) - $blockDup),
            );
        }
    }

    $repairedFields=0; $repairNotes=array();
    foreach($blocks as $rb){
        if(!empty($rb['_repairReason'])){ $repairedFields++; foreach($rb['_repairReason'] as $rn) $repairNotes[]=$rn; }
        if(!empty($rb['_repairAmbiguous'])) foreach($rb['_repairAmbiguous'] as $rn) $warnings[]=$rn;
        foreach($rb['subjects'] as $rs) if(!empty($rs['_repaired'])) $repairedFields++;
    }
    $repairNotes=array_values(array_unique($repairNotes));

    echo json_encode(array(
        'ok' => true,
        'preview' => true,
        'format' => $format,
        'studentBlocks' => count($blocks),
        'newEnrollments' => $newCount,
        'existingEnrollments' => $existingCount,
        'subjectRows' => $subjectCount,
        'studentsExisting' => $knownStudents,
        'studentsNew' => max(0, count($blocks)-$knownStudents),
        'subjectsExisting' => $existingSubjects,
        'subjectsNew' => $newSubjects,
        'gradeUpdates' => $updateRows,
        'confidence' => empty($errors) ? 'High Confidence' : 'Needs Review',
        'autoRepaired' => $repairedFields,
        'repairNotes' => $repairNotes,
        'warnings' => $warnings,
        'mapping' => $mapping,
        'unrecognizedColumns' => $unrecognizedColumns,
        'sheetsProcessed' => count($sheetRows),
        /* (FIX) Ang mga ito ay HINDI na basta "nilalaktawan" — DUPLICATE
           errors ito (nasa $errors na rin), kaya haharangin ang BUONG
           import hangga't hindi pa naitatama ng UNIT HEAD ang file. */
        'duplicateRowsInFile' => $dupInFile,
        'duplicateRowsExisting' => $dupExisting,
        'duplicateRows' => $dupInFile + $dupExisting,
        /* Kung wala pang duplicate, ito ang talagang isusulat sa database. */
        'importSubjectRows' => $errors ? 0 : $subjectCount,
        'errors' => $errors,
        'sample' => $sample,
    ));
    exit;
}

/* ---------- 5. COMMIT: isulat na sa database (all-or-nothing) ---------- */

/* (FIX) DUPLICATE-VS-DATABASE GUARD (commit-time re-check) — kailangan
   itong gawin dito, BAGO ang "if ($errors)" guard sa ibaba, dahil ang
   mga within-file duplicate errors lang ang nasa $errors sa puntong ito
   (nadagdag na habang pina-parse ang file sa itaas — parehong ginagamit
   ng Preview AT Commit). Ang laban-sa-database na duplicate check ay
   kailangan pa ring gawin dito nang hiwalay dahil nangangailangan ito
   ng query sa database — kung tinawag direkta ang commit (o kung may
   ibang nag-import na ng magkaparehong record sa pagitan ng Preview at
   Commit), dapat pa rin itong mahuli BAGO magsimula ang transaction.

   Kahit ISANG subject row lang ang duplicate (Student+Subject+Term+
   School Year na existing na sa database) — HAHARANGIN ang BUONG
   commit, walang partial import (0 records inserted/updated). Iisang
   batch lookup lang (2 query) — muling ginagamit ang $ascbGiLookup na
   ito sa ibaba ng commit loop mismo, kaya walang double query. */
$ascbGiDupInfo = ascb_gi_detect_existing_duplicates($pdo, $blocks);
if ($ascbGiDupInfo['dupErrors']) $errors = array_merge($errors, $ascbGiDupInfo['dupErrors']);

if ($errors) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'There are errors in the file — please fix them before committing. No records were inserted or updated.', 'errors' => $errors));
    exit;
}

$ascbGiLookup = $ascbGiDupInfo['lookup'];

$myId = (int) ascb_get($ascbUser, 'id', 0);
$enrollCount = 0;
$subjectCount = 0;
$studentCreatedCount = 0;
$studentUpdatedCount = 0;
$gradeInsertedCount = 0;
$gradeUpdatedCount = 0;
$subjectCreatedCount = 0;
$subjectUpdatedCount = 0;

/* Bilang ng subject row na nilaktawan dahil existing na sa
   database ang Subject na ito para sa Enrollment (defense-in-depth
   lang ito — dapat naharang na ang mga ito sa guard sa itaas BAGO
   pa nagsimula ang transaction; hindi ito dapat maabot sa normal
   na daloy). */

/* =========================================================
   NAME SYNC FIX — Student ID is the permanent identity.
   If an existing enrollment is found by Student ID + School Year + Term,
   the imported name must NOT be ignored just because the surname changed
   (e.g. marriage). The matching enrollment is refreshed with the imported
   current name, and student_master is also synchronized. A name-history
   row is written when the permanent Master Record changes.
   Historical enrollments from OTHER terms are intentionally left untouched.
   ========================================================= */
function ascb_gi_sync_existing_name($pdo, $enrollmentId, $b, $userId) {
    $sid = trim((string) $b['studentId']);
    $surname = trim((string) $b['surname']);
    $first = trim((string) $b['firstName']);
    $middle = trim((string) $b['middleName']);
    if ($sid === '' || $surname === '' || $first === '') return false;

    $q = $pdo->prepare(
        "SELECT student_id, surname, first_name, middle_name" .
        (ascb_column_exists($pdo, 'enrollees', 'suffix') ? ", suffix" : ", NULL AS suffix") .
        (ascb_column_exists($pdo, 'enrollees', 'suffix_position') ? ", suffix_position" : ", 'separate' AS suffix_position") .
        " FROM enrollees WHERE id = ? LIMIT 1 FOR UPDATE"
    );
    $q->execute(array((int)$enrollmentId));
    $oldEnrollment = $q->fetch(PDO::FETCH_ASSOC);
    if (!$oldEnrollment) return false;

    $nameChanged = (
        strcasecmp(trim((string)$oldEnrollment['surname']), $surname) !== 0 ||
        strcasecmp(trim((string)$oldEnrollment['first_name']), $first) !== 0 ||
        strcasecmp(trim((string)$oldEnrollment['middle_name']), $middle) !== 0
    );

    if ($nameChanged) {
        $sets = array('surname = ?', 'first_name = ?', 'middle_name = ?');
        $params = array($surname, $first, $middle);

        /* Import does not require a suffix column, but if one exists and the
           file supplies it, keep the enrollment's PSA suffix placement. */
        if (ascb_column_exists($pdo, 'enrollees', 'suffix') && array_key_exists('suffix', $b)) {
            $sets[] = 'suffix = ?';
            $params[] = trim((string)$b['suffix']) !== '' ? trim((string)$b['suffix']) : null;
        }
        $params[] = (int)$enrollmentId;
        $u = $pdo->prepare("UPDATE enrollees SET " . implode(', ', $sets) . " WHERE id = ?");
        $u->execute($params);
    }

    /* Permanent identity record: synchronize current name by Student ID.
       Do not silently overwrite a different name; record the change first. */
    if (ascb_master_available($pdo)) {
        $mq = $pdo->prepare("SELECT * FROM student_master WHERE student_id = ? LIMIT 1 FOR UPDATE");
        $mq->execute(array($sid));
        $master = $mq->fetch(PDO::FETCH_ASSOC);

        if (!$master) {
            ascb_master_ensure($pdo, $sid, array(
                'surname' => $surname,
                'first_name' => $first,
                'middle_name' => $middle,
                'sex' => ascb_get($b, 'sex', ''),
                'birth_date' => ascb_get($b, 'birthdate', ''),
                'address' => ascb_get($b, 'address', '')
            ), $userId);
        } else {
            $masterChanged = (
                strcasecmp(trim((string)$master['surname']), $surname) !== 0 ||
                strcasecmp(trim((string)$master['first_name']), $first) !== 0 ||
                strcasecmp(trim((string)$master['middle_name']), $middle) !== 0
            );

            if ($masterChanged) {
                $hasPos = ascb_column_exists($pdo, 'student_master', 'suffix_position');
                $oldPos = isset($master['suffix_position']) ? $master['suffix_position'] : 'separate';
                $newPos = $hasPos ? ascb_normalize_suffix_position(isset($b['suffix_position']) ? $b['suffix_position'] : $oldPos) : 'separate';
                $oldSuffix = isset($master['suffix']) ? trim((string)$master['suffix']) : '';
                $newSuffix = isset($b['suffix']) ? trim((string)$b['suffix']) : $oldSuffix;

                if (ascb_column_exists($pdo, 'student_name_history', 'previous_suffix_position')) {
                    $hi = $pdo->prepare(
                        "INSERT INTO student_name_history
                         (student_id, previous_surname, previous_first_name, previous_middle_name,
                          previous_suffix, previous_suffix_position,
                          new_surname, new_first_name, new_middle_name,
                          new_suffix, new_suffix_position, reason, updated_by)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    );
                    $hi->execute(array(
                        $sid,
                        $master['surname'], $master['first_name'], $master['middle_name'],
                        $oldSuffix !== '' ? $oldSuffix : null, $oldPos,
                        $surname, $first, $middle !== '' ? $middle : null,
                        $newSuffix !== '' ? $newSuffix : null, $newPos,
                        'Grade Import — Student ID matched; name synchronized from import',
                        $userId > 0 ? $userId : null
                    ));
                } else {
                    $hi = $pdo->prepare(
                        "INSERT INTO student_name_history
                         (student_id, previous_surname, previous_first_name, previous_middle_name,
                          previous_suffix, new_surname, new_first_name, new_middle_name,
                          new_suffix, reason, updated_by)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?)"
                    );
                    $hi->execute(array(
                        $sid,
                        $master['surname'], $master['first_name'], $master['middle_name'],
                        $oldSuffix !== '' ? $oldSuffix : null,
                        $surname, $first, $middle !== '' ? $middle : null,
                        $newSuffix !== '' ? $newSuffix : null,
                        'Grade Import — Student ID matched; name synchronized from import',
                        $userId > 0 ? $userId : null
                    ));
                }

                $sets = array('surname = ?', 'first_name = ?', 'middle_name = ?', 'updated_by = ?');
                $params = array($surname, $first, $middle !== '' ? $middle : null, $userId > 0 ? $userId : null);
                if (ascb_column_exists($pdo, 'student_master', 'suffix')) {
                    $sets[] = 'suffix = ?';
                    $params[] = $newSuffix !== '' ? $newSuffix : null;
                }
                if ($hasPos) {
                    $sets[] = 'suffix_position = ?';
                    $params[] = $newPos;
                }
                $params[] = $sid;
                $mu = $pdo->prepare("UPDATE student_master SET " . implode(', ', $sets) . " WHERE student_id = ?");
                $mu->execute($params);
            }
        }
    }

    return $nameChanged;
}

$skippedCount = 0;

// Batch-fetch ng department_id per unique Program Code (isang query
// para sa LAHAT ng bagong estudyante sa file), kapalit ng dating
// "SELECT department_id FROM programs ..." PER BLOCK.
$ascbGiDeptByCode = array();
$ascbGiProgramCodes = array();
foreach ($blocks as $b) {
    if ($b['programCode'] !== '') $ascbGiProgramCodes[strtoupper(trim($b['programCode']))] = true;
}
if ($ascbGiProgramCodes) {
    $codes = array_keys($ascbGiProgramCodes);
    $in = implode(',', array_fill(0, count($codes), '?'));
    $dq = $pdo->prepare("SELECT UPPER(TRIM(code)) AS norm_code, department_id FROM programs WHERE UPPER(TRIM(code)) IN ($in)");
    $dq->execute($codes);
    foreach ($dq->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $ascbGiDeptByCode[$row['norm_code']] = $row['department_id'];
    }
}

/* Student IDs na aktwal na nagbago (bagong enrollment o bagong/
   na-update na subject/grade) sa commit na ito — ibinabalik sa
   response para agad ma-locate/ma-search ng UNIT HEAD sa Grade
   Management, kahit hindi ito sa unang page (25 per page, alpabetikal)
   at kahit may aktibong search filter pa mula sa dati. Ito ang tunay
   na dahilan kung bakit "successful ang import pero parang hindi
   lumalabas sa View/Update" — nandoon naman talaga ang record, hindi
   lang ito kaagad nakikita ng user. */
$ascbGiTouchedStudentIds = array();

try {
    $pdo->beginTransaction();

    foreach ($blocks as $b) {
        $tupleKey = ascb_gi_tuple_key($b['studentId'], $b['schoolYear'], $b['term']);
        /* Serialize concurrent imports for the same student/term. This is
           connection-scoped in MySQL and does not require changing the
           existing enrollment schema. */
        $lockName = 'ascb_gi_' . substr(hash('sha256',$tupleKey),0,48);
        $lockStmt = $pdo->prepare("SELECT GET_LOCK(?, 15)");
        $lockStmt->execute(array($lockName));
        if ((int)$lockStmt->fetchColumn() !== 1) {
            throw new RuntimeException('Could not obtain the import lock for Student ID '.$b['studentId'].' / '.$b['schoolYear'].' / '.$b['term'].'. Please retry.');
        }
        try {
            /* Re-read under the lock; the preview/batch lookup may be stale
               if another request committed between Preview and Confirm. */
            $rq=$pdo->prepare("SELECT id FROM enrollees
                                      WHERE UPPER(TRIM(student_id)) = UPPER(TRIM(?))
                                        AND UPPER(TRIM(school_year)) = UPPER(TRIM(?))
                                        AND UPPER(TRIM(trimester)) = UPPER(TRIM(?))
                                      ORDER BY id ASC LIMIT 1 FOR UPDATE");
            $rq->execute(array($b['studentId'],$b['schoolYear'],$b['term']));
            $freshExisting=$rq->fetchColumn();
            $existingId = $freshExisting !== false ? (int)$freshExisting : null;

        if ($existingId !== null) {
            $enrollmentId = $existingId;
            $studentUpdatedCount++;

            /* FIX: Student ID is the identity. If the imported Excel has a
               new surname (e.g. married name), refresh THIS matching
               enrollment and the permanent Master Record instead of leaving
               the old surname in place. Other term rows remain historical. */
            ascb_gi_sync_existing_name($pdo, $enrollmentId, $b, $myId);

            /* Lahat ng naka-save nang subject+grade ng Enrollment na
               ito — mula sa batch lookup, hindi na bagong query. */
            $ascbGiExistingRows = isset($ascbGiLookup['subjectRows'][$enrollmentId]) ? $ascbGiLookup['subjectRows'][$enrollmentId] : array();
            $existingSubjMap = ascb_gi_subject_map_from_rows($ascbGiExistingRows);
        } else {
            $ascbGiExistingRows = array();
            $existingSubjMap = array();
            $deptId = null;
            if ($b['programCode'] !== '') {
                $normCode = strtoupper(trim($b['programCode']));
                if (isset($ascbGiDeptByCode[$normCode])) $deptId = $ascbGiDeptByCode[$normCode];
            }
            $bdate = null;
            if ($b['birthdate'] !== '') {
                if (is_numeric($b['birthdate']) && (float) $b['birthdate'] > 1000 && (float) $b['birthdate'] < 100000) {
                    /* Excel serial date (hal. 35073) -> Y-m-d */
                    $bdate = gmdate('Y-m-d', (int) round(((float) $b['birthdate'] - 25569) * 86400));
                } else {
                    $ts = strtotime($b['birthdate']);
                    if ($ts !== false) $bdate = date('Y-m-d', $ts);
                }
            }
            $sexNormalized = ucfirst(strtolower(trim((string) ascb_get($b, 'sex', ''))));
            list($giSfx, $giSfxPos) = ascb_gi_master_suffix($pdo, $b);
            $giHasSfx = ascb_column_exists($pdo, 'enrollees', 'suffix') && ascb_column_exists($pdo, 'enrollees', 'suffix_position');
            $ins = $pdo->prepare(
                "INSERT INTO enrollees (student_id, surname, first_name, middle_name" . ($giHasSfx ? ", suffix, suffix_position" : "") . ", sex, student_type, birth_date, address,
                   program_code, department_id, course, major, year_level, trimester, school_year,
                   enrolled_by_user_id, status, approved_by_user_id, approved_at)
                 VALUES (?,?,?,?" . ($giHasSfx ? ",?,?" : "") . ",?,?,?,?, ?,?,?,?,?,?,?, ?, 'approved', ?, NOW())"
            );
            $giHead = array(
                $b['studentId'], $b['surname'], $b['firstName'], $b['middleName'] !== '' ? $b['middleName'] : null,
            );
            if ($giHasSfx) { $giHead[] = $giSfx !== '' ? $giSfx : null; $giHead[] = $giSfxPos; }
            $ins->execute(array_merge($giHead, array(
                in_array($sexNormalized, array('Male', 'Female'), true) ? $sexNormalized : null,
                in_array($b['studentType'], array('Regular', 'Transferee', 'Irregular'), true) ? $b['studentType'] : null,
                $bdate, ascb_get($b, 'address', '') !== '' ? $b['address'] : null,
                $b['programCode'] !== '' ? $b['programCode'] : null, $deptId,
                $b['program'] !== '' ? $b['program'] : null, $b['major'] !== '' ? $b['major'] : null,
                $b['yearLevel'] !== '' ? $b['yearLevel'] : null, $b['term'], $b['schoolYear'],
                $myId, $myId,
            )));
            $enrollmentId = (int) $pdo->lastInsertId();
            $enrollCount++;
            $studentCreatedCount++;

            /* MASTER RECORD: one permanent master row per Student ID (INSERT IGNORE). */
            ascb_master_ensure($pdo, $b['studentId'], array(
                'surname' => $b['surname'], 'first_name' => $b['firstName'], 'middle_name' => $b['middleName'],
                'sex' => in_array($sexNormalized, array('Male', 'Female'), true) ? $sexNormalized : '',
                'birth_date' => $bdate, 'address' => ascb_get($b, 'address', ''),
            ), $myId);
        }

        $ascbGiTouchedStudentIds[$b['studentId']] = true;

        foreach ($b['subjects'] as $s) {

            /* Existing subject is an UPDATE, not a duplicate error. The
               canonical model allows the importer to repair/refresh a grade
               for the same Student + Enrollment + Subject. */
            // In-memory lookup (mula sa batch query sa itaas) sa halip na
            // isang bagong "SELECT ... WHERE enrollment_id=? AND description=?"
            // PER SUBJECT ROW — ito ang pinakamabigat na N+1 dati sa file na
            // may daan-daang subject row.
            $existingSubj = ascb_gi_find_subject_row($ascbGiExistingRows, $s['description'], $s['code']);

            // Keep the imported/curriculum units even when the imported grade
            // is failing (4.00/5.00, INC, DRP, NG). Grade status must not erase
            // subject units. A dash grade retains the legacy zero-unit meaning.
            $importGrade = ascb_normalize_grade($s['grade']);
            $isPendingZero = is_numeric($importGrade) && (float)$importGrade === 0.0;
            // 0/0.0 is NOT GRADED; preserve curriculum units and do not create a grade row.
            $subjUnits = ($importGrade === '-') ? 0 : $s['units'];

            $existingGradeId = null;
            if ($existingSubj) {
                $subjectUpdatedCount++;
                // Subject-level lock is a hard server-side boundary. The legacy
                // bulk importer must not become a back door around the new
                // Professor Gradebook lock.
                ascb_gradebook_lock_assert_editable($pdo, $b['schoolYear'], $b['term'], $s['code'], $s['description'], $role);
                $subjectId = (int) $existingSubj['subject_id'];
                $existingGradeId = $existingSubj['grade_id'] !== null ? (int) $existingSubj['grade_id'] : null;
                /* SELF-HEAL: ang lumang import ay nag-save ng code bilang description
                   (hal. "A1A"). Itinutuwid ito dito imbes na gumawa ng bagong row. */
                $rowCodeKey = ascb_gi_code_key(ascb_get($existingSubj, 'course_code', ''));
                $rowDescKey = ascb_gi_code_key(ascb_gi_norm_desc(ascb_get($existingSubj, 'description', '')));
                $impCodeKey = ascb_gi_code_key($s['code']);
                $impDescKey = ascb_gi_code_key(ascb_gi_norm_desc($s['description']));
                $descIsPlaceholder = $rowDescKey !== '' && ($rowDescKey === $rowCodeKey || $rowDescKey === $impCodeKey);
                $healDesc = ($descIsPlaceholder && $impDescKey !== '' && $impDescKey !== $impCodeKey) ? $s['description'] : null;
                $healCode = ($rowCodeKey === '' && $impCodeKey !== '') ? $s['code'] : null;
                if ($healDesc !== null || $healCode !== null) {
                    $hq = $pdo->prepare("UPDATE enrollment_subjects SET description = COALESCE(?, description), course_code = COALESCE(?, course_code) WHERE id = ?");
                    $hq->execute(array($healDesc, $healCode, $subjectId));
                }
                if ($importGrade === '-') {
                    $zu = $pdo->prepare("UPDATE enrollment_subjects SET units = 0 WHERE id = ? AND units <> 0");
                    $zu->execute(array($subjectId));
                }
            } else {
                $si = $pdo->prepare("INSERT INTO enrollment_subjects (enrollment_id, course_code, description, units) VALUES (?,?,?,?)");
                $si->execute(array($enrollmentId, $s['code'] !== '' ? $s['code'] : null, $s['description'], $subjUnits));
                $subjectId = (int) $pdo->lastInsertId();
                $subjectCreatedCount++;
                $ascbGiExistingRows[] = array('subject_id'=>$subjectId, 'description'=>$s['description'], 'course_code'=>($s['code'] !== '' ? $s['code'] : null), 'grade_id'=>null, 'grade'=>null);
            }

            // Ang grade id ay galing na rin sa parehong batch row (grade_id) —
            // hindi na kailangan ng hiwalay na "SELECT id FROM grades" PER
            // SUBJECT ROW. Bagong INSERT na subject lang (walang $existingSubj)
            // ang walang kasamang grade row pa, kaya wala ring dagdag na query.
            $newGrade = $isPendingZero ? null : ($importGrade !== '' ? $importGrade : null);
            if ($existingGradeId !== null) {
                $gu = $pdo->prepare("UPDATE grades SET grade=?, updated_by_user_id=?, updated_at=NOW() WHERE id=?");
                $gu->execute(array($newGrade, $myId, $existingGradeId));
                $gradeUpdatedCount++;
            } elseif ($newGrade !== null) {
                $gi = $pdo->prepare("INSERT INTO grades (enrollment_subject_id, grade, entered_by_user_id, entered_at) VALUES (?,?,?,NOW())");
                $gi->execute(array($subjectId, $newGrade, $myId));
                $gradeInsertedCount++;
            }

            /* Tandaan ang bagong naisulat para masalo rin ang mga
               sumunod pang kaparehong row sa loob ng parehong file. */
            ascb_gi_remember_subject($existingSubjMap, $s['description'], $newGrade ?? '');

            $subjectCount++;
        }
        } finally {
            $unlock=$pdo->prepare("SELECT RELEASE_LOCK(?)");
            $unlock->execute(array($lockName));
        }
    }

    $pdo->commit();

    // Bagong Enrollment ang posibleng naidagdag ng import na ito — burahin
    // ang cached Dashboard stats para hindi na maghintay pang mag-expire.
    ascb_cache_clear_prefix('dashboard_stats_');

    /* Persistent import history is optional until the one-time migration
       is run. Never make a successful grade import fail merely because the
       audit table is not present yet. */
    try {
        $hasHistory = (bool)$pdo->query("SHOW TABLES LIKE 'grade_import_history'")->fetchColumn();
        if ($hasHistory) {
            $hs=$pdo->prepare("INSERT INTO grade_import_history
                (filename, imported_by_user_id, imported_by_username, file_type, format_detected,
                 sheets_processed, students_processed, students_created, students_updated,
                 subjects_processed, subjects_created, subjects_updated, enrollments_created,
                 grades_imported, grades_updated, skipped_records, warning_count, error_count,
                 confidence, status, summary)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $hs->execute(array(
                $origName, $myId, (string)ascb_get($ascbUser,'username',''), $ext, $format,
                count($sheetRows), count($blocks), $studentCreatedCount, $studentUpdatedCount,
                $subjectCount, $subjectCreatedCount, $subjectUpdatedCount, $enrollCount,
                $gradeInsertedCount, $gradeUpdatedCount, $skippedCount, count($warnings), 0,
                empty($warnings) ? 'High Confidence' : 'Medium Confidence', 'completed',
                count($blocks).' students; '.$subjectCount.' subject rows; '.$enrollCount.' enrollments created.'
            ));
        }
    } catch (Throwable $historyError) {
        error_log('ASCB intelligent import history failed: '.$historyError->getMessage());
    }

    ascb_log_activity($pdo, $ascbUser, 'GRADE_BULK_IMPORT', 'enrollment', $origName,
        count($blocks) . ' estudyante, ' . $enrollCount . ' bagong enrollment, ' . $subjectCount . ' subject/grade row, '
        . ($skippedCount + $dupInFile) . ' nilaktawang duplicate mula sa bulk .' . $ext . ' import (' . $format . ').');

    $ascbGiTouchedIdsList = array_keys($ascbGiTouchedStudentIds);
    sort($ascbGiTouchedIdsList, SORT_NATURAL | SORT_FLAG_CASE);

    /* AUTO STUDENT ACCOUNT — every student in this import gets exactly one
       STUDENT account (existing accounts are left untouched; no duplicates).
       Runs AFTER the commit, so it can never undo the import. The one-time
       temporary passwords are returned ONCE in this response so the registrar
       can download the credential sheet; they are stored only as hashes. */
    /* Bawat password_hash() ay ~50-100 ms: ang malaking import (daan-daang
       estudyante) ay pwedeng lumampas sa max_execution_time. Tapos na ang
       commit ng import, kaya huwag hayaang maputol ang paggawa ng accounts. */
    @set_time_limit(0);
    @ignore_user_abort(true);
    $ascbGiCredentials = array();
    $ascbGiAcctExisting = 0;
    $ascbGiAcctFailed = 0;
    /* (fix) defer_accounts=1: ang browser ang gagawa ng accounts nang paunti-unti (action create_accounts) para
       mabilis ang sagot ng commit at hindi maputol ng timeout. Kung walang flag (lumang client), gumagana pa rin gaya ng dati. */
    $ascbGiDeferAccounts = (string) ascb_get($_POST, 'defer_accounts', '') === '1';
    foreach ($ascbGiDeferAccounts ? array() : $ascbGiTouchedIdsList as $ascbGiSid) {
        $ascbGiNm = ascb_sa_name_for_student($pdo, $ascbGiSid);
        $ascbGiRes = ascb_sa_ensure_account($pdo, $ascbGiSid, (array) $ascbGiNm, $ascbUser);
        if ($ascbGiRes['status'] === 'created') {
            $ascbGiCredentials[] = array(
                'studentId' => $ascbGiSid,
                'name' => $ascbGiNm ? trim($ascbGiNm['surname'] . ', ' . $ascbGiNm['first_name']) : '',
                'username' => $ascbGiRes['username'],
                'tempPassword' => $ascbGiRes['tempPassword'],
            );
        } elseif ($ascbGiRes['status'] === 'exists') {
            $ascbGiAcctExisting++;
        } else {
            $ascbGiAcctFailed++;
        }
    }
    header('Cache-Control: no-store');

    echo json_encode(array(
        'ok' => true,
        'accountsDeferred' => $ascbGiDeferAccounts,
        'studentAccounts' => $ascbGiDeferAccounts ? null : array(
            'created' => count($ascbGiCredentials),
            'existing' => $ascbGiAcctExisting,
            'failed' => $ascbGiAcctFailed,
            'credentials' => $ascbGiCredentials,
        ),
        'studentBlocks' => count($blocks),
        'newEnrollments' => $enrollCount,
        'subjectRows' => $subjectCount,
        'studentsCreated' => $studentCreatedCount,
        'studentsUpdated' => $studentUpdatedCount,
        'subjectsCreated' => $subjectCreatedCount,
        'subjectsUpdated' => $subjectUpdatedCount,
        'gradesImported' => $gradeInsertedCount,
        'gradesUpdated' => $gradeUpdatedCount,
        'sheetsProcessed' => count($sheetRows),
        'warnings' => $warnings,
        'duplicateRowsInFile' => $dupInFile,
        'duplicateRowsExisting' => $skippedCount,
        'duplicateRows' => $dupInFile + $skippedCount,
        'format' => $format,
        /* Student ID ng bawat estudyanteng naapektuhan ng commit na
           ito — ginagamit ng frontend para i-search/i-locate agad sila
           sa Grade Management (View/Update), kahit hindi sila sa unang
           page o may dating aktibong search filter. */
        'importedStudentIds' => $ascbGiTouchedIdsList,
    ));
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => ASCB_DEBUG ? $e->getMessage() : 'The file could not be imported. Nothing was changed in the database.'));
}
