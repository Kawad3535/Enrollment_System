<?php
require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json; charset=utf-8');
$role=trim((string)ascb_get($ascbUser,'role',''));
function gba_json($a,$s=200){http_response_code($s);echo json_encode($a,JSON_UNESCAPED_UNICODE);exit;}
function gba_tables($pdo){
 $pdo->exec("CREATE TABLE IF NOT EXISTS gradebook_approval_submissions (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, department_id INT NOT NULL, school_year VARCHAR(30) NOT NULL, term VARCHAR(50) NOT NULL,
 course_code VARCHAR(100) DEFAULT '', description VARCHAR(255) DEFAULT '', submitted_by INT NOT NULL, submitted_by_name VARCHAR(150) DEFAULT NULL,
 status ENUM('PENDING_UNIT_HEAD','PENDING_REGISTRAR','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING_UNIT_HEAD',
 unit_head_id INT DEFAULT NULL, unit_head_at DATETIME DEFAULT NULL, registrar_id INT DEFAULT NULL, registrar_at DATETIME DEFAULT NULL,
 rejection_reason VARCHAR(500) DEFAULT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX idx_gas_status_dept(status,department_id), INDEX idx_gas_created(created_at)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $pdo->exec("CREATE TABLE IF NOT EXISTS gradebook_approval_items (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, submission_id BIGINT NOT NULL, enrollment_subject_id INT NOT NULL,
 student_id VARCHAR(100) DEFAULT NULL, student_name VARCHAR(255) DEFAULT NULL, old_grade VARCHAR(30) DEFAULT NULL, new_grade VARCHAR(30) DEFAULT NULL,
 UNIQUE KEY uq_gai_submission_subject(submission_id,enrollment_subject_id), INDEX idx_gai_submission(submission_id)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $cols=[]; foreach($pdo->query("SHOW COLUMNS FROM gradebook_approval_items")->fetchAll(PDO::FETCH_ASSOC) as $c) $cols[$c['Field']]=true;
 if(!isset($cols['old_units'])) $pdo->exec("ALTER TABLE gradebook_approval_items ADD COLUMN old_units DECIMAL(8,2) DEFAULT NULL");
 if(!isset($cols['new_units'])) $pdo->exec("ALTER TABLE gradebook_approval_items ADD COLUMN new_units DECIMAL(8,2) DEFAULT NULL");
 /* RE-SUBMIT: mga column para sa na-reject na submission na ipapasa ulit ng encoder (Admin Staff).
    - rejected_by_role / rejected_at : sino at kailan nag-reject (Unit Head o School Registrar)
    - last_rejection_reason         : dating dahilan ng reject (para makita pa rin ng reviewer pagkatapos ng re-submit)
    - resubmit_count / resubmitted_at / resubmit_note : ilang beses na na-re-submit, kailan, at note ng encoder */
 $scols=[]; foreach($pdo->query("SHOW COLUMNS FROM gradebook_approval_submissions")->fetchAll(PDO::FETCH_ASSOC) as $c) $scols[$c['Field']]=true;
 $addCols=['rejected_by_role'=>"VARCHAR(30) DEFAULT NULL",'rejected_at'=>"DATETIME DEFAULT NULL",'last_rejection_reason'=>"VARCHAR(500) DEFAULT NULL",'resubmit_count'=>"INT NOT NULL DEFAULT 0",'resubmitted_at'=>"DATETIME DEFAULT NULL",'resubmit_note'=>"VARCHAR(500) DEFAULT NULL"];
 foreach($addCols as $cn=>$def){ if(!isset($scols[$cn])) $pdo->exec("ALTER TABLE gradebook_approval_submissions ADD COLUMN $cn $def"); }
}
/* (fix) Ayusin ang mga lumang submission na MALI ang department_id.
   Dati, ang inilalagay ay users.department_id ng Admin Staff (iisang legacy value) kahit iba ang Department ng mga
   estudyante — kaya hindi lumalabas sa Unit Head ang tamang Department (hal. College of Accounting and Business Education).
   Ngayon: ang aktwal na Department ng bawat enrollment ang batayan.
   - Kung iisa ang tunay na Department ng lahat ng item -> ire-retag ang submission.
   - Kung halo-halo -> hahatiin sa hiwalay na submission bawat Department (parehong status/reviewer info).
   Walang binabago sa APPROVED. Ligtas ulit-ulitin (walang mismatch = walang gagawin). Hindi kailanman nagpapabagsak sa list. */
function gba_retag_departments($pdo){
 try{
  $rdept="COALESCE(NULLIF(e.department_id,0),(SELECT p.department_id FROM programs p WHERE UPPER(TRIM(p.code)) COLLATE utf8mb4_unicode_ci=UPPER(TRIM(COALESCE(NULLIF(e.program_code,''),e.course,''))) COLLATE utf8mb4_unicode_ci LIMIT 1))";
  $q=$pdo->query("SELECT t.sid,t.iid,t.rdept FROM (SELECT s.id AS sid,s.department_id AS sdept,i.id AS iid,$rdept AS rdept
     FROM gradebook_approval_submissions s
     JOIN gradebook_approval_items i ON i.submission_id=s.id
     JOIN enrollment_subjects es ON es.id=i.enrollment_subject_id
     JOIN enrollees e ON e.id=es.enrollment_id
     WHERE s.status IN ('PENDING_UNIT_HEAD','PENDING_REGISTRAR','REJECTED')) t
     WHERE t.rdept IS NOT NULL AND t.rdept>0 AND t.rdept<>t.sdept");
  $bad=[];
  foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r) $bad[(int)$r['sid']][(int)$r['rdept']][]=(int)$r['iid'];
  if(!$bad) return;
  $cnt=$pdo->prepare("SELECT COUNT(*) FROM gradebook_approval_items WHERE submission_id=?");
  $get=$pdo->prepare("SELECT * FROM gradebook_approval_submissions WHERE id=?");
  $setDept=$pdo->prepare("UPDATE gradebook_approval_submissions SET department_id=? WHERE id=?");
  $cols="department_id,school_year,term,course_code,description,submitted_by,submitted_by_name,status,unit_head_id,unit_head_at,registrar_id,registrar_at,created_at,resubmit_count,resubmitted_at,resubmit_note,last_rejection_reason,rejection_reason,rejected_by_role,rejected_at";
  $colArr=explode(',',$cols);
  $ins=$pdo->prepare("INSERT INTO gradebook_approval_submissions($cols) VALUES(".implode(',',array_fill(0,count($colArr),'?')).")");
  $pdo->beginTransaction();
  foreach($bad as $sid=>$byDept){
   $get->execute([$sid]);$sub=$get->fetch(PDO::FETCH_ASSOC);if(!$sub)continue;
   $cnt->execute([$sid]);$total=(int)$cnt->fetchColumn();
   $mismatched=0;foreach($byDept as $ids)$mismatched+=count($ids);
   $groups=$byDept;
   if($mismatched>=$total){
    /* Walang item na tugma sa kasalukuyang department_id: ang unang grupo ang magiging department ng orihinal. */
    $firstDept=array_key_first($groups);
    $setDept->execute([$firstDept,$sid]);
    unset($groups[$firstDept]);
   }
   foreach($groups as $dept=>$ids){
    $vals=[];foreach($colArr as $c)$vals[]=($c==='department_id')?(int)$dept:($sub[$c]??null);
    $ins->execute($vals);$newId=(int)$pdo->lastInsertId();
    $in=implode(',',array_fill(0,count($ids),'?'));
    $mv=$pdo->prepare("UPDATE gradebook_approval_items SET submission_id=? WHERE submission_id=? AND id IN ($in)");
    $mv->execute(array_merge([$newId,$sid],$ids));
   }
  }
  $pdo->commit();
 }catch(Throwable $e){
  if($pdo->inTransaction())$pdo->rollBack();
  error_log('gba_retag_departments: '.$e->getMessage());
 }
}
/* Grade validator (kapareho ng rules sa Grade Management / api/grades.php). */
function gba_grade_valid($grade){
 $grade=trim((string)$grade); if($grade==='')return true;
 if(preg_match('/^(INC|DRP|DR\.?|NG|P|PASSED|[-–—])$/iu',$grade))return true;
 if(is_numeric($grade)){$n=(float)$grade;return $n>=0&&$n<=5;}
 return false;
}
/* Dagdag na info ng na-reject na submission: sino ang nag-reject at kailan (may fallback para sa lumang rows). */
function gba_decorate_rejected(array $r){
 if(($r['status']??'')!=='REJECTED')return $r;
 $role=trim((string)($r['rejected_by_role']??''));
 if($role==='')$role=!empty($r['registrar_id'])?'SCHOOL REGISTRAR':'UNIT HEAD';
 $r['rejected_by_role']=$role;
 $r['rejected_by_name']=$role==='SCHOOL REGISTRAR'?($r['registrar_name']??null):($r['unit_head_name']??null);
 if(empty($r['rejected_at']))$r['rejected_at']=$role==='SCHOOL REGISTRAR'?($r['registrar_at']??null):($r['unit_head_at']??null);
 return $r;
}
try{
 gba_tables($pdo);
 $action=(string)($_GET['action']??$_POST['action']??'list');
 if(!in_array($role,['ADMIN STAFF','UNIT HEAD','SCHOOL REGISTRAR'],true)) gba_json(['ok'=>false,'error'=>'Access denied.'],403);
 if(!in_array($action,['list','resubmit','pending_count'],true) && $role==='ADMIN STAFF') gba_json(['ok'=>false,'error'=>'Admin Staff can encode and submit grades only. Approval and rejection are restricted to the Unit Head and School Registrar.'],403);
 if($action==='resubmit' && $role!=='ADMIN STAFF') gba_json(['ok'=>false,'error'=>'Only the Admin Staff who encoded the grades can re-submit a rejected submission.'],403);
 /* NOTIFICATION: magaan na bilang ng submission na naghihintay ng approval ng KASALUKUYANG approver.
   UNIT HEAD -> PENDING_UNIT_HEAD, SCHOOL REGISTRAR -> PENDING_REGISTRAR. Walang department filter (sila ang may access sa lahat).
   Ang ADMIN STAFF ay hindi approver kaya 0 ang ibinabalik. COUNT lang ito — hindi nagbabago ng data. */
 if($action==='pending_count'){
  if($role!=='UNIT HEAD'&&$role!=='SCHOOL REGISTRAR') gba_json(['ok'=>true,'count'=>0,'items'=>0,'latest_id'=>0,'departments'=>[]]);
  $stat=$role==='UNIT HEAD'?'PENDING_UNIT_HEAD':'PENDING_REGISTRAR';
  $c=$pdo->prepare("SELECT COUNT(*) AS n, COALESCE(MAX(id),0) AS latest FROM gradebook_approval_submissions WHERE status=?");$c->execute([$stat]);$cr=$c->fetch(PDO::FETCH_ASSOC);
  $it=$pdo->prepare("SELECT COUNT(*) FROM gradebook_approval_items i JOIN gradebook_approval_submissions s ON s.id=i.submission_id WHERE s.status=?");$it->execute([$stat]);
  $dp=$pdo->prepare("SELECT COALESCE(d.name,'—') AS name, COUNT(*) AS n FROM gradebook_approval_submissions s LEFT JOIN departments d ON d.id=s.department_id WHERE s.status=? GROUP BY d.name ORDER BY d.name");$dp->execute([$stat]);
  gba_json(['ok'=>true,'count'=>(int)$cr['n'],'items'=>(int)$it->fetchColumn(),'latest_id'=>(int)$cr['latest'],'departments'=>$dp->fetchAll(PDO::FETCH_ASSOC),'role'=>$role]);
 }
 if($action==='list'){
  gba_retag_departments($pdo);
  $deptNames=[];$totalRows=null;
  if($role==='ADMIN STAFF'){
   /* Sariling submissions lang ng Admin Staff ang lalabas. Hindi na hinahanap ang iisang users.department_id
      (maraming Department ang pwedeng naka-assign sa Admin Staff). Ang APPROVED ay hindi na ipinapakita —
      kaya kusang nawawala ang Re-submit button kapag final approved na. */
   $only=strtolower(trim((string)($_GET['only']??'')));
   $statusSql=$only==='rejected'?"s.status='REJECTED'":"s.status<>'APPROVED'";
   $st=$pdo->prepare("SELECT s.*,d.name department_name,uh.display_name AS unit_head_name,reg.display_name AS registrar_name FROM gradebook_approval_submissions s LEFT JOIN departments d ON d.id=s.department_id LEFT JOIN users uh ON uh.id=s.unit_head_id LEFT JOIN users reg ON reg.id=s.registrar_id WHERE s.submitted_by=? AND $statusSql ORDER BY (s.status='REJECTED') DESC, s.created_at DESC LIMIT 300");$st->execute([(int)$ascbUser['id']]);
  } else {
   $baseWhere=$role==='UNIT HEAD'?"WHERE s.status='PENDING_UNIT_HEAD'":"WHERE s.status='PENDING_REGISTRAR'";
   /* Ang LIMIT 300 ay dating global (pinakaluma muna), kaya ang department na maraming backlog ang pumupuno sa lahat
      at hindi na nakikita ang ibang department. Ngayon: ang listahan ng Department ay galing sa LAHAT ng pending,
      at kapag pumili ng department, ang department na iyon ang kinukuha (per-department ang 300). */
   $deptFilter=trim((string)($_GET['department']??''));
   $where=$baseWhere;$params=[];
   if($deptFilter!==''){$where.=" AND d.name=?";$params[]=$deptFilter;}
   $fromSql="FROM gradebook_approval_submissions s LEFT JOIN departments d ON d.id=s.department_id";
   $dn=$pdo->prepare("SELECT DISTINCT d.name $fromSql $baseWhere AND d.name IS NOT NULL AND d.name<>'' ORDER BY d.name");$dn->execute();
   $deptNames=array_values(array_map('strval',$dn->fetchAll(PDO::FETCH_COLUMN)));
   $cq=$pdo->prepare("SELECT COUNT(*) $fromSql $where");$cq->execute($params);$totalRows=(int)$cq->fetchColumn();
   $st=$pdo->prepare("SELECT s.*,d.name department_name,uh.display_name AS unit_head_name,reg.display_name AS registrar_name FROM gradebook_approval_submissions s LEFT JOIN departments d ON d.id=s.department_id LEFT JOIN users uh ON uh.id=s.unit_head_id LEFT JOIN users reg ON reg.id=s.registrar_id $where ORDER BY s.created_at ASC LIMIT 300");$st->execute($params);
  }
  $rows=array_map('gba_decorate_rejected',$st->fetchAll(PDO::FETCH_ASSOC));
  $itemsStmt=$pdo->prepare("SELECT gai.id,gai.student_id,gai.student_name,gai.old_grade,gai.new_grade,COALESCE(gai.old_units,es.units) AS old_units,COALESCE(gai.new_units,CASE WHEN UPPER(TRIM(COALESCE(gai.new_grade,''))) IN ('INC','DRP','DR.','DR','NG') OR (gai.new_grade REGEXP '^[0-9]+([.][0-9]+)?$' AND CAST(gai.new_grade AS DECIMAL(8,2))>=4 AND CAST(gai.new_grade AS DECIMAL(8,2))>0) THEN 0 ELSE es.units END) AS new_units,es.course_code AS subject_code,es.description AS subject_description,es.enrollment_id,e.program_code,e.course,e.major FROM gradebook_approval_items gai LEFT JOIN enrollment_subjects es ON es.id=gai.enrollment_subject_id LEFT JOIN enrollees e ON e.id=es.enrollment_id WHERE gai.submission_id=? ORDER BY gai.student_name");
  $programStmt=$pdo->prepare("SELECT course_name,major FROM programs WHERE UPPER(TRIM(code))=UPPER(TRIM(?)) OR UPPER(TRIM(course_name))=UPPER(TRIM(?)) ORDER BY CASE WHEN UPPER(TRIM(code))=UPPER(TRIM(?)) THEN 0 ELSE 1 END LIMIT 1");
  $courseCache=[];
  $resolveCourse=function(array $it) use ($programStmt,&$courseCache){
   $programKey=trim((string)($it['program_code']??''));$courseFallback=trim((string)($it['course']??''));
   $ck=$programKey.'|'.$courseFallback.'|'.trim((string)($it['major']??''));
   if(isset($courseCache[$ck]))return $courseCache[$ck];
   $programStmt->execute([$programKey!==''?$programKey:$courseFallback,$courseFallback,$programKey!==''?$programKey:$courseFallback]);$program=$programStmt->fetch(PDO::FETCH_ASSOC);
   $courseName=trim((string)($program['course_name']??''));
   if($courseName==='')$courseName=$courseFallback!==''?$courseFallback:$programKey;
   $major=trim((string)($program['major']??($it['major']??'')));
   return $courseCache[$ck]=($courseName!==''?($major!==''?$courseName.' — Major in '.$major:$courseName):'—');
  };
  foreach($rows as &$r){
   $itemsStmt->execute([(int)$r['id']]);$r['items']=$itemsStmt->fetchAll(PDO::FETCH_ASSOC);
   foreach($r['items'] as &$itm){$itm['course_name']=$resolveCourse($itm);} unset($itm);
   $first=$r['items'][0]??[];
   $r['subject_code']=trim((string)($first['subject_code']??''));
   $r['subject_description']=trim((string)($first['subject_description']??''));
   $programKey=trim((string)($first['program_code']??''));$courseFallback=trim((string)($first['course']??''));
   $programStmt->execute([$programKey!==''?$programKey:$courseFallback,$courseFallback,$programKey!==''?$programKey:$courseFallback]);$program=$programStmt->fetch(PDO::FETCH_ASSOC);
   $courseName=trim((string)($program['course_name']??''));
   if($courseName==='')$courseName=$courseFallback!==''?$courseFallback:$programKey;
   $major=trim((string)($program['major']??($first['major']??'')));
   $r['course_name']=$courseName!==''?($major!==''?$courseName.' — Major in '.$major:$courseName):'—';
  } unset($r);
  gba_json(['ok'=>true,'rows'=>$rows,'departments'=>$deptNames,'total'=>$totalRows]);
 }
 if(!in_array($action,['approve','reject','resubmit'],true)) gba_json(['ok'=>false,'error'=>'Invalid action.'],400);
 $id=(int)($_POST['submission_id']??0); if($id<1)gba_json(['ok'=>false,'error'=>'Submission ID is required.'],400);
 $pdo->beginTransaction();
 $q=$pdo->prepare("SELECT * FROM gradebook_approval_submissions WHERE id=? FOR UPDATE");$q->execute([$id]);$sub=$q->fetch(PDO::FETCH_ASSOC);
 if(!$sub)throw new Exception('Submission not found.');
 /* =========================================================
    RE-SUBMIT (Admin Staff lang, sariling na-reject na submission lang)
    - Ibinabalik sa PENDING_UNIT_HEAD ang na-reject ng Unit Head O ng School Registrar,
      kaya dadaan ulit: Unit Head -> School Registrar (final approval).
    - Pwedeng itama muna ang grade/units (edits) at magdagdag ng note para sa reviewer.
    - Ni-re-check ang enrollment at ni-re-refresh ang "previous" grade/units mula sa official records.
    - Kapag APPROVED na, hindi na REJECTED ang status kaya hindi na ito pwedeng i-re-submit (at
      hindi na rin ito lumalabas sa listahan ng Admin Staff).
    ========================================================= */
 if($action==='resubmit'){
  if((int)$sub['submitted_by']!==(int)$ascbUser['id'])throw new Exception('You can only re-submit your own rejected submissions.');
  if($sub['status']!=='REJECTED')throw new Exception('This submission is no longer rejected, so it cannot be re-submitted. It may already be waiting for review, or it was already approved.');
  $edits=[];$rawEdits=$_POST['edits']??'';
  if(is_string($rawEdits)&&$rawEdits!==''){$dec=json_decode($rawEdits,true);if(is_array($dec))foreach($dec as $e){if(is_array($e)&&isset($e['id']))$edits[(int)$e['id']]=$e;}}
  $note=mb_substr(trim((string)($_POST['note']??'')),0,500);
  $itq=$pdo->prepare("SELECT * FROM gradebook_approval_items WHERE submission_id=? ORDER BY id FOR UPDATE");$itq->execute([$id]);$items=$itq->fetchAll(PDO::FETCH_ASSOC);
  if(!$items)throw new Exception('This submission has no grade items to re-submit.');
  $scope=ascb_staff_assignment_scope_sql($pdo,$ascbUser,'e');
  $curStmt=$pdo->prepare("SELECT es.id,es.units,e.student_id,e.school_year,e.trimester,g.grade FROM enrollment_subjects es JOIN enrollees e ON e.id=es.enrollment_id LEFT JOIN grades g ON g.enrollment_subject_id=es.id WHERE es.id=? AND e.status='approved' AND e.archived_at IS NULL".$scope['sql']." LIMIT 1 FOR UPDATE");
  $dupStmt=$pdo->prepare("SELECT 1 FROM gradebook_approval_items i JOIN gradebook_approval_submissions s2 ON s2.id=i.submission_id WHERE i.enrollment_subject_id=? AND s2.id<>? AND s2.status IN ('PENDING_UNIT_HEAD','PENDING_REGISTRAR') AND COALESCE(i.new_grade,'')=? AND ABS(COALESCE(i.new_units,0)-?)<0.001 LIMIT 1");
  $histStmt=$pdo->prepare("SELECT old_units FROM gradebook_approval_items WHERE enrollment_subject_id=? AND old_units>0 ORDER BY id ASC LIMIT 1");
  $keep=[];$dropped=[];
  foreach($items as $item){
   $iid=(int)$item['id'];$label=trim((string)$item['student_name']);$label=$label!==''?$label:('item #'.$iid);
   $curStmt->execute(array_merge([(int)$item['enrollment_subject_id']],$scope['params']));$cur=$curStmt->fetch(PDO::FETCH_ASSOC);
   if(!$cur||$cur['school_year']!==$sub['school_year']||$cur['trimester']!==$sub['term']||(string)$cur['student_id']!==(string)$item['student_id']){$dropped[]=['id'=>$iid,'reason'=>$label.': enrollment changed or is outside your assignment'];continue;}
   $ed=$edits[$iid]??null;
   $gradeEdited=is_array($ed)&&array_key_exists('grade',$ed);
   $grade=$gradeEdited?trim((string)$ed['grade']):trim((string)$item['new_grade']);
   if(!gba_grade_valid($grade))throw new Exception('Invalid grade "'.$grade.'" for '.$label.'. Use 0.00–5.00, INC, DRP, NG, P or a dash. Nothing was re-submitted.');
   $grade=ascb_normalize_grade($grade);if($grade!==''&&is_numeric($grade)&&(float)$grade===0.0)$grade='';
   if(is_array($ed)&&isset($ed['units'])&&trim((string)$ed['units'])!=='')$unitsIn=trim((string)$ed['units']);
   elseif($gradeEdited)$unitsIn=(string)$cur['units'];
   else $unitsIn=($item['new_units']!==null&&$item['new_units']!=='')?(string)$item['new_units']:(string)$cur['units'];
   if(preg_match('/^[-–—]$/u',$unitsIn))$unitsIn='0';
   if(!is_numeric($unitsIn)||(float)$unitsIn<0||(float)$unitsIn>99)throw new Exception('Invalid units for '.$label.'. Nothing was re-submitted.');
   /* Safeguard (kapareho ng Grade Management): pasado na ang grade pero 0 ang units dahil dating na-zero ng bagsak na grade. */
   if($grade!==''&&$grade!=='-'&&!ascb_grade_is_failing($grade)&&(float)$unitsIn===0.0&&(float)$cur['units']===0.0){
    $histStmt->execute([(int)$item['enrollment_subject_id']]);$prev=$histStmt->fetchColumn();
    if($prev!==false&&(float)$prev>0)$unitsIn=(string)(float)$prev;
   }
   $oldNorm=trim((string)($cur['grade']??''));if($oldNorm!=='')$oldNorm=ascb_normalize_grade($oldNorm);if($oldNorm!==''&&is_numeric($oldNorm)&&(float)$oldNorm===0.0)$oldNorm='';
   if($grade===$oldNorm&&abs((float)$unitsIn-(float)$cur['units'])<0.001){$dropped[]=['id'=>$iid,'reason'=>$label.': already matches the official record'];continue;}
   $proposedUnits=ascb_grade_is_failing($grade)?0.0:(float)$unitsIn;
   $dupStmt->execute([(int)$item['enrollment_subject_id'],$id,$grade,$proposedUnits]);
   if($dupStmt->fetchColumn()){$dropped[]=['id'=>$iid,'reason'=>$label.': same change is already waiting for approval'];continue;}
   $keep[]=['id'=>$iid,'grade'=>$grade,'units'=>$proposedUnits,'old_grade'=>$cur['grade']??null,'old_units'=>(float)$cur['units']];
  }
  $delItem=$pdo->prepare("DELETE FROM gradebook_approval_items WHERE id=? AND submission_id=?");
  foreach($dropped as $d)$delItem->execute([$d['id'],$id]);
  if(!$keep){
   /* Walang natirang item na may saysay — isara (alisin) ang na-reject na submission para hindi na ito manatili sa listahan. */
   $pdo->prepare("DELETE FROM gradebook_approval_submissions WHERE id=?")->execute([$id]);
   $pdo->commit();ascb_log_activity($pdo,$ascbUser,'GRADEBOOK_SUBMISSION_CLOSED','gradebook_approval',(string)$id,'Rejected submission closed on re-submit: no valid changes left ('.count($dropped).' item(s) dropped).');
   gba_json(['ok'=>true,'closed'=>true,'dropped'=>count($dropped),'dropped_reasons'=>array_column($dropped,'reason'),'message'=>'Nothing left to re-submit. The grades already match the official records (or are already pending), so this rejected submission was closed.']);
  }
  $updItem=$pdo->prepare("UPDATE gradebook_approval_items SET new_grade=?,new_units=?,old_grade=?,old_units=? WHERE id=? AND submission_id=?");
  foreach($keep as $k)$updItem->execute([$k['grade']!==''?$k['grade']:null,$k['units'],$k['old_grade'],$k['old_units'],$k['id'],$id]);
  $u=$pdo->prepare("UPDATE gradebook_approval_submissions SET status='PENDING_UNIT_HEAD',last_rejection_reason=rejection_reason,rejection_reason=NULL,rejected_by_role=NULL,rejected_at=NULL,unit_head_id=NULL,unit_head_at=NULL,registrar_id=NULL,registrar_at=NULL,resubmit_count=resubmit_count+1,resubmitted_at=NOW(),resubmit_note=? WHERE id=? AND status='REJECTED'");
  $u->execute([$note!==''?$note:null,$id]);
  if($u->rowCount()<1)throw new Exception('This submission was changed by someone else. Please refresh and try again.');
  $pdo->commit();
  ascb_log_activity($pdo,$ascbUser,'GRADEBOOK_SUBMISSION_RESUBMITTED','gradebook_approval',(string)$id,'Re-submitted '.count($keep).' grade item(s) to Unit Head'.($dropped?(' ('.count($dropped).' dropped)'):'').'.');
  gba_json(['ok'=>true,'closed'=>false,'submission_id'=>$id,'resubmitted'=>count($keep),'dropped'=>count($dropped),'dropped_reasons'=>array_column($dropped,'reason'),'message'=>'Re-submitted to the Unit Head for verification. It will then go to the School Registrar for final approval.'.($dropped?(' '.count($dropped).' item(s) were left out because they no longer apply.'):'')]);
 }
 /* PARTIAL (approve AT reject): kapag may item_ids (galing sa filter / sa piniling row), ang mga napiling item LANG
    ang ima-approve o ire-reject. Inililipat sila sa bagong submission (kopya ng metadata); ang natira ay mananatili
    sa original na queue at hindi nadadamay. Dati, buong submission ang nare-reject kahit isang subject lang ang mali. */
 $splitMoved=0;$splitTotal=0;
 $rawIds=$_POST['item_ids']??[]; if(is_string($rawIds))$rawIds=explode(',',$rawIds);
 $itemIds=array_values(array_unique(array_filter(array_map('intval',(array)$rawIds),function($v){return $v>0;})));
 if($itemIds){
  $awaiting=($role==='UNIT HEAD'&&$sub['status']==='PENDING_UNIT_HEAD')||($role==='SCHOOL REGISTRAR'&&$sub['status']==='PENDING_REGISTRAR');
  if(!$awaiting)throw new Exception('This submission is not awaiting your review.');
  $allQ=$pdo->prepare("SELECT id FROM gradebook_approval_items WHERE submission_id=? ORDER BY id FOR UPDATE");$allQ->execute([$id]);
  $allIds=array_map('intval',$allQ->fetchAll(PDO::FETCH_COLUMN));
  $pick=array_values(array_intersect($allIds,$itemIds));
  if(!$pick)throw new Exception('The selected grades are no longer in this submission. Please refresh the list.');
  $splitTotal=count($allIds);$splitMoved=count($pick);
  if(count($pick)<count($allIds)){
   $cp=$pdo->prepare("INSERT INTO gradebook_approval_submissions(department_id,school_year,term,course_code,description,submitted_by,submitted_by_name,status,unit_head_id,unit_head_at,registrar_id,registrar_at,created_at,resubmit_count,resubmitted_at,resubmit_note,last_rejection_reason) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
   $cp->execute([$sub['department_id'],$sub['school_year'],$sub['term'],$sub['course_code'],$sub['description'],$sub['submitted_by'],$sub['submitted_by_name'],$sub['status'],$sub['unit_head_id'],$sub['unit_head_at'],$sub['registrar_id'],$sub['registrar_at'],$sub['created_at'],(int)($sub['resubmit_count']??0),$sub['resubmitted_at']??null,$sub['resubmit_note']??null,$sub['last_rejection_reason']??null]);
   $newId=(int)$pdo->lastInsertId();
   $in=implode(',',array_fill(0,count($pick),'?'));
   $mv=$pdo->prepare("UPDATE gradebook_approval_items SET submission_id=? WHERE submission_id=? AND id IN ($in)");
   $mv->execute(array_merge([$newId,$id],$pick));
   ascb_log_activity($pdo,$ascbUser,'GRADEBOOK_SUBMISSION_SPLIT','gradebook_approval',(string)$id,'Partial approval: moved '.count($pick).' of '.count($allIds).' item(s) to submission #'.$newId.'.');
   $id=$newId;$q->execute([$id]);$sub=$q->fetch(PDO::FETCH_ASSOC);
  }
 }
 if($action==='reject'){
  $reason=trim((string)($_POST['reason']??'')); if($reason==='')throw new Exception('Please provide a reason for rejection.');
  if($role==='UNIT HEAD' && $sub['status']==='PENDING_UNIT_HEAD'){$u=$pdo->prepare("UPDATE gradebook_approval_submissions SET status='REJECTED',unit_head_id=?,unit_head_at=NOW(),rejected_by_role='UNIT HEAD',rejected_at=NOW(),rejection_reason=? WHERE id=?");$u->execute([(int)$ascbUser['id'],mb_substr($reason,0,500),$id]);}
  elseif($role==='SCHOOL REGISTRAR' && $sub['status']==='PENDING_REGISTRAR'){$u=$pdo->prepare("UPDATE gradebook_approval_submissions SET status='REJECTED',registrar_id=?,registrar_at=NOW(),rejected_by_role='SCHOOL REGISTRAR',rejected_at=NOW(),rejection_reason=? WHERE id=?");$u->execute([(int)$ascbUser['id'],mb_substr($reason,0,500),$id]);}
  else throw new Exception('This submission is not awaiting your review.');
  $pdo->commit(); ascb_log_activity($pdo,$ascbUser,'GRADEBOOK_SUBMISSION_REJECTED','gradebook_approval',(string)$id,'Rejected'.($itemIds?(' '.$splitMoved.' of '.$splitTotal.' item(s)'):'').': '.$reason); $partialRej=($itemIds&&$splitMoved>0&&$splitMoved<$splitTotal);
  gba_json(['ok'=>true,'rejected'=>$splitMoved?:$splitTotal,'partial'=>$partialRej,'submission_id'=>$id,'message'=>$partialRej?($splitMoved.' grade'.($splitMoved===1?'':'s').' rejected. The other '.($splitTotal-$splitMoved).' stay in the queue.'):'Submission rejected.']);
 }
 if($role==='UNIT HEAD' && $sub['status']==='PENDING_UNIT_HEAD'){
  $u=$pdo->prepare("UPDATE gradebook_approval_submissions SET status='PENDING_REGISTRAR',unit_head_id=?,unit_head_at=NOW() WHERE id=?");$u->execute([(int)$ascbUser['id'],$id]);$pdo->commit();ascb_log_activity($pdo,$ascbUser,'GRADEBOOK_UNIT_HEAD_APPROVED','gradebook_approval',(string)$id,'Forwarded to School Registrar for final approval.');gba_json(['ok'=>true,'message'=>'Unit Head approved. Forwarded to School Registrar for final approval.']);
 }
 if($role!=='SCHOOL REGISTRAR'||$sub['status']!=='PENDING_REGISTRAR')throw new Exception('Only the School Registrar can give final approval after Unit Head review.');
 $it=$pdo->prepare("SELECT * FROM gradebook_approval_items WHERE submission_id=? ORDER BY id");$it->execute([$id]);$items=$it->fetchAll(PDO::FETCH_ASSOC);
 $check=$pdo->prepare("SELECT es.id,es.course_code,es.description,e.student_id,e.surname,e.first_name,e.middle_name,e.school_year,e.trimester,e.status,e.archived_at FROM enrollment_subjects es JOIN enrollees e ON e.id=es.enrollment_id WHERE es.id=? FOR UPDATE");
 $get=$pdo->prepare("SELECT id,grade FROM grades WHERE enrollment_subject_id=? LIMIT 1 FOR UPDATE");
 $upd=$pdo->prepare("UPDATE grades SET grade=?,updated_by_user_id=?,updated_at=NOW() WHERE id=?");
 $ins=$pdo->prepare("INSERT INTO grades(enrollment_subject_id,grade,entered_by_user_id,entered_at) VALUES(?,?,?,NOW())");
 foreach($items as $item){
  $check->execute([(int)$item['enrollment_subject_id']]);$en=$check->fetch(PDO::FETCH_ASSOC);
  if(!$en||$en['status']!=='approved'||$en['archived_at']!==null||$en['school_year']!==$sub['school_year']||$en['trimester']!==$sub['term'])throw new Exception('Enrollment changed since submission. Nothing was approved; please resubmit after checking the gradebook.');
  if((string)$en['student_id']!==(string)$item['student_id'])throw new Exception('Student identity changed since submission. Nothing was approved.');
  $new=trim((string)$item['new_grade']);
  if($new!=='' && !preg_match('/^(INC|DRP|DR\.?|NG|P|PASSED|[-–—])$/iu',$new) && (!is_numeric($new)||(float)$new<0||(float)$new>5))throw new Exception('Invalid grade found in submission.');
  if(array_key_exists('new_units',$item) && $item['new_units']!==null && $item['new_units']!==''){
   $units=(float)$item['new_units']; if($units<0||$units>99)throw new Exception('Invalid units found in submission.');
   $pdo->prepare("UPDATE enrollment_subjects SET units=? WHERE id=?")->execute([$units,(int)$item['enrollment_subject_id']]);
  }
  $get->execute([(int)$item['enrollment_subject_id']]);$g=$get->fetch(PDO::FETCH_ASSOC);
  if($new===''){if($g)$pdo->prepare("DELETE FROM grades WHERE id=?")->execute([(int)$g['id']]);}
  elseif($g)$upd->execute([$new,(int)$ascbUser['id'],(int)$g['id']]);
  else $ins->execute([(int)$item['enrollment_subject_id'],$new,(int)$ascbUser['id']]);
 }
 $u=$pdo->prepare("UPDATE gradebook_approval_submissions SET status='APPROVED',registrar_id=?,registrar_at=NOW() WHERE id=?");$u->execute([(int)$ascbUser['id'],$id]);
 $pdo->commit();ascb_log_activity($pdo,$ascbUser,'GRADEBOOK_REGISTRAR_FINAL_APPROVAL','gradebook_approval',(string)$id,'Final approval applied '.count($items).' grade item(s).');gba_json(['ok'=>true,'message'=>'Final approval completed. Official grades have been updated.']);
}catch(Throwable $e){if(isset($pdo)&&$pdo instanceof PDO&&$pdo->inTransaction())$pdo->rollBack();gba_json(['ok'=>false,'error'=>$e instanceof PDOException?'Database error during grade approval.':$e->getMessage()],400);}
