<?php
require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/gradebook_lock.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$role = ascb_get($ascbUser, 'role', '');

function rc_json($data, $status=200) { http_response_code($status); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }
function rc_grade_valid($grade) {
    $grade = trim((string)$grade);
    if ($grade === '') return true;
    /* (audit fix) Same bug na na-ayos sa api/grades.php: ang dating pattern
       ('5(?:\.0)?') ay TINATANGGIHAN ang "5.00" (dalawang decimal place) —
       kahit ito mismo ang standard na paraan ng pagsulat ng FAILING grade
       sa Philippine grading scale, at kahit sinasabi mismo ng error message
       na "0.00–5.00" ang format. */
    if (preg_match('/^(INC|DRP|DR\.?|NG|P|PASSED|[-–—])$/iu', $grade)) {
        return true;
    }
    if (is_numeric($grade)) {
        $n = (float)$grade;
        return $n >= 0 && $n <= 5;
    }
    return false;
}
function rc_load_enrollment(PDO $pdo, $id) {
    $st=$pdo->prepare("SELECT id, student_id, surname, first_name, middle_name".ascb_suffix_sql_cols($pdo,'enrollees').", course, major, year_level, trimester, school_year, status, archived_at FROM enrollees WHERE id=? LIMIT 1");
    $st->execute([(int)$id]); return $st->fetch();
}
/* Buong pangalan ayon sa PSA placement ng suffix: "Surname, First Middle Jr." */
function rc_name($e) {
    $e = ascb_row_master_suffix($e);
    return ascb_name_print(
        isset($e['surname'])?$e['surname']:'', isset($e['first_name'])?$e['first_name']:'', isset($e['middle_name'])?$e['middle_name']:'',
        isset($e['suffix'])?$e['suffix']:'', isset($e['suffix_position'])?$e['suffix_position']:'separate'
    );
}
function rc_subject_snapshot(PDO $pdo, $enrollmentId) {
    $st=$pdo->prepare("SELECT es.id, es.course_code, es.description, es.units, g.grade FROM enrollment_subjects es LEFT JOIN grades g ON g.enrollment_subject_id=es.id WHERE es.enrollment_id=? ORDER BY es.id");
    $st->execute([(int)$enrollmentId]); return $st->fetchAll();
}

if ($method === 'GET') {
    $enrollmentId=(int)($_GET['enrollment_id'] ?? 0);
    $status=trim((string)($_GET['status'] ?? ''));
    $sql="SELECT rc.id, rc.enrollment_id, rc.student_id, rc.correction_type, rc.reason, rc.changes_json, rc.status, rc.requested_at, rc.reviewed_at, rc.review_remarks,
                 CONCAT(COALESCE(u.display_name,u.username),'') AS requested_by,
                 CONCAT(COALESCE(r.display_name,r.username),'') AS reviewed_by,
                 e.surname, e.first_name, e.middle_name".ascb_suffix_sql_cols($pdo,'e')." , e.course, e.major, e.year_level, e.trimester, e.school_year
          FROM record_corrections rc
          INNER JOIN enrollees e ON e.id=rc.enrollment_id
          LEFT JOIN users u ON u.id=rc.requested_by_user_id
          LEFT JOIN users r ON r.id=rc.reviewed_by_user_id WHERE 1=1";
    $params=[];
    if($enrollmentId>0){$sql.=" AND rc.enrollment_id=?";$params[]=$enrollmentId;}
    if($status!==''){$sql.=" AND rc.status=?";$params[]=$status;}
    if($role==='DEAN'){$sql.=" AND e.department_id=?";$params[]=(int)ascb_require_dean_department($pdo,$ascbUser);}
    if(!ascb_can($role,'approve_record_correction') && $enrollmentId<=0){
        $sql.=" AND rc.requested_by_user_id=?";$params[]=(int)$ascbUser['id'];
    }
    $sql.=" ORDER BY rc.id DESC LIMIT 100";
    $st=$pdo->prepare($sql);$st->execute($params);$rows=$st->fetchAll();
    foreach($rows as &$r){$r['changes']=json_decode($r['changes_json'],true) ?: []; unset($r['changes_json']); $r['name']=rc_name($r);}
    rc_json(['ok'=>true,'rows'=>$rows]);
}

if ($method !== 'POST') rc_json(['ok'=>false,'error'=>'Method not allowed.'],405);
$input=ascb_read_json_body();
$action=trim((string)($input['action']??''));

if($action==='request'){
    if(!ascb_can($role,'request_record_correction')) rc_json(['ok'=>false,'error'=>'You do not have permission to request a correction.'],403);
    $enrollmentId=(int)($input['enrollmentId']??0); $reason=trim((string)($input['reason']??'')); $changes=$input['changes']??[];
    if($enrollmentId<=0 || $reason==='' || mb_strlen($reason)>500 || !is_array($changes) || !$changes) rc_json(['ok'=>false,'error'=>'Please complete the correction reason and changes.'],400);
    $e=rc_load_enrollment($pdo,$enrollmentId);
    if(!$e || $e['archived_at']!==null || $e['status']!=='approved') rc_json(['ok'=>false,'error'=>'Previous term record not found or not approved.'],404);
    $subjects=rc_subject_snapshot($pdo,$enrollmentId); $byId=[]; foreach($subjects as $s)$byId[(int)$s['id']]=$s;
    $clean=[]; $seen=[];
    foreach($changes as $c){
        if(!is_array($c)) rc_json(['ok'=>false,'error'=>'Invalid correction item.'],400);
        $type=trim((string)($c['type']??''));
        if($type==='grade' || $type==='subject_update' || $type==='subject_remove'){
            $sid=(int)($c['subjectId']??0); if($sid<=0 || !isset($byId[$sid]) || isset($seen[$type.':'.$sid])) rc_json(['ok'=>false,'error'=>'Invalid or duplicate subject correction.'],400);
            $seen[$type.':'.$sid]=1; $old=$byId[$sid];
            if($type==='grade'){
                $new=trim((string)($c['newGrade']??'')); if(!rc_grade_valid($new)) rc_json(['ok'=>false,'error'=>'Invalid grade. Use 0.00–5.00, INC, Dr., NG, P, "-", or blank.'],400);
                $new=ascb_normalize_grade($new); // standardized format, e.g. "2" -> "2.0"
                $clean[]=['type'=>'grade','subjectId'=>$sid,'oldGrade'=>$old['grade']===null?'':(string)$old['grade'],'newGrade'=>$new,'courseCode'=>(string)$old['course_code'],'description'=>(string)$old['description']];
            } elseif($type==='subject_update') {
                $code=trim((string)($c['courseCode']??'')); $desc=trim((string)($c['description']??'')); $units=trim((string)($c['units']??''));
                /* (Dash) Units na "-" (hal. Comprehensive Exam) = 0 units. Parehong panuntunan ng grade_import.php / grades.php. */
                if(preg_match('/^[-–—]$/u',$units)) $units='0';
                if($desc==='' || !is_numeric($units) || (float)$units<0 || (float)$units>99) rc_json(['ok'=>false,'error'=>'Invalid subject details.'],400);
                $clean[]=['type'=>'subject_update','subjectId'=>$sid,'oldCourseCode'=>(string)$old['course_code'],'newCourseCode'=>$code,'oldDescription'=>(string)$old['description'],'newDescription'=>$desc,'oldUnits'=>(float)$old['units'],'newUnits'=>(float)$units];
            } else {
                $clean[]=['type'=>'subject_remove','subjectId'=>$sid,'courseCode'=>(string)$old['course_code'],'description'=>(string)$old['description'],'units'=>(float)$old['units'],'grade'=>$old['grade']===null?'':(string)$old['grade']];
            }
        } elseif($type==='subject_add') {
            $code=trim((string)($c['courseCode']??'')); $desc=trim((string)($c['description']??'')); $units=trim((string)($c['units']??'')); $grade=trim((string)($c['grade']??''));
            /* (Dash) Units na "-" (hal. Comprehensive Exam) = 0 units. Parehong panuntunan ng grade_import.php / grades.php. */
            if(preg_match('/^[-–—]$/u',$units)) $units='0';
            if($desc==='' || !is_numeric($units) || (float)$units<0 || (float)$units>99 || !rc_grade_valid($grade)) rc_json(['ok'=>false,'error'=>'Invalid new subject details.'],400);
            $grade=ascb_normalize_grade($grade); // standardized format, e.g. "2" -> "2.0"
            $clean[]=['type'=>'subject_add','courseCode'=>$code,'description'=>$desc,'units'=>(float)$units,'grade'=>$grade];
        } else rc_json(['ok'=>false,'error'=>'Unsupported correction type.'],400);
    }
    if(!$clean) rc_json(['ok'=>false,'error'=>'No valid changes.'],400);
    $pending=$pdo->prepare("SELECT COUNT(*) FROM record_corrections WHERE enrollment_id=? AND status='PENDING'");$pending->execute([$enrollmentId]);
    if((int)$pending->fetchColumn()>0) rc_json(['ok'=>false,'error'=>'There is already a pending correction request for this term. Please review that first before creating another.'],409);
    try{
        $pdo->beginTransaction();
        $ins=$pdo->prepare("INSERT INTO record_corrections (enrollment_id,student_id,correction_type,reason,changes_json,status,requested_by_user_id) VALUES (?,?,?,?,?,'PENDING',?)");
        $ins->execute([$enrollmentId,$e['student_id'],'SUBJECT_GRADE',$reason,json_encode($clean,JSON_UNESCAPED_UNICODE),(int)$ascbUser['id']]); $id=(int)$pdo->lastInsertId();
        foreach($clean as $c){
            if($c['type']==='grade') $items=[['grade',$c['oldGrade'],$c['newGrade']]];
            elseif($c['type']==='subject_update') $items=[['course_code',$c['oldCourseCode'],$c['newCourseCode']],['description',$c['oldDescription'],$c['newDescription']],['units',(string)$c['oldUnits'],(string)$c['newUnits']]];
            elseif($c['type']==='subject_remove') $items=[['action','EXISTING','REMOVE']];
            else $items=[['action','NONE','ADD'],['course_code','',$c['courseCode']],['description','',$c['description']],['units','',$c['units']],['grade','',$c['grade']]];
            foreach($items as $it){$q=$pdo->prepare("INSERT INTO record_correction_items (correction_id,entity_type,entity_id,field_name,old_value,new_value) VALUES (?,?,?,?,?,?)");$q->execute([$id,'enrollment_subject',$c['subjectId']??null,$it[0],$it[1],$it[2]]);}
        }
        $pdo->commit();
        ascb_log_activity($pdo,$ascbUser,'RECORD_CORRECTION_REQUESTED','enrollment',rc_name($e).' ('.$e['student_id'].')',$e['trimester'].' / '.$e['school_year'].' — correction request #'.$id);
        rc_json(['ok'=>true,'id'=>$id,'status'=>'PENDING']);
    }catch(Throwable $x){if($pdo->inTransaction())$pdo->rollBack();rc_json(['ok'=>false,'error'=>'The correction request could not be created.'],500);}
}

if($action==='approve' || $action==='reject'){
    if(!ascb_can($role,'approve_record_correction')) rc_json(['ok'=>false,'error'=>'You do not have permission to review a correction.'],403);
    $id=(int)($input['correctionId']??0); $remarks=trim((string)($input['remarks']??'')); if($id<=0)rc_json(['ok'=>false,'error'=>'Invalid correction request.'],400);
    $st=$pdo->prepare("SELECT * FROM record_corrections WHERE id=? LIMIT 1");$st->execute([$id]);$rc=$st->fetch();
    if(!$rc || $rc['status']!=='PENDING')rc_json(['ok'=>false,'error'=>'Correction request is no longer pending.'],409);
    /* 2026 fix: kahit sinong UNIT HEAD ang gumawa ng request, kahit sinong
       UNIT HEAD account (kasama na ang gumawa nito) ay pwedeng mag-approve.
       Ang approve_record_correction permission (UNIT HEAD lang) na ang
       tanging security boundary dito — tinanggal na ang dating
       "requester ≠ approver" restriction. */
    $e=rc_load_enrollment($pdo,(int)$rc['enrollment_id']); if(!$e || $e['status']!=='approved' || $e['archived_at']!==null)rc_json(['ok'=>false,'error'=>'Historical enrollment record is no longer available.'],409);
    try{
        $pdo->beginTransaction();
        if($action==='reject'){
            $up=$pdo->prepare("UPDATE record_corrections SET status='REJECTED', reviewed_by_user_id=?, reviewed_at=NOW(), review_remarks=? WHERE id=? AND status='PENDING'");$up->execute([(int)$ascbUser['id'],$remarks,$id]);
            $pdo->commit(); ascb_log_activity($pdo,$ascbUser,'RECORD_CORRECTION_REJECTED','enrollment',rc_name($e).' ('.$e['student_id'].')','Correction #'.$id.' rejected.'); rc_json(['ok'=>true,'status'=>'REJECTED']);
        }
        $changes=json_decode($rc['changes_json'],true); if(!is_array($changes))throw new Exception('Invalid stored correction data.');
        $countSubjects=(int)$pdo->query("SELECT COUNT(*) FROM enrollment_subjects WHERE enrollment_id=".(int)$e['id'])->fetchColumn();
        foreach($changes as $c){
            $type=$c['type']??'';
            if($type==='grade'){
                $sid=(int)$c['subjectId'];$q=$pdo->prepare("SELECT es.id,es.course_code,es.description,es.units,g.id AS grade_id,g.grade FROM enrollment_subjects es LEFT JOIN grades g ON g.enrollment_subject_id=es.id WHERE es.id=? AND es.enrollment_id=? FOR UPDATE");$q->execute([$sid,$e['id']]);$s=$q->fetch();if(!$s)throw new Exception('A subject in this request no longer exists.'); ascb_gradebook_lock_assert_editable($pdo,$e['school_year'],$e['trimester'],$s['course_code'],$s['description'],$role);
                $current=$s['grade']===null?'':(string)$s['grade']; if($current!==(string)$c['oldGrade'])throw new Exception('Stale correction: the original grade has already changed.');
                if($s['grade_id']){$u=$pdo->prepare("UPDATE grades SET grade=?,updated_by_user_id=?,updated_at=NOW() WHERE id=?");$u->execute([$c['newGrade']!==''?$c['newGrade']:null,(int)$ascbUser['id'],(int)$s['grade_id']]);}elseif($c['newGrade']!==''){$u=$pdo->prepare("INSERT INTO grades(enrollment_subject_id,grade,entered_by_user_id,entered_at) VALUES(?,?,?,NOW())");$u->execute([$sid,$c['newGrade'],(int)$ascbUser['id']]);}
                // (feature) Automatic zero-units on failing/"bagsak" grade — same rule as api/grades.php.
                if(ascb_grade_is_failing($c['newGrade'])){$zu=$pdo->prepare("UPDATE enrollment_subjects SET units=0 WHERE id=? AND units<>0");$zu->execute([$sid]);}
            } elseif($type==='subject_update'){
                $q=$pdo->prepare("SELECT id,course_code,description,units FROM enrollment_subjects WHERE id=? AND enrollment_id=? FOR UPDATE");$q->execute([(int)$c['subjectId'],$e['id']]);$s=$q->fetch();if(!$s)throw new Exception('A subject in this request no longer exists.'); ascb_gradebook_lock_assert_editable($pdo,$e['school_year'],$e['trimester'],$s['course_code'],$s['description'],$role);
                if((string)$s['course_code']!==(string)$c['oldCourseCode'] || (string)$s['description']!==(string)$c['oldDescription'] || (float)$s['units']!=(float)$c['oldUnits'])throw new Exception('Stale correction: the subject was changed after this request.');
                $u=$pdo->prepare("UPDATE enrollment_subjects SET course_code=?,description=?,units=? WHERE id=?");$u->execute([$c['newCourseCode'],$c['newDescription'],$c['newUnits'],(int)$c['subjectId']]);
            } elseif($type==='subject_remove'){
                if($countSubjects<=1)throw new Exception('Hindi puwedeng maging walang subject ang enrollment term.');
                $q=$pdo->prepare("SELECT id,course_code,description,units FROM enrollment_subjects WHERE id=? AND enrollment_id=? FOR UPDATE");$q->execute([(int)$c['subjectId'],$e['id']]);$s=$q->fetch();if(!$s)throw new Exception('A subject to remove no longer exists.'); ascb_gradebook_lock_assert_editable($pdo,$e['school_year'],$e['trimester'],$s['course_code'],$s['description'],$role);
                if((string)$s['course_code']!==(string)$c['courseCode'] || (string)$s['description']!==(string)$c['description'])throw new Exception('Stale correction: subject details changed after this request.');
                $d=$pdo->prepare("DELETE FROM enrollment_subjects WHERE id=? AND enrollment_id=?");$d->execute([(int)$c['subjectId'],$e['id']]);$countSubjects--;
            } elseif($type==='subject_add'){
                // Do not allow a correction request to create a new row for a
                // subject that has already been locked for this term.
                ascb_gradebook_lock_assert_editable($pdo,$e['school_year'],$e['trimester'],$c['courseCode']??'',$c['description']??'',$role);
                $addUnits=ascb_grade_is_failing($c['grade']??'')?0:$c['units'];
                $u=$pdo->prepare("INSERT INTO enrollment_subjects(enrollment_id,course_code,description,units) VALUES(?,?,?,?)");$u->execute([$e['id'],$c['courseCode'],$c['description'],$addUnits]);$newSubject=(int)$pdo->lastInsertId();
                if(($c['grade']??'')!==''){$g=$pdo->prepare("INSERT INTO grades(enrollment_subject_id,grade,entered_by_user_id,entered_at) VALUES(?,?,?,NOW())");$g->execute([$newSubject,$c['grade'],(int)$ascbUser['id']]);}
                $countSubjects++;
            }
        }
        $up=$pdo->prepare("UPDATE record_corrections SET status='APPROVED',reviewed_by_user_id=?,reviewed_at=NOW(),review_remarks=? WHERE id=? AND status='PENDING'");$up->execute([(int)$ascbUser['id'],$remarks,$id]);
        $pdo->commit();
        ascb_log_activity($pdo,$ascbUser,'RECORD_CORRECTION_APPROVED','enrollment',rc_name($e).' ('.$e['student_id'].')','Correction #'.$id.' approved and applied.');
        rc_json(['ok'=>true,'status'=>'APPROVED']);
    }catch(PDOException $x){if($pdo->inTransaction())$pdo->rollBack();error_log('ASCB record correction database failure: '.$x->getMessage());rc_json(['ok'=>false,'error'=>'A database error prevented this correction from being applied. No changes were committed.'],500);}catch(Exception $x){if($pdo->inTransaction())$pdo->rollBack();rc_json(['ok'=>false,'error'=>$x->getMessage()],409);}catch(Throwable $x){if($pdo->inTransaction())$pdo->rollBack();error_log('ASCB record correction unexpected failure: '.$x->getMessage());rc_json(['ok'=>false,'error'=>'The correction could not be applied. No changes were committed.'],500);}
}
rc_json(['ok'=>false,'error'=>'Invalid correction action.'],400);
