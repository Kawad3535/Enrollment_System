<?php
/* AUTH GUARD (server-side): redirects to index.php before any
   HTML is sent if there's no valid session — this replaces the
   old client-side ascbGuardPage() approach. */
require_once __DIR__ . '/includes/auth_check.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/permissions.php';
require_once __DIR__ . '/includes/programs_helper.php';

$ascbSchools = $pdo->query("SELECT id, name, address FROM schools ORDER BY name")->fetchAll();
$ascbCourses = $pdo->query("SELECT id, name FROM courses ORDER BY name")->fetchAll();
$ascbPermissions = ascb_permissions_for(ascb_get($ascbUser, 'role', ''));

/* Program options and curriculum are loaded exclusively from the programs tables. */
$ascbProgramOptions = array('' => 'Select Program') + ascb_program_dropdown_options($pdo);
$ascbCustomProgramsData = ascb_build_structured_programs($pdo);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="icon" type="image/png" href="ASCB_LOGO.png">
    <title>Office of the Registrar | ASCB</title>

    <script src="auth.js?v=<?php echo (int) @filemtime(__DIR__ . '/auth.js'); ?>"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet"
    >

    <link rel="stylesheet" href="style.css?v=<?php echo (int) @filemtime(__DIR__ . '/style.css'); ?>">
    <link rel="stylesheet" href="responsive.css?v=<?php echo (int) @filemtime(__DIR__ . '/responsive.css'); ?>">

    <!-- Apply saved theme before first paint, so there's no
         light-mode flash when Dark Mode is on. -->
    <script>
        (function () {
            var t = localStorage.getItem("ascbTheme") === "dark" ? "dark" : "light";
            document.documentElement.setAttribute("data-theme", t);
        })();
    </script>
</head>

<body>

<div class="app-shell" id="appShell">

    <!-- =====================================================
         MOBILE TOP BAR (shown only on small screens)
    ====================================================== -->
    <div class="mobile-topbar">
        <button type="button" class="mobile-menu-btn" onclick="ascbToggleSidebar()" aria-label="Open menu">☰</button>
        <img src="ASCB_LOGO.png" class="mobile-topbar-logo" alt="ASCB Logo">
        <span class="mobile-topbar-title">ASCB Registrar</span>
    </div>

    <div class="sidebar-backdrop" id="sidebarBackdrop" onclick="ascbToggleSidebar(false)"></div>


    <!-- =====================================================
         LEFT NAVIGATION SIDEBAR
    ====================================================== -->
    <aside class="main-sidebar" id="mainSidebar">

        <div class="main-sidebar-brand">
            <img src="ASCB_LOGO.png" class="main-sidebar-logo" alt="ASCB Logo">
            <h5>OFFICE OF THE REGISTRAR</h5>
        </div>

        <nav class="main-sidebar-nav">

            <div class="main-sidebar-label">Menu</div>

            <div class="main-sidebar-label">Overview</div>

            <button type="button" class="main-nav-link active" id="navDashboard" data-view="dashboard" onclick="ascbNavigate('dashboard'); ascbLoadDashboardStats(); if (typeof ascbLoadRegistrarAnalytics === 'function') ascbLoadRegistrarAnalytics();">
                <span class="main-nav-icon">🏠</span>
                Dashboard
            </button>

            <div class="main-sidebar-label">Student &amp; Enrollment</div>

            <button type="button" class="main-nav-link" id="navStudent360" data-view="student360" onclick="ascbNavigate('student360'); ascbLoadStudent360();">
                <span class="main-nav-icon">🧑</span>
                Student 360
            </button>

            <?php if (!empty($ascbPermissions['manageMasterRecord'])): ?>
            <button type="button" class="main-nav-link" id="navMasterRecord" data-view="masterrecord" onclick="ascbNavigate('masterrecord'); ascbLoadMasterRecord();">
                <span class="main-nav-icon">🗃</span>
                Master Record
            </button>
            <?php endif; ?>

            <button type="button" class="main-nav-link" id="navEnrollment" data-view="enrollment" onclick="ascbNavigate('enrollment'); ascbLoadEnrollment();">
                <span class="main-nav-icon">📝</span>
                Enrollment
            </button>

            <button type="button" class="main-nav-link" id="navNewTerm" data-view="newterm" onclick="ascbNavigate('newterm'); ascbLoadEnrollment();">
                <span class="main-nav-icon">🗂</span>
                New Term
                <span id="newTermNavBadge" class="nav-notif-badge" style="display:none;" title="Pending enrollee(s) from Admin Staff">0</span>
            </button>

            <div class="main-sidebar-label">Academic Records</div>

            <button type="button" class="main-nav-link" id="navCertificates" data-view="certificates" onclick="ascbCertificatesNavReset()">
                <span class="main-nav-icon">📃</span>
                Certificates
            </button>

            <button type="button" class="main-nav-link" id="navGradeManagement" data-view="grademanagement" onclick="ascbNavigate('grademanagement'); ascbLoadGradeManagement();">
                <span class="main-nav-icon">✏️</span>
                Grade Management
                <span id="gradeMgmtNavBadge" class="nav-notif-badge" style="display:none;" title="Pending correction request(s)">0</span>
            </button>

            <button type="button" class="main-nav-link" id="navGradeEvaluation" data-view="gradeevaluation" onclick="ascbNavigate('gradeevaluation'); ascbLoadGradeEvaluation();">
                <span class="main-nav-icon">🎓</span>
                Grade Evaluation
            </button>

            <?php if (!empty($ascbPermissions['viewHonors'])): ?>
            <button type="button" class="main-nav-link" id="navHonors" data-view="honors" onclick="ascbNavigate('honors'); ascbLoadHonors();">
                <span class="main-nav-icon">🏅</span>
                President's &amp; Dean's Lister
            </button>
            <?php endif; ?>


            <div class="main-sidebar-label">Documents &amp; Requests</div>

            <button type="button" class="main-nav-link" id="navForm137" data-view="form137" onclick="ascbForm137NavReset()">
                <span class="main-nav-icon">📄</span>
                Form 137-A
            </button>

            <button type="button" class="main-nav-link" id="navRecords" data-view="records" onclick="ascbNavigate('records'); ascbLoadRecords();">
                <span class="main-nav-icon">🗂</span>
                History
            </button>

            <button type="button" class="main-nav-link" id="navApprovedSO" data-view="approvedso" onclick="ascbNavigate('approvedso'); ascbLoadApprovedSO();">
                <span class="main-nav-icon">✅</span>
                Approved SO
            </button>

            <button type="button" class="main-nav-link" id="navRejected" data-view="rejected" onclick="ascbNavigate('rejected'); ascbLoadRejectedStudents();">
                <span class="main-nav-icon">🚫</span>
                Rejected Students
            </button>

            <div class="main-sidebar-label">System</div>

            <?php if (!empty($ascbPermissions['viewArchive'])): ?>
            <button type="button" class="main-nav-link" id="navArchive" data-view="archive" onclick="ascbNavigate('archive'); ascbLoadArchive();">
                <span class="main-nav-icon">🗄</span>
                Archive
            </button>

            <?php endif; ?>
            <button type="button" class="main-nav-link" id="navAdmin" data-view="admin" onclick="ascbNavigate('admin'); ascbAdminOpen();">
                <span class="main-nav-icon">⚙</span>
                Settings
            </button>

        </nav>

        <div class="main-sidebar-footer">

            <div class="main-sidebar-user">
                <div class="main-sidebar-user-avatar" id="ascbUserAvatar"><?php echo htmlspecialchars(ascb_first_initial($ascbUser['displayName']), ENT_QUOTES, 'UTF-8'); ?></div>
                <div class="main-sidebar-user-info">
                    <span class="main-sidebar-user-name" id="ascbCurrentUserName"><?php echo htmlspecialchars($ascbUser['displayName']); ?></span>
                    <span class="main-sidebar-user-role" id="ascbCurrentUserRole"><?php echo htmlspecialchars($ascbUser['role']); ?></span>
                </div>
            </div>

            <a class="main-sidebar-logout" href="./?view=home" title="Home page" style="text-decoration:none;margin-bottom:8px;">
                <span class="main-nav-icon">⌂</span>
                Home
            </a>

            <button type="button" class="main-sidebar-logout" onclick="ascbConfirmLogout()" title="Sign out">
                <span class="main-nav-icon">⎋</span>
                Logout
            </button>

            <button type="button" class="theme-quick-toggle" data-theme-quick-toggle onclick="ascbToggleTheme()" title="Toggle dark mode">
                <span class="theme-quick-toggle-icon">🌙</span> Dark Mode
            </button>

        </div>

    </aside>


    <!-- =====================================================
         APP MAIN
    ====================================================== -->
    <main class="app-main">

        <!-- =================================================
             DASHBOARD VIEW
        ================================================== -->
        <section class="app-view active-view" id="dashboardView">

            <div class="dashboard-hero">
                <div class="dashboard-hero-copy">
                    <div class="dashboard-eyebrow">OFFICE OF THE REGISTRAR</div>
                    <h1>Registrar Dashboard</h1>
                    <p>Good day, <strong id="dashboardUserName"><?php echo htmlspecialchars($ascbUser['displayName'], ENT_QUOTES, 'UTF-8'); ?></strong>. Monitor enrollment activity and access the registrar's core services from one place.</p>
                </div>
                <div class="dashboard-hero-widget">
                    <div class="dashboard-clock" id="dashboardAnalogClock" aria-hidden="true">
                        <div class="dashboard-clock-face">
                            <?php for ($i = 0; $i < 12; $i++): ?>
                                <span class="dashboard-clock-tick" style="--i:<?php echo $i; ?>"></span>
                            <?php endfor; ?>
                            <div class="dashboard-clock-hand dashboard-clock-hand--hour" id="dashboardClockHourHand"></div>
                            <div class="dashboard-clock-hand dashboard-clock-hand--minute" id="dashboardClockMinuteHand"></div>
                            <div class="dashboard-clock-hand dashboard-clock-hand--second" id="dashboardClockSecondHand"></div>
                            <div class="dashboard-clock-center"></div>
                        </div>
                    </div>
                    <div class="dashboard-mini-calendar" id="dashboardCalendarDate" title="Today">
                        <div class="dashboard-mini-calendar-month" id="dashboardCalendarMonth">---</div>
                        <div class="dashboard-mini-calendar-day" id="dashboardCalendarDay">--</div>
                        <div class="dashboard-mini-calendar-weekday" id="dashboardCalendarWeekday">Loading…</div>
                    </div>
                    <div class="dashboard-clock-info">
                        <div class="dashboard-clock-digital" id="dashboardDigitalClock">--:--:-- --</div>
                        <div class="dashboard-hero-meta">
                            <span class="dashboard-status-dot" aria-hidden="true"></span>
                            <span>System Online</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- =============================================
                 ENROLLMENT OVERVIEW — Total Enrolled, Male/Female,
                 saka breakdown kada Course/Program. Ino-fetch mula
                 sa api/dashboard_stats.php (tingnan ang
                 ascbLoadDashboardStats() sa script.js).
            ============================================== -->
            <div class="dashboard-stats" id="dashboardStats">

                <div class="dashboard-stats-header">
                    <div>
                        <div class="dashboard-section-kicker">ENROLLMENT MONITORING</div>
                        <h3>Enrollment Overview</h3>
                    </div>
                    <div class="dashboard-stats-header-actions">
                        <input type="text" id="dashboardSchoolYearFilter" class="dashboard-schoolyear-input" placeholder="e.g. 2025-2026" onchange="ascbLoadDashboardStats()" title="Filter by School Year">
                        <?php if (!empty($ascbPermissions['generateReports']) && strtoupper((string)ascb_get($ascbUser, 'role', '')) !== 'DEAN'): ?>
                        <select id="dashboardReportDepartment" onchange="ascbLoadDashboardReportCourses()" title="Summary Report: i-limit sa isang Department (optional)">
                            <option value="">— All Departments —</option>
                        </select>
                        <select id="dashboardReportCourse" title="Summary Report: i-limit sa isang Course (optional, kailangan munang pumili ng Department)">
                            <option value="">— All Courses —</option>
                        </select>
                        <button type="button" class="btn btn-outline" onclick="ascbExportDashboardReport()" title="Export Summary of Enrollment bilang PDF — sumusunod sa napiling Department/Course sa itaas">📄 Summary Report</button>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="records-status" id="dashboardStatsStatus">Loading…</div>

                <div class="dashboard-stats-cards" id="dashboardStatsCards" style="display:none;">
                    <div class="dashboard-stat-card dashboard-stat-total">
                        <span class="dashboard-stat-icon">👥</span>
                        <span class="dashboard-stat-label">Total Enrolled</span>
                        <span class="dashboard-stat-note">Unique active students</span>
                        <span class="dashboard-stat-value" id="dashboardStatTotal">0</span>
                    </div>
                    <div class="dashboard-stat-card dashboard-stat-male">
                        <span class="dashboard-stat-icon">♂</span>
                        <span class="dashboard-stat-label">Total Male</span>
                        <span class="dashboard-stat-note">Active student records</span>
                        <span class="dashboard-stat-value" id="dashboardStatMale">0</span>
                    </div>
                    <div class="dashboard-stat-card dashboard-stat-female">
                        <span class="dashboard-stat-icon">♀</span>
                        <span class="dashboard-stat-label">Total Female</span>
                        <span class="dashboard-stat-note">Active student records</span>
                        <span class="dashboard-stat-value" id="dashboardStatFemale">0</span>
                    </div>
                </div>

                <div class="dashboard-course-stats" id="dashboardCourseStats" style="display:none;"></div>

            </div>

            <?php if (strtoupper((string)ascb_get($ascbUser, 'role', '')) !== 'DEAN'): ?>
            <!-- =============================================
                 REGISTRAR ANALYTICS — operational overview
                 Uses the same filters above and the existing DB tables.
            ============================================== -->
            <section class="registrar-analytics" id="registrarAnalytics">
                <div class="analytics-header">
                    <div>
                        <div class="dashboard-section-kicker">REGISTRAR OPERATIONS</div>
                        <h3>Registrar Analytics</h3>
                        <p>Quick view of enrollment, workflow queues, services, programs and recent activity.</p>
                    </div>
                </div>
                <div class="analytics-status" id="analyticsStatus">Loading analytics…</div>
                <div class="analytics-kpi-grid" id="analyticsKpiGrid" style="display:none;">
                    <div class="analytics-kpi"><span>👥</span><div><small>Active Students</small><strong id="analyticsTotal">0</strong></div></div>
                    <button type="button" class="analytics-kpi analytics-kpi-clickable" id="analyticsPendingCard" onclick="ascbOpenPendingEnrollment()" title="Open Enrollment and show Pending records" aria-label="Open Pending Enrollment records"><span>⏳</span><div><small>Pending Enrollment</small><strong id="analyticsPending">0</strong></div><span class="analytics-kpi-arrow" aria-hidden="true">→</span></button>
                    <div class="analytics-kpi"><span>📝</span><div><small>Documents</small><strong id="analyticsDocuments">0</strong></div></div>
                    <div class="analytics-kpi"><span>🎓</span><div><small>Certificates</small><strong id="analyticsCertificates">0</strong></div></div>
                    <div class="analytics-kpi"><span>📜</span><div><small>Approved SO</small><strong id="analyticsSO">0</strong></div></div>
                </div>
                <div class="analytics-panels" id="analyticsPanels" style="display:none;">
                    <div class="analytics-panel">
                        <div class="analytics-panel-title"><span>Enrollment by Program</span><span class="analytics-muted">Top 12</span></div>
                        <div id="analyticsCourseBars" class="analytics-bars"></div>
                    </div>
                    <div class="analytics-panel">
                        <div class="analytics-panel-title"><span>Enrollment by Year Level</span></div>
                        <div id="analyticsYearBars" class="analytics-bars"></div>
                    </div>
                    <div class="analytics-panel">
                        <div class="analytics-panel-title"><span>Student Type</span></div>
                        <div id="analyticsStudentType" class="analytics-type-grid"></div>
                    </div>
                    <div class="analytics-panel">
                        <div class="analytics-panel-title"><span>Workflow Queue</span></div>
                        <div id="analyticsQueue" class="analytics-queue"></div>
                    </div>
                    <div class="analytics-panel analytics-panel-wide">
                        <div class="analytics-panel-title"><span>Enrollment Activity — Last 30 Days</span><span class="analytics-muted">records created</span></div>
                        <div id="analyticsDaily" class="analytics-spark"></div>
                    </div>
                </div>
            </section>
            <?php endif; // Registrar Analytics is not shown to DEAN accounts. ?>

            <div class="dashboard-grid">

                <?php if (ascb_get($ascbUser, 'role', '') !== 'DEAN'): ?>
                <button type="button" class="dashboard-action-card dashboard-action-card--enroll" onclick="ascbNavigate('enrollment'); ascbLoadEnrollment();">
                    <span class="dashboard-action-icon">📝</span>
                    <div>
                        <h3>Enroll a Student</h3>
                        <p>Add a new enrollee's Surname, Given Name, Middle Name, Birth Date, Address, and Previous School.</p>
                    </div>
                    <span class="dashboard-action-arrow">→</span>
                </button>

                <button type="button" class="dashboard-action-card dashboard-action-card--certificate" onclick="ascbCertificatesNavReset()">
                    <span class="dashboard-action-icon">📃</span>
                    <div>
                        <h3>Generate Certificate</h3>
                        <p>Create a Certificate of Enrollment, Registration, or Grade Evaluation for a student.</p>
                    </div>
                    <span class="dashboard-action-arrow">→</span>
                </button>

                <button type="button" class="dashboard-action-card dashboard-action-card--form137" onclick="ascbForm137NavReset()">
                    <span class="dashboard-action-icon">📄</span>
                    <div>
                        <h3>Request Form 137-A</h3>
                        <p>Prepare a transfer of credentials request letter for a receiving school.</p>
                    </div>
                    <span class="dashboard-action-arrow">→</span>
                </button>
                <?php endif; ?>

                <button type="button" class="dashboard-action-card dashboard-action-card--grade" onclick="ascbNavigate('gradeevaluation'); ascbLoadGradeEvaluation();">
                    <span class="dashboard-action-icon">🎓</span>
                    <div>
                        <h3>Grade Evaluation</h3>
                        <p>Pick a student and see every subject and grade from all of their enrollment records in one place.</p>
                    </div>
                    <span class="dashboard-action-arrow">→</span>
                </button>

            </div>

        </section>


        <!-- =================================================
             CERTIFICATES VIEW
        ================================================== -->
        <section class="app-view" id="certificatesView">

            <!-- =============================================
                 ACTIONS PANEL (collapsible)
            ============================================== -->
            <div class="actions-panel" id="actionsPanel">

                <button type="button" class="actions-panel-toggle" onclick="ascbToggleActionsPanel()">
                    <span class="actions-panel-toggle-label">
                        <span class="app-nav-icon">⚙</span>
                        Actions
                    </span>
                    <span class="actions-panel-chevron" id="actionsPanelChevron">▾</span>
                </button>

                <div class="actions-panel-body" id="actionsPanelBody">

                    <!-- =====================================
                         DATA SOURCE MODE
                         AUTOMATIC = kinukuha ang student, term,
                         subject at grades sa approved enrollment
                         record (default at inirerekomenda).
                         MANUAL = hayagang ita-type ng tauhan ang
                         lahat ng detalye — para sa walk-in o lumang
                         record na wala sa database.
                    ====================================== -->
                    <div class="certificate-mode-selector" role="radiogroup" aria-label="Certificate data source">
                            <div class="certificate-type-selector">
                                    <label for="certificateType" class="actions-inline-label">Document Type</label>
                                        <select id="certificateType" onchange="changeCertificateType()">

                                            <option value="ENROLLMENT">CERTIFICATE OF ENROLLMENT</option>

                                            <option value="REGISTRATION">CERTIFICATE OF REGISTRATION</option>

                                            <option value="GRADE_EVALUATION">GRADE EVALUATION</option>

                                        </select>
                            </div>

                    <button
                        type="button"
                        class="app-nav-btn app-nav-btn-primary"
                        id="generateCertificateButton"
                        disabled
                        onclick="generateCertificate()"
                    >
                        <span class="app-nav-icon">✔</span>
                        SUBMIT DATA
                    </button>

                    <button
                        type="button"
                        class="app-nav-btn"
                        onclick="clearForm()"
                    >
                        <span class="app-nav-icon">↺</span>
                        CLEAR DATA
                    </button>

                        <span class="actions-inline-label">You Can choose</span>

                        <div class="certificate-mode-options">

                            <label class="certificate-mode-option">
                                <input
                                    type="radio"
                                    name="certificateMode"
                                    value="AUTO"
                                    checked
                                    onchange="ascbCertificateChangeMode('AUTO')"
                                >
                                <span>
                                    <strong>Automatic</strong>
                                    <small>From an Enrolled Students</small>
                                </span>
                            </label>

                            <label class="certificate-mode-option">
                                <input
                                    type="radio"
                                    name="certificateMode"
                                    value="MANUAL"
                                    onchange="ascbCertificateChangeMode('MANUAL')"
                                >
                                <span>
                                    <strong>Manual</strong>
                                    <small>Type all details yourself</small>
                                </span>
                            </label>

                        </div>

                    </div>





                </div>

            </div>

        <!-- STUDENT INFORMATION -->
        <section class="card">

            <div class="card-title">

                <div>
                    <h2>STUDENT INFORMATION</h2>
                    <p id="certificateStudentInfoNote">
                        Student and term details fill in automatically.
                    </p>
                </div>

            </div>

            <div class="certificate-student-picker" id="certificateStudentPickerBlock">
                <label for="certificateStudentSearch">Find an Enrolled Student</label>
                <input
                    type="search"
                    id="certificateStudentSearch"
                    autocomplete="off"
                    minlength="2"
                    placeholder="Search Student Name or Student ID"
                    oninput="ascbCertificateStudentSearch()"
                    aria-describedby="certificateStudentSearchStatus"
                >
                <p class="certificate-student-search-status" id="certificateStudentSearchStatus" role="status" aria-live="polite">
                    Enter at least 2 characters. Only Enrolled, non-archived enrollment records are shown.
                </p>
                <div class="certificate-student-results" id="certificateStudentSearchResults" aria-label="Matching approved enrollment records"></div>
            </div>

            <div class="form-grid">

                <!-- STUDENT NAME -->
                <div class="form-group">

                    <label for="studentName">
                        Student Name
                    </label>

                    <input
                        type="text"
                        id="studentName"
                        placeholder="Surname, Given Name Middle Name"
                        readonly
                    >

                </div>


                <!-- STUDENT ID -->
                <div class="form-group">

                    <label for="studentId">
                        Student ID
                    </label>

                    <input
                        type="text"
                        id="studentId"
                        placeholder="Student ID Number"
                        readonly
                    >

                </div>


                <!-- PROGRAM -->
                <div class="form-group">

                    <label for="program">
                        Course / Program
                    </label>

                    <select id="program" onchange="ascbCertificateSelectionChanged(true)" disabled>
                        <option value="">Select Program</option>
                        <?php foreach ($ascbProgramOptions as $code => $label): if ($code === '') continue; ?>
                        <option value="<?php echo htmlspecialchars($code, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($label, ENT_QUOTES, 'UTF-8'); ?></option>
                        <?php endforeach; ?>
                    </select>

                </div>


                <!-- YEAR -->
                <div class="form-group">

                    <label for="yearLevel">
                        Year Level
                    </label>

                    <select id="yearLevel" onchange="ascbCertificateSelectionChanged()" disabled>

                        <option value="">
                            Select Year Level
                        </option>

                        <option>
                            1st Year
                        </option>

                        <option>
                            2nd Year
                        </option>

                        <option>
                            3rd Year
                        </option>

                        <option>
                            4th Year
                        </option>

                    </select>

                </div>


                <!-- TRIMESTER -->
                <div class="form-group">

                    <label for="trimester">
                       Trimester
                    </label>

                    <select id="trimester" onchange="ascbCertificateSelectionChanged(false, true)" disabled>
                        <option value="">Select Term</option>
                    </select>

                </div>


                <!-- ACADEMIC YEAR -->
                <div class="form-group">

                    <label for="academicYear">
                        Academic Year
                    </label>

                    <input
                        type="text"
                        id="academicYear"
                        placeholder="2026–2027"
                        readonly
                    >

                </div>


                <!-- DATE OF ENROLLMENT -->
                <div class="form-group">

                    <label for="enrollmentDate">
                        Date of Enrollment
                    </label>

                    <input
                        type="date"
                        id="enrollmentDate"
                        readonly
                    >

                </div>


                <!-- STATUS -->
                <div class="form-group">

                    <label for="status">
                        Enrollment Status
                    </label>

                    <select id="status" disabled>

                        <option>
                            OFFICIALLY ENROLLED
                        </option>

                        <option>
                            FOR VALIDATION
                        </option>

                    </select>

                </div>


                <!-- OR NUMBER -->
                <div class="form-group">

                    <label for="orNumber">
                        O.R. Number
                    </label>

                    <input
                        type="text"
                        id="orNumber"
                        placeholder="Official Receipt No."
                    >

                </div>


                <!-- PREPARED BY (hidden — auto-credited to the
                     logged-in user; see ascbInitPreparedBy()) -->
                <input type="hidden" id="preparedBy" value="<?php echo htmlspecialchars(ascb_get($ascbUser, 'preparedBy', '')); ?>">

            </div>

        </section>


        <!-- =================================================
             SUBJECTS
        ================================================== -->
        <section class="card">

            <div class="subjects-header">

                <div class="subjects-header-text">

                    <h2>
                        SUBJECTS
                    </h2>

                    <p id="certificateSubjectsNote">
                        Subjects, units, and recorded grades are loaded from the selected enrollment.
                    </p>

                </div>

                <div class="subjects-header-actions">

                    <button
                        type="button"
                        class="btn btn-add"
                        id="addCertificateSubjectButton"
                        disabled
                        onclick="addSubjectRow()"
                    >
                        <span class="btn-icon">+</span> Add Subject
                    </button>

                </div>

            </div>


            <div class="table-wrapper">

                <table class="subject-input-table">

                        <thead>
                            <tr>

                                <th width="25%">
                                    Course Code
                                </th>

                                <th width="40%">
                                    Course Description
                                </th>

                                <th width="13%">
                                    Grade
                                </th>

                                <th width="10%">
                                    Units
                                </th>

                                <th width="7%">
                                    Action
                                </th>

                            </tr>
                        </thead>


                        <tbody id="subjectRows">
                            <!-- JavaScript generated rows -->
                        </tbody>


                        <tfoot>
                            <tr>

                                <td
                                    colspan="3"
                                    class="total-label"
                                >
                                    TOTAL UNITS
                                </td>

                                <td
                                    id="totalUnitsInput"
                                    class="total-value"
                                >
                                    0
                                </td>

                                <td></td>

                            </tr>

                            <tr id="gwaInputRow">

                                <td
                                    colspan="3"
                                    class="total-label"
                                >
                                    GENERAL WEIGHTED AVERAGE (GWA)
                                </td>

                                <td
                                    id="gwaValueInput"
                                    class="total-value"
                                >
                                    0.00
                                </td>

                                <td></td>

                            </tr>
                        </tfoot>

                    </table>

            </div>

        </section>
        </section>


        <!-- =================================================
             FORM 137 VIEW
             Functions the same way as Certificates: a normal
             in-page view reached from the sidebar, with a
             collapsible actions panel and stacked form cards.
             Generating opens a print-ready preview modal.
        ================================================== -->
        <section class="app-view" id="form137View">

            <!-- =============================================
                 ACTIONS PANEL (collapsible)
            ============================================== -->
            <div class="actions-panel" id="f137ActionsPanel">

                <button type="button" class="actions-panel-toggle" onclick="ascbToggleF137ActionsPanel()">
                    <span class="actions-panel-toggle-label">
                        <span class="app-nav-icon">⚙</span>
                        Actions
                    </span>
                    <span class="actions-panel-chevron" id="f137ActionsPanelChevron">▾</span>
                </button>

                <div class="actions-panel-body" id="f137ActionsPanelBody">

                    <div class="f137-view-intro">
                        <h2>Request Form 137-A</h2>
                        <p>Prepare a transfer-of-credentials request letter for a receiving school.</p>
                    </div>

                    <div class="f137-action-buttons" role="group" aria-label="Form 137 actions">
                        <button
                            type="button"
                            class="f137-action-btn f137-action-btn--submit"
                            onclick="generateForm137()"
                        >
                            <span class="f137-action-btn-icon" aria-hidden="true">✓</span>
                            <span>SUBMIT DATA</span>
                        </button>

                        <button
                            type="button"
                            class="f137-action-btn f137-action-btn--clear"
                            onclick="clearForm137()"
                        >
                            <span class="f137-action-btn-icon" aria-hidden="true">↺</span>
                            <span>CLEAR DATA</span>
                        </button>
                    </div>

                </div>

            </div>

            <!-- STUDENT INFORMATION -->
            <section class="f137-card">
                <div class="f137-section-title">
                    <span class="f137-icon">👤</span>
                    <div>
                        <h3>Student Information</h3>
                        <p>Add one or more students for this request.</p>
                    </div>
                </div>

                <div class="f137-form-grid">
                    <div class="f137-field f137-span-2">
                        <label for="f137_studentName">Student Name</label>
                        <input id="f137_studentName" type="text" placeholder="Last Name, First Name, Middle Name">
                    </div>

                    <div class="f137-field">
                        <label for="f137_courseSelect">Admitted To / Course</label>
                        <div class="f137-inline">
                            <select id="f137_courseSelect"></select>
                            <button type="button" class="f137-plus" onclick="openF137CourseDialog()">+</button>
                        </div>
                    </div>

                    <div class="f137-field">
                        <label for="f137_schoolYear">Last School Year Attended</label>
                        <input id="f137_schoolYear" type="text" placeholder="e.g. 2023-2024">
                    </div>

                    <div class="f137-field">
                        <label for="f137_yearSection">Year &amp; Section</label>
                        <input id="f137_yearSection" type="text" placeholder="e.g. XII-HUMSS B">
                    </div>
                </div>

                <button type="button" class="f137-add-student" onclick="addF137Student()">
                    + Add Student to This Request
                </button>

                <div class="f137-students-list" id="f137_studentsList"></div>
            </section>

            <!-- RECEIVING SCHOOL -->
            <section class="f137-card">
                <div class="f137-section-title">
                    <span class="f137-icon">🏫</span>
                    <div>
                        <h3>Receiving School</h3>
                        <p>One recipient per request letter.</p>
                    </div>
                </div>

                <div class="f137-field">
                    <label for="f137_schoolSelect">Previous / Last School Attended</label>
                    <div class="f137-inline">
                        <select id="f137_schoolSelect"></select>
                        <button type="button" class="f137-plus" onclick="openF137SchoolDialog()">+</button>
                    </div>
                    <small>Double-click a saved school to remove it.</small>
                </div>

                <div class="f137-field">
                    <label for="f137_schoolAddress">School Address</label>
                    <input id="f137_schoolAddress" type="text" placeholder="School address">
                </div>
            </section>

            <!-- REQUEST DETAILS -->
            <section class="f137-card">
                <div class="f137-section-title">
                    <span class="f137-icon">✍</span>
                    <div>
                        <h3>Request Details</h3>
                        <p>Select the applicable request options.</p>
                    </div>
                </div>

                <div class="f137-check-grid">
                    <label><input type="checkbox" id="f137_firstRequest"> <span>1st Request</span></label>
                    <label><input type="checkbox" id="f137_secondRequest"> <span>2nd Request</span></label>
                    <label><input type="checkbox" id="f137_urgentRequest"> <span>Urgent</span></label>
                    <label><input type="checkbox" id="f137_bearerRequest"> <span>Entrust to Bearer</span></label>
                    <label class="f137-span-2"><input type="checkbox" id="f137_copyForASCB"> <span>Indicate: Copy for <strong>Andres Soriano Colleges of Bislig, Inc.</strong></span></label>
                </div>

                <div class="f137-field">
                    <label for="f137_requestDate">Date</label>
                    <input id="f137_requestDate" type="date">
                </div>
            </section>

        </section>


        <!-- =================================================
             RECORDS VIEW
             Nagpapakita ng mga naka-log na Certificates at
             Form 137-A requests mula sa database (api/records.php).
        ================================================== -->
        <section class="app-view" id="recordsView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🗂</span>
                    <div>
                        <h3>Records</h3>
                        <p>History of Certificates & Form 137-A Requests</p>
                    </div>
                </div>

                <div class="records-toolbar">

                    <div class="records-tabs">
                        <button type="button" class="records-tab active" id="recordsTabCertificates" onclick="ascbRecordsSwitchTab('certificates')">
                            📃 Certificates
                        </button>
                        <button type="button" class="records-tab" id="recordsTabForm137" onclick="ascbRecordsSwitchTab('form137')">
                            📄 Form 137-A
                        </button>
                    </div>

                    <div class="records-search">
                        <input type="search" id="recordsSearchInput" name="search_recordsSearchInput" autocomplete="new-password" inputmode="search" placeholder="Search full name, Student ID, OR #, school..." oninput="ascbRecordsFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadRecords()" title="Refresh">⟳ Refresh</button>
                    </div>

                </div>

                <div class="records-status" id="recordsStatus">Loading records…</div>

                <div class="table-wrapper records-table-wrapper" id="recordsTableWrapper" style="display:none;">
                    <table class="records-table" id="recordsTable">
                        <thead id="recordsTableHead"></thead>
                        <tbody id="recordsTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="recordsPagination"></div>
                </div>

            </section>

        </section>


        <!-- =================================================
             STUDENT 360 VIEW
             Isang page na pinagsasama ang Student Information,
             Enrollment History, Grade Evaluation, Certificates,
             at Audit Timeline ng ISANG estudyante (api/student_360.php).
             Read-only — search muna, saka piliin ang estudyante.
        ================================================== -->
        <section class="app-view" id="student360View">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🧑‍🎓</span>
                    <div>
                        <h3>Student Profile</h3>
                        <p>Full Profile of one Student</p>
                    </div>
                </div>

                <div class="records-toolbar">
                    <div class="records-search">
                        <input type="search" id="student360SearchInput" name="search_student360SearchInput" autocomplete="new-password" inputmode="search" placeholder="Search full name or Student ID..." oninput="ascbStudent360Search()">
                    </div>
                </div>

                <div class="records-status" id="student360SearchStatus" style="display:none;"></div>

                <div class="table-wrapper records-table-wrapper" id="student360ResultsWrapper" style="display:none;">
                    <table class="records-table" id="student360ResultsTable">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Student Name</th>
                                <th>Course / Program</th>
                                <th>Major</th>
                                <th>Year / Term</th>
                                <th>Department</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="student360ResultsTableBody"></tbody>
                    </table>
                </div>

            </section>

            <div id="student360ProfileWrapper" style="display:none;">

                <section class="f137-card student360-profile-card">
                    <div class="f137-section-title">
                        <span class="f137-icon">🪪</span>
                        <div>
                            <h3 id="student360ProfileName">—</h3>
                            <p id="student360ProfileSub">—</p>
                        </div>
                        <button type="button" class="btn btn-secondary" style="margin-left:auto;" onclick="ascbStudent360ClosePofile()">✕ Isara</button>
                    </div>
                    <div class="student360-info-grid" id="student360InfoGrid"></div>
                </section>

                <section class="f137-card">
                    <div class="f137-section-title">
                        <span class="f137-icon">🗂</span>
                        <div><h3>Enrollment History</h3></div>
                    </div>
                    <div class="table-wrapper records-table-wrapper">
                        <table class="records-table">
                            <thead>
                                <tr>
                                    <th>School Year</th>
                                    <th>Trimester / Semester</th>
                                    <th>Year Level</th>
                                    <th>Course / Major</th>
                                    <th>Status</th>
                                    <th>Enrolled By</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody id="student360HistoryTableBody"></tbody>
                        </table>
                    </div>
                </section>

                <section class="f137-card">
                    <div class="f137-section-title">
                        <span class="f137-icon">🎓</span>
                        <div><h3>Grade Evaluation</h3></div>
                    </div>
                    <div id="student360GradesContainer"></div>
                </section>

                <section class="f137-card" id="student360CertificatesCard" style="display:none;">
                    <div class="f137-section-title">
                        <span class="f137-icon">📃</span>
                        <div><h3>Certificates</h3><p>COE, COR, at iba pang na-generate na certificate.</p></div>
                    </div>
                    <div class="table-wrapper records-table-wrapper">
                        <table class="records-table">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>OR #</th>
                                    <th>School Year</th>
                                    <th>Term</th>
                                    <th>GWA</th>
                                    <th>Date Issued</th>
                                </tr>
                            </thead>
                            <tbody id="student360CertificatesTableBody"></tbody>
                        </table>
                    </div>
                </section>

                <section class="f137-card" id="student360AuditCard" style="display:none;">
                    <div class="f137-section-title">
                        <span class="f137-icon">🕒</span>
                        <div><h3>Audit Timeline</h3><p>History ng mga pagbabago sa record ng estudyanteng ito.</p></div>
                    </div>
                    <ul class="student360-timeline" id="student360TimelineList"></ul>
                    <div class="student360-timeline-more" id="student360TimelineMore"></div>
                </section>

            </div>

        </section>


<?php if (!empty($ascbPermissions['manageMasterRecord'])): ?>
        <!-- =================================================
             MASTER RECORD VIEW  (api/master_record.php)
             The permanent, current profile of each student. The
             Student ID never changes; old enrollment, grade and
             certificate records are never modified from here.
        ================================================== -->
        <section class="app-view" id="masterrecordView">

            <section class="f137-card">
                <div class="f137-section-title">
                    <span class="f137-icon">🗃</span>
                    <div>
                        <h3>Master Record</h3>
                        <p>The permanent profile of each student. The Student ID never changes.</p>
                    </div>
                    <button type="button" class="btn btn-outline mr-sync-btn" id="mrSyncBtn" onclick="ascbMasterSync()" title="Add students from Enrollment that have no Master Record yet">Sync from Enrollment</button>
                </div>

                <div class="records-toolbar">
                    <div class="records-search">
                        <input type="search" id="mrSearchInput" name="search_mrSearchInput" autocomplete="off" inputmode="search" placeholder="Search Student Name ..." oninput="ascbMasterSearch()">
                    </div>
                </div>

                <div class="records-status" id="mrSearchStatus" style="display:none;"></div>

                <div class="table-wrapper records-table-wrapper" id="mrResultsWrapper" style="display:none;">
                    <table class="records-table">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Student Name</th>
                                <th>Course / Program</th>
                                <th>Year / Term</th>
                                <th>Civil status</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="mrResultsBody"></tbody>
                    </table>
                </div>
            </section>

            <div id="mrProfileWrapper" style="display:none;">

                <section class="f137-card mr-profile-card">
                    <div class="mr-profile-head">
                        <div class="mr-photo" id="mrPhoto" aria-hidden="true"></div>
                        <div class="mr-profile-main">
                            <h3 id="mrProfileName">—</h3>
                            <p id="mrProfileId">—</p>
                            <div class="mr-chip-row" id="mrProfileChips"></div>
                        </div>
                        <div class="mr-profile-actions">
                            <button type="button" class="btn btn-primary" onclick="ascbMasterOpenMarriage()">Update after marriage</button>
                            <button type="button" class="btn btn-outline" onclick="document.getElementById('mrPhotoInput').click()">Change photo</button>
                            <button type="button" class="btn btn-outline" id="mrPhotoRemoveBtn" onclick="ascbMasterRemovePhoto()">Remove photo</button>
                            <button type="button" class="btn btn-secondary" onclick="ascbMasterCloseProfile()">Close</button>
                            <input type="file" id="mrPhotoInput" accept="image/jpeg,image/png,image/webp" style="display:none;" onchange="ascbMasterUploadPhoto(this)">
                        </div>
                    </div>
                    <div class="student360-info-grid" id="mrCardGrid"></div>
                </section>

                <section class="f137-card">
                    <div class="records-tabs mr-tabs" id="mrTabs" role="tablist">
                        <button type="button" class="records-tab active" data-tab="personal" role="tab" onclick="ascbMasterSwitchTab('personal')">Personal information</button>
                        <button type="button" class="records-tab" data-tab="enrollments" role="tab" onclick="ascbMasterSwitchTab('enrollments')">Enrollment history</button>
                        <button type="button" class="records-tab" data-tab="grades" role="tab" onclick="ascbMasterSwitchTab('grades')">Grade history</button>
                        <button type="button" class="records-tab" data-tab="certificates" role="tab" onclick="ascbMasterSwitchTab('certificates')">Certificates</button>
                        <button type="button" class="records-tab" data-tab="names" role="tab" onclick="ascbMasterSwitchTab('names')">Name history</button>
                    </div>

                    <!-- TAB 1: PERSONAL INFORMATION -->
                    <div class="mr-tab-panel" id="mrPanel-personal">
                        <div class="student360-info-grid" id="mrReadonlyGrid"></div>
                        <form id="mrForm" class="mr-form" autocomplete="off" onsubmit="event.preventDefault(); ascbMasterSave();"></form>
                        <div class="mr-form-actions">
                            <button type="button" class="btn btn-primary" id="mrSaveBtn" onclick="ascbMasterSave()">Save changes</button>
                            <button type="button" class="btn btn-secondary" id="mrDiscardBtn" onclick="ascbMasterDiscard()">Discard changes</button>
                            <span class="mr-dirty-note" id="mrDirtyNote" style="display:none;">You have unsaved changes.</span>
                        </div>
                    </div>

                    <!-- TAB 2: ENROLLMENT HISTORY -->
                    <div class="mr-tab-panel" id="mrPanel-enrollments" style="display:none;">
                        <div class="table-wrapper records-table-wrapper">
                            <table class="records-table">
                                <thead>
                                    <tr>
                                        <th>School year</th>
                                        <th>Trimester</th>
                                        <th>Year level</th>
                                        <th>Program</th>
                                        <th>Type</th>
                                        <th>Department</th>
                                        <th>Status</th>
                                        <th>Recorded</th>
                                    </tr>
                                </thead>
                                <tbody id="mrEnrollmentsBody"></tbody>
                            </table>
                        </div>
                    </div>

                    <!-- TAB 3: GRADE HISTORY -->
                    <div class="mr-tab-panel" id="mrPanel-grades" style="display:none;">
                        <div id="mrGradesContainer"></div>
                    </div>

                    <!-- TAB 4: CERTIFICATES -->
                    <div class="mr-tab-panel" id="mrPanel-certificates" style="display:none;">
                        <p class="mr-note">Certificates keep the name they were issued under. New certificates use the current Master Record.</p>
                        <div class="table-wrapper records-table-wrapper">
                            <table class="records-table">
                                <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th>Issued under name</th>
                                        <th>OR #</th>
                                        <th>School year</th>
                                        <th>Term</th>
                                        <th>GWA</th>
                                        <th>Date issued</th>
                                    </tr>
                                </thead>
                                <tbody id="mrCertificatesBody"></tbody>
                            </table>
                        </div>
                    </div>

                    <!-- TAB 5: NAME HISTORY -->
                    <div class="mr-tab-panel" id="mrPanel-names" style="display:none;">
                        <div id="mrNamesContainer"></div>
                    </div>
                </section>

            </div>

        </section>
<?php endif; ?>


        <!-- =================================================
             ENROLLMENT VIEW
             Basic student info bawat entry (api/enrollment.php).
             Add / Edit / Delete.
        ================================================== -->
        <section class="app-view" id="enrollmentView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">📝</span>
                    <div>
                        <h3>Enroll a Student</h3>
                        <p>Basic Information of Student</p>
                    </div>
                </div>

                <div class="f137-form-sections">

                    <div class="f137-form-section">
                        <div class="f137-form-section-title"><span class="f137-form-section-num">1</span> PERSONAL INFORMATION</div>
                        <div class="f137-form-grid">

                            <div class="f137-field">
                                <label for="enroll_surname">Surname</label>
                                <input id="enroll_surname" type="text" placeholder="e.g. Dela Cruz">
                            </div>

                            <div class="f137-field">
                                <label for="enroll_firstName">Given Name</label>
                                <input id="enroll_firstName" type="text" placeholder="e.g. Juan">
                            </div>

                            <div class="f137-field">
                                <label for="enroll_middleName">Middle Name</label>
                                <input id="enroll_middleName" type="text" placeholder="e.g. Santos">
                            </div>

                            <div class="f137-field">
                                <label for="enroll_suffix">Suffix</label>
                                <select id="enroll_suffix" onchange="ascbEnrollSuffixChanged('enroll')">
                                    <option value="">None</option>
                                    <option value="Jr.">Jr.</option>
                                    <option value="Sr.">Sr.</option>
                                    <option value="II">II</option>
                                    <option value="III">III</option>
                                    <option value="IV">IV</option>
                                    <option value="V">V</option>
                                </select>
                            </div>

                            <div class="f137-field ascb-suffix-psa" id="enroll_suffixPsa" style="grid-column: 1 / -1; display:none;">
                                <label class="ascb-suffix-check">
                                    <input type="checkbox" id="enroll_suffixFirst" onchange="ascbEnrollSuffixToggle('enroll','first_name')">
                                    Suffix on Firstname (Base on PSA)
                                </label>
                                <label class="ascb-suffix-check">
                                    <input type="checkbox" id="enroll_suffixSurname" onchange="ascbEnrollSuffixToggle('enroll','surname')">
                                    Suffix on Lastname (Base on PSA)
                                </label>
                                <small id="enroll_suffixPreview" class="ascb-suffix-preview"></small>
                            </div>

                            <div class="f137-field">
                                <label for="enroll_sex">Sex</label>
                                <select id="enroll_sex">
                                    <option value="">Select Sex</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>

                            <div class="f137-field">
                                <label for="enroll_civilStatus">Civil Status</label>
                                <select id="enroll_civilStatus">
                                    <option value="">Select Civil Status</option>
                                    <option value="Single">Single</option>
                                    <option value="Married">Married</option>
                                    <option value="Widowed">Widowed</option>
                                    <option value="Separated">Separated</option>
                                </select>
                            </div>

                            <div class="f137-field">
                                <label for="enroll_studentType">Student Type</label>
                                <select id="enroll_studentType">
                                    <option value="">Select Student Type</option>
                                    <option value="Regular">Regular</option>
                                    <option value="Transferee">Transferee</option>
                                    <option value="Irregular">Irregular</option>
                                </select>
                            </div>

                            <div class="f137-field">
                                <label for="enroll_birthMonth">Birth Date</label>
                                <div class="f137-inline">
                                    <select id="enroll_birthMonth"><option value="">Month</option></select>
                                    <select id="enroll_birthDay"><option value="">Day</option></select>
                                    <select id="enroll_birthYear"><option value="">Year</option></select>
                                </div>
                            </div>

                            <div class="f137-field f137-span-2">
                                <label for="enroll_birthPlace">Birth Place</label>
                                <input id="enroll_birthPlace" type="text" maxlength="255" placeholder="e.g. Bislig City, Surigao del Sur">
                            </div>

                        </div>
                    </div>

                    <div class="f137-form-section">
                        <div class="f137-form-section-title"><span class="f137-form-section-num">2</span> CONTACT &amp; EDUCATIONAL BACKGROUND</div>
                        <div class="f137-form-grid">

                            <div class="f137-field f137-span-2">
                                <label for="enroll_address">Address</label>
                                <input id="enroll_address" type="text" placeholder="e.g. Andres Soriano Avenue, Mangagoy, Bislig City, Surigao del Sur, 8311, Philippines">
                            </div>

                            <div class="f137-field">
                                <label for="enroll_mobileNumber">Mobile Number</label>
                                <input id="enroll_mobileNumber" type="text" placeholder="e.g. 09171234567" maxlength="20">
                            </div>

                            <div class="f137-field">
                                <label for="enroll_guardianName">Guardian Name</label>
                                <input id="enroll_guardianName" type="text" placeholder="e.g. Juana Dela Cruz" maxlength="150">
                            </div>

                            <div class="f137-field">
                                <label for="enroll_email">Email Address</label>
                                <input id="enroll_email" type="email" placeholder="e.g. juan@gmail.com (optional)" maxlength="254">
                                <small>Optional.</small>
                            </div>

                            <div class="f137-field f137-span-2">
                                <label for="enroll_prevSchoolJuniorHs">Junior High School</label>
                                <input id="enroll_prevSchoolJuniorHs" type="text" placeholder="e.g. Andres Soriano Colleges of Bislig, Inc.">
                            </div>

                            <div class="f137-field f137-span-2">
                                <label for="enroll_prevSchoolSeniorHs">Senior High School</label>
                                <input id="enroll_prevSchoolSeniorHs" type="text" placeholder="e.g. Andres Soriano Colleges of Bislig, Inc.">
                            </div>

                            <div class="f137-field">
                                <label for="enroll_juniorHsGraduated">Junior High School Graduated</label>
                                <input id="enroll_juniorHsGraduated" type="text" inputmode="numeric" maxlength="9" pattern="\d{4}-\d{4}" placeholder="YYYY-YYYY" title="Use YYYY-YYYY, e.g. 2020-2021">
                            </div>

                            <div class="f137-field">
                                <label for="enroll_seniorHsGraduated">Senior High School Graduated</label>
                                <input id="enroll_seniorHsGraduated" type="text" inputmode="numeric" maxlength="9" pattern="\d{4}-\d{4}" placeholder="YYYY-YYYY" title="Use YYYY-YYYY, e.g. 2022-2023">
                            </div>

                        </div>
                    </div>

                    <div class="f137-form-section">
                        <div class="f137-form-section-title"><span class="f137-form-section-num">3</span> PROGRAM &amp; ENROLLMENT DETAILS</div>
                        <div class="f137-form-grid">

                            <div class="f137-field f137-span-2">
                                <label for="enroll_program">Course / Program</label>
                                <select id="enroll_program" onchange="ascbEnrollProgramChanged()">
                                    <?php foreach ($ascbProgramOptions as $code => $label): ?>
                                    <option value="<?php echo htmlspecialchars($code); ?>"><?php echo htmlspecialchars($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="f137-field">
                                <label for="enroll_major">Major</label>
                                <input id="enroll_major" type="text" placeholder="Automatic Fill the Major" readonly>
                                <small>Auto-fills Major.</small>
                            </div>

                            <div class="f137-field">
                                <label for="enroll_yearLevel">Year Level</label>
                                <select id="enroll_yearLevel">
                                    <option value="">Select Year Level</option>
                                    <option>1st Year</option>
                                    <option>2nd Year</option>
                                    <option>3rd Year</option>
                                    <option>4th Year</option>
                                </select>
                            </div>

                            <div class="f137-field">
                                <label for="enroll_trimester">Trimester</label>
                                <select id="enroll_trimester">
                                    <option value="">Select Trimester</option>
                                    <option>1st Trimester</option>
                                    <option>2nd Trimester</option>
                                    <option>3rd Trimester</option>
                    </select>
                            </div>

                            <div class="f137-field">
                                <label for="enroll_schoolYear">School Year</label>
                                <input 
                                    id="enroll_schoolYear" 
                                    type="text" 
                                    placeholder="e.g. 2026-2027"
                                    maxlength="9"
                                    inputmode="numeric"
                                    pattern="[0-9]{4}-[0-9]{4}"
                                    oninput="
                                        this.value = this.value
                                            .replace(/[^0-9]/g, '')
                                            .replace(/^(\d{4})(\d)/, '$1-$2');
                                    "
                                >
                                <small>Format: YYYY-YYYY</small>
                            </div>

                        </div>
                    </div>

                </div>


                <div class="subjects-header">

                    <div class="subjects-header-text">
                        <h3>Subjects</h3>
                        <p style="margin:0;">Load subjects from the prospectus, or add Manually. <strong>Grades are entered in Grade Management.</strong></p>
                    </div>

                    <div class="subjects-header-actions">
                        <button type="button" class="btn btn-outline" onclick="ascbEnrollAddSubjectsForTerm('enroll_subjectRows', 'enroll_program', 'enroll_yearLevel', 'enroll_trimester')">
                            <span class="btn-icon">⬇</span> Load Subjects
                        </button>
                        <button type="button" class="btn btn-add" onclick="ascbEnrollAddSubjectRow('enroll_subjectRows')">
                            <span class="btn-icon">+</span> Add Subject
                        </button>
                    </div>

                </div>

                <div class="table-wrapper">
                    <table class="subject-input-table">
                        <thead>
                            <tr>
                                <th width="22%">Course Code</th>
                                <th width="38%">Course Description</th>
                                <th width="15%">Units</th>
                                <th width="25%">Action</th>
                            </tr>
                        </thead>
                        <tbody id="enroll_subjectRows"></tbody>
                        <tfoot>
                            <tr>
                                <td colspan="2" class="total-label">Total Units</td>
                                <td id="enroll_totalUnitsInput" class="total-value"></td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbEnrollSubmit()" style="margin-top:16px;">
                    <span class="app-nav-icon">✔</span>
                    Add New Student
                </button>

                <div class="records-status" id="enrollFormStatus" style="display:none;"></div>

            </section>

        </section>


        <!-- =================================================
             NEW TERM VIEW
             Listahan ng mga naka-enroll na estudyante (dating
             nasa loob ng ENROLLMENT VIEW). Ginawa itong bukod
             na tab/view para hiwalay sa "Enroll a Student" form.
             Parehong data at functions pa rin ang ginagamit
             (api/enrollment.php, ascbLoadEnrollment(), atbp.) —
             inilipat lang ang section papunta rito.
        ================================================== -->
        <section class="app-view" id="newtermView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🗂</span>
                    <div>
                        <h3>Enrollees</h3>
                        <p>Student Records</p>
                    </div>
                </div>

                <div class="records-toolbar">

                    <div class="records-search">
                        <input type="search" id="enrollSearchInput" name="search_enrollSearchInput" autocomplete="new-password" inputmode="search" placeholder="Search full name or Student ID..." oninput="ascbEnrollFilter()">
                        <select id="enrollStatusFilterInput" onchange="ascbEnrollFilter()" title="I-filter ayon sa Approval Status">
                            <option value="">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="approved">Enrolled</option>
                        </select>
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadEnrollment()" title="Refresh">⟳ Refresh</button>
                    </div>

                </div>

                <div class="records-status" id="enrollStatus">Loading records…</div>

                <div class="table-wrapper records-table-wrapper" id="enrollTableWrapper" style="display:none;">
                    <table class="records-table" id="enrollTable">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Student Name</th>
                                <th>Course / Program</th>
                                <th>Major</th>
                                <th>Year &amp; Trimester / Semester</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="enrollTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="enrollPagination"></div>
                </div>

            </section>

        </section>


        <!-- =================================================
             REJECTED STUDENTS VIEW
             Listahan ng mga enrollee na "rejected" ang status
             (hindi pa naka-archive). Hindi na lumalabas ang mga
             ito sa Enrollment / New Term list o sa Grade
             Evaluation habang nandito pa sila. "Delete" dito ay
             nag-a-archive lang (tingnan ang Archive menu sa
             ibaba), hindi tuluyang binubura sa database.
        ================================================== -->
        <section class="app-view" id="rejectedView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🚫</span>
                    <div>
                        <h3>Rejected Students</h3>
                        <p>Lacking Requirements</p>
                    </div>
                </div>

                <div class="records-toolbar">

                    <div class="records-search">
                        <input type="search" id="rejectedSearchInput" name="search_rejectedSearchInput" autocomplete="new-password" inputmode="search" placeholder="Search full name, course, student ID..." oninput="ascbRejectedFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadRejectedStudents()" title="Refresh">⟳ Refresh</button>
                    </div>

                </div>

                <div class="records-status" id="rejectedStatus">Loading records…</div>

                <div class="table-wrapper records-table-wrapper" id="rejectedTableWrapper" style="display:none;">
                    <table class="records-table" id="rejectedTable">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Course</th>
                                <th>Major</th>
                                <th>School Year</th>
                                <th>Reason / Rejected By</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="rejectedTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="rejectedPagination"></div>
                </div>

            </section>

        </section>


        <!-- =================================================
             ARCHIVE VIEW
             Listahan ng mga enrollee na na-archive na (dating
             "Delete" mula sa Enrollment / New Term / Rejected
             Students) — hal. mga estudyanteng nag-drop. Hindi
             sila tuluyang nabubura sa database dito, "Restore"
             lang ang ibinabalik sa normal na listahan. "Delete
             Permanently" lang dito ang tunay na tumatanggal sa
             database.
        ================================================== -->
        <section class="app-view" id="archiveView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🗄</span>
                    <div>
                        <h3>Archive</h3>
                        <p>All Student Droped.</p>
                    </div>
                </div>

                <div class="records-toolbar">

                    <div class="records-search">
                        <input type="search" id="archiveSearchInput" name="search_archiveSearchInput" autocomplete="new-password" inputmode="search" placeholder="Search full name, course, student ID..." oninput="ascbArchiveFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadArchive()" title="Refresh">⟳ Refresh</button>
                    </div>

                </div>

                <div class="records-status" id="archiveStatus">Loading records…</div>

                <div class="table-wrapper records-table-wrapper" id="archiveTableWrapper" style="display:none;">
                    <table class="records-table" id="archiveTable">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Course</th>
                                <th>Major</th>
                                <th>Archived On</th>
                                <th>Archived By / Reason</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="archiveTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="archivePagination"></div>
                </div>

            </section>

        </section>


        <!-- =================================================
             GRADE MANAGEMENT VIEW
        ================================================== -->
        <section class="app-view" id="grademanagementView">
            <section class="f137-card">
                <div class="f137-section-title">
                    <span class="f137-icon">✏️</span>
                    <div>
                        <h3>Grade Management</h3>
                        <p id="gradeMgmtScopeNote">Add &amp; Update Grades of Student.</p>
                    </div>
                </div>
                <div class="records-toolbar">
                    <div class="records-search">
                        <input type="search" id="gradeMgmtSearchInput" name="search_gradeMgmtSearchInput" autocomplete="new-password" inputmode="search" placeholder="Search full name or Student ID..." oninput="ascbGradeManagementFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadGradeManagement()">⟳ Refresh</button>
                        <button type="button" class="btn btn-outline" id="gradeCorrectionReviewBtn" style="display:none" onclick="ascbRecordCorrectionReviewOpen()">🛡 Correction Requests <span id="gradeCorrectionReviewBtnBadge" class="nav-notif-badge" style="display:none;">0</span></button>
                        <button type="button" class="btn btn-outline" id="gradebookApprovalWorkflowBtn" style="display:none" onclick="ascbGradebookApprovalsOpen()">✓ Grade Approval Workflow <span id="gradebookApprovalWorkflowBadge" class="nav-notif-badge" style="display:none;">0</span></button>
                        <button type="button" class="btn btn-outline" id="gradeImportBtn" style="display:none" onclick="ascbGradeImportOpen()">📥 Import from Excel</button>
                        <button type="button" class="btn btn-outline" id="gradebookBtn" style="display:none" onclick="ascbGradebookOpen()">📘 Subject Gradebook</button>
                    </div>
                </div>
                <div class="records-status" id="gradeMgmtStatus">Loading students…</div>
                <div class="table-wrapper records-table-wrapper" id="gradeMgmtWrapper" style="display:none;">
                    <table class="records-table">
                        <thead><tr><th>Student ID</th><th>Student Name</th><th>Course / Program</th><th>Current Term</th><th>Terms Count</th><th>Action</th></tr></thead>
                        <tbody id="gradeMgmtBody"></tbody>
                    </table>
                </div>
                <div class="pagination-bar" id="gradeMgmtPagination"></div>
            </section>
        </section>

        <!-- =================================================
             GRADE EVALUATION VIEW
             Read-only report na pinagsasama-sama ang LAHAT ng
             subjects/grades ng isang estudyante mula sa lahat
             ng kanyang naka-log na Enrollment records (lahat ng
             School Year / Year Level / Trimester), gamit ang
             data mula sa api/grades.php. Read-only report ito;
             ang grade entry at updates ay ginagawa sa Grade Management.
        ================================================== -->
        <section class="app-view" id="gradeevaluationView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🎓</span>
                    <div>
                        <h3>Grade Evaluation</h3>
                        <p>Student Grade Records</p>
                    </div>
                </div>

                <div class="records-toolbar">
                    <div class="records-search">
                        <input type="search" id="gradeEvalSearchInput" name="search_gradeEvalSearchInput" autocomplete="new-password" inputmode="search" placeholder="Search full name or Student ID..." oninput="ascbGradeEvalFilterStudents()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadGradeEvaluation()" title="Refresh">⟳ Refresh</button>
                    </div>
                </div>

                <div class="records-status" id="gradeEvalListStatus">Loading students…</div>

                <div class="table-wrapper records-table-wrapper" id="gradeEvalListWrapper" style="display:none;">
                    <table class="records-table" id="gradeEvalStudentTable">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Student Name</th>
                                <th>Course / Program</th>
                                <th>Major</th>
                                <th>Terms Count</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="gradeEvalStudentTableBody"></tbody>
                    </table>
                </div>

                <div class="pagination-bar" id="gradeEvalPagination"></div>

            </section>

        </section>


        <?php if (!empty($ascbPermissions['viewHonors'])): ?>
        <section class="app-view" id="honorsView">
            <section class="f137-card honors-card">

                <header class="honors-head">
                    <div class="honors-head-copy">
                        <span class="honors-eyebrow">Academic Honors</span>
                        <h3>President's &amp; Dean's Lister</h3>
                        <p>Qualified students per academic period. Lower GWA is better (1.00 is the highest).</p>
                    </div>
                    <button type="button" class="btn btn-primary honors-export" onclick="ascbHonorsExport()" title="Exports both lists for the selected period and school year">⇩ Export CSV</button>
                </header>

                <div class="honors-tabs" role="tablist" aria-label="Honor list">
                    <button type="button" id="honorsTabPresident" class="honors-tab is-president active" role="tab" aria-selected="true" onclick="ascbHonorsSwitchTab('PRESIDENT')">
                        <span class="honors-tab-icon" aria-hidden="true">🏅</span>
                        <span class="honors-tab-copy"><strong>President's Lister</strong><small id="honorsBestPresident">—</small></span>
                        <span class="honors-tab-count"><b id="honorsCountPresident">0</b><small>entries</small></span>
                    </button>
                    <button type="button" id="honorsTabDean" class="honors-tab is-dean" role="tab" aria-selected="false" onclick="ascbHonorsSwitchTab('DEAN')">
                        <span class="honors-tab-icon" aria-hidden="true">🎓</span>
                        <span class="honors-tab-copy"><strong>Dean's Lister</strong><small id="honorsBestDean">—</small></span>
                        <span class="honors-tab-count"><b id="honorsCountDean">0</b><small>entries</small></span>
                    </button>
                </div>

                <div class="honors-filters">
                    <div class="honors-field">
                        <label for="honorsTrimesterFilter">Academic Period</label>
                        <select id="honorsTrimesterFilter" onchange="ascbLoadHonors()">
                            <option value="">ALL — All Terms</option>
                            <option value="1st Trimester">1st Trimester</option>
                            <option value="2nd Trimester">2nd Trimester</option>
                            <option value="3rd Trimester">3rd Trimester</option>
                            <option value="1st Semester">1st Semester</option>
                            <option value="2nd Semester">2nd Semester</option>
                            <option value="Summer">Summer</option>
                        </select>
                    </div>
                    <div class="honors-field">
                        <label for="honorsSchoolYearFilter">School Year <em>(optional)</em></label>
                        <input type="text" id="honorsSchoolYearFilter" placeholder="e.g. 2025-2026" inputmode="numeric" autocomplete="off" oninput="ascbHonorsQueueLoad()" onkeydown="if(event.key==='Enter'){event.preventDefault();ascbLoadHonors();}">
                        <small class="honors-hint" id="honorsSchoolYearHint" hidden>Use the format 2025-2026.</small>
                    </div>
                    <div class="honors-field honors-field-search">
                        <label for="honorsSearchInput">Search</label>
                        <input type="search" id="honorsSearchInput" placeholder="Student name, ID, course, department…" autocomplete="off" oninput="ascbHonorsFilter()">
                    </div>
                    <div class="honors-actions">
                        <button type="button" class="btn btn-secondary" onclick="ascbHonorsReset()" title="Clear all filters">Reset</button>
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadHonors()" title="Reload from the server" aria-label="Refresh">⟳</button>
                    </div>
                </div>

                <div class="honors-meta" id="honorsMeta" aria-live="polite"></div>
                <div class="records-status honors-status" id="honorsStatus" aria-live="polite">Loading…</div>

                <div class="table-wrapper records-table-wrapper honors-table-wrap" id="honorsTableWrapper" style="display:none;">
                    <table class="records-table honors-table" id="honorsTable">
                        <thead>
                            <tr>
                                <th data-sort="student_name" aria-sort="none"><button type="button" class="honors-sort" onclick="ascbHonorsSortBy('student_name')">Student <i aria-hidden="true"></i></button></th>
                                <th data-sort="course" aria-sort="none"><button type="button" class="honors-sort" onclick="ascbHonorsSortBy('course')">Course / Major <i aria-hidden="true"></i></button></th>
                                <th data-sort="department_name" aria-sort="none"><button type="button" class="honors-sort" onclick="ascbHonorsSortBy('department_name')">Department <i aria-hidden="true"></i></button></th>
                                <th data-sort="year_level" aria-sort="none"><button type="button" class="honors-sort" onclick="ascbHonorsSortBy('year_level')">Year Level <i aria-hidden="true"></i></button></th>
                                <th data-sort="school_year" aria-sort="none"><button type="button" class="honors-sort" onclick="ascbHonorsSortBy('school_year')">Period <i aria-hidden="true"></i></button></th>
                                <th data-sort="gwa" aria-sort="none" class="honors-col-gwa"><button type="button" class="honors-sort" onclick="ascbHonorsSortBy('gwa')">GWA <i aria-hidden="true"></i></button></th>
                            </tr>
                        </thead>
                        <tbody id="honorsTableBody"></tbody>
                    </table>
                </div>
                <div class="pagination-bar" id="honorsPagination"></div>
            </section>
        </section>
        <?php endif; ?>

        <section class="app-view" id="approvedsoView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">✅</span>
                    <div>
                        <h3>Upload Approved Special Order</h3>
                        <p>Upload Name & PDF file.</p>
                    </div>
                </div>

                <div class="f137-form-grid">

                    <div class="f137-field f137-span-2">
                        <label for="so_file">Attach Approved SO PDF file(s)</label>
                        <input id="so_file" type="file" accept="application/pdf,.pdf" multiple onchange="ascbSoPreparePreview()">
                        <small class="field-help">Choose Approved S.O PDF Files.</small>
                    </div>

                </div>

                <div id="soBatchPreview" class="so-batch-preview" style="display:none;"></div>

                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbSoSubmit()">
                    <span class="app-nav-icon">✔</span>
                    UPLOAD ALL PDFS
                </button>

                <div class="records-status" id="soFormStatus" style="display:none;"></div>

            </section>

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🗂</span>
                    <div>
                        <h3>Approved Special Order</h3>
                        <p>Only Approved S.O. 2023-Present</p>
                    </div>
                </div>

                <div class="records-toolbar">

                    <div class="records-search">
                        <input type="search" id="soSearchInput" name="search_soSearchInput" autocomplete="new-password" inputmode="search" placeholder="Search name..." oninput="ascbSoFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadApprovedSO()" title="Refresh">⟳ Refresh</button>
                    </div>

                </div>

                <div class="records-status" id="soStatus">Loading records…</div>

                <div class="table-wrapper records-table-wrapper" id="soTableWrapper" style="display:none;">
                    <table class="records-table" id="soTable">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>File</th>
                                <th>Uploaded By</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="soTableBody"></tbody>
                    </table>
                </div>
                <div class="pagination-bar" id="soPagination"></div>

            </section>

        </section>


        <!-- APPROVED SO UPLOAD RESULT MODAL -->
        <div class="so-result-modal" id="soResultModal" aria-hidden="true">
            <div class="so-result-backdrop" onclick="ascbSoCloseResultModal()"></div>
            <div class="so-result-card" role="dialog" aria-modal="true" aria-labelledby="soResultTitle">
                <button type="button" class="so-result-close" onclick="ascbSoCloseResultModal()" aria-label="Close">×</button>
                <div class="so-result-icon" id="soResultIcon">✓</div>
                <h3 id="soResultTitle">Upload Complete</h3>
                <p id="soResultMessage"></p>
                <div class="so-result-stats">
                    <div><strong id="soResultTotal">0</strong><span>Total PDF</span></div>
                    <div><strong id="soResultSaved">0</strong><span>Uploaded</span></div>
                    <div><strong id="soResultFailed">0</strong><span>Failed</span></div>
                </div>
                <div class="so-result-errors" id="soResultErrors" style="display:none;"></div>
                <button type="button" class="app-nav-btn app-nav-btn-primary so-result-ok" onclick="ascbSoCloseResultModal()">OK</button>
            </div>
        </div>


        <!-- =================================================
             ADMIN VIEW
             Lahat ng naka-login ay may access dito, pero
             magkaiba ang kayang gawin bawat role — tingnan ang
             includes/permissions.php. Kung ano ang kaya ng
             kasalukuyang user, sinasabi ito ng $ascbPermissions
             (PHP) / ASCB_PERMISSIONS (JS).
        ================================================== -->
        <section class="app-view" id="adminView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">⚙</span>
                    <div>
                        <h3>Settings</h3>
                        <p>User accounts, Schools &amp; Courses, at Activity Log ng system.</p>
                    </div>
                </div>

                <div class="records-tabs" id="adminTabs">
                    <button type="button" class="records-tab active" id="adminTabAccount" onclick="ascbAdminSwitchTab('account')">
                        👤 My Account
                    </button>
                    <button type="button" class="records-tab" id="adminTabAppearance" onclick="ascbAdminSwitchTab('appearance')">
                        🎨 Appearance
                    </button>
                    <button type="button" class="records-tab" id="adminTabUsers" onclick="ascbAdminSwitchTab('users')">
                        🧑‍💼 Users
                    </button>
            <?php if (!empty($ascbPermissions['manageLookups'])): ?>
                    <button type="button" class="records-tab" id="adminTabLookups" onclick="ascbAdminSwitchTab('lookups')">
                        🏫 Schools &amp; Courses
                    </button>
            <?php endif; ?>
            <?php if (!empty($ascbPermissions['viewDepartmentsTab'])): ?>
                    <button type="button" class="records-tab" id="adminTabDepartments" onclick="ascbAdminSwitchTab('departments')">
                        <?php echo ascb_get($ascbUser, 'role', '') === 'DEAN' ? '📊 Department Export' : '🏢 Departments &amp; Backup'; ?>
                    </button>
            <?php endif; ?>
                    <button type="button" class="records-tab" id="adminTabPrograms" onclick="ascbAdminSwitchTab('programs')">
                        📚 Programs &amp; Subjects
                    </button>
                    <button type="button" class="records-tab" id="adminTabLog" onclick="ascbAdminSwitchTab('log')">
                        🗂 Activity Log
                    </button>
                </div>

            </section>

            <!-- ---------- MY ACCOUNT ---------- -->
            <section class="f137-card admin-tab-panel" id="adminPanelAccount">

                <div class="f137-section-title">
                    <span class="f137-icon">👤</span>
                    <div>
                        <h3><?php echo htmlspecialchars($ascbUser['displayName']); ?></h3>
                        <p><?php echo htmlspecialchars($ascbUser['role']); ?></p>
                    </div>
                </div>

                <div class="f137-form-grid">
                    <div class="f137-field">
                        <label for="acct_currentPassword">Current Password</label>
                        <input id="acct_currentPassword" type="password" autocomplete="current-password">
                    </div>
                    <div class="f137-field">
                        <label for="acct_newPassword">New Password</label>
                        <input id="acct_newPassword" type="password" autocomplete="new-password">
                    </div>
                    <div class="f137-field">
                        <label for="acct_confirmPassword">Confirm New Password</label>
                        <input id="acct_confirmPassword" type="password" autocomplete="new-password">
                    </div>
                </div>

                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbChangeOwnPassword()">
                    <span class="app-nav-icon">✔</span>
                    CHANGE PASSWORD
                </button>

                <div class="records-status" id="acctStatus" style="display:none;"></div>

            </section>

            <!-- Duplicate marker removed -->
            <section class="f137-card admin-tab-panel" id="adminPanelAppearance" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">🎨</span>
                    <div>
                        <h3>Appearance</h3>
                        <p>Theme.</p>
                    </div>
                </div>

                <div class="theme-switch">
                    <button
                        type="button"
                        class="theme-switch-track"
                        id="themeSwitchTrack"
                        data-theme-switch
                        role="switch"
                        aria-checked="false"
                        aria-label="Toggle dark mode"
                        onclick="ascbToggleTheme()"
                    >
                        <span class="theme-switch-thumb"></span>
                    </button>
                    <div class="theme-switch-labels">
                        <strong>Dark Mode</strong>
                        <span data-theme-status>Light mode is on.</span>
                    </div>
                </div>


            </section>

            <!-- ---------- USERS (UNIT HEAD lang) ---------- -->
            <section class="f137-card admin-tab-panel" id="adminPanelUsers" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">➕</span>
                    <div>
                        <h3>Add Staff Account</h3>
                        <p>Create new account of employee.</p>
                    </div>
                </div>

                <div class="f137-form-grid">
                    <div class="f137-field">
                        <label for="user_displayName">Full Name</label>
                        <input id="user_displayName" type="text" placeholder="e.g. JUAN DELA CRUZ">
                    </div>
                    <div class="f137-field">
                        <label for="user_role">Role</label>
                        <select id="user_role" onchange="ascbUserToggleStudentField('user_role','user_studentIdField')">
                            <option value="ADMIN STAFF">ADMIN STAFF</option>
                            <option value="SCHOOL REGISTRAR">SCHOOL REGISTRAR</option>
                            <option value="UNIT HEAD">UNIT HEAD</option>
                            <option value="DEAN">DEAN</option>
                            <option value="STUDENT">STUDENT</option>
                        </select>
                    </div>
                    <div class="f137-field">
                        <label for="user_departmentId">Department (required for DEAN / ADMIN STAFF)</label>
                        <select id="user_departmentId"><option value="">— Select Department —</option></select>
                    </div>
                    <div class="f137-field" id="user_studentIdField" style="display:none;">
                        <label for="user_studentId">Student ID (required for STUDENT)</label>
                        <input id="user_studentId" type="text" maxlength="50" placeholder="Must match an existing Student ID" autocomplete="off">
                    </div>
                    <div class="f137-field">
                        <label for="user_preparedByCode">"Prepared By" Code (optional)</label>
                        <input id="user_preparedByCode" type="text" placeholder="e.g. jdcruz">
                    </div>
                    <div class="f137-field">
                        <label for="user_username">Username</label>
                        <input id="user_username" name="new_account_username" type="text" value="" autocomplete="username">
                    </div>
                    <div class="f137-field f137-span-2">
                        <label for="user_password">Password</label>
                        <input id="user_password" type="password" placeholder="Hindi bababa sa 8 karakter">
                    </div>
                </div>

                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbUserAdd()">
                    <span class="app-nav-icon">✔</span>
                    ADD ACCOUNT
                </button>

                <div class="records-status" id="userFormStatus" style="display:none;"></div>

            </section>

            <section class="f137-card admin-tab-panel" id="adminPanelUsersList" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">🧑‍💼</span>
                    <div>
                        <h3>Staff Accounts</h3>
                        <p>ALl Employee.</p>
                    </div>
                </div>

                <div class="records-toolbar">
                    <div class="records-search">
                        <input type="search" id="userSearchInput" name="search_userSearchInput" autocomplete="new-password" inputmode="search" placeholder="Search name, role..." oninput="ascbUsersFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadUsers()" title="Refresh">⟳ Refresh</button>
                    </div>
                </div>

                <div class="records-status" id="usersStatus">Loading accounts…</div>

                <div class="table-wrapper records-table-wrapper" id="usersTableWrapper" style="display:none;">
                    <table class="records-table" id="usersTable">
                        <thead>
                            <tr>
                                <th>Employee Name</th>
                                <th>Role</th>
                                <th>Department</th>
                                <th>Student ID</th>
                                <th>Prepared By</th>
                                <th>Status</th>
                                <th>Date Added</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="usersTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="usersPagination"></div>
                </div>

            </section>

            <!-- ---------- SCHOOLS & COURSES (UNIT HEAD / ADMIN STAFF only) ---------- -->
            <?php if (!empty($ascbPermissions['manageLookups'])): ?>
            <section class="f137-card admin-tab-panel" id="adminPanelLookups" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">🏫</span>
                    <div>
                        <h3>Schools</h3>
                        <p>Listahan ng schools sa Form 137-A dropdown.</p>
                    </div>
                </div>

                <div class="f137-form-grid">
                    <div class="f137-field">
                        <label for="admLookup_schoolName">School Name</label>
                        <input id="admLookup_schoolName" type="text" placeholder="School name">
                    </div>
                    <div class="f137-field">
                        <label for="admLookup_schoolAddress">Address (optional)</label>
                        <input id="admLookup_schoolAddress" type="text" placeholder="Address">
                    </div>
                </div>
                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbAdminAddSchool()">
                    <span class="app-nav-icon">✔</span>
                    ADD SCHOOL
                </button>
                <div class="records-status" id="admSchoolFormStatus" style="display:none;"></div>

                <div class="records-toolbar" style="margin-top:20px;">
                    <div class="records-search">
                        <input type="search" id="admSchoolSearchInput" name="search_admSchoolSearchInput" autocomplete="new-password" inputmode="search" placeholder="Search school..." oninput="ascbAdminSchoolsFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbAdminLoadSchools()" title="Refresh">⟳ Refresh</button>
                    </div>
                </div>

                <div class="records-status" id="admSchoolsStatus">Loading…</div>

                <div class="table-wrapper records-table-wrapper" id="admSchoolsTableWrapper" style="display:none;">
                    <table class="records-table" id="admSchoolsTable">
                        <thead>
                            <tr>
                                <th>School Name</th>
                                <th>Address</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="admSchoolsTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="admSchoolsPagination"></div>
                </div>

            </section>

            <section class="f137-card admin-tab-panel" id="adminPanelLookupsCourses" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">🎓</span>
                    <div>
                        <h3>Courses</h3>
                        <p>List of Course</p>
                    </div>
                </div>

                <div class="f137-form-grid">
                    <div class="f137-field f137-span-2">
                        <label for="admLookup_courseName">Course Name</label>
                        <input id="admLookup_courseName" type="text" placeholder="e.g. BSIT">
                    </div>
                </div>
                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbAdminAddCourse()">
                    <span class="app-nav-icon">✔</span>
                    ADD COURSE
                </button>
                <div class="records-status" id="admCourseFormStatus" style="display:none;"></div>

                <div class="records-toolbar" style="margin-top:20px;">
                    <div class="records-search">
                        <input type="search" id="admCourseSearchInput" name="search_admCourseSearchInput" autocomplete="new-password" inputmode="search" placeholder="Search course..." oninput="ascbAdminCoursesFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbAdminLoadCourses()" title="Refresh">⟳ Refresh</button>
                    </div>
                </div>

                <div class="records-status" id="admCoursesStatus">Loading…</div>

                <div class="table-wrapper records-table-wrapper" id="admCoursesTableWrapper" style="display:none;">
                    <table class="records-table" id="admCoursesTable">
                        <thead>
                            <tr>
                                <th>Course Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="admCoursesTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="admCoursesPagination"></div>
                </div>

            </section>
            <?php endif; ?>


            <!-- ---------- DEPARTMENTS / DEAN EXPORT / FULL BACKUP ---------- -->
            <section class="f137-card admin-tab-panel" id="adminPanelDepartments" style="display:none;">
                <?php if (ascb_get($ascbUser, 'role', '') !== 'DEAN'): /* Departments & Dean Data Distribution — hindi para sa DEAN account */ ?>
                <div class="f137-section-title"><span class="f137-icon">🏢</span><div><h3>Departments &amp; Dean Data Distribution</h3><p>I-group ang Programs per Department, mag-assign ng Dean account, at mag-export ng Department student data para sa Dean.</p></div></div>
                <div class="f137-form-grid" id="deptManageForm">
                    <input type="hidden" id="dept_id" value="">
                    <div class="f137-field"><label for="dept_code">Department Code</label><input id="dept_code" type="text" placeholder="e.g. CBE"></div>
                    <div class="f137-field"><label for="dept_name">Department Name</label><input id="dept_name" type="text" placeholder="e.g. College of Business Education"></div>
                    <div class="f137-field" id="dept_active_field" style="display:none;">
                        <label for="dept_isActive">Status</label>
                        <select id="dept_isActive"><option value="1">Active</option><option value="0">Inactive</option></select>
                    </div>
                </div>
                <button type="button" class="app-nav-btn app-nav-btn-primary" id="deptAddBtn" onclick="ascbDepartmentAdd()"><span class="app-nav-icon">✔</span> ADD DEPARTMENT</button>
                <button type="button" class="btn btn-outline" id="deptCancelEditBtn" onclick="ascbDepartmentCancelEdit()" style="display:none; margin-left:8px;">Cancel</button>
                <div class="records-status" id="deptStatus" style="display:none;"></div>

                <?php if (ascb_get($ascbUser, 'role', '') === 'UNIT HEAD'): ?>
                <div class="f137-section-title" style="margin-top:24px;"><span class="f137-icon">🔗</span><div><h3>Assign Existing Programs / Courses to Department</h3><p>I-assign ang mga existing Program/Course na dati nang ginawa pero walang Department. Hindi buburahin ang enrollment records.</p></div></div>
                <div class="f137-form-grid">
                    <div class="f137-field">
                        <label for="deptAssign_department">Target Department</label>
                        <select id="deptAssign_department" onchange="ascbLoadDepartmentAssignablePrograms()"><option value="">— Select Department —</option></select>
                    </div>
                    <div class="f137-field f137-span-2">
                        <label for="deptAssign_search">Search Program / Course</label>
                        <input id="deptAssign_search" type="text" placeholder="e.g. BSIT, Bachelor of Science..." oninput="ascbRenderDepartmentAssignablePrograms()">
                    </div>
                </div>
                <div class="records-status" id="deptAssignStatus" style="display:none;"></div>
                <div class="table-wrapper records-table-wrapper" id="deptAssignTableWrapper" style="display:none; margin-top:12px;">
                    <table class="records-table">
                        <thead><tr><th style="width:7%;">Select</th><th>Course Code</th><th>Course / Program</th><th>Major</th><th>Current Department</th></tr></thead>
                        <tbody id="deptAssignTableBody"></tbody>
                    </table>
                </div>
                <button type="button" class="app-nav-btn app-nav-btn-primary" id="deptAssignBtn" onclick="ascbAssignSelectedPrograms()" style="margin-top:10px; display:none;"><span class="app-nav-icon">🔗</span> ASSIGN SELECTED PROGRAMS</button>
                <button type="button" class="btn btn-outline" id="deptAssignSelectAllBtn" onclick="ascbToggleDepartmentAssignablePrograms(true)" style="margin:10px 0 0 8px; display:none;">Select All Visible</button>
                <button type="button" class="btn btn-outline" id="deptAssignClearBtn" onclick="ascbToggleDepartmentAssignablePrograms(false)" style="margin:10px 0 0 8px; display:none;">Clear Visible</button>
                <?php endif; ?>
                <div class="table-wrapper records-table-wrapper" style="margin-top:16px;"><table class="records-table"><thead><tr><th>Code</th><th>Department</th><th>Programs</th><th>Active Deans</th><th>Status</th><th>Actions</th></tr></thead><tbody id="deptTableBody"></tbody></table></div>
                <?php endif; ?>
                <?php if (!empty($ascbPermissions['exportDepartment'])): ?>
                <?php if (ascb_get($ascbUser, 'role', '') !== 'DEAN'): ?><hr style="margin:24px 0; opacity:.25;"><?php endif; ?>
                <div class="f137-section-title"><span class="f137-icon">📊</span><div><h3>Department Excel Export</h3><p>Excel-compatible student/enrollment/subject/grade data. DEAN accounts can export only their assigned Department.</p></div></div>
                <div class="f137-form-grid">
                    <div class="f137-field"><label for="deptExport_department">Department</label><select id="deptExport_department" onchange="ascbLoadDeptExportCourses()"><option value="">— Select Department —</option></select></div>
                    <div class="f137-field"><label for="deptExport_sy">School Year (optional)</label><input id="deptExport_sy" type="text" placeholder="e.g. 2026-2027"></div>
                    <div class="f137-field f137-span-2"><label for="deptExport_course">Course (optional)</label><select id="deptExport_course" onchange="ascbUpdateDeptExportTerms()"><option value="">— All Courses —</option></select></div>
                    <div class="f137-field"><label for="deptExport_term">Term (optional)</label><select id="deptExport_term"><option value="">All Terms</option><option>1st Trimester</option><option>2nd Trimester</option><option>3rd Trimester</option><option>1st Semester</option><option>2nd Semester</option><option>Summer</option></select></div>
                </div>
                <button type="button" class="btn btn-outline" onclick="ascbPromotionalReportExport()" style="margin-top:18px;" title="Kailangan pumili ng Course — isang Program bawat Promotional Report."><span class="app-nav-icon">📄</span> EXPORT PROMOTIONAL REPORT (.xlsx)</button>
                <?php endif; ?>
                <?php if (!empty($ascbPermissions['fullBackup'])): ?>
                <button type="button" class="btn btn-outline" id="fullSqlBackupBtn" onclick="ascbFullSqlBackup()" style="margin-left:8px;">Full SQL Backup</button>
                <?php endif; ?>
                <p style="margin-top:8px; opacity:.7; font-size:.85em;">PROMOTIONAL REPORT</p>

                <?php if (!empty($ascbPermissions['fullBackup'])): ?>
                <!-- ---------- AUTOMATIC BACKUP SCHEDULE ---------- -->
                <hr style="margin:24px 0; opacity:.25;">
                <div class="f137-section-title"><span class="f137-icon">⏰</span><div><h3>Automatic Backup Schedule</h3></div></div>
                <div class="f137-form-grid">
                    <div class="f137-field"><label for="abk_enabled">Automatic Backup</label><select id="abk_enabled"><option value="0">Off</option><option value="1">On</option></select></div>
                    <div class="f137-field"><label for="abk_frequency">Repeat</label><select id="abk_frequency" onchange="ascbBackupToggleWeekday()"><option value="daily">Every day</option><option value="weekly">Every week</option></select></div>
                    <div class="f137-field" id="abk_weekday_field" style="display:none;"><label for="abk_weekday">Day of the week</label><select id="abk_weekday"><option value="1">Monday</option><option value="2">Tuesday</option><option value="3">Wednesday</option><option value="4">Thursday</option><option value="5">Friday</option><option value="6">Saturday</option><option value="0">Sunday</option></select></div>
                    <div class="f137-field"><label for="abk_time">Time of backup</label><input id="abk_time" type="time" value="02:00"></div>
                    <div class="f137-field"><label for="abk_keep">Keep latest backups (1–60)</label><input id="abk_keep" type="number" min="1" max="60" value="7"></div>
                    <div class="f137-field f137-span-2">
                        <label>What to back up</label>
                        <label class="abk-check" for="abk_sql"><input type="checkbox" id="abk_sql" checked><span>Full SQL database backup</span></label>
                        <label class="abk-check" for="abk_dept"><input type="checkbox" id="abk_dept" checked><span>Department data (Promotional Report format — one Excel .xlsx per Program, School Year &amp; Term, per active Department)</span></label>
                    </div>
                </div>
                <div style="margin-top:12px;display:flex;flex-wrap:wrap;gap:8px;">
                    <button type="button" class="app-nav-btn app-nav-btn-primary" id="abk_saveBtn" onclick="ascbBackupScheduleSave()"><span class="app-nav-icon">💾</span> SAVE SCHEDULE</button>
                    <button type="button" class="btn btn-outline" id="abk_runBtn" onclick="ascbBackupRunNow()">Run Backup Now</button>
                    <button type="button" class="btn btn-outline" onclick="ascbBackupScheduleLoad()">⟳ Refresh</button>
                </div>
                <div class="records-status" id="abk_status" style="display:none;"></div>
                <div id="abk_summary" style="margin-top:10px;font-size:.92em;line-height:1.6;"></div>

                <div class="f137-field f137-span-2" style="margin-top:14px;">
                    <label for="abk_cron_url">AUTOMATIC BACKUP</label>
                    <div style="display:flex;flex-wrap:wrap;gap:8px;">
                        <input id="abk_cron_url" type="text" readonly style="flex:1 1 260px;min-width:0;" onclick="this.select()">
                        <button type="button" class="btn btn-outline" onclick="ascbBackupCopyCron()">Copy</button>
                        <button type="button" class="btn btn-outline" onclick="ascbBackupRegenToken()">New Token</button>
                    </div>
                    
                </div>

                <div class="abk-perpage">
                    <label for="abk_perPage" style="font-size:.85em;opacity:.8;">Rows per page</label>
                    <select id="abk_perPage" onchange="ascbBackupSetPerPage(this.value)" style="width:auto;min-width:72px;">
                        <option value="5">5</option><option value="10" selected>10</option><option value="20">20</option><option value="50">50</option>
                    </select>
                </div>
                <div class="table-wrapper records-table-wrapper" style="margin-top:8px;">
                    <table class="records-table">
                        <thead><tr><th>Date &amp; Time</th><th>Type</th><th>File</th><th>Size</th><th>Download</th></tr></thead>
                        <tbody id="abk_filesBody"><tr><td colspan="5" class="records-empty">Wala pang automatic backup.</td></tr></tbody>
                    </table>
                </div>
                <div class="pagination-bar abk-pagination" id="abk_pagination"></div>
                <?php endif; ?>
            </section>

            <!-- ---------- PROGRAMS & SUBJECTS (view: lahat; delete: may permission lang) ---------- -->
            <section class="f137-card admin-tab-panel" id="adminPanelPrograms" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">📚</span>
                    <div>
                        <h3>Add Course / Program</h3>
                        <p>Idagdag ang bagong Course, Major (kung meron), at kung Trimester o Semester ang term system nito. Awtomatiko itong lalabas sa Course dropdown ng Enrollment.</p>
                    </div>
                </div>

                <div class="f137-form-grid">
                    <div class="f137-field">
                        <label for="admProg_departmentId">Department</label>
                        <select id="admProg_departmentId"><option value="">— Select Department —</option></select>
                    </div>
                    <div class="f137-field">
                        <label for="admProg_code">Course Code</label>
                        <input id="admProg_code" type="text" placeholder="e.g. BSHM">
                    </div>
                    <div class="f137-field">
                        <label for="admProg_termType">Term System</label>
                        <select id="admProg_termType">
                            <option value="Trimester">Trimester</option>
                            <option value="Semester">Semester</option>
                        </select>
                    </div>
                    <div class="f137-field f137-span-2">
                        <label for="admProg_courseName">Course Name</label>
                        <input id="admProg_courseName" type="text" placeholder="e.g. Bachelor of Science in Hospitality Management">
                    </div>
                    <div class="f137-field f137-span-2">
                        <label for="admProg_major">Major (optional)</label>
                        <input id="admProg_major" type="text" placeholder="e.g. Financial Management — iwan blangko kung walang major">
                    </div>
                </div>
                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbAdminAddProgram()">
                    <span class="app-nav-icon">✔</span>
                    ADD PROGRAM
                </button>
                <div class="records-status" id="admProgFormStatus" style="display:none;"></div>

                <div class="records-toolbar" style="margin-top:20px;">
                    <div class="records-search">
                        <input type="search" id="admProgSearchInput" name="search_admProgSearchInput" autocomplete="new-password" inputmode="search" placeholder="Search course, major..." oninput="ascbAdminProgramsFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbAdminLoadPrograms()" title="Refresh">⟳ Refresh</button>
                    </div>
                </div>

                <div class="records-status" id="admProgsStatus">Loading…</div>

                <div class="table-wrapper records-table-wrapper" id="admProgsTableWrapper" style="display:none;">
                    <table class="records-table" id="admProgsTable">
                        <thead>
                            <tr>
                                <th>Department</th>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Major</th>
                                <th>Term System</th>
                                <th>Subjects</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="admProgsTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="admProgsPagination"></div>
                </div>

            </section>

            <!-- ---------- ACTIVITY LOG (UNIT HEAD / SCHOOL REGISTRAR lang) ---------- -->
            <section class="f137-card admin-tab-panel" id="adminPanelLog" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">🗂</span>
                    <div>
                        <h3>Activity Log</h3>
                        <p>History of Every Transaction</p>
                    </div>
                </div>

                <div class="records-toolbar">
                    <div class="records-search">
                        <input type="search" id="logSearchInput" name="search_logSearchInput" autocomplete="new-password" inputmode="search" placeholder="Search name, action..." oninput="ascbActivityLogFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadActivityLog()" title="Refresh">⟳ Refresh</button>
                    </div>
                </div>

                <div class="records-status" id="logStatus">Loading…</div>

                <div class="activity-history" id="logTableWrapper" style="display:none;">
                    <div class="activity-history-list" id="logTableBody"></div>
                    <div class="pagination-bar" id="logPagination"></div>
                </div>

            </section>

            <section class="f137-card admin-tab-panel" id="adminPanelNoAccess" style="display:none;">
                <div class="records-empty" style="padding: 30px 0;">Wala kang access sa section na ito.</div>
            </section>

        </section>

    </main>

</div>



<!-- =========================================================
     CERTIFICATE MODAL
========================================================== -->

<div
    class="modal"
    id="certificateModal"
>

    <div
        class="modal-overlay"
        onclick="closeCertificate()"
    ></div>


    <div class="modal-window">


        <!-- MODAL TOOLBAR -->
        <div class="modal-toolbar">

            <div>

                <strong>
                    Certificate Preview
                </strong>

                <span>
                    Ready for printing
                </span>

            </div>


            <div class="toolbar-buttons">

                <button
                    type="button"
                    class="btn btn-secondary"
                    onclick="closeCertificate()"
                >
                    Close
                </button>

                <button
                    type="button"
                    class="btn btn-primary"
                    onclick="printCertificate()"
                >
                    Print Certificate
                </button>

            </div>

        </div>



        <!-- =================================================
             SCROLLABLE PREVIEW WRAPPER
             (keeps the fixed 8.5x11in sheet fully viewable
             and scrollable inside the modal, on any screen)
        ================================================== -->

        <div class="modal-print-scroll">

        <!-- =================================================
             PRINT AREA
             LETTER / SHORT BOND
             8.5 x 11 INCHES
        ================================================== -->

        <div
            class="print-area"
            id="printArea"
        >


            <!-- =================================================
                 OFFICIAL HEADER
                 LOGO + SCHOOL NAME + ADDRESS + OFFICE + EMAIL
            ================================================== -->

            <div class="document-header">

                <img
                    src="Header_ASCB.png"
                    class="letterhead-banner"
                    alt="Andres Soriano Colleges of Bislig, Inc."
                >

                <div class="header-subtitle">

                    <p class="header-office">
                        Office of the Registrar
                    </p>

                    <p class="header-email">
                        collegeregistrar.ascb@gmail.com &nbsp;|&nbsp; (086) 853-2306 (PhilCom)
                    </p>

                </div>

            </div>



            <!-- =================================================
                 CENTER WATERMARK
                 IMPORTANT:
                 Actual IMG instead of CSS background
            ================================================== -->

            <div
                class="watermark-container"
                aria-hidden="true"
            >

                <img
                    src="ASCB_LOGO.png"
                    class="document-watermark"
                    alt=""
                >

            </div>



            <!-- =================================================
                 DOCUMENT CONTENT
            ================================================== -->

            <div class="document-content">


                <!-- TITLE -->

                <h1 class="certificate-title" id="previewCertificateTitle">
                    CERTIFICATE OF ENROLLMENT
                </h1>



                <!-- INTRODUCTION -->

                <p class="certificate-intro" id="certificateIntro">

                        This is to certify that

                        <strong id="previewStudentName">
                            ______________________________
                        </strong>

                        is officially enrolled at

                        <strong>
                            Andres Soriano Colleges of Bislig, Inc.
                        </strong>

                        in the

                        <strong id="previewProgram">
                            ______________________________
                        </strong>

                        program for the

                        <strong id="previewTrimester">
                            ______________________________
                        </strong>,

                        <strong>Academic Year</strong>

                        <strong id="previewAcademicYear">
                            ____________
                        </strong>.

                    </p>



                <!-- SUMMARY -->

                <p class="summary-title">

                    <span id="summaryTitleText">Below is the Summary of the Student's Enrollment:</span>

                </p>



                <!-- =================================================
                     STUDENT DETAILS
                ================================================== -->

                <div class="student-details">


                    <div class="detail-row">

                        <span class="detail-label">
                            Student Name
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <span
                            id="previewName2"
                            class="detail-value"
                        ></span>

                    </div>



                    <div class="detail-row">

                        <span class="detail-label">
                            Student ID
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <span
                            id="previewStudentId"
                            class="detail-value"
                        ></span>

                    </div>



                    <div class="detail-row">

                        <span class="detail-label">
                            Course / Program
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <span
                            id="previewCourse"
                            class="detail-value"
                        ></span>

                    </div>



                    <div class="detail-row">

                        <span class="detail-label">
                            Year Level
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <span
                            id="previewYearLevel"
                            class="detail-value"
                        ></span>

                    </div>



                    <div class="detail-row">

                        <span class="detail-label">
                            Semester / Trimester
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <span
                            id="previewTerm"
                            class="detail-value"
                        ></span>

                    </div>



                    <div class="detail-row" id="detailRowEnrollmentDate">

                        <span class="detail-label">
                            Date of Enrollment
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <span
                            id="previewEnrollmentDate"
                            class="detail-value"
                        ></span>

                    </div>



                    <div class="detail-row" id="detailRowStatus">

                        <span class="detail-label">
                            Status
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <strong
                            id="previewStatus"
                            class="detail-value status-text"
                        ></strong>

                    </div>


                </div>



                <!-- =================================================
                     SUBJECT TABLE
                ================================================== -->

                <table class="certificate-table">


                    <thead>

                        <tr id="certTableHeadRow">

                            <th class="code-column">
                                Course Code
                            </th>

                            <th>
                                Course Description
                            </th>

                            <th class="units-column">
                                Units
                            </th>

                        </tr>

                    </thead>


                    <tbody id="previewSubjects">

                        <!-- JavaScript -->

                    </tbody>


                    <tfoot>

                        <tr>

                            <td colspan="2" class="cert-total-label" id="certTotalLabelCell">
                                TOTAL UNITS
                            </td>

                            <td id="previewTotalUnits">
                                0
                            </td>

                        </tr>

                        <tr id="certGwaRow" style="display: none;">

                            <td colspan="2" class="cert-total-label" id="certGwaLabelCell">
                                GENERAL WEIGHTED AVERAGE (GWA)
                            </td>

                            <td id="previewGWA">
                                0.00
                            </td>

                        </tr>

                    </tfoot>


                </table>



                <!-- =================================================
                     CERTIFICATION
                ================================================== -->

                <div class="certification-text" id="certificationTextBlock">

                    <h2 id="certificationTextContent">

                        This certification is issued upon the request
                        of the student for whatever lawful purpose it
                        may serve.

                    </h2>

                </div>

                <div class="Issued" id="issuedDateBlock">
                <h2>

                        Issued this

                        <span id="previewIssuedDate">
                            ____________________
                        </span>

                        at Andres Soriano Colleges of Bislig, Inc.,
                        Mangagoy, Bislig City, Surigao del Sur.

                </h2>
                </div>



                <!-- =================================================
                     SIGNATURE
                ================================================== -->

                <div class="signature-area">


                    <div class="signature-box">





                        <div class="signature-space">
                            &nbsp;
                        </div>


                        <div class="signature-line">

                            REBECCA P. CAPONONG, MAEd

                        </div>


                        <div class="signature-position">

                            School Registrar

                        </div>


                    </div>


                </div>

                <!-- VERIFICATION QR CODE (Enrollment / Registration only).
                     Nasa gitna, sa ILALIM ng School Registrar, may margin.
                     Nilalagyan ng script.js (ascbCertificateRenderQr). -->
                <div class="cert-qr-box" id="certQrBox" style="display:none" data-state="hidden">
                    <div class="cert-qr-img" id="certQrImg"></div>
                    <div class="cert-qr-caption">SCAN TO VERIFY</div>
                    <div class="cert-qr-code" id="certQrCode"></div>
                    <div class="cert-qr-site" id="certQrSite"></div>
                </div>



            </div>



            <!-- =================================================
                 SCHOOL SEAL NOTICE
                 FIXED AT VERY BOTTOM LEFT
            ================================================== -->

            <div class="school-seal-warning">
                <strong>NOT VALID WITHOUT</strong>
                <strong><span>SCHOOL SEAL</span></strong>
            </div>


            <!-- =================================================
                 TRANSACTION NOTES
                 O.R. NUMBER + PREPARED BY
                 FIXED BELOW THE SCHOOL SEAL NOTICE
            ================================================== -->

            <div class="transaction-notes">

                <div class="transaction-row">
                    <span class="transaction-label">O.R. No.</span>
                    <span class="transaction-colon">:</span>
                    <span id="previewOrNumber" class="transaction-value">—</span>
                </div>

                <div class="transaction-row">
                    <span class="transaction-label">Prepared by</span>
                    <span class="transaction-colon">:</span>
                    <span id="previewPreparedBy" class="transaction-value">—</span>
                </div>

            </div>


        </div>

        </div>

    </div>

</div>



<!-- SCRIPT -->


<!-- =========================================================
     GRADE EVALUATION REPORT MODAL
     Binuksan pag ni-View sa Grade Evaluation student list.
     Maliit/centered modal (gaya ng ibang detail modals) na
     sakto lang sa laman/screen — hindi na full-screen — at may
     sarili siyang scroll kapag mahaba ang laman (maraming
     trimester/record). Nasa loob din ng parehong card ang
     pangalan at course/major (hindi na hiwalay sa toolbar).
========================================================== -->
<!-- BULK GRADE/STUDENT IMPORT MODAL (.xlsx / .csv, Department Export format, UNIT HEAD lang) -->
<div class="f137-mini-modal" id="gradeImportModal" onclick="if(event.target===this) ascbGradeImportClose()">
    <div class="f137-mini-card f137-mini-card-lg record-correction-card" onclick="event.stopPropagation()">
        <button type="button" class="f137-mini-close" onclick="ascbGradeImportClose()">×</button>
        <div class="f137-section-title" style="margin-bottom:10px;">
            <span class="f137-icon">📥</span>
            <div><h3 style="margin:0;">Intelligent Excel Import</h3><p style="margin:2px 0 0;font-size:12.5px;color:var(--muted);">Automatic column detection • Multiple sheets • Student / Enrollment / Subject / Grade migration</p></div>
        </div>
        <div class="f137-form-grid">
            <div class="f137-field f137-span-2">
                <label for="gradeImportFile">Excel file (.xlsx / .csv)</label>
                <input type="file" id="gradeImportFile" accept=".xlsx,.csv">
                <small style="display:block;margin-top:5px;color:var(--muted);">No fixed template required. The system analyzes headers, merged/blank rows, column order, extra columns, and multiple worksheets.</small>
            </div>
        </div>
        <div style="margin-top:12px; display:flex; gap:8px; flex-wrap:wrap;">
            <button type="button" class="btn btn-secondary" id="gradeImportPreviewBtn" onclick="ascbGradeImportPreview()">1. Analyze & Preview</button>
            <button type="button" class="btn btn-danger-solid" id="gradeImportCommitBtn" style="display:none" onclick="ascbGradeImportCommit()">3. Confirm Migration</button>
            <button type="button" class="btn btn-outline" onclick="ascbGradeImportHistoryOpen()">Import History</button>
        </div>
        <div id="gradeImportResult" style="margin-top:14px;"></div>
        <div class="records-status" id="gradeImportStatus" style="display:none"></div>
    </div>
</div>

<!-- INTELLIGENT IMPORT HISTORY MODAL -->
<div class="f137-mini-modal" id="gradeImportHistoryModal" onclick="if(event.target===this) ascbGradeImportHistoryClose()">
    <div class="f137-mini-card f137-mini-card-lg record-correction-card" onclick="event.stopPropagation()">
        <button type="button" class="f137-mini-close" onclick="ascbGradeImportHistoryClose()">×</button>
        <div class="f137-section-title" style="margin-bottom:10px;">
            <span class="f137-icon">🧾</span>
            <div><h3 style="margin:0;">Grade Import History</h3><p style="margin:2px 0 0;font-size:12.5px;color:var(--muted);">Audit trail for intelligent Excel migrations</p></div>
        </div>
        <div id="gradeImportHistoryBody"></div>
    </div>
</div>

<!-- PREVIOUS TERM CORRECTION MODAL -->
<div class="f137-mini-modal" id="recordCorrectionModal" onclick="if(event.target===this) ascbRecordCorrectionClose()">
    <div class="f137-mini-card f137-mini-card-lg record-correction-card" onclick="event.stopPropagation()">
        <button type="button" class="f137-mini-close" onclick="ascbRecordCorrectionClose()">×</button>
        <div class="f137-section-title" style="margin-bottom:10px;">
            <span class="f137-icon">🛡️</span>
            <div><h3 id="recordCorrectionTitle" style="margin:0;">Correct Previous Term</h3><p id="recordCorrectionSub" style="margin:2px 0 0;font-size:12.5px;color:var(--muted);">Historical record correction</p></div>
        </div>
        <div id="recordCorrectionBody"></div>
        <div class="records-status" id="recordCorrectionStatus" style="display:none"></div>
    </div>
</div>

<div class="f137-mini-modal" id="recordCorrectionReviewModal" onclick="if(event.target===this) ascbRecordCorrectionReviewClose()">
    <div class="f137-mini-card f137-mini-card-lg record-correction-card" onclick="event.stopPropagation()">
        <button type="button" class="f137-mini-close" onclick="ascbRecordCorrectionReviewClose()">×</button>
        <div class="f137-section-title" style="margin-bottom:10px;">
            <span class="f137-icon">🛡️</span>
            <div><h3 style="margin:0;">Correction Requests</h3><p style="margin:2px 0 0;font-size:12.5px;color:var(--muted);">Review pending previous-term corrections</p></div>
        </div>
        <div id="recordCorrectionReviewBody"></div>
    </div>
</div>

<?php if (!empty($ascbPermissions['manageMasterRecord'])): ?>
<!-- MASTER RECORD: UPDATE AFTER MARRIAGE -->
<div class="f137-mini-modal" id="mrMarriageModal" onclick="if(event.target===this) ascbMasterCloseMarriage()">
    <div class="f137-mini-card" onclick="event.stopPropagation()" role="dialog" aria-modal="true" aria-labelledby="mrMarriageTitle">
        <button type="button" class="f137-mini-close" onclick="ascbMasterCloseMarriage()" aria-label="Close">×</button>
        <div class="f137-section-title" style="margin-bottom:6px;">
            <span class="f137-icon">💍</span>
            <div><h3 id="mrMarriageTitle" style="margin:0;">Update after marriage</h3><p style="margin:2px 0 0;font-size:12.5px;color:var(--muted);">Changes the current profile only.</p></div>
        </div>
        <div class="f137-field">
            <label for="mrMarriageCurrent">Current name</label>
            <input type="text" id="mrMarriageCurrent" readonly>
        </div>
        <div class="f137-field">
            <label for="mrMarriageSurname">New surname</label>
            <input type="text" id="mrMarriageSurname" maxlength="100" autocomplete="off" oninput="ascbMasterMarriagePreview()">
            <small class="mr-field-error" id="mrMarriageSurnameError"></small>
        </div>
        <div class="f137-field">
            <label for="mrMarriageCivil">Civil status</label>
            <input type="text" id="mrMarriageCivil" value="Married" readonly>
        </div>
        <div class="f137-field">
            <label for="mrMarriageReason">Reason</label>
            <input type="text" id="mrMarriageReason" value="Marriage" maxlength="255" autocomplete="off">
            <small class="mr-field-error" id="mrMarriageReasonError"></small>
        </div>
        <div class="mr-preview" id="mrMarriagePreview"></div>
        <label class="mr-confirm">
            <input type="checkbox" id="mrMarriageConfirm" onchange="ascbMasterMarriagePreview()">
            <span>I confirm this change. Past enrollments, grades and certificates keep the previous name.</span>
        </label>
        <div class="mr-modal-actions">
            <button type="button" class="btn btn-secondary" onclick="ascbMasterCloseMarriage()">Cancel</button>
            <button type="button" class="btn btn-primary" id="mrMarriageSubmit" onclick="ascbMasterSubmitMarriage()" disabled>Confirm update</button>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- PROFESSOR GRADE SHEET / SUBJECT GRADEBOOK -->
<div class="f137-mini-modal" id="gradebookModal">
    <div class="f137-mini-card f137-mini-card-xl gradebook-card" onclick="event.stopPropagation()">
        <button type="button" class="f137-mini-close" onclick="ascbGradebookClose()">×</button>
        <div class="f137-section-title" style="margin-bottom:10px;">
            <span class="f137-icon">📘</span>
            <div><h3 style="margin:0;">Subject Gradebook</h3><p style="margin:2px 0 0;font-size:12.5px;color:var(--muted);">One subject = one professor grade sheet. Excel needs only Student ID and Grade.</p></div>
        </div>
        <div class="gradebook-toolbar">
            <div class="f137-field gradebook-search-field">
                <label for="gradebookSearchInput">Find student (ID / Name)</label>
                <input type="text" id="gradebookSearchInput" placeholder="Type full name or Student ID…" oninput="ascbGradebookApplyFilter()" autocomplete="off">
            </div>
            <div class="f137-field gradebook-filter-field">
                <label for="gradebookYearSelect">School Year</label>
                <select id="gradebookYearSelect" onchange="ascbGradebookOnYearChange()"><option value="">Loading…</option></select>
            </div>
            <div class="f137-field gradebook-filter-field">
                <label for="gradebookTermSelect">Trimester / Semester</label>
                <select id="gradebookTermSelect" onchange="ascbGradebookOnTermChange()"><option value="">Loading…</option></select>
            </div>
            <div class="f137-field gradebook-subject-field">
                <label for="gradebookSubjectSelect">Subject</label>
                <select id="gradebookSubjectSelect" onchange="ascbGradebookPage=1;ascbGradebookLoad()"><option value="">Loading subjects…</option></select>
            </div>
            <div class="f137-field gradebook-filter-field">
                <label for="gradebookCourseSelect">Course / Program</label>
                <select id="gradebookCourseSelect" onchange="ascbGradebookOnCourseChange()"><option value="">All Courses</option></select>
            </div>
            <div class="gradebook-actions">
                <span class="gradebook-queue-note">Only students without a grade are shown</span>
                <button type="button" class="btn btn-secondary" onclick="ascbGradebookLoad()">⟳ Refresh</button>
                <button type="button" class="btn btn-outline" onclick="ascbGradebookHistoryOpen()">🕘 View Encoding History</button>
                <?php /* TEMPORARILY DISABLED: Import Professor Grade Sheet button
                <button type="button" class="btn btn-outline" id="gradebookImportBtn" onclick="ascbGradebookShowImport()">📥 Import Professor Grade Sheet</button>
                */ ?>
            </div>
        </div>
        <div id="gradebookProgress" class="gradebook-progress" style="display:none"></div>
        <?php /* TEMPORARILY DISABLED: Import Professor Grade Sheet panel
        <div id="gradebookImportPanel" class="gradebook-import-panel" style="display:none">
            <div class="gradebook-import-help"><strong>Professor Excel format</strong><br><code>Student ID | Grade</code><br><span>No Subject column is needed — the selected Gradebook subject is already known by the system.</span></div>
            <input type="file" id="gradebookFile" accept=".xlsx,.csv">
            <div class="gradebook-import-actions">
                <button type="button" class="btn btn-secondary" id="gradebookPreviewBtn" onclick="ascbGradebookImportPreview()">1. Preview</button>
                <button type="button" class="btn btn-danger-solid" id="gradebookCommitBtn" style="display:none" onclick="ascbGradebookImportCommit()">2. Confirm Import</button>
                <button type="button" class="btn btn-outline" onclick="ascbGradebookHideImport()">Cancel</button>
            </div>
            <div id="gradebookImportResult" class="gradebook-import-result"></div>
        </div>
        */ ?>
        <div class="records-status" id="gradebookStatus" style="display:none"></div>
        <div class="gradebook-filter-empty" id="gradebookFilterEmpty" style="display:none">No student matches the search / filter. Clear the search box to see all students.</div>
        <div class="table-wrapper records-table-wrapper gradebook-table-wrapper">
            <table class="records-table gradebook-table">
                <thead><tr><th>Student ID</th><th>Student Name</th><th>Course / Program</th><th>Year Level</th><th>Grade</th><th>Status</th></tr></thead>
                <tbody id="gradebookBody"><tr><td colspan="6" class="records-empty">Select a subject.</td></tr></tbody>
            </table>
        </div>
        <div class="pagination-bar gradebook-pagination-bottom" id="gradebookPagination"></div>
    </div>
</div>

<!-- GRADEBOOK APPROVAL WORKFLOW: one unified, responsive modal -->
<div class="f137-mini-modal gradebook-approvals-overlay" id="gradebookApprovalsModal" onclick="if(event.target===this) ascbGradebookApprovalsClose()">
 <section class="f137-mini-card f137-mini-card-xl gradebook-approvals-card" role="dialog" aria-modal="true" aria-labelledby="gradebookApprovalsTitle" onclick="event.stopPropagation()">
  <header class="gradebook-approvals-header">
   <div class="f137-section-title"><span class="f137-icon">✓</span><div><h3 id="gradebookApprovalsTitle">Grade Approval Workflow</h3><p>Admin Staff → Unit Head → School Registrar (final approval)</p></div></div>
   <button type="button" class="f137-mini-close" onclick="ascbGradebookApprovalsClose()" aria-label="Close Grade Approval Workflow">×</button>
  </header>
  <div class="gradebook-approvals-content">
   <div id="gradebookApprovalsStatus" class="records-status" role="status" aria-live="polite"></div>
   <div class="gradebook-approval-filters">
    <label>Department <select id="gbaDepartmentFilter" onchange="ascbGbaDepartmentChanged()"><option value="">All departments</option></select></label>
    <label>Course <select id="gbaCourseFilter" onchange="ascbGradebookApprovalsRender()"><option value="">All courses</option></select></label>
    <label>Subject <select id="gbaSubjectFilter" onchange="ascbGradebookApprovalsRender()"><option value="">All subjects</option></select></label>
    <label>School Year / Term <select id="gbaTermFilter" onchange="ascbGradebookApprovalsRender()"><option value="">All school years / terms</option></select></label>
    <label>Search <input id="gbaSearchFilter" type="search" placeholder="Student / submission" oninput="ascbGradebookApprovalsRender()"></label>
    <button type="button" id="gbaBulkApproveBtn" class="btn btn-add" style="display:none" onclick="ascbGradebookApprovalsBulkApprove()">Approve all filtered</button>
    <button type="button" id="gbaBulkRejectBtn" class="btn btn-secondary" style="display:none" onclick="ascbGradebookApprovalsBulkReject()">Reject all filtered</button>
   </div>
   <div id="gbaSummary" class="gba-summary" aria-live="polite"></div>
   <div id="gradebookApprovalsList" class="gradebook-approvals-list"></div>
  </div>
  <footer class="gradebook-approvals-footer"><span>Official grades update only after School Registrar final approval.</span><button type="button" class="btn btn-secondary" onclick="ascbGradebookApprovalsLoad()">⟳ Refresh</button></footer>
 </section>
</div>

<!-- GRADEBOOK ENCODING HISTORY -->
<div class="f137-mini-modal" id="gradebookHistoryModal">
    <div class="f137-mini-card f137-mini-card-xl gradebook-history-card" onclick="event.stopPropagation()">
        <button type="button" class="f137-mini-close" onclick="ascbGradebookHistoryClose()">×</button>
        <div class="f137-section-title" style="margin-bottom:10px;">
            <span class="f137-icon">🕘</span>
            <div><h3 style="margin:0;">Grade Encoding History</h3><p id="gradebookHistorySubtitle" style="margin:2px 0 0;font-size:12.5px;color:var(--muted);">Recent grades encoded in Subject Gradebook.</p></div>
        </div>
        <div class="gradebook-history-toolbar">
            <input type="text" id="gradebookHistorySearch" placeholder="Search Student ID, name, subject, or encoder…" oninput="ascbGradebookHistoryLoad(1)">
            <button type="button" class="btn btn-secondary" onclick="ascbGradebookHistoryLoad(1)">⟳ Refresh</button>
        </div>
        <div class="records-status" id="gradebookHistoryStatus" style="display:none"></div>
        <div class="table-wrapper gradebook-history-table-wrapper">
            <table class="records-table">
                <thead><tr><th>Date / Time</th><th>Student ID</th><th>Student Name</th><th>Subject</th><th>Term</th><th>Previous</th><th>New Grade</th><th>Encoded By</th><th>View</th></tr></thead>
                <tbody id="gradebookHistoryBody"><tr><td colspan="9" class="records-empty">No history loaded.</td></tr></tbody>
            </table>
        </div>
        <div class="pagination-bar" id="gradebookHistoryPagination"></div>
    </div>
</div>

<div class="f137-mini-modal" id="gradeManagementModal">
    <div class="f137-mini-card f137-mini-card-lg">
        <button type="button" class="f137-mini-close" onclick="ascbGradeManagementClose()">×</button>
        <div class="f137-section-title" style="margin-bottom:12px;">
            <span class="f137-icon">✏️</span>
            <div><h3 id="gradeMgmtModalName" style="margin:0;">Enter Grades</h3><p id="gradeMgmtModalSub" style="margin:2px 0 0;font-size:12.5px;color:var(--muted);">&nbsp;</p></div>
        </div>
        <div id="gradeMgmtTermTabs" class="grade-mgmt-term-tabs"></div>
        <div id="gradeMgmtEditorBody"></div>
        <div class="records-status" id="gradeMgmtSaveStatus" style="display:none;"></div>
    </div>
</div>

<div class="f137-mini-modal" id="gradeEvalReportModal">

    <div class="f137-mini-card f137-mini-card-lg grade-eval-report-card">

        <div class="grade-eval-report-header">
            <div class="f137-section-title">
                <span class="f137-icon">📋</span>
                <div>
                    <h3 id="gradeEvalReportName">Grade Evaluation</h3>
                    <p id="gradeEvalReportSub">&nbsp;</p>
                </div>
            </div>
            <button type="button" class="f137-mini-close" onclick="ascbGradeEvalCloseReport()" aria-label="Close Grade Evaluation">×</button>
        </div>

        <div class="grade-eval-report-scroll">
            <div id="gradeEvalReportBody"></div>

            <div class="grade-eval-print-actions">
            <div class="f137-field grade-eval-print-select-field">
                <label for="gradeEvalTermSelect">Select Term</label>
                <select id="gradeEvalTermSelect"></select>
            </div>
            <div class="grade-eval-print-buttons">
                <button type="button" class="btn btn-print-action" onclick="ascbGradeEvalPrintTerm()">
                    <span class="btn-icon"></span>
                    <span class="grade-eval-print-btn-text">
                        <strong>Print Selected Term</strong>
                        <small>Short Bond Paper</small>
                    </span>
                </button>
                <button type="button" class="btn btn-print-action" onclick="ascbGradeEvalPrintAll()">
                    <span class="btn-icon"></span>
                    <span class="grade-eval-print-btn-text">
                        <strong>Print All Trimesters</strong>
                        <small>Long Bond Paper</small>
                    </span>
                </button>
            </div>
            </div>
        </div>

    </div>

</div>


<!-- =========================================================
     GRADE EVALUATION PRINT PREVIEW MODAL
     Binuksan ng dalawang Print button sa itaas (Print Selected
     Trimester / Print All Trimesters) BAGO pa man lumabas ang
     browser print dialog — malaking full-screen modal na
     katulad-tulad ng Certificate Preview modal (parehong
     .modal / .modal-window / .modal-toolbar / .modal-print-scroll
     na piraso), para makita muna ng user ang buong balita bago
     siya mag-print. Ang aktwal na content ay nasa loob ng isang
     <iframe> (may sarili itong stylesheet/page-size para hindi
     masira ang layout ng buong app), at ang "Print" button sa
     toolbar ang nagpapalabas ng totoong browser print dialog
     (iframe.contentWindow.print()).
========================================================= -->
<div class="modal" id="gradeEvalPrintPreviewModal">

    <div class="modal-overlay" onclick="ascbGradeEvalClosePrintPreview()"></div>

    <div class="modal-window">

        <div class="modal-toolbar">

            <div>
                <strong id="gradeEvalPrintPreviewTitle">Grade Evaluation Preview</strong>
                <span id="gradeEvalPrintPreviewSub">Ready for printing</span>
            </div>

            <div class="toolbar-buttons">
                <button type="button" class="btn btn-secondary" onclick="ascbGradeEvalClosePrintPreview()">Close</button>
                <button type="button" class="btn btn-add" onclick="ascbGradeEvalPrintNow()">
                    <span class="btn-icon"></span> Print
                </button>
            </div>

        </div>

        <div class="modal-print-scroll">
            <iframe id="gradeEvalPrintFrame" class="grade-eval-print-frame" title="Grade Evaluation Preview"></iframe>
        </div>

    </div>

</div>


<!-- =========================================================
     FORM 137 PREVIEW MODAL
     Opened by "Preview & Generate" once the form validates,
     the same way the Certificates view opens its preview.
========================================================= -->
<div class="modal" id="form137PreviewModal">

    <div class="modal-overlay" onclick="closeForm137Preview()"></div>

    <div class="modal-window">

        <div class="modal-toolbar">
            <div>
                <strong>Form 137-A Request Letter</strong>
                <span>Ready for printing</span>
            </div>

            <div class="toolbar-buttons">
                <button type="button" class="btn btn-secondary" onclick="closeForm137Preview()">Close</button>
                <button type="button" class="btn btn-primary" onclick="printForm137()">Print</button>
            </div>
        </div>

        <div class="modal-print-scroll">
            <article class="f137-paper" id="f137PrintArea">
                <div class="document-header">
                    <img src="Header_ASCB.png" class="letterhead-banner" alt="Andres Soriano Colleges of Bislig, Inc.">
                    <div class="header-subtitle">
                        <p class="header-office">Office of the Registrar</p>
                        <p class="header-email">collegeregistrar.ascb@gmail.com &nbsp;|&nbsp; (086) 853-2306 (PhilCom)</p>
                    </div>
                </div>

                <div class="f137-watermark">
                    <img src="ASCB_LOGO.png" alt="">
                </div>

                <div class="f137-paper-content">
                    <div class="f137-date" id="f137_previewDate"></div>

                    <div class="f137-recipient">
                        <strong>The Principal</strong>
                        <div id="f137_previewSchool">ANDRES SORIANO COLLEGES OF BISLIG, INC.</div>
                        <div id="f137_previewSchoolAddress">Mangagoy, Bislig City</div>
                    </div>

                    <div class="f137-salutation">Sir/Madam:</div>

                    <p class="f137-letter-text">
                        May I have the honor to request for the original copy of the
                        <strong>Form 137-A</strong> of the following student<span id="f137_pluralTag">s</span>
                        who <span id="f137_isAreTag">are</span> temporarily enrolled in this school
                        upon presentation of his/her Form-138 duly signed by the principal.
                    </p>

                    <table class="f137-student-table">
                        <thead>
                            <tr>
                                <th>NAME</th>
                                <th>ADMITTED TO</th>
                                <th>LAST SCHOOL YEAR<br>ATTENDED</th>
                                <th>YEAR &amp; SECTION</th>
                            </tr>
                        </thead>
                        <tbody id="f137_studentTableBody"></tbody>
                    </table>

                    <p class="f137-letter-text-we f137-request-paragraph">
                        We shall highly appreciate your kind consideration of this request
                        and the prompt release of the above-mentioned academic record<span id="f137_pluralTag2">s</span>.
                        <br><br>
                        Thank you very much for your continued cooperation and support.
                    </p>

                    <div class="f137-options">
                        <div><span id="f137_checkFirst" class="f137-print-check"></span> 1st Request</div>
                        <div><span id="f137_checkSecond" class="f137-print-check"></span> 2nd Request</div>
                        <div><span id="f137_checkUrgent" class="f137-print-check"></span> Urgent</div>
                        <div><span id="f137_checkBearer" class="f137-print-check"></span> Please entrust to the bearer</div>
                        <div class="f137-option-wide"><span id="f137_checkCopy" class="f137-print-check"></span> Indicate: Copy for <strong>Andres Soriano Colleges of Bislig, Inc.</strong></div>
                    </div>

                    <div class="f137-signature">
                        <div>Very truly yours,</div>
                        <div class="f137-signature-space"></div>
                        <strong style="text-decoration: underline; text-underline-offset: 2px;">
                            REBECCA P. CAPONONG, MAEd
                        </strong>
                        <span>School Registrar</span>
                    </div>

                    <div class="f137-seal-warning"><strong>NOT VALID WITHOUT</strong><br><strong>SCHOOL SEAL</strong></div>
                </div>
            </article>
        </div>
    </div>
</div>

<div class="f137-mini-modal" id="f137SchoolDialog">
    <div class="f137-mini-card">
        <button type="button" class="f137-mini-close" onclick="closeF137SchoolDialog()">×</button>
        <h3>Add School</h3>
        <input id="f137_newSchoolName" type="text" placeholder="School Name">
        <input id="f137_newSchoolAddress" type="text" placeholder="School Address">
        <button type="button" class="btn btn-primary" onclick="saveF137School()">Add School</button>
    </div>
</div>

<div class="f137-mini-modal" id="f137CourseDialog">
    <div class="f137-mini-card">
        <button type="button" class="f137-mini-close" onclick="closeF137CourseDialog()">×</button>
        <h3>Add Course</h3>
        <input id="f137_newCourseName" type="text" placeholder="e.g. BS Psychology">
        <button type="button" class="btn btn-primary" onclick="saveF137Course()">Add Course</button>
    </div>
</div>

<div class="f137-mini-modal enroll-form-modal" id="enrollEditModal">
    <div class="f137-mini-card f137-mini-card-lg enroll-form-card">
        <button type="button" class="f137-mini-close" onclick="ascbEnrollCloseEdit()">×</button>
        <h3>UPDATE INFORMATION</h3>
        <input type="hidden" id="enroll_edit_id">

        <div class="f137-mini-note">
            Student ID: <strong id="enroll_edit_studentIdDisplay">—</strong> (Permanent Student No.)
        </div>

        <div class="f137-mini-divider">Personal Info</div>
        <div class="f137-form-grid">

            <div class="f137-field">
                <label for="enroll_edit_surname">Surname</label>
                <input id="enroll_edit_surname" type="text" placeholder="e.g. Dela Cruz">
            </div>

            <div class="f137-field">
                <label for="enroll_edit_firstName">Given Name</label>
                <input id="enroll_edit_firstName" type="text" placeholder="e.g. Juan">
            </div>

            <div class="f137-field">
                <label for="enroll_edit_middleName">Middle Name</label>
                <input id="enroll_edit_middleName" type="text" placeholder="e.g. Santos">
            </div>

                            <div class="f137-field">
                                <label for="enroll_edit_suffix">Suffix</label>
                                <select id="enroll_edit_suffix" onchange="ascbEnrollSuffixChanged('enroll_edit')">
                                    <option value="">None</option>
                                    <option value="Jr.">Jr.</option>
                                    <option value="Sr.">Sr.</option>
                                    <option value="II">II</option>
                                    <option value="III">III</option>
                                    <option value="IV">IV</option>
                                    <option value="V">V</option>
                                </select>
                            </div>

                            <div class="f137-field ascb-suffix-psa" id="enroll_edit_suffixPsa" style="grid-column: 1 / -1; display:none;">
                                <label class="ascb-suffix-check">
                                    <input type="checkbox" id="enroll_edit_suffixFirst" onchange="ascbEnrollSuffixToggle('enroll_edit','first_name')">
                                    Suffix on Firstname (Base on PSA)
                                </label>
                                <label class="ascb-suffix-check">
                                    <input type="checkbox" id="enroll_edit_suffixSurname" onchange="ascbEnrollSuffixToggle('enroll_edit','surname')">
                                    Suffix on Lastname (Base on PSA)
                                </label>
                                <small id="enroll_edit_suffixPreview" class="ascb-suffix-preview"></small>
                            </div>

            <div class="f137-field">
                <label for="enroll_edit_sex">Sex</label>
                <select id="enroll_edit_sex">
                    <option value="">Select Sex</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_edit_civilStatus">Civil Status</label>
                <select id="enroll_edit_civilStatus">
                    <option value="">Select Civil Status</option>
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                    <option value="Widowed">Widowed</option>
                    <option value="Separated">Separated</option>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_edit_studentType">Student Type</label>
                <select id="enroll_edit_studentType">
                    <option value="">Select Student Type</option>
                    <option value="Regular">Regular</option>
                    <option value="Transferee">Transferee</option>
                    <option value="Irregular">Irregular</option>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_edit_birthMonth">Birth Date</label>
                <div class="f137-inline">
                    <select id="enroll_edit_birthMonth"><option value="">Month</option></select>
                    <select id="enroll_edit_birthDay"><option value="">Day</option></select>
                    <select id="enroll_edit_birthYear"><option value="">Year</option></select>
                </div>
            </div>

            <div class="f137-field f137-span-2">
                <label for="enroll_edit_birthPlace">Birth Place</label>
                <input id="enroll_edit_birthPlace" type="text" maxlength="255" placeholder="e.g. Bislig City, Surigao del Sur">
            </div>

            <div class="f137-field f137-span-2">
                <label for="enroll_edit_address">Address</label>
                <input id="enroll_edit_address" type="text" placeholder="e.g. Purok 1, Mangagoy, Bislig City">
            </div>

            <div class="f137-field">
                <label for="enroll_edit_mobileNumber">Mobile Number</label>
                <input id="enroll_edit_mobileNumber" type="text" placeholder="e.g. 09171234567" maxlength="20">
            </div>

            <div class="f137-field">
                <label for="enroll_edit_guardianName">Guardian Name</label>
                <input id="enroll_edit_guardianName" type="text" placeholder="e.g. Juana Dela Cruz" maxlength="150">
            </div>

            <div class="f137-field">
                <label for="enroll_edit_email">Email Address</label>
                <input id="enroll_edit_email" type="email" placeholder="e.g. juan@gmail.com" maxlength="254">
            </div>

            <div class="f137-field f137-span-2">
                <label for="enroll_edit_prevSchoolJuniorHs">Junior High School</label>
                <input id="enroll_edit_prevSchoolJuniorHs" type="text" placeholder="e.g. Andres Soriano Colleges of Bislig, Inc.">
            </div>

            <div class="f137-field f137-span-2">
                <label for="enroll_edit_prevSchoolSeniorHs">Senior High School</label>
                <input id="enroll_edit_prevSchoolSeniorHs" type="text" placeholder="e.g. Andres Soriano Colleges of Bislig, Inc.">
            </div>

            <div class="f137-field">
                <label for="enroll_edit_juniorHsGraduated">Junior High School Graduated</label>
                <input id="enroll_edit_juniorHsGraduated" type="text" inputmode="numeric" maxlength="9" pattern="\d{4}-\d{4}" placeholder="YYYY-YYYY" title="Use YYYY-YYYY, e.g. 2020-2021">
            </div>

            <div class="f137-field">
                <label for="enroll_edit_seniorHsGraduated">Senior High School Graduated</label>
                <input id="enroll_edit_seniorHsGraduated" type="text" inputmode="numeric" maxlength="9" pattern="\d{4}-\d{4}" placeholder="YYYY-YYYY" title="Use YYYY-YYYY, e.g. 2022-2023">
            </div>

        </div>

        <div class="f137-mini-divider">Academic Info</div>
        <div class="f137-form-grid">

            <div class="f137-field f137-span-2">
                <label for="enroll_edit_program">Course / Program</label>
                <select id="enroll_edit_program" onchange="ascbEnrollProgramChanged('enroll_edit_program', 'enroll_edit_major', 'enroll_edit_subjectRows', 'enroll_edit_trimester')">
                    <?php foreach ($ascbProgramOptions as $code => $label): ?>
                    <option value="<?php echo htmlspecialchars($code); ?>"><?php echo htmlspecialchars($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_edit_major">Major</label>
                <input id="enroll_edit_major" type="text" placeholder="Automatic Fill the Major" readonly>
            </div>

            <div class="f137-field">
                <label for="enroll_edit_yearLevel">Year Level</label>
                <select id="enroll_edit_yearLevel">
                    <option value="">Select Year Level</option>
                    <option>1st Year</option>
                    <option>2nd Year</option>
                    <option>3rd Year</option>
                    <option>4th Year</option>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_edit_trimester">Trimester</label>
                <select id="enroll_edit_trimester">
                    <option value="">Select Trimester</option>
                    <option>1st Trimester</option>
                    <option>2nd Trimester</option>
                    <option>3rd Trimester</option>
                    </select>
            </div>

            <div class="f137-field">
                <label for="enroll_edit_schoolYear">School Year</label>
                <input id="enroll_edit_schoolYear" type="text" placeholder="e.g. 2025-2026">
            </div>

        </div>

        <div class="subjects-header" style="margin-top:2px;">
            <div class="subjects-header-text">
                <h3 style="margin:0 0 4px;">SUBJECTS</h3>
                <p style="margin:0;">Load subjects from the prospectus, o idagdag mo mismo. <strong>Grades are entered in Grade Management.</strong></p>
            </div>
            <div class="subjects-header-actions">
                <button type="button" class="btn btn-outline" onclick="ascbEnrollAddSubjectsForTerm('enroll_edit_subjectRows', 'enroll_edit_program', 'enroll_edit_yearLevel', 'enroll_edit_trimester')">
                    <span class="btn-icon">⬇</span> Load Subjects for Term
                </button>
                <button type="button" class="btn btn-add" onclick="ascbEnrollAddSubjectRow('enroll_edit_subjectRows')">
                    <span class="btn-icon">+</span> Add Subject
                </button>
            </div>
        </div>

        <div class="table-wrapper">
            <table class="subject-input-table">
                <thead>
                    <tr>
                        <th width="22%">Course Code</th>
                        <th width="33%">Course Description</th>
                        <th width="15%">Units</th>
                        <th width="25%">Action</th>
                    </tr>
                </thead>
                <tbody id="enroll_edit_subjectRows"></tbody>
            </table>
        </div>

        <button type="button" class="btn btn-primary" onclick="ascbEnrollSubmitEdit()" style="margin-top: 12px;">Save Changes</button>
        <div class="records-status" id="enrollEditStatus" style="display:none;"></div>
    </div>
</div>

<div class="f137-mini-modal enroll-form-modal" id="enrollNewTermModal">
    <div class="f137-mini-card f137-mini-card-lg enroll-form-card">
        <button type="button" class="f137-mini-close" onclick="ascbEnrollCloseNewTerm()" aria-label="Close New Term Enrollment">×</button>
        <h3>New Term Enrollment</h3>
        <input type="hidden" id="enroll_newterm_sourceId">
        <input type="hidden" id="enroll_newterm_studentId">

        <div class="f137-mini-note">
            Student ID: <strong id="enroll_newterm_studentIdDisplay">—</strong>
        </div>

        <!-- Basic Info: hindi na ipinapakita/ine-edit dito — kinokopya
             lang mula sa napiling estudyante papunta sa hidden fields
             (nasa ascbEnrollOpenNewTerm sa script.js), para hindi
             magulo. Gamitin ang "Update" kung may itatama sa basic
             info ng estudyante. -->
        <div class="f137-mini-note">
            Student: <strong id="enroll_newterm_nameDisplay">—</strong>
        </div>
        <input type="hidden" id="enroll_newterm_surname">
        <input type="hidden" id="enroll_newterm_firstName">
        <input type="hidden" id="enroll_newterm_middleName">
        <input type="hidden" id="enroll_newterm_suffix">
        <input type="hidden" id="enroll_newterm_suffixPosition">
        <input type="hidden" id="enroll_newterm_sex">
        <input type="hidden" id="enroll_newterm_civilStatus">
        <input type="hidden" id="enroll_newterm_email">
        <input type="hidden" id="enroll_newterm_birthDate">
        <input type="hidden" id="enroll_newterm_birthPlace">
        <input type="hidden" id="enroll_newterm_address">
        <input type="hidden" id="enroll_newterm_mobileNumber">
        <input type="hidden" id="enroll_newterm_guardianName">
        <input type="hidden" id="enroll_newterm_prevSchoolJuniorHs">
        <input type="hidden" id="enroll_newterm_prevSchoolSeniorHs">
        <input type="hidden" id="enroll_newterm_juniorHsGraduated">
        <input type="hidden" id="enroll_newterm_seniorHsGraduated">

        <!-- (design) Read-only na buod: kita lahat ng Personal Information
             at School Background. Gamitin ang "Update" para mag-edit. -->
        <div class="enroll-form-summary">
            <section class="enroll-form-summary-card">
                <div class="enroll-form-summary-head"><span>Student profile</span><h4>Personal Information</h4></div>
                <div class="enroll-form-ro-grid">
                <div class="enroll-form-ro"><span>Sex</span><strong id="enroll_newterm_view_sex">—</strong></div>
                <div class="enroll-form-ro"><span>Civil Status</span><strong id="enroll_newterm_view_civilStatus">—</strong></div>
                <div class="enroll-form-ro"><span>Gmail / Email</span><strong id="enroll_newterm_view_email">—</strong></div>
                <div class="enroll-form-ro"><span>Birth Date</span><strong id="enroll_newterm_view_birthDate">—</strong></div>
                <div class="enroll-form-ro"><span>Birth Place</span><strong id="enroll_newterm_view_birthPlace">—</strong></div>
                <div class="enroll-form-ro"><span>Mobile Number</span><strong id="enroll_newterm_view_mobileNumber">—</strong></div>
                <div class="enroll-form-ro"><span>Guardian</span><strong id="enroll_newterm_view_guardianName">—</strong></div>
                <div class="enroll-form-ro enroll-form-ro--full"><span>Address</span><strong id="enroll_newterm_view_address">—</strong></div>
                </div>
            </section>
            <section class="enroll-form-summary-card">
                <div class="enroll-form-summary-head"><span>Previous education</span><h4>School Background</h4></div>
                <div class="enroll-form-ro-grid">
                <div class="enroll-form-ro enroll-form-ro--full"><span>Junior High School</span><strong id="enroll_newterm_view_prevSchoolJuniorHs">—</strong></div>
                <div class="enroll-form-ro enroll-form-ro--full"><span>Senior High School</span><strong id="enroll_newterm_view_prevSchoolSeniorHs">—</strong></div>
                <div class="enroll-form-ro"><span>JHS Graduated</span><strong id="enroll_newterm_view_juniorHsGraduated">—</strong></div>
                <div class="enroll-form-ro"><span>SHS Graduated</span><strong id="enroll_newterm_view_seniorHsGraduated">—</strong></div>
                </div>
            </section>
        </div>

        <div class="f137-mini-divider">NEW TERM</div>

        <div class="f137-form-grid">

            <div class="f137-field">
                <label for="enroll_newterm_studentType">Student Type</label>
                <select id="enroll_newterm_studentType">
                    <option value="">Select Student Type</option>
                    <option value="Regular">Regular</option>
                    <option value="Transferee">Transferee</option>
                    <option value="Irregular">Irregular</option>
                </select>
            </div>

            <div class="f137-field f137-span-2">
                <label for="enroll_newterm_program">Course / Program</label>
                <select id="enroll_newterm_program" onchange="ascbEnrollProgramChanged('enroll_newterm_program', 'enroll_newterm_major', 'enroll_newterm_subjectRows', 'enroll_newterm_trimester')">
                    <?php foreach ($ascbProgramOptions as $code => $label): ?>
                    <option value="<?php echo htmlspecialchars($code); ?>"><?php echo htmlspecialchars($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_newterm_major">Major</label>
                <input id="enroll_newterm_major" type="text" placeholder="Automatic Fill the Major" readonly>
            </div>

            <div class="f137-field">
                <label for="enroll_newterm_yearLevel">Year Level</label>
                <select id="enroll_newterm_yearLevel">
                    <option value="">Select Year Level</option>
                    <option>1st Year</option>
                    <option>2nd Year</option>
                    <option>3rd Year</option>
                    <option>4th Year</option>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_newterm_trimester">Trimester</label>
                <select id="enroll_newterm_trimester">
                    <option value="">Select Trimester</option>
                    <option>1st Trimester</option>
                    <option>2nd Trimester</option>
                    <option>3rd Trimester</option>
                    </select>
            </div>

            <div class="f137-field">
                <label for="enroll_newterm_schoolYear">School Year</label>
                <input id="enroll_newterm_schoolYear" type="text" placeholder="e.g. 2025-2026">
            </div>

        </div>

        <div class="subjects-header">
            <div class="subjects-header-text">
                <h3 style="margin:0 0 4px;">SUBJECTS</h3>
                <p style="margin:0;">Load subjects from the prospectus, o idagdag mo mismo. <strong>Grades are entered in Grade Management.</strong></p>
            </div>
            <div class="subjects-header-actions">
                <button type="button" class="btn btn-outline" onclick="ascbEnrollAddSubjectsForTerm('enroll_newterm_subjectRows', 'enroll_newterm_program', 'enroll_newterm_yearLevel', 'enroll_newterm_trimester')">
                    <span class="btn-icon">⬇</span> Load Subjects for Term
                </button>
                <button type="button" class="btn btn-add" onclick="ascbEnrollAddSubjectRow('enroll_newterm_subjectRows')">
                    <span class="btn-icon">+</span> Add Subject
                </button>
            </div>
        </div>

        <div class="table-wrapper">
            <table class="subject-input-table">
                <thead>
                    <tr>
                        <th width="22%">Course Code</th>
                        <th width="33%">Course Description</th>
                        <th width="15%">Units</th>
                        <th width="25%">Action</th>
                    </tr>
                </thead>
                <tbody id="enroll_newterm_subjectRows"></tbody>
            </table>
        </div>

        <button type="button" class="btn btn-primary" onclick="ascbEnrollSubmitNewTerm()" style="margin-top: 12px;">Save New Term</button>
        <div class="records-status" id="enrollNewTermStatus" style="display:none;"></div>
    </div>
</div>

<div class="f137-mini-modal" id="soEditModal">
    <div class="f137-mini-card">
        <button type="button" class="f137-mini-close" onclick="ascbSoCloseEdit()">×</button>
        <h3>Edit Approved SO</h3>
        <input type="hidden" id="so_edit_id">
        <input id="so_edit_name" type="text" placeholder="Name">
        <label for="so_edit_file" class="actions-inline-label" style="display:block; margin: 10px 0 6px;">
            Replace PDF file (optional — iwan lang na blangko para panatilihin ang luma)
        </label>
        <input id="so_edit_file" type="file" accept="application/pdf">
        <button type="button" class="btn btn-primary" onclick="ascbSoSubmitEdit()" style="margin-top: 12px;">Save Changes</button>
        <div class="records-status" id="soEditStatus" style="display:none;"></div>
    </div>
</div>

<div class="f137-mini-modal" id="staffAssignmentModal" aria-hidden="true">
    <div class="f137-mini-card staff-assignment-modal-card" role="dialog" aria-modal="true" aria-labelledby="staffAssignmentModalTitle">
        <button type="button" class="f137-mini-close" onclick="ascbCloseStaffAssignment()" aria-label="Close staff assignment">×</button>
        <h3 id="staffAssignmentModalTitle">Department &amp; Program Assignment</h3>
        <p class="staff-assignment-modal-subtitle">Piliin ang departments at courses na puwedeng ma-access ng Admin Staff o Dean.</p>
        <iframe id="staffAssignmentFrame" title="Staff department and program assignments" src="about:blank" loading="lazy"></iframe>
    </div>
</div>
<style>
#staffAssignmentModal .staff-assignment-modal-card{width:min(980px,96vw);max-width:980px;padding:22px 24px 20px;max-height:94vh;overflow:hidden;display:flex;flex-direction:column;gap:0;border-radius:18px;position:relative;}
#staffAssignmentModal h3{margin:0 40px 4px 0;font-size:21px;color:var(--text-primary,#17243b);}
#staffAssignmentModal .staff-assignment-modal-subtitle{margin:0 0 14px;color:var(--text-secondary,#64748b);font-size:13px;line-height:1.5;}
#staffAssignmentFrame{width:100%;height:min(72vh,700px);border:1px solid var(--border-color,#dce4ef);border-radius:14px;background:#f5f7fb;display:block;}
#staffAssignmentModal.loading .staff-assignment-modal-card::after{content:"";position:absolute;left:50%;top:55%;width:34px;height:34px;margin:-17px 0 0 -17px;border:3px solid #cfe0f7;border-top-color:#0a6ed9;border-radius:50%;animation:saSpin .8s linear infinite;}
#staffAssignmentModal.loading #staffAssignmentFrame{opacity:.25;}
@keyframes saSpin{to{transform:rotate(360deg)}}
[data-theme="dark"] #staffAssignmentFrame{background:#0f2238;border-color:#27425f;}
@media(max-width:640px){#staffAssignmentModal .staff-assignment-modal-card{width:100%;max-width:100%;height:96vh;max-height:96vh;padding:18px 12px;border-radius:16px;}#staffAssignmentFrame{height:calc(96vh - 130px);min-height:400px;}}
</style>

<div class="f137-mini-modal" id="userEditModal">
    <div class="f137-mini-card">
        <button type="button" class="f137-mini-close" onclick="ascbUserCloseEdit()">×</button>
        <h3>Edit Account</h3>
        <input type="hidden" id="user_edit_id">
        <input id="user_edit_displayName" type="text" placeholder="Full Name" style="margin-bottom:10px;">
        <select id="user_edit_role" style="margin-bottom:10px;" onchange="ascbUserToggleStudentField('user_edit_role','user_edit_studentIdField')">
            <option value="ADMIN STAFF">ADMIN STAFF</option>
            <option value="SCHOOL REGISTRAR">SCHOOL REGISTRAR</option>
            <option value="UNIT HEAD">UNIT HEAD</option>
            <option value="DEAN">DEAN</option>
            <option value="STUDENT">STUDENT</option>
        </select>
        <select id="user_edit_departmentId" style="margin-bottom:10px;"><option value="">— Assigned Department —</option></select>
        <div id="user_edit_studentIdField" style="display:none;">
            <input id="user_edit_studentId" type="text" maxlength="50" placeholder="Student ID (required for STUDENT)" autocomplete="off" style="margin-bottom:10px;">
        </div>
        <input id="user_edit_preparedByCode" type="text" placeholder="Prepared By Code (optional)" style="margin-bottom:10px;">
        <input id="user_edit_username" type="text" placeholder="Username" style="margin-bottom:10px;">
        <label for="user_edit_password" class="actions-inline-label" style="display:block; margin: 10px 0 6px;">
            New Password (optional — iwan lang na blangko para panatilihin ang luma)
        </label>
        <input id="user_edit_password" type="password" placeholder="Bagong password">
        <button type="button" class="btn btn-primary" onclick="ascbUserSubmitEdit()" style="margin-top: 12px;">Save Changes</button>
        <div class="records-status" id="userEditStatus" style="display:none;"></div>
    </div>
</div>

<div class="f137-mini-modal" id="progEditModal">
    <div class="f137-mini-card">
        <button type="button" class="f137-mini-close" onclick="ascbAdminProgCloseEdit()">×</button>
        <h3>Update Course - Program</h3>
        <input type="hidden" id="admProg_edit_id">
        <label for="admProg_edit_departmentId" class="actions-inline-label" style="display:block; margin-bottom:4px;">Department</label>
        <select id="admProg_edit_departmentId" style="margin-bottom:10px;"><option value="">— Select Department —</option></select>
        <label for="admProg_edit_code" class="actions-inline-label" style="display:block; margin-bottom:4px;">Course Code</label>
        <input id="admProg_edit_code" type="text" placeholder="e.g. BSHM" style="margin-bottom:10px;">
        <label for="admProg_edit_courseName" class="actions-inline-label" style="display:block; margin-bottom:4px;">Course Name</label>
        <input id="admProg_edit_courseName" type="text" placeholder="Course Name" style="margin-bottom:10px;">
        <label for="admProg_edit_major" class="actions-inline-label" style="display:block; margin-bottom:4px;">Major (optional)</label>
        <input id="admProg_edit_major" type="text" placeholder="Major" style="margin-bottom:10px;">
        <label for="admProg_edit_termType" class="actions-inline-label" style="display:block; margin-bottom:4px;">Term System</label>
        <select id="admProg_edit_termType" style="margin-bottom:10px;">
            <option value="Trimester">Trimester</option>
            <option value="Semester">Semester</option>
        </select>
        <label class="actions-inline-label" style="display:flex; align-items:center; gap:8px; margin-bottom:10px;">
            <input type="checkbox" id="admProg_edit_isActive"> Active 
        </label>
        <button type="button" class="btn btn-primary" onclick="ascbAdminProgSubmitEdit()" style="margin-top:4px;">Save Changes</button>
        <div class="records-status" id="admProgEditStatus" style="display:none;"></div>
    </div>
</div>

<div class="f137-mini-modal" id="progSubjectsModal">
    <div class="f137-mini-card records-detail-card">
        <button type="button" class="f137-mini-close" onclick="ascbAdminProgSubjClose()">×</button>
        <h3 id="progSubjModalTitle">Manage Subjects</h3>
        <p id="progSubjModalSubtitle" style="margin:-6px 0 14px; color:var(--f137-muted, #667085); font-size:.9rem;"></p>

        <div class="f137-form-grid">
            <div class="f137-field">
                <label for="admProgSubj_yearLevel">Year Level</label>
                <select id="admProgSubj_yearLevel">
                    <option value="">Select Year Level</option>
                    <option>1st Year</option>
                    <option>2nd Year</option>
                    <option>3rd Year</option>
                    <option>4th Year</option>
                </select>
            </div>
            <div class="f137-field">
                <label for="admProgSubj_termLabel" id="admProgSubj_termLabelLabel">Trimester</label>
                <select id="admProgSubj_termLabel"></select>
            </div>
            <div class="f137-field">
                <label for="admProgSubj_code">Subject Code</label>
                <input id="admProgSubj_code" type="text" placeholder="e.g. HM 101">
            </div>
            <div class="f137-field">
                <label for="admProgSubj_units">Units</label>
                <input id="admProgSubj_units" type="number" step="0.5" min="0" placeholder="3">
            </div>
            <div class="f137-field f137-span-2">
                <label for="admProgSubj_description">Subject Description</label>
                <input id="admProgSubj_description" type="text" placeholder="e.g. Introduction to Hospitality Management">
            </div>
        </div>
        <input type="hidden" id="admProgSubj_editId">
        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <button type="button" class="btn btn-primary" id="admProgSubjAddBtn" onclick="ascbAdminProgSubjectSave()">
                <span class="btn-icon">+</span> Add Subject
            </button>
            <button type="button" class="btn btn-outline" id="admProgSubjCancelEditBtn" onclick="ascbAdminProgSubjectCancelEdit()" style="display:none;">
                Cancel Edit
            </button>
        </div>
        <div class="records-status" id="admProgSubjFormStatus" style="display:none;"></div>

        <div class="table-wrapper" style="margin-top:16px;">
            <table class="records-table" id="admProgSubjTable">
                <thead>
                    <tr>
                        <th>Year Level</th>
                        <th>Term</th>
                        <th>Code</th>
                        <th>Description</th>
                        <th>Units</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="admProgSubjTableBody"></tbody>
            </table>
        </div>
        <div class="records-status" id="admProgSubjListStatus">Loading…</div>
    </div>
</div>

<div class="f137-mini-modal" id="recordsDetailModal">
    <div class="f137-mini-card records-detail-card">
        <button type="button" class="f137-mini-close" onclick="ascbCloseRecordsDetail()">×</button>
        <h3 id="recordsDetailTitle">Details</h3>
        <div id="recordsDetailBody"></div>
    </div>
</div>

<div class="f137-mini-modal enroll-detail-modal" id="enrollDetailModal">
    <div class="f137-mini-card records-detail-card enroll-detail-card">
        <button type="button" class="f137-mini-close" onclick="ascbEnrollCloseDetail()">×</button>
        <h3 id="enrollDetailTitle">Details</h3>
        <div id="enrollDetailBody"></div>
    </div>
</div>


    <div class="ascb-confirm-overlay" id="ascbLogoutModal">
        <div class="ascb-confirm-card">
            <div class="ascb-confirm-icon">🔒</div>
            <h3>Log Out</h3>
            <p>Are you sure you want to log out of the registrar system?</p>
            <div class="ascb-confirm-actions">
                <button type="button" class="btn btn-outline" onclick="ascbCancelLogout()">Cancel</button>
                <button type="button" class="btn btn-danger-solid" onclick="ascbLogout()">Yes, Logout</button>
            </div>
        </div>
    </div>

<script>
    /* Data mula sa MySQL database (config/db.php), inihanda ng
       dashboard.php — script.js gagamit nito sa halip na
       localStorage para sa Schools/Courses dropdown. */
    const ASCB_SCHOOLS = <?php echo json_encode($ascbSchools, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
    const ASCB_COURSES = <?php echo json_encode(array_column($ascbCourses, 'name'), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
    const ASCB_CURRENT_USER = <?php echo json_encode($ascbUser, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
    const ASCB_PERMISSIONS = <?php echo json_encode($ascbPermissions, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
    const ASCB_CSRF_TOKEN = <?php echo json_encode(ascb_csrf_token(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;

    /* All program names, terms, and subjects are sourced from the database. */
    const ASCB_CUSTOM_PROGRAMS = <?php echo json_encode($ascbCustomProgramsData['structured'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
    const ASCB_CUSTOM_PROGRAM_NAMES = <?php echo json_encode($ascbCustomProgramsData['names'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
    const ASCB_CUSTOM_PROGRAM_TERM_TYPES = <?php echo json_encode($ascbCustomProgramsData['termTypes'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
    const ASCB_PROGRAM_CODES = <?php echo json_encode(array_values(array_filter(array_keys($ascbProgramOptions))), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
</script>
<script src="js/qrcode.js?v=<?php echo (int) @filemtime(__DIR__ . '/js/qrcode.js'); ?>"></script>
<script src="script.js?v=<?php echo (int) @filemtime(__DIR__ . '/script.js'); ?>"></script>
<script>
/* Dashboard-only Christmas music. The melody is synthesized in-browser so no
   external audio file or third-party asset is added. Browser autoplay rules
   require a user interaction before sound can begin. */
(function () {
    var audioCtx = null;
    var timer = null;
    var musicStarted = false;
    var musicMuted = false;
    var noteIndex = 0;

    // Jingle Bells — start directly at the chorus and loop the chorus only.
    // No intro/verse is played before the chorus.
    var melody = [
        ['E4',.28],['E4',.28],['E4',.56],
        ['E4',.28],['E4',.28],['E4',.56],
        ['E4',.28],['G4',.28],['C4',.42],['D4',.14],['E4',.70],
        ['F4',.28],['F4',.28],['F4',.42],['F4',.14],['F4',.28],
        ['E4',.28],['E4',.28],['E4',.14],['E4',.14],
        ['E4',.28],['D4',.28],['D4',.28],['E4',.28],['D4',.56],['G4',.56]
    ];
    var freqs = {C4:261.63,D4:293.66,E4:329.63,F4:349.23,G4:392.00};

    function isDashboardActive() {
        var view = document.getElementById('dashboardView');
        return !!(view && view.classList.contains('active-view'));
    }

    function playNote(name, seconds) {
        if (!audioCtx || musicMuted || !isDashboardActive()) return;
        var now = audioCtx.currentTime;
        var osc = audioCtx.createOscillator();
        var gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freqs[name] || 329.63;
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(0.085, now + 0.025);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + Math.max(0.08, seconds * 0.88));
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(now);
        osc.stop(now + Math.max(0.1, seconds));
    }

    function tick() {
        if (!isDashboardActive()) {
            stopMusic();
            return;
        }
        var item = melody[noteIndex % melody.length];
        playNote(item[0], item[1]);
        noteIndex++;
        timer = window.setTimeout(tick, item[1] * 1000 + 45);
    }

    function startMusic() {
        if (!isDashboardActive() || musicStarted || musicMuted) return;
        try {
            audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
            if (audioCtx.state === 'suspended') audioCtx.resume();
            musicStarted = true;
            noteIndex = 0;
            tick();
        } catch (e) {}
    }

    function stopMusic() {
        if (timer) { window.clearTimeout(timer); timer = null; }
        musicStarted = false;
    }

    window.ascbDashboardChristmasMusic = {
        start: startMusic,
        stop: stopMusic,
        toggle: function () {
            // First click must PLAY (not mute). After playback has started,
            // subsequent clicks toggle mute/play.
            if (!musicStarted) {
                musicMuted = false;
                startMusic();
            } else {
                musicMuted = !musicMuted;
                if (musicMuted) stopMusic(); else startMusic();
            }
            var btn = document.getElementById('dashboardMusicToggle');
            if (btn) btn.textContent = musicMuted ? '🔇 Music' : '🔔 Music';
        }
    };

    // Browser autoplay rules require a user gesture. The Music button itself
    // provides that gesture, so playback starts reliably on its first click.

    // If the user changes views, the song stops; returning to Dashboard can
    // start it again on the next interaction.
    window.setInterval(function () {
        if (!isDashboardActive()) stopMusic();
    }, 500);
})();
</script>
<script>
(function () {
    var dashboard = document.getElementById('dashboardView');
    if (!dashboard || document.getElementById('dashboardMusicToggle')) return;
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.id = 'dashboardMusicToggle';
    btn.className = 'dashboard-music-toggle';
    btn.textContent = '🔔 Music';
    btn.title = 'Play Jingle Bells chorus / mute music';
    btn.setAttribute('aria-label', 'Play Jingle Bells chorus or mute music');
    btn.onclick = function () {
        if (window.ascbDashboardChristmasMusic) window.ascbDashboardChristmasMusic.toggle();
    };

    // Place the Music control directly above the digital clock.
    var clockInfo = dashboard.querySelector('.dashboard-clock-info');
    var digitalClock = document.getElementById('dashboardDigitalClock');
    if (clockInfo && digitalClock) {
        clockInfo.insertBefore(btn, digitalClock);
    } else {
        dashboard.appendChild(btn);
    }
})();
</script>
<script>
    ascbRestoreLastView();
</script>



</body>
</html>
