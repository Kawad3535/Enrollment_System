<?php
/* =========================================================
   SMALL HELPER — PHP 5.6 COMPATIBLE
   ---------------------------------------------------------
   Ginagamit sa halip na ang `??` (null coalescing) operator,
   dahil hindi ito suportado bago PHP 7.0 (kasama ang PHP na
   bundled sa mas lumang XAMPP releases).
   ========================================================= */

if (!function_exists('ascb_get')) {
    function ascb_get($array, $key, $default = null) {
        return (is_array($array) && isset($array[$key])) ? $array[$key] : $default;
    }
}


if (!function_exists('ascb_first_initial')) {
    function ascb_first_initial($value) {
        $value = trim((string) $value);
        if ($value === '') return '?';
        if (function_exists('mb_substr') && function_exists('mb_strtoupper')) {
            return mb_strtoupper(mb_substr($value, 0, 1, 'UTF-8'), 'UTF-8');
        }
        return strtoupper(substr($value, 0, 1));
    }
}

if (!function_exists('ascb_text_too_long')) {
    function ascb_text_too_long($value, $max) {
        $value = (string) $value;
        $len = function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
        return $len > (int) $max;
    }
}

if (!function_exists('ascb_clean_numeric_string')) {
    /* Nililinis ang mga numeric string (grade, units) na may floating-point
       imprecision — hal. "1.1000000000000001" o "2.0999999999999996" —
       bunga ng pag-convert papunta't pabalik sa float. Bumabalik ng
       "1.1" / "2.1". Mga non-numeric na value (INC, DRP, NG, blangko)
       ay hindi ginagalaw. */
    function ascb_clean_numeric_string($value) {
        $value = trim((string) $value);
        if ($value === '' || !is_numeric($value)) return $value;
        $num = round((float) $value, 4);
        $str = rtrim(rtrim(sprintf('%.4F', $num), '0'), '.');
        if ($str === '' || $str === '-0') $str = '0';
        return $str;
    }
}

if (!function_exists('ascb_normalize_grade')) {
    /* STANDARDIZED GRADE FORMAT — laging isang decimal place ang numeric
       grades (hal. "2" -> "2.0", "1.5" -> "1.5", "3.00" -> "3.0"), para
       consistent kahit saan pumasok ang grade (Grade Management, Grade
       Import, Record Corrections). Ito ang tinatawag na "standard" na
       format ng system. Non-numeric (INC/DRP/NG) ay iniuuppercase lang;
       blangko ay nananatiling blangko. Hindi ito ang validator — dapat
       munang pumasa sa ascb_grade_valid()/rc_grade_valid()/
       ascb_gi_grade_valid() bago ito tawagin. */
    function ascb_normalize_grade($grade) {
        $grade = trim((string) $grade);
        if ($grade === '') return '';
        /* (Dr.) Ang "Dropped" na grade ay laging naka-save/ipinapakita bilang
           "Dr." (hindi "DRP"). Tinatanggap pa rin ang "DRP", "DR", "dr.",
           "drp" na input — lahat ay ginagawang "Dr.". Ang INC/NG ay
           iniuuppercase lang. */
        if (preg_match('/^(DRP|DR\.?)$/i', $grade)) {
            return 'Dr.';
        }
        /* (Dash) "-" (o en/em dash) = walang grade/hindi applicable (hal.
           Comprehensive Exam ng Semester-based na Program). Laging "-" ang
           naka-save; hindi ito bagsak at hindi kasama sa GWA. */
        if (preg_match('/^[-–—]$/u', $grade)) {
            return '-';
        }
        if (preg_match('/^(INC|NG)$/i', $grade)) {
            return strtoupper($grade);
        }
        /* (P) "Passed" — ginagamit sa mga hindi-numeric na subject tulad
           ng Thesis Writing / Comprehensive Exam (Promotional Report
           template ng paaralan). Laging naka-save bilang "P"; hindi ito
           bagsak (tingnan ascb_grade_is_failing()). */
        if (preg_match('/^(P|PASSED)$/i', $grade)) {
            return 'P';
        }
        if (is_numeric($grade)) {
            return number_format((float) $grade, 1, '.', '');
        }
        return $grade;
    }
}

if (!function_exists('ascb_read_json_body')) {
    /* AI/API PAYLOAD LIMIT — ligtas na pagbasa ng JSON request body.
       Ginagamit ito sa halip na ang direktang
       "json_decode(file_get_contents('php://input'), true)" na
       paulit-ulit na pattern sa mga api/*.php — para may isang lugar
       lang na nagpapatupad ng maximum na laki (ASCB_MAX_JSON_PAYLOAD_KB,
       config/app.php) BAGO pa man i-decode ang laman. Kapag lumagpas
       sa limitasyon, agad na tumitigil ito gamit ang 413 Payload Too
       Large — hindi na kailangang i-load pa ang buong sobrang-laking
       body sa memory (mahalaga rin ito balang-araw kung magdagdag ng
       AI/LLM-backed na feature na tumatanggap ng JSON prompt/context —
       parehong function ang gagamitin para may consistent na limit). */
    function ascb_read_json_body($maxBytes = null) {
        if ($maxBytes === null) {
            $maxBytes = (defined('ASCB_MAX_JSON_PAYLOAD_KB') ? ASCB_MAX_JSON_PAYLOAD_KB : 512) * 1024;
        }

        $contentLength = isset($_SERVER['CONTENT_LENGTH']) ? (int) $_SERVER['CONTENT_LENGTH'] : 0;
        if ($contentLength > $maxBytes) {
            http_response_code(413);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('ok' => false, 'error' => 'The request body exceeds the allowed size.'));
            exit;
        }

        $fh = fopen('php://input', 'rb');
        if ($fh === false) return array();
        $raw = '';
        $read = 0;
        while (!feof($fh)) {
            $chunk = fread($fh, 8192);
            if ($chunk === false) break;
            $read += strlen($chunk);
            if ($read > $maxBytes) {
                fclose($fh);
                http_response_code(413);
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(array('ok' => false, 'error' => 'The request body exceeds the allowed size.'));
                exit;
            }
            $raw .= $chunk;
        }
        fclose($fh);

        if ($raw === '') return array();
        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : array();
    }
}

if (!function_exists('ascb_grade_is_failing')) {
    /* "Bagsak" / failing grade detection — ginagamit sa Grade Management
       (api/grades.php), Grade Import (api/grade_import.php), at Record
       Corrections (api/record_corrections.php) para malaman kung ang
       subject ay dapat AUTOMATIC na maging ZERO ang units.
       Itinuturing na "bagsak": 4.00 pataas na numeric grade (kasama ang
       5.00), o INC/DRP/NG. Blangkong grade (wala pang grade) ay HINDI
       bagsak — hindi pa dapat galawin ang units habang wala pang grade. */
    function ascb_grade_is_failing($grade) {
        $grade = trim((string) $grade);
        if ($grade === '') return false;
        if (preg_match('/^(INC|DRP|DR\.?|NG)$/i', $grade)) return true;
        if (preg_match('/^(P|PASSED)$/i', $grade)) return false; // "Passed" — hindi bagsak
        if (preg_match('/^[-–—]$/u', $grade)) return false; // Dash is a valid graded/non-applicable value; units are displayed as '-'.
        if (is_numeric($grade)) return ((float) $grade > 0 && (float) $grade >= 4); // 0/0.0 = not graded.
        return false;
    }
}

/* =========================================================
   SUFFIX + PSA PLACEMENT  (Jr., Sr., II, III ...)
   ---------------------------------------------------------
   Ang pangalan ng estudyante ay dapat lumabas EKSAKTONG kapareho
   ng nasa PSA Birth Certificate niya (TOR, Diploma, Certificates).
   May mga lumang PSA na nakasama ang "Jr." sa First Name field
   ("Juan Jr."), at mayroon namang nakasama sa Surname ("Santos Jr.").

   Kaya hiwalay ang suffix sa database (para malinis ang search at
   sorting), at may "suffix_position" na nagsasabi kung SAAN ito
   ilalagay kapag inilabas ang pangalan:

     'separate'   -> Santos, Juan Reyes Jr.   (default, walang pagbabago)
     'first_name' -> Santos, Juan Jr. Reyes   (per PSA: kasama sa First Name)
     'surname'    -> Santos Jr., Juan Reyes   (per PSA: kasama sa Surname)
   ========================================================= */
if (!function_exists('ascb_normalize_suffix_position')) {
    function ascb_normalize_suffix_position($v) {
        $v = strtolower(trim((string) $v));
        return in_array($v, array('first_name', 'surname'), true) ? $v : 'separate';
    }
}

if (!function_exists('ascb_name_print_parts')) {
    /* Ibinabalik ang mga bahagi ng pangalan AS PRINTED (may suffix na
       nakakabit sa tamang field). Hindi ito binabago sa database. */
    function ascb_name_print_parts($surname, $first, $middle, $suffix = '', $position = 'separate') {
        $surname = trim((string) $surname);
        $first   = trim((string) $first);
        $middle  = trim((string) $middle);
        $suffix  = trim((string) $suffix);
        $position = ascb_normalize_suffix_position($position);
        $tail = '';
        if ($suffix !== '') {
            if ($position === 'first_name') {
                $first = trim($first . ' ' . $suffix);
            } elseif ($position === 'surname') {
                $surname = trim($surname . ' ' . $suffix);
            } else {
                $tail = $suffix;
            }
        }
        return array('surname' => $surname, 'first_name' => $first, 'middle_name' => $middle, 'suffix_tail' => $tail);
    }
}

if (!function_exists('ascb_name_print')) {
    /* "Surname, First Middle" ayon sa PSA placement ng suffix. */
    function ascb_name_print($surname, $first, $middle, $suffix = '', $position = 'separate') {
        $p = ascb_name_print_parts($surname, $first, $middle, $suffix, $position);
        $given = trim($p['first_name'] . ' ' . $p['middle_name']);
        $name = $p['surname'];
        if ($given !== '') $name .= ($name !== '' ? ', ' : '') . $given;
        if ($p['suffix_tail'] !== '') $name .= ' ' . $p['suffix_tail'];
        return $name;
    }
}

if (!function_exists('ascb_validate_suffix')) {
    /* Ibinabalik ang malinis na suffix, o null kung invalid (gaya ng
       rule sa Master Record: letters, numbers, period lang). */
    function ascb_validate_suffix($v) {
        $v = trim(preg_replace('/\s+/u', ' ', (string) $v));
        if ($v === '') return '';
        if (function_exists('mb_strlen') ? mb_strlen($v, 'UTF-8') > 20 : strlen($v) > 20) return null;
        if (!preg_match('/^[\p{L}\p{N}.\s]+$/u', $v)) return null;
        return $v;
    }
}

if (!function_exists('ascb_column_exists')) {
    /* Cached na check kung may column na sa table (para gumana ang code
       kahit hindi pa napapatakbo ang suffix migration). */
    function ascb_column_exists($pdo, $table, $column) {
        static $cache = array();
        $key = $table . '.' . $column;
        if (isset($cache[$key])) return $cache[$key];
        try {
            $st = $pdo->prepare("SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1");
            $st->execute(array($table, $column));
            $cache[$key] = (bool) $st->fetchColumn();
        } catch (Exception $e) {
            $cache[$key] = false;
        }
        return $cache[$key];
    }
}

if (!function_exists('ascb_suffix_sql_cols')) {
    /* ", e.suffix, e.suffix_position" kapag naka-install na ang migration,
       kung hindi ay walang laman (para hindi mag-error ang mga query). */
    function ascb_suffix_sql_cols($pdo, $alias = 'e') {
        return (ascb_column_exists($pdo, 'enrollees', 'suffix') && ascb_column_exists($pdo, 'enrollees', 'suffix_position'))
            ? ', ' . $alias . '.suffix, ' . $alias . '.suffix_position'
            : '';
    }
}

if (!function_exists('ascb_master_suffix_map')) {
    /* (fix) Ang Master Record ang source of truth ng Suffix + PSA placement.
       Ang exports ay nagbabasa ng enrollees (snapshot bawat term) na maaaring
       luma, kaya kinukuha rito ang CURRENT suffix ng lahat ng estudyanteng may
       suffix sa student_master (maliit lang ang set) - isang query bawat
       request. Ibinabalik: array(student_id => array(suffix, position)). */
    function ascb_master_suffix_map($db = null, $refresh = false) {
        static $map = null;
        if ($refresh) $map = null;
        if ($map !== null) return $map;
        $map = array();
        if ($db === null && isset($GLOBALS['pdo'])) $db = $GLOBALS['pdo'];
        if (!$db) { $map = null; return array(); }
        try {
            if (!ascb_column_exists($db, 'student_master', 'suffix')) return $map;
            $hasPos = ascb_column_exists($db, 'student_master', 'suffix_position');
            $q = $db->query("SELECT student_id, suffix" . ($hasPos ? ", suffix_position" : "") . " FROM student_master WHERE suffix IS NOT NULL AND TRIM(suffix) <> ''");
            foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $map[(string) $r['student_id']] = array(
                    trim((string) $r['suffix']),
                    ascb_normalize_suffix_position($hasPos ? $r['suffix_position'] : 'separate'),
                );
            }
        } catch (Exception $e) {
            error_log('ASCB master suffix map failed: ' . $e->getMessage());
        }
        return $map;
    }
}

if (!function_exists('ascb_row_master_suffix')) {
    /* Palitan ang suffix / suffix_position ng isang enrollment row ng CURRENT
       nasa Master Record (kung may suffix ang master). Kung walang suffix ang
       master, hindi ginagalaw ang row. */
    function ascb_row_master_suffix($row) {
        if (!is_array($row) || empty($row['student_id'])) return $row;
        $map = ascb_master_suffix_map();
        $sid = (string) $row['student_id'];
        if (isset($map[$sid])) {
            $row['suffix'] = $map[$sid][0];
            $row['suffix_position'] = $map[$sid][1];
        }
        return $row;
    }
}

if (!function_exists('ascb_row_print_split')) {
    /* Para sa mga output na hiwalay ang Surname / Given / Middle na column
       (Excel/CSV exports, Grade Management). Ang suffix ay inilalagay ayon
       sa PSA placement; kung 'separate', idinudugtong ito sa dulo ng
       pangalan (middle name, o given name kung walang middle) para hindi
       magbago ang sequence ng buong pangalan at hindi mabago ang format ng
       file. Ibinabalik ang row na may raw_surname / raw_first_name /
       raw_middle_name para sa mga kailangan ang orihinal. */
    function ascb_row_print_split($row) {
        $row = ascb_row_master_suffix($row); /* (fix) CURRENT suffix + placement mula sa Master Record */
        $sfx = isset($row['suffix']) ? trim((string) $row['suffix']) : '';
        if ($sfx === '') return $row;
        $p = ascb_name_print_parts(
            isset($row['surname']) ? $row['surname'] : '',
            isset($row['first_name']) ? $row['first_name'] : '',
            isset($row['middle_name']) ? $row['middle_name'] : '',
            $sfx,
            isset($row['suffix_position']) ? $row['suffix_position'] : 'separate'
        );
        $row['raw_surname']     = isset($row['surname']) ? $row['surname'] : '';
        $row['raw_first_name']  = isset($row['first_name']) ? $row['first_name'] : '';
        $row['raw_middle_name'] = isset($row['middle_name']) ? $row['middle_name'] : '';
        $row['surname']     = $p['surname'];
        $row['first_name']  = $p['first_name'];
        $row['middle_name'] = $p['middle_name'];
        if ($p['suffix_tail'] !== '') {
            if ($row['middle_name'] !== '') $row['middle_name'] .= ' ' . $p['suffix_tail'];
            else $row['first_name'] .= ' ' . $p['suffix_tail'];
        }
        return $row;
    }
}
