<?php
/* =========================================================
   STUDENT PORTAL — HELPERS (READ-ONLY)
   ========================================================= */
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/master_record_helper.php';

/* ACCOUNT <-> STUDENT ID LINKING */

if (!function_exists('ascb_student_clean_id')) {
    function ascb_student_clean_id($value) {
        $value = trim(preg_replace('/\s+/u', ' ', (string) $value));
        if ($value === '' || strlen($value) > 50) return '';
        if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9\-_\/\. ]*$/', $value)) return '';
        return $value;
    }
}

if (!function_exists('ascb_student_canonical_id')) {
    function ascb_student_canonical_id($pdo, $input) {
        $clean = ascb_student_clean_id($input);
        if ($clean === '') return null;

        if (ascb_master_available($pdo)) {
            $q = $pdo->prepare(
                "SELECT student_id FROM student_master
                 WHERE UPPER(TRIM(student_id)) = UPPER(?) LIMIT 1"
            );
            $q->execute(array($clean));
            $v = $q->fetchColumn();
            if ($v !== false && trim((string) $v) !== '') {
                return trim((string) $v);
            }
        }

        $q = $pdo->prepare(
            "SELECT student_id FROM enrollees
             WHERE UPPER(TRIM(student_id)) = UPPER(?)
             ORDER BY id DESC LIMIT 1"
        );
        $q->execute(array($clean));
        $v = $q->fetchColumn();

        if ($v !== false && trim((string) $v) !== '') {
            return trim((string) $v);
        }

        return null;
    }
}

if (!function_exists('ascb_student_id_taken_by')) {
    function ascb_student_id_taken_by($pdo, $studentId, $excludeUserId = 0) {
        $q = $pdo->prepare(
            "SELECT display_name FROM users
             WHERE UPPER(TRIM(student_id)) = UPPER(TRIM(?))
             AND id <> ? LIMIT 1"
        );
        $q->execute(array($studentId, (int) $excludeUserId));
        $v = $q->fetchColumn();

        return ($v === false) ? null : (string) $v;
    }
}

/* GRADE -> DISPLAY / REMARKS / STATUS */

if (!function_exists('ascb_student_grade_display')) {
    function ascb_student_grade_display($grade) {
        $g = trim((string) $grade);
        if ($g === '') return '—';
        return ascb_normalize_grade($g);
    }
}

if (!function_exists('ascb_student_grade_remarks')) {
    function ascb_student_grade_remarks($grade) {
        $g = trim((string) $grade);

        if ($g === '' || (is_numeric($g) && (float) $g == 0.0)) {
            return array('NOT YET GRADED', 'Enrolled');
        }

        if (preg_match('/^(DRP|DR\.?)$/i', $g)) {
            return array('DROPPED', 'Dropped');
        }

        if (preg_match('/^INC$/i', $g)) {
            return array('INCOMPLETE', 'Incomplete');
        }

        if (preg_match('/^NG$/i', $g)) {
            return array('NO GRADE', 'No Grade');
        }

        if (preg_match('/^(P|PASSED)$/i', $g)) {
            return array('PASSED', 'Completed');
        }

        if (preg_match('/^[-–—]$/u', $g)) {
            return array('—', 'Completed');
        }

        if (is_numeric($g)) {
            return ascb_grade_is_failing($g)
                ? array('FAILED', 'Failed')
                : array('PASSED', 'Completed');
        }

        return array('—', 'Enrolled');
    }
}

/* ACADEMIC YEAR / TRIMESTER SORTING */

if (!function_exists('ascb_student_term_rank')) {
    function ascb_student_term_rank($trimester) {
        $t = trim((string) $trimester);
        if ($t !== '' && ctype_digit($t[0])) return (int) $t[0];
        return 9;
    }
}

if (!function_exists('ascb_student_sy_start')) {
    function ascb_student_sy_start($schoolYear) {
        if (preg_match('/(\d{4})/', (string) $schoolYear, $m)) {
            return (int) $m[1];
        }
        return 0;
    }
}

/* GWA */

if (!function_exists('ascb_student_gwa_grade')) {
    function ascb_student_gwa_grade($grade) {
        $g = trim((string) $grade);
        if ($g === '' || !is_numeric($g)) return null;

        $v = (float) $g;
        return $v > 0 ? $v : null;
    }
}

if (!function_exists('ascb_student_gwa_value')) {
    function ascb_student_gwa_value($weightedSum, $gradedUnits) {
        if ($gradedUnits <= 0) return null;
        return round($weightedSum / $gradedUnits, 2);
    }
}

/* CLEAN COURSE / MAJOR */

if (!function_exists('ascb_student_clean_course_major')) {
    function ascb_student_clean_course_major($course, $major) {
        $course = trim(preg_replace('/\s+/u', ' ', (string) $course));
        $major  = trim(preg_replace('/\s+/u', ' ', (string) $major));

        if (
            $course !== '' &&
            preg_match('/^(.*?)[\s,\-–—]*\bmajor(?:ing)?\s+in\s+(.+)$/iu', $course, $m) &&
            trim($m[1]) !== ''
        ) {
            $course = trim($m[1]);
            if ($major === '') $major = trim($m[2]);
        }

        if ($course !== '' && $major !== '') {
            $q = preg_quote($major, '/');

            if (
                preg_match('/^(.*?)[\s,:\-–—]+' . $q . '\s*$/iu', $course, $m) &&
                trim($m[1]) !== ''
            ) {
                $course = trim($m[1]);
            }
        }

        return array($course, $major);
    }
}

/* STUDENT PROFILE */

if (!function_exists('ascb_student_portal_profile')) {
    function ascb_student_portal_profile($pdo, $studentId) {
        $name = '';
        $master = ascb_master_current($pdo, $studentId);

        if ($master) {
            $name = ascb_name_print(
                $master['surname'],
                $master['first_name'],
                $master['middle_name'],
                isset($master['suffix']) ? $master['suffix'] : '',
                isset($master['suffix_position'])
                    ? $master['suffix_position']
                    : 'separate'
            );
        }

        $q = $pdo->prepare(
            "SELECT surname, first_name, middle_name, program_code,
                    course, major, year_level
             FROM enrollees
             WHERE UPPER(TRIM(student_id)) = UPPER(TRIM(?))
               AND archived_at IS NULL
               AND status = 'approved'
             ORDER BY id DESC LIMIT 1"
        );
        $q->execute(array($studentId));
        $latest = $q->fetch();

        if ($name === '' && $latest) {
            $name = ascb_name_print(
                $latest['surname'],
                $latest['first_name'],
                $latest['middle_name']
            );
        }

        $pCourse = '';
        $pMajor = '';

        if ($latest) {
            list($pCourse, $pMajor) = ascb_student_clean_course_major(
                ($latest['course'] !== null && $latest['course'] !== '')
                    ? $latest['course']
                    : $latest['program_code'],
                $latest['major']
            );
        }

        return array(
            'studentId' => $studentId,
            'name'      => $name,
            'program'   => $pCourse,
            'major'     => $pMajor,
            'yearLevel' => $latest
                ? trim((string) $latest['year_level'])
                : '',
        );
    }
}

/* PROGRAM LABEL */

if (!function_exists('ascb_student_program_label')) {
    function ascb_student_program_label($r) {
        list($c, $m) = ascb_student_clean_course_major(
            ($r['course'] !== null && $r['course'] !== '')
                ? $r['course']
                : $r['program_code'],
            isset($r['major']) ? $r['major'] : ''
        );

        return $m !== '' ? ($c . ' — ' . $m) : $c;
    }
}

/* STUDENT PORTAL RECORDS */

if (!function_exists('ascb_student_portal_records')) {
    function ascb_student_portal_records($pdo, $studentId) {
        $sql = "SELECT
                    e.id AS enrollment_id,
                    e.school_year,
                    e.trimester,
                    e.year_level,
                    e.program_code,
                    e.course,
                    e.major,
                    es.id AS enrollment_subject_id,
                    es.course_code,
                    es.description,
                    es.units,
                    es.hidden_on_print,
                    g.grade
                FROM enrollees e
                LEFT JOIN enrollment_subjects es
                    ON es.enrollment_id = e.id
                LEFT JOIN grades g
                    ON g.enrollment_subject_id = es.id
                WHERE UPPER(TRIM(e.student_id)) = UPPER(TRIM(?))
                  AND e.archived_at IS NULL
                  AND e.status = 'approved'
                ORDER BY e.id ASC, es.id ASC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute(array($studentId));

        $terms = array();
        $hasHiddenSubjects = false;

        foreach ($stmt->fetchAll() as $r) {
            $eid = (int) $r['enrollment_id'];

            if (!isset($terms[$eid])) {
                $terms[$eid] = array(
                    'schoolYear'  => trim((string) $r['school_year']),
                    'trimester'   => trim((string) $r['trimester']),
                    'yearLevel'   => trim((string) $r['year_level']),
                    'program'     => ascb_student_program_label($r),
                    'subjects'    => array(),
                    'totalUnits'  => 0.0,
                    'gradedUnits' => 0.0,
                    '_ws'         => 0.0,
                );
            }

            if ($r['enrollment_subject_id'] === null) {
                continue;
            }

            $isHidden = (int) $r['hidden_on_print'] === 1;

            if ($isHidden) {
                $hasHiddenSubjects = true;
            }

            $rem = ascb_student_grade_remarks($r['grade']);
            $units = (float) $r['units'];

            $terms[$eid]['subjects'][] = array(
                'courseCode'  => (string) $r['course_code'],
                'description' => (string) $r['description'],
                'units'       => $units,

                /*
                 * UPDATED:
                 * Hidden grade = asterisk.
                 * Visible grade = actual normalized grade.
                 * The actual hidden grade is never sent to the student.
                 */
                'grade' => $isHidden
                    ? 'Hidden'
                    : ascb_student_grade_display($r['grade']),

                /* Huwag ibunyag ang remarks kapag naka-hide. */
                'remarks' => $isHidden ? '—' : $rem[0],

                /* Nananatiling Enrolled ang status kapag hidden. */
                'status' => $isHidden ? 'Enrolled' : $rem[1],
            );

            /*
             * Hindi isasama sa totals at GWA ang hidden subject,
             * ayon sa kasalukuyang behavior ng system.
             */
            if ($isHidden) {
                continue;
            }

            $terms[$eid]['totalUnits'] += $units;

            $gv = ascb_student_gwa_grade($r['grade']);

            if ($gv !== null && $units > 0) {
                $terms[$eid]['_ws'] += $gv * $units;
                $terms[$eid]['gradedUnits'] += $units;
            }
        }

        /* Academic Year: pinakabago muna. */
        $byYear = array();

        foreach ($terms as $t) {
            $byYear[$t['schoolYear']][] = $t;
        }

        $years = array_keys($byYear);

        usort($years, function ($a, $b) {
            $d = ascb_student_sy_start($b) - ascb_student_sy_start($a);
            return $d !== 0 ? $d : strcmp((string) $b, (string) $a);
        });

        $out = array();
        $allWs = 0.0;
        $allGraded = 0.0;
        $allTotal = 0.0;

        foreach ($years as $sy) {
            $list = $byYear[$sy];

            usort($list, function ($a, $b) {
                $d = ascb_student_term_rank($a['trimester'])
                    - ascb_student_term_rank($b['trimester']);

                return $d !== 0
                    ? $d
                    : strcmp($a['trimester'], $b['trimester']);
            });

            $ayWs = 0.0;
            $ayGraded = 0.0;

            foreach ($list as $i => $t) {
                $ayWs += $t['_ws'];
                $ayGraded += $t['gradedUnits'];
                $allTotal += $t['totalUnits'];

                $list[$i]['gwa'] = ascb_student_gwa_value(
                    $t['_ws'],
                    $t['gradedUnits']
                );

                unset($list[$i]['_ws']);
            }

            $allWs += $ayWs;
            $allGraded += $ayGraded;

            $out[] = array(
                'schoolYear'  => $sy,
                'gwa'         => ascb_student_gwa_value($ayWs, $ayGraded),
                'gradedUnits' => $ayGraded,
                'terms'       => $list,
            );
        }

        return array(
            'academicYears' => $out,
            'hasHiddenSubjects' => $hasHiddenSubjects,
            'overall' => array(
                'gwa'         => ascb_student_gwa_value($allWs, $allGraded),
                'gradedUnits' => $allGraded,
                'totalUnits'  => $allTotal,
            ),
        );
    }
}